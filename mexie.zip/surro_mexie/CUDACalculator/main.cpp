#include <stdio.h>
#include <stdlib.h>

#include "HuxleyCalculatorCudaCustom.h"
#include "HuxleyCalculatorCudaParam.h"
//#include "HuxleyCalculatorCudaThrust.h"

int main(int argc, char **argv)
{
    HuxleyCalculatorCudaCustom *hux = new HuxleyCalculatorCudaCustom();
    HuxleyCalculatorCudaParam *param_hux = new HuxleyCalculatorCudaParam();

    HuxleyParameters* p;
	printf("prolaz 1\n");	 
    p = new HuxleyParameters();
//    HuxleyCalculatorCuda hux(1,&p);

    p->InputData();
    printf("m1: %f  dt: %f\n", p->m_f1,p->m_dt);
    printf("g1: %f  g2: %f\n", p->m_g1, p->m_g2);
    hux->Initialize(1, p);


    printf("Pre inicijalizacije\n");
    param_hux->Initialize(1, p);
    printf("Posle inicijalizacije\n");
	
	//hux.Initialize(1);

	printf("test test \n");

//    FILE *k = fopen("posle_prvog.csv", "w");
//	FILE *u = fopen("dva_puta.csv", "w");
	std::vector<float> def(1);
	std::vector<float> pp_f1(1);
	std::vector<float> pp_g1(1);
	std::vector<float> pp_g2(1);

    std::vector<float> temp_X, temp_N;

    pp_f1[0] = p->m_f1;
    pp_g1[0] = p->m_g1;
    pp_g2[0] = p->m_g2;

    printf("Podesio sam parametre samo van!\n");

    param_hux->Set_m_f1(pp_f1);
    param_hux->Set_m_g1(pp_g1);
    param_hux->Set_m_g2(pp_g2);
    

    printf("Podesio parametre unutar klase.\n");

	int i;
	def[0] = 0.0f;
	hux->Calculate(def, 0.005f);

    hux->SetToNew(0);
	


    printf("Pre pozivanja Calculate\n");

    param_hux->Calculate(def, 0.005f);

    printf("Pre pozivanja SetToNew\n");
    param_hux->SetToNew(0);

//	temp_X = hux.Get_X(0);
//	temp_N = hux.Get_N(0);
	
    hux->Get_X(0,temp_X);
    hux->Get_N(0,temp_N);
	for(i = 0; i < 8000; i++)
	{
//		fprintf(k, "%f, %f \n", temp_X[i], temp_N[i]);
	}
//	fclose(k);

    //printf("GetForce: %.10f\n", hux.getForce(0, 1.25f));

    printf("GetForce: %.10f\n", hux->getForce(0));
    printf("GetForce param: %.10f\n", param_hux->getForce(0));
	/*	
	hux.Calculate(def, 0.005f);
	hux.SetToNew(0);
	
	temp_X = hux.Get_X(0);
	temp_N = hux.Get_N(0);

	for(i = 0; i < 8000; i++)
	{
		fprintf(u, "%f, %f \n", temp_X[i], temp_N[i]);	
	}
	fclose(u);

	printf("GetForce: %f\n", hux.getForce(0, 1.25f));
	*/

}
