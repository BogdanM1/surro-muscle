/*!
 * \file OutVector.cpp
 * Implementation of the COutVector class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// OutVector.cpp: implementation of the COutVector class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "OutVector.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//IMPLEMENT_SERIAL(COutVector,CObject,VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
COutVector::COutVector()
{
	for(UINT i=0;i<20;i++) m_Comp[i]=0;
	m_bCalc_warn = FALSE;
	m_bCent_total = FALSE;

	m_dMin_val = m_dMax_val = 0.0;
}

/*!
 * Destructor.
 */
COutVector::~COutVector()
{

}

/*!
 * Equalizes two objects of the COutVector class.
 * 
 * \param[in] other
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
COutVector& COutVector::operator =(const COutVector &other)
{
	m_nSetID=other.m_nSetID;
	m_nID=other.m_nID;

	m_sTitle=other.m_sTitle;
	m_dMin_val=other.m_dMin_val;
	m_dMax_val=other.m_dMax_val;
	m_dAbs_max=other.m_dAbs_max;

	for(UINT i=0;i<20;i++) m_Comp[i]=other.m_Comp[i];

	m_nID_min=other.m_nID_min;
	m_nID_max=other.m_nID_max;
	m_nOut_type=other.m_nOut_type;
	m_nEnt_type=other.m_nEnt_type;
	m_bCalc_warn=other.m_bCalc_warn;

	m_nComp_dir=other.m_nComp_dir;
	m_bCent_total=other.m_bCent_total;


	m_Values.RemoveAll();
	//m_Values.InitHashTable(other.m_Values.GetHashTableSize());
	map<UINT,double>::const_iterator pos=other.m_Values.GetStartPosition();
	UINT    key;
	double val;
	while (pos != other.m_Values.end())
	{
		other.m_Values.GetNextAssoc( pos, key, val );
		m_Values.SetAt(key,val);
    }

	return *this;
}

///*!
// * Serializes object of the COutVector class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void COutVector::Serialize(CArchive& ar)
//{
//	UINT i;
//
//	if (ar.IsStoring())
//	{
//		ar << m_nSetID;
//		ar << m_nID;
//
//		ar << m_sTitle;
//		ar << m_dMin_val;
//		ar << m_dMax_val;
//		ar << m_dAbs_max;
//
//		for(i=0;i<20;i++) 
//			ar << m_Comp[i];
//
//		ar << m_nID_min;
//		ar << m_nID_max;
//		ar << m_nOut_type;
//		ar << m_nEnt_type;
//		ar << m_bCalc_warn;
//
//		ar << m_nComp_dir;
//		ar << m_bCent_total;
//
///*		UINT ValCount=m_Values.GetCount();
//		ar << ValCount;
//
//		POSITION pos=m_Values.GetStartPosition();
//		UINT    key;
//		double val;
//		while (pos != NULL)
//		{
//			m_Values.GetNextAssoc( pos, key, val );
//			ar << key;
//			ar << val;
//		}
//*/
//	}
//	else
//	{
//		ar >> m_nSetID;
//		ar >> m_nID;
//
//		ar >> m_sTitle;
//		ar >> m_dMin_val;
//		ar >> m_dMax_val;
//		ar >> m_dAbs_max;
//
//		for(i=0;i<20;i++) 
//			ar >> m_Comp[i];
//
//		ar >> m_nID_min;
//		ar >> m_nID_max;
//		ar >> m_nOut_type;
//		ar >> m_nEnt_type;
//		ar >> m_bCalc_warn;
//
//		ar >> m_nComp_dir;
//		ar >> m_bCent_total;
//
///*		UINT ValCount;
//		ar >> ValCount;
//
//		m_Values.RemoveAll();
//		UINT    key;
//		double val;
//		for(i=0;i<ValCount;i++)
//		{
//			ar >> key;
//			ar >> val;
//			m_Values.SetAt(key,val);
//		}
//*/
//	}
//
//	m_Values.Serialize(ar);
//}

/*!
 * Sets value for the specified node or element.
 * 
 * \param[in] ID
 * ID of the node or element.
 * 
 * \param[in] val
 * Value for the specified node or element.
 * 
 * \returns
 * Zero if successful.
 */
UINT COutVector::SetValue(UINT ID, double val)
{
	UINT Count=m_Values.GetCount();

	m_Values.SetAt(ID,val);

	if(val<m_dMin_val || Count==0)
	{
		m_dMin_val=val;
		m_nID_min=ID;
	}
	if(val>m_dMax_val || Count==0)
	{
		m_dMax_val=val;
		m_nID_max=ID;
	}
	if(fabs(val)>m_dAbs_max || Count==0)
	{
		m_dAbs_max=fabs(val);
	}

	return(0);
}

/*!
 * Recalculates minimal and maximal values in the vector.
 * 
 * \returns
 * Zero if successful.
 */
void COutVector::RecalculateMinMax()
{
	UINT   nID;
	double dValue;

	//Assume the first element is minimum and maximum
	map<UINT,double>::const_iterator pos=m_Values.GetStartPosition();
	if( pos != m_Values.end())
	{
		m_Values.GetNextAssoc( pos, nID, dValue );

		m_dMin_val = dValue;
		m_nID_min = nID;

		m_dMax_val = dValue;
		m_nID_max = nID;

		m_dAbs_max=fabs(dValue);
	}

	//Search for better solution
	while (pos != m_Values.end())
	{
		m_Values.GetNextAssoc( pos, nID, dValue );

		if( dValue < m_dMin_val )
		{
			m_dMin_val = dValue;
			m_nID_min = nID;
		}
		if( dValue > m_dMax_val )
		{
			m_dMax_val = dValue;
			m_nID_max = nID;
		}
		if( fabs(dValue)>m_dAbs_max )
		{
			m_dAbs_max=fabs(dValue);
		}
    }
}

/*!
 * Gets number of components of the output vector.
 * 
 * \returns
 * Number of components of the output vector.
 */
UINT COutVector::GetComponentCount()
{
	UINT nComponentCount = 0;

	if( (UINT)m_Comp[0] != m_nID )
	{
		while( m_Comp[nComponentCount] != 0 )
		{
			nComponentCount++;
		}
	}

	return(nComponentCount);
}
