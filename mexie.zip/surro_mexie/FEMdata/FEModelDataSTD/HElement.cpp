/*!
 * \file HElement.cpp
 * Implementation of the HElement class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HElement.cpp: implementation of the HElement class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "Femcon.h"
#include "HElement.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//IMPLEMENT_SERIAL(HElement,HDataBlock, VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
HElement::HElement()
{
	m_nID=0;
	m_uLayer=0;
	m_uOrientID=0;
	m_uPropID=0;
	m_uTopology=0;
	m_uType=0;
	m_uColor=0;
	int i;
	for (i=0;i<21;i++)
		m_uNode[i]=0;
	for (i=0;i<3;i++)
	{
		m_dOrient[i]=0.;
		m_dOffset1[i]=0.;
		m_dOffset2[i]=0.;
	}
	for (i=0;i<6;i++)
	{
		m_bRelease1[i]=false;
		m_bRelease2[i]=false;
	}
}

/*!
 * Copy constructor.
 */
HElement::HElement(const HElement& rc)
{

	(*this)=rc;
}


/*!
 * Destructor.
 */
HElement::~HElement()
{
}

/*!
 * Equalizes two objects of the HElement class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
HElement& HElement::operator = (const HElement& rp)
{
	*((HDataBlock*)this) = rp;

	m_uDataBlockID=rp.m_uDataBlockID;	
	m_nID=rp.m_nID;
	m_uColor=rp.m_uColor;
	m_uPropID=rp.m_uPropID;
	m_uType=rp.m_uType;
	m_uTopology=rp.m_uTopology;
	m_uLayer=rp.m_uLayer;
	m_uOrientID=rp.m_uOrientID; 
	m_bMatl_orflag=rp.m_bMatl_orflag;// Material orientation flag
	int i;
	for (i=0;i<21;i++)
		m_uNode[i]=rp.m_uNode[i];
	for (i=0;i<3;i++)
		m_dOrient[i]=rp.m_dOrient[i];
	for (i=0;i<3;i++)
		m_dOffset1[i]=rp.m_dOffset1[i];
	for (i=0;i<3;i++)
		m_dOffset2[i]=rp.m_dOffset2[i];
	for (i=0;i<6;i++)
		m_bRelease1[i]=rp.m_bRelease1[i];
	for (i=0;i<6;i++)
		m_bRelease2[i]=rp.m_bRelease2[i];

	m_NodeList.RemoveAll();
	m_NodeList.Copy(rp.m_NodeList);

	return *this;
}

///*!
// * serializes object of the HElement class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void HElement::Serialize(CArchive& ar)
//{
//	int i;
//	if (ar.IsStoring())
//	{
//		ar << m_uDataBlockID;	
//		ar << m_nID;
//		ar << m_uColor;
//		ar << m_uPropID;
//		ar << m_uType;
//		ar << m_uTopology;
//		ar << m_uLayer;
//		ar << m_uOrientID; 
//		ar << m_bMatl_orflag;// Material orientation flag
//		for (i=0;i<21;i++)
//			ar << m_uNode[i];
//		for (i=0;i<3;i++)
//			ar << m_dOrient[i];
//		for (i=0;i<3;i++)
//			ar << m_dOffset1[i];
//		for (i=0;i<3;i++)
//			ar << m_dOffset2[i];
//		for (i=0;i<6;i++)
//			ar << m_bRelease1[i];
//		for (i=0;i<6;i++)
//			ar << m_bRelease2[i];
//	}
//	else
//	{
//		ar >> m_uDataBlockID;
//		ar >> m_nID;
//		ar >> m_uColor;
//		ar >> m_uPropID;
//		ar >> m_uType;
//		ar >> m_uTopology;
//		ar >> m_uLayer;
//		ar >> m_uOrientID; 
//		ar >> m_bMatl_orflag;
//		for (i=0;i<21;i++)
//			ar >> m_uNode[i];
//		for (i=0;i<3;i++)
//			ar >> m_dOrient[i];
//		for (i=0;i<3;i++)
//			ar >> m_dOffset1[i];
//		for (i=0;i<3;i++)
//			ar >> m_dOffset2[i];
//		for (i=0;i<6;i++)
//		{
//			ar >> m_bRelease1[i];
//		}
//		for (i=0;i<6;i++)
//		{
//			ar >> m_bRelease2[i];
//		}
//
//	}
//
//	m_NodeList.Serialize(ar);
//}




