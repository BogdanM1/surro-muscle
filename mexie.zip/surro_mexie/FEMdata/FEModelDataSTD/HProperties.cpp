/*!
 * \file HProperties.cpp
 * Implementation of the HProperties class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HProperties.cpp: implementation of the HProperties class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "Femcon.h"
#include "HProperties.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL(HProperties,HDataBlock, VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
HProperties::HProperties()
{
	Init();
}

/*!
 * Copy contructor.
 */
HProperties::HProperties(const HProperties & rc)
{
	Init();
	(*this)=rc;
}


/*!
 * Destructor.
 */
HProperties::~HProperties()
{

}

/*!
 * Equalizes two objects of the HProperties class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
HProperties& HProperties::operator =(const HProperties & rp)
{
	m_uDataBlockID=rp.m_uDataBlockID;
	m_nID=rp.m_nID;
	m_uColor=rp.m_uColor;	
	m_uMatIID=rp.m_uMatIID;
	m_Type=rp.m_Type;
	m_uLayer=rp.m_uLayer;
	m_uRefCS=rp.m_uRefCS;// Reference coordinate system
	m_strTitle=rp.m_strTitle;
	for (int i=0;i<4;i++)
		m_uFlag[i]=rp.m_uFlag[i];
	
	m_uLam_MID.RemoveAll();
	m_uLam_MID.Copy(rp.m_uLam_MID);

	//m_uNum_val=rp.m_uNum_val;
	//m_dValue.SetSize(m_uNum_val);

	m_dValue.RemoveAll();
	m_dValue.Copy(rp.m_dValue);

	m_AnalysisType = rp.m_AnalysisType;
	m_IncompatibleModes = rp.m_IncompatibleModes;
	m_PrintStressShell = rp.m_PrintStressShell;

	return *this;
}

///*!
// * Serializes object of the HProperties class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void HProperties::Serialize(CArchive& ar)
//{
//
//	UINT i;
//	if (ar.IsStoring())
//	{
//		ar << m_uDataBlockID;
//		ar << m_nID;
//		ar << m_uColor;	
//		ar << m_uMatIID;
//		ar << m_Type;
//		ar << m_uLayer;
//		ar << m_uRefCS;// Reference coordinate system
//		ar << m_strTitle;
//		for (i=0;i<4;i++)
//			ar << m_uFlag[i];
//
//		ar << m_AnalysisType;
//		ar << m_IncompatibleModes;
//		ar << m_PrintStressShell;
//	}
//	else
//	{
//		ar >> m_uDataBlockID;
//		ar >> m_nID;
//		ar >> m_uColor;	
//		ar >> m_uMatIID;
//
//		UINT nType;
//		ar >> nType;
//		m_Type = (HProperties::TPropertyType)nType;
//
//		ar >> m_uLayer;
//		ar >> m_uRefCS;// Reference coordinate system
//		ar >> m_strTitle;
//		for (i=0;i<4;i++)
//			ar >> m_uFlag[i];
//
//		int nAnalysisType;
//		ar >> nAnalysisType;
//		m_AnalysisType = (TAnalysisType) nAnalysisType;
//
//		int nIncompatibleModes;
//		ar >> nIncompatibleModes;
//		m_IncompatibleModes = (TIncompatibleModes) m_IncompatibleModes;
//
//		int nPrintStressShell;
//		ar >> nPrintStressShell;
//		m_PrintStressShell = (TPrintStressShell) m_PrintStressShell;
//	}
//
//	m_uLam_MID.Serialize(ar);
//	m_dValue.Serialize(ar);
//}

/*!
 * Initializes property.
 */
void HProperties::Init()
{
	//m_uNum_lam=0;
	//m_uNum_val=0;

	m_AnalysisType = AT_LINEAR;
	m_IncompatibleModes = IM_NOT_USED;

	m_PrintStressShell = PSS_PRINTED_IN_LOCAL_SYSTEM;
}
