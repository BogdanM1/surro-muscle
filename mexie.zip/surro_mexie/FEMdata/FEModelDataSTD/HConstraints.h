/*!
 * \file HConstraints.h
 * Interface for the HConstraints class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HConstraints.h: interface for the HConstraints class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HCONSTRAINTS_H__7D2CD282_6362_11D2_8266_004F4900B9E0__INCLUDED_)
#define AFX_HCONSTRAINTS_H__7D2CD282_6362_11D2_8266_004F4900B9E0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "HDataBlock.h"
#include "HNodes.h"
#include "MyString.h"
#include "MyArray.h"

/** Class representing nodal constraint. */
class ConsNode //: public CObject
{
public:
	ConsNode& operator =(const ConsNode& rc);
	ConsNode(const ConsNode& rc);
	ConsNode();
	~ConsNode();
	/// ID of the node where constraint is applied
	UINT m_uNodeID;
	/// Color of the nodal constraint
	UINT m_uColor;
	/// Layer of the nodal constraint
	UINT m_uLayer;

	/// Array of indicators of selected degrees of freedom
	bool m_bDOF[HNODES_MAX_DOF_COUNT];
};

	struct EqCoeff
	{
		/// ID of the node
		UINT m_uEqn_nodeID;
		/// Degree of freedom
		UINT m_uEqn_dof;
		/// Equation coefficient
		double m_dCoeff;
	};

/** Class representing nodal equation. */
class ConsEq //:public CObject
{
public:
	ConsEq ();
	ConsEq (const ConsEq& rc);
	~ConsEq ();
	ConsEq& operator = (const ConsEq& rc);
	/// ID of the equation
	UINT m_uEqnID;
	/// Color of the equation
	UINT m_uColor;
	/// Layer of the equation
	UINT m_uLayer;
	/// Collection of equation coeficients
	MyArray<EqCoeff,EqCoeff> m_EqCoefs;	
};

/** Class representing constraint set. */
class HConstraints : public HDataBlock  
{
public:
	void Init();
	void GetGlobalConstraints(bool GlobalConstraints[]);
	void SetGlobalConstraints(bool GlobalConstraints[]);

	HConstraints();
	HConstraints (const HConstraints& rc);

	virtual ~HConstraints();

	//DECLARE_SERIAL(HConstraints)
	//void Serialize( CArchive& ar );
	HConstraints& operator =(const HConstraints& rp);

	/// ID of the constraint set
	UINT m_nID;
	/// Title of the constraint set
	MyString m_strTitle;

	/// Collection of node constraints
	MyArray<ConsNode,ConsNode&> m_ConsNodes;
	/// Collection of equation constraints
	MyArray<ConsEq,ConsEq&> m_ConsEqs;

private:
	/// Array of global constraints
	bool m_GlobalConstraints[HNODES_MAX_DOF_COUNT];
};

#endif // !defined(AFX_HCONSTRAINTS_H__7D2CD282_6362_11D2_8266_004F4900B9E0__INCLUDED_)
