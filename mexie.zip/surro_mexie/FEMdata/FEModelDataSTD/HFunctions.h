/*!
 * \file HFunctions.h
 * Interface for the HFunctions class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HFunctions.h: interface for the HFunctions class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HFUNCTIONS_H__342BA6A3_28D7_11D0_84F7_CCED03C10000__INCLUDED_)
#define AFX_HFUNCTIONS_H__342BA6A3_28D7_11D0_84F7_CCED03C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "HDataBlock.h"
#include "MyString.h"
#include "MyArray.h"

class CTimeSteps;

struct FunctionEntry
{
	FunctionEntry()
	{
	};
	FunctionEntry(UINT EntryID, double X, double Y)
	{
		m_uEntryID=EntryID;
		m_dX=X;
		m_dY=Y;
	};

	/// ID of entry (ascending order, must be -1 for last entry)
	UINT m_uEntryID;	
	/// X value of function entry
	double m_dX;
	/// Y value of function entry
	double m_dY;
};

/** Class representing function. */
class HFunctions : public HDataBlock  
{
public:
	bool GetY(double dX, double &dY) const;
	typedef enum
	{
		FT_DIMENSIONLESS =	0,
		FT_VS_TIME =		1,
		FT_VS_TEMP =		2,
		FT_VS_FREQ =		3,
		FT_VS_STRESS =		4,
		FT_FUNC_VS_TEMP =	5,
		FT_STRUCTDAMP_VS_FREQ =		6,
		FT_CRITDAMP_VS_FREQ =		7,
		FT_QDAMP_VS_FREQ =			8,
		FT_VS_STRAINRATE =			9,
		FT_FUNC_VS_STRAINRATE =		10,
		FT_VS_CURVELENGTH =			11,
		FT_VS_CURVEPARAM =			12,
		FT_VS_WATERVOLUME,
		FT_DISPLACEMENT_VS_TIME
	} FunctionType;

	bool GetRange(double &dXmin, double &dXmax, double &dYmin, double &dYmax);
	void ConvertToIncremental(CTimeSteps &TimeSteps, HFunctions &IncFunction);

	HFunctions();
	HFunctions (const HFunctions& rc);

	virtual ~HFunctions();

	//DECLARE_SERIAL(HFunctions)      
	//void Serialize( CArchive& ar );
	HFunctions& operator =(const HFunctions& rp);
	HFunctions operator +(const HFunctions &other);
	HFunctions operator *(double dK);

	/// ID of the function
	UINT m_nID;
	/// Type of the function (0=Dimensionless, 1=vs. Time, 2=vs. Temp)
	FunctionType m_uFunc_type;	
	/// Title of the function
	MyString m_strTitle;
	/// Collection of function points
	MyArray<FunctionEntry,FunctionEntry&> m_FunctionEntry;
};

#endif // !defined(AFX_HFUNCTIONS_H__342BA6A3_28D7_11D0_84F7_CCED03C10000__INCLUDED_)
