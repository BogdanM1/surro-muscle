/*
 * MPIProcess.h
 *
 *  Created on: May 14, 2014
 *      Author: anakaplarevic
 */

#ifndef MPI_H
#define MPI_H

#include <mpi.h>
#include <vector>

#endif /* MPI_H */

#ifndef MPIPROCESS_H_
#define MPIPROCESS_H_
#include "Globals.h"


class MPIProcess {
protected:
	  int mpi_ID;
	  int mpi_SIZE;

//	  int n_q_points_all;	// const   sizeofWORLDchunks

	  int *podela,*dispodela;
	  int *podela3,*dispodela3;
	  int *podela33,*dispodela33;

	  int* tipovi_part;
      std::vector<double> m_E_part;
      std::vector<double> m_ni_part;
      std::vector<double> m_fi_part;
      std::vector<_TIPF1> m_f1_part;

      FILE* velikiLog;
      double *e_part,*sigma_part,*deltasigma_part;

public:
	MPIProcess();
	virtual ~MPIProcess();
	virtual  void run() = 0;

	void timestamp();
	char* createFileName();
    char* createFileName(char* base);
	virtual void createFileForChunk()=0;
};

#endif /* MPIPROCESS_H_ */
