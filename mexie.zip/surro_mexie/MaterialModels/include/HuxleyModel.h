/*
 * HuxleyMaterialModel.h
 *
 *  Created on: Aug 8, 2013
 *      Author: anakaplarevic
 */

#ifndef HUXLEYMODEL_H_
#define HUXLEYMODEL_H_

#include "MaterialModel.h"
#include "HuxleyState.h"
#include "HuxleyParameters.h"
#include "HuxleyCalculator.h"

class HuxleyModel: public MaterialModel {
private:
	HuxleyParameters* _param;
	HuxleyCalculator* _calculator;

public:
	HuxleyModel(HuxleyParameters* param);
	virtual ~HuxleyModel();

	void Calculate(MaterialModelState *state,double *e,double* sigma,double* dsigmade);
	void CalculateStress(_TIP *force,_TIP *forceP,double* e,double* sigma,double* dsigmade);
	MaterialModelParameters* getParameters();
};

#endif /* HUXLEYMATERIALMODEL_H_ */
