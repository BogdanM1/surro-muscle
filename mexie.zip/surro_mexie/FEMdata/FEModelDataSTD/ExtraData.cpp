/*!
 * \file ExtraData.cpp
 * Implementation of the CExtraData class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// ExtraData.cpp: implementation of the CExtraData class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "ExtraData.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*!
 * Default constructor.
 */
CExtraData::CExtraData()
{

}

/*!
 * Destructor
 */
CExtraData::~CExtraData()
{

}
