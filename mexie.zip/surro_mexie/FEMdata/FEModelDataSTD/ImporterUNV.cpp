/*!
 * \file ImporterUNV.cpp
 * Implementation of the CImporterUNV class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// ImporterUNV.cpp: implementation of the CImporterUNV class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "ImporterUNV.h"

#include "FEModelData.h"
#include "EffectiveTranslation.h"
#include "EquivalentVonMisesStress.h"
#include "EquivalentStrain.h"
#include "EffectiveScalar.h"
#include "FileIO.h"
//#include "..\FEMDoc\MeshElem1D.h"
//#include "..\FEMDoc\MeshElem2D.h"
//#include "..\FEMDoc\MeshElem3D.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
const UINT CImporterUNV::UNV2FEMAP_NodeOrder1D[2]={0,1};
const UINT CImporterUNV::UNV2FEMAP_NodeOrder2D_4[4]={2,3,0,1};
const UINT CImporterUNV::UNV2FEMAP_NodeOrder2D_9[9]={2,6,3,7,0,4,1,5,8};
const UINT CImporterUNV::UNV2FEMAP_NodeOrder3D[21]={6,7,4,5,2,3,0,1,18,19,16,17,10,11,8,9,14,15,12,13,20};

const UINT CImporterUNV::UNV2FEMAP_ComponentOrder1D[6]={0,3,1,5,4,2};
const UINT CImporterUNV::UNV2FEMAP_ComponentOrder2D[6]={0,3,1,5,4,2};
const UINT CImporterUNV::UNV2FEMAP_ComponentOrder3D[6]={0,3,1,5,4,2};

/*!
 * Default constructor.
 */
CImporterUNV::CImporterUNV()
{
	m_bImportGeometry = TRUE;
	m_bImportOutput = TRUE;
	m_bExpectedNodeCount = FALSE;
	m_bExpectedElemCount = FALSE;
	m_bExtrapolateToNodes = TRUE;
	m_bInterelementAveraging = TRUE;
}

/*!
 * Destructor.
 */
CImporterUNV::~CImporterUNV()
{

}

/*!
 * Search for the next block in UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::FindNextBlock(MyFile &File)
{
	MyString str;
	int nBlockID;
	bool block_found=FALSE;
	static long nDirectAccessOffset = 2*(UNV_BLOCK_ID_LENGTH+2);

	while(!feof(File))
	{
		File.ReadString(str);
		str=str.Left(UNV_BLOCK_ID_LENGTH);
		if(str==UNV_BLOCK_BEGIN)
		{
			block_found=TRUE;
		}
		else
		{
			if (block_found)
				{
					m_nBlockDirectAccessPosition = ftell(File)-nDirectAccessOffset;
					nBlockID=atoi(str);
					return(nBlockID);
			}
		}
	};
	return(0);
}
/*
bool CImporterUNV::FindBlock(MyFile &File,UINT nBlockID)
{
	UINT block;
	do
	{
		block=FindNextBlock(File);
	}
	while((block!=nBlockID) && (block!=0));
	if(block==nBlockID) return(TRUE);

	return(FALSE);
}

bool CImporterUNV::FindHeader(MyFile &File,UINT nBlockID,UINT VarType)
{
	while(FindBlock(File,nBlockID))
	{
		SkipRows(File,5);

		MyString str;
		UINT tmp,type;
		File.ReadString(str);

		sscanf(str,"%d%d%d%d",&tmp,&tmp,&tmp,&type);
		if(type==VarType) return(TRUE);
	}

	return(FALSE);
}
*/

/*!
 * Imports data from UNV file into ModelData object.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[out] ModelData
 * Reference to the ModelData object.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::Import(MyFile &File, CModelData &ModelData)
{
	m_pModelData = &ModelData;

	MyString str;
	UINT nBlockID;

	while((nBlockID=FindNextBlock(File))!=0)
	{
		switch (nBlockID)
		{
		case UBID_NODES:
			{
				if(m_bImportGeometry)
				{
					ImportNodes(File);
				
					if(!m_bExpectedNodeCount) m_nExpectedNodeCount=m_pModelData->m_NodArray.GetSize();
				}
			}
		break;

		case UBID_ELEMENTS:
			{
				if(m_bImportGeometry)
				{
					ImportElements(File);
					
					if(!m_bExpectedElemCount) m_nExpectedElemCount = m_pModelData->m_ElArray.GetSize();
				}
			}
		break;

		case UBID_LOADS:
			{
//				ImportUNV_Loads(file);
			}
		break;

		case UBID_CONSTRAINTS:
			{
//				ImportUNV_Constraints(file);
			}
		break;

		case UBID_NODAL_RESULTS: case UBID_ELEMENT_RESULTS:
			{
				if(m_bImportOutput) 
				{
			 		if( ImportOutput(File,nBlockID) != 0 ) return(1);
				}
			}
		break;
		}

	}

	if( m_bExtrapolateToNodes && m_bInterelementAveraging)
	{
		ModelData.InterelementAveraging(UNV_VAR_ELEM_VELOCITIES,UNV_VAR_NODAL_VELOCITIES,201,CEffectiveTranslation3D());
	}

	return(0);
}

/*!
 * Imports constraints from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CImporterUNV::ImportConstraints(MyFile &File)
{

	MyString str;

	File.ReadString(str);
	
	while (atoi(str)!=-1)
	{
		HConstraints constraints;

		constraints.m_uDataBlockID=UBID_CONSTRAINTS;
		constraints.m_nID=atoi(str);

		File.ReadString(str);
		
		constraints.m_strTitle=str;
		
		File.ReadString(str);
		
		while (atoi(str)!=-1)
		{
			ConsNode cn;
		
			sscanf(str,"%u,%u,%u,%d,%d,%d,%d,%d,%d",
					&cn.m_uNodeID,&cn.m_uColor,&cn.m_uLayer,
					&cn.m_bDOF[0],&cn.m_bDOF[1],&cn.m_bDOF[2],
					&cn.m_bDOF[3],&cn.m_bDOF[4],&cn.m_bDOF[5]);
			
			constraints.m_ConsNodes.Add(cn);
			
			File.ReadString(str);
			
		}//while (str.Left(3)!="-1,")
		
		File.ReadString(str);

		while (atoi(str)!=-1)
		{
			ConsEq conseq;
			sscanf(str,"%u,%u,%u,%u",
					&conseq.m_uEqnID,&conseq.m_uColor,&conseq.m_uLayer);
		
			File.ReadString(str);
			
			int nSize=atoi(str);
			
			conseq.m_EqCoefs.SetSize(nSize);
			
			for (int i=0;i<nSize;i++)
			{
				//EqCoeff e;
			
//				conseq.m_EqCoefs.Add(e);
				
//				EqCoeff& eqcoeff=conseq.m_EqCoefs[conseq.m_EqCoefs.GetUpperBound()];
				EqCoeff eqcoeff;

				File.ReadString(str);
				
				sscanf(str,"%u,%u,%lf",
						&eqcoeff.m_uEqn_nodeID,&eqcoeff.m_uEqn_dof,
						&eqcoeff.m_dCoeff);
				
				conseq.m_EqCoefs.Add(eqcoeff);
			}
			
			constraints.m_ConsEqs.Add(conseq);
			
			File.ReadString(str);
			
		}//while (str.Left(3)!="-1,")

		m_pModelData->m_ConsArray.Add(constraints);

		File.ReadString(str);
		
	}//	while (str.Left(5)!="   -1")
	
	return(-1);
}

/*!
 * Imports elements from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CImporterUNV::ImportElements(MyFile &File)
{

	MyString str;
	UINT NodeCount,Type,Subtype,tmp;
	UINT k;

	File.ReadString(str);

	while (atoi(str)!=-1)
	{

		HElement element;

		element.m_uDataBlockID=UBID_ELEMENTS;
		
		//Read basic data of element
		sscanf(str,"%u%u%u%u%u%u%u",
				&element.m_nID,
				&Type, //Privremeno
				&Subtype,&tmp,
				&element.m_uLayer,&element.m_uOrientID,&NodeCount); //Privremeno

		//Recognize element type and topology
		if(Type==19 && Subtype==115)
		{
			element.m_uType=HProperties::PT_3D_LIN;
			element.m_uTopology=FETO_BRICK8;
		}
		else if((Type==27 && Subtype==44) || 
				(Type==27 && Subtype==54) ||
				(Type== 5 && Subtype==94))
		{
			element.m_uType=HProperties::PT_MEMBRANE_LIN;
			element.m_uTopology=FETO_QUAD4;
		}
		else if((Type==27 && Subtype==84))
		{
			element.m_uType=HProperties::PT_AXISYM_LIN;
			element.m_uTopology=FETO_QUAD4;
		}
		else if((Type==28 && Subtype==45))
		{
			element.m_uType=HProperties::PT_MEMBRANE_PAR_9;
			element.m_uTopology=FETO_QUAD9;
		}
/*		else if((Type==28 && Subtype==85))
		{
			element.m_uType=FET_AXISYM_LIN;
			element.m_uTopology=FETO_QUAD8;
		} */
		else if(Type==1 && Subtype==21)
		{
			element.m_uType=HProperties::PT_BEAM;
			element.m_uTopology=FETO_LINE;
		}
		else if(Type==1 && Subtype==11)
		{
			element.m_uType=HProperties::PT_ROD;
			element.m_uTopology=FETO_LINE;
		}
		else if(Type==34)
		{
			element.m_uType=HProperties::PT_RIGID_BODY;
			element.m_uTopology=FETO_RIGIDLIST;
			element.m_NodeList.SetSize(NodeCount-1);
		}
		else
		{
			char msg[200];
			sprintf(msg,"ImportUNV_Elements: Unrecognized element type (Type=%u, Subtype=%u).",Type,Subtype);
			//AfxMessageBox(msg);
			printf(msg);
		}

		//Read nodes
		
		UINT nNodeID;
		for(k=0;k<NodeCount;k++)
		{
			fscanf(File,"%10u",&nNodeID);
//			if( str=="" ) File.ReadString(str);
//			sscanf(str,"%ld",&nNodeID);
//			str.Delete(0,10);
			switch(element.m_uTopology)
			{
			case FETO_QUAD4: 
				element.m_uNode[UNV2FEMAP_NodeOrder2D_4[k]] = nNodeID;
				break;
			case FETO_QUAD8: case FETO_QUAD9: 
				element.m_uNode[UNV2FEMAP_NodeOrder2D_9[k]] = nNodeID;
				break;
			case FETO_BRICK8: 
				element.m_uNode[UNV2FEMAP_NodeOrder3D[k]] = nNodeID;
				break;
			case FETO_RIGIDLIST: 
				if( k==0 ) element.m_uNode[0] = nNodeID;
				else element.m_NodeList[k-1] = nNodeID;

				break;
			default:
				element.m_uNode[k] = nNodeID;
			}
		}

		//Iscitavanje kraja reda
		File.ReadString(str);

		m_pModelData->m_ElArray.Add(element);

		File.ReadString(str);
	}

	return(-1);
}

/*!
 * Imports loads from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CImporterUNV::ImportLoads(MyFile &File)
{

	MyString str;

	File.ReadString(str);

	while (str.Left(5)!="   -1")
	{
	
		HLoads load;
	
		load.m_uDataBlockID=407;
		load.m_nID=atoi(str);
		
		File.ReadString(str);
		
		load.m_strTitle=str;
		
		File.ReadString(str);
		
		sscanf(str,"%u,%lf,%d,%d,%d",&load.m_uCSys,&load.m_dDef_temp,
				&load.m_bTemp_on,&load.m_bGrav_on,&load.m_bOmega_on);

		File.ReadString(str);
		
		sscanf(str,"%lf,%lf,%lf",&load.m_dGrav[0],&load.m_dGrav[1],&load.m_dGrav[2]);

		File.ReadString(str);

		sscanf(str,"%lf,%lf,%lf",&load.m_dGrav[3],&load.m_dGrav[4],&load.m_dGrav[5]);

		File.ReadString(str);
		
		sscanf(str,"%lf,%lf,%lf",&load.m_dOrigin[0],&load.m_dOrigin[1],&load.m_dOrigin[2]);

		File.ReadString(str);
		
		sscanf(str,"%lf,%lf,%lf",&load.m_dOmega[0],&load.m_dOmega[1],&load.m_dOmega[2]);

		File.ReadString(str);
		
		sscanf(str,"%lf,%lf,%lf",&load.m_dStef_boltz,&load.m_dAbs_temp,&load.m_dFree_cnv_exp);

		File.ReadString(str);
		
		sscanf(str,"%lf,%lf,%lf,%lf",&load.m_dFc_flu_cond,&load.m_dFc_flu_cp,
				&load.m_dFc_flu_vis,&load.m_dFc_flu_dens);

		File.ReadString(str);
		
		sscanf(str,"%lf,%lf,%lf,%lf",&load.m_dFc_cons_coef,&load.m_dFc_reynolds,
				&load.m_dFc_pran_in,&load.m_dFc_pran_out);

		File.ReadString(str);
		
		sscanf(str,"%u,%u,%u",&load.m_uTfc_flu_cond,&load.m_uTfc_flu_cp,&load.m_uTfc_flu_vis);

		File.ReadString(str);
		
		int a,ff,cf;
		
		sscanf(str,"%d,%d,%d",&a,&ff,&cf);

		load.m_bAlt_free_conv=a;
		load.m_bFc_flu_flag=ff;
		load.m_bFc_conv_flow=cf;

		// Nepoznati redovi
		
		int i;
		for (i=0;i<9;i++) File.ReadString(str);
					
		File.ReadString(str);

		while (str.Left(3)!="-1,")
		{

			StructLoad structload;
			
			sscanf(str,"%u,%u,%u,%u,%u,%u",&structload.m_uLoadID,&structload.m_uLoadtype,
					&structload.m_uColor,&structload.m_uLayer,&structload.m_uDefine_sys,&structload.m_uSl_funcID);

			File.ReadString(str);
			
			sscanf(str,"%lf,%lf",&structload.m_dPhase,&structload.m_dCoefficient);

			for (i=0;i<6;i++)
			{
				File.ReadString(str);
				
				sscanf(str,"%u,%lf",&structload.m_uDof_face[i],&structload.m_dValue[i]);
			}
			
			File.ReadString(str);
			
			sscanf(str,"%lf,%u,%u,%u", &structload.m_dAddI_coeff,&structload.m_uAddI_fnc[0],
					&structload.m_uAddI_fnc[1],&structload.m_uAddI_fnc[2]);

			File.ReadString(str); // Nejasno
			
			File.ReadString(str);
			
			sscanf(str,"%u,%u,%u",&structload.m_uDir_func[0],&structload.m_uDir_func[1],
					&structload.m_uDir_func[2]);
					
			File.ReadString(str);
			
			sscanf(str,"%lf,%lf,%lf",&structload.m_dDirection[0],&structload.m_dDirection[1],
					&structload.m_dDirection[2]);
					
			load.m_StructLoads.Add(structload);

			File.ReadString(str);

		}//while (str.Left(3)!="-1,")

		File.ReadString(str);
		
		while (str.Left(3)!="-1,")
		{
			NodalTemp nodaltemp;

			sscanf(str,"%u,%u,%u,%lf,%u",&nodaltemp.m_uNdtempID,&nodaltemp.m_uColor,
					&nodaltemp.m_uLayer,&nodaltemp.m_dNdtemp,&nodaltemp.m_uNdt_funcID);
					
			load.m_NodalTemps.Add(nodaltemp);
			
			File.ReadString(str);	

		}//while (str.Left(3)!="-1,")


		File.ReadString(str);
		
		while (str.Left(3)!="-1,")
		{
			ElTemp eltemp;

			sscanf(str,"%u,%u,%u,%lf,%u",&eltemp.m_uEltempID,&eltemp.m_uColor,
					&eltemp.m_uLayer,&eltemp.m_dEltemp,&eltemp.m_uElf_funcID);

			load.m_ElTemps.Add(eltemp);

			File.ReadString(str);

		}//while (str.Left(3)!="-1,")
			
		m_pModelData->m_LoadArray.Add(load);					

		File.ReadString(str);

	}//	while (str.Left(5)!="   -1")

	return(-1);
}

/*!
 * Imports nodes from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CImporterUNV::ImportNodes(MyFile &File)
{

	MyString str;
	
	File.ReadString(str);
	
	while (atoi(str)!=-1)
	{
		HNodes node;
		
		node.m_uDataBlockID=UBID_NODES;
		
		sscanf(str,"%u%d%d%d%lf%lf%lf",
				&node.m_nID,
				&node.m_uDefine_sys,&node.m_uOutput_sys, //Privremeno
				&node.m_uColor,
				&node.m_dX,&node.m_dY,&node.m_dZ);
		
		m_pModelData->m_NodArray.Add(node);
		
		File.ReadString(str);

	}
	
	return(-1);
}

/*
UINT CImporterUNV::ImportUNVOutBlock(MyFile& file,COutSet &os,UINT nBlockID,MyString& Title,UINT VarType,UINT ValCount,UINT ExpectedNodeCount,UINT ExpectedElemCount)
{
	MyString str;
	UINT i,j,k;

	MyString TransStr[4]={" "," R"," Top"," Top R"};
	UINT tmp,ID,NodeCount;
	UINT ovTotalID[4],ovNodalID[4][25],ovCompID[4][25][6];
	COutVector *ovTotal[4],*ovNodal[4][25],*ovComp[4][25][6];
	UINT VectorID;
	UINT PAK2FEMAP_NodeOrder2D[4]={2,3,0,1};
	UINT PAK2FEMAP_NodeOrder3D[21]={6,7,4,5,2,3,0,1,18,19,16,17,10,11,8,9,14,15,12,13,20};

	UINT HashTableSize=(nBlockID==UBID_NODAL_RESULTS ? ExpectedNodeCount : ExpectedElemCount)*6/5;

	UINT TotalCount;
	UINT SumCompCount=3; //Broj komponenti koje se sabiraju


	bool first=TRUE;
	File.ReadString(str);
	while(str.Left(6)!=UNV_BLOCK_END)
	{
		if(nBlockID==UBID_NODAL_RESULTS)
		{
			sscanf(str,"%d",&ID);
			NodeCount=1;
		}
		else sscanf(str,"%d%d%d%d",&ID,&tmp,&NodeCount,&tmp);


		if(first)
		{
			first=FALSE;


			//Za Kraljevo
			if(nBlockID==UBID_NODAL_RESULTS)
			{
				VectorID=1000+os.m_OutVectors.GetSize();
			}
			else
			{
				if		(NodeCount==4 || NodeCount==8)
				{
					switch(VarType)
					{
					case 2: VectorID=6200;
						break;
					case 3: VectorID=6300;
						break;
					default: VectorID=6500;
					}
				}
				else if	(NodeCount==2) VectorID=3000;
				else if	(NodeCount==1) VectorID=4000;
			}
			
			if(ValCount < 3) SumCompCount=ValCount;

			TotalCount=ValCount/SumCompCount; //Broj vektora za efektivne vrednosti

			for(i=0;i<TotalCount;i++)
			{
				os.ProvideSetOfOutVectors(nBlockID==UBID_ELEMENT_RESULTS,Title+TransStr[i],VectorID,VarType,NodeCount,SumCompCount,
											ovTotal[i],ovNodal[i],ovComp[i],HashTableSize);
				ovTotal[i]->m_nOut_type=VarType;
				ovTotalID[i]=ovTotal[i]->m_nID;

				for(j=0;j<NodeCount;j++)
				{
					if(NodeCount>1) ovNodalID[i][j]=ovNodal[i][j]->m_nID;

					for(k=0;k<SumCompCount;k++) 
						ovCompID[i][j][k]=ovComp[i][j][k]->m_nID;
				}

			}

			for(i=0;i<TotalCount;i++)
			{
				ovTotal[i]=&(os.GetOutVector(ovTotalID[i]));

				for(j=0;j<NodeCount;j++)
				{
					if(NodeCount>1) ovNodal[i][j]=&(os.GetOutVector(ovNodalID[i][j]));

					for(k=0;k<SumCompCount;k++) 
						ovComp[i][j][k]=&(os.GetOutVector(ovCompID[i][j][k]));
				}
			}

		}
		
		
		//Ucitavanje rezultata za jedan cvor ili element
		double val;
		double TotalVal;

		for(j=0;j<NodeCount;j++)	//Citanje redova rezultata (cvorova u elementu)
		{
			//File.ReadString(str);

			for(i=0;i<TotalCount;i++)
			{
				TotalVal=0;

				for(k=0;k<SumCompCount;k++)
				{
//					sscanf(str,"%lf",&val);
					fscanf(File,"%lf",&val);
//					str.Delete(0,13);

					ovComp[i][j][k]->SetValue(ID,val);
					
					TotalVal+=val*val;
				}

				TotalVal=sqrt(TotalVal);

				if(NodeCount>1)
				{
					switch(NodeCount)
					{
					case 4: ovNodal[i][PAK2FEMAP_NodeOrder2D[j]]->SetValue(ID,TotalVal);
						break;
					default:
						ovNodal[i][j]->SetValue(ID,TotalVal);
					}
				}
				else ovTotal[i]->SetValue(ID,TotalVal);
			}
		}
		
		//Iscitavanje kraja reda
		File.ReadString(str);

		//Sledeci cvor ili element
		File.ReadString(str);
	}

	return(0);
}
*/

/*!
 * Imports block of results from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in,out] OutSet
 * Reference to the destination output set.
 * 
 * \param[in] nBlockID
 * Type of the result block (nodal or elemental results).
 * 
 * \param[in] nVarType
 * Type of the variable in the block.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::ImportOutBlock(MyFile &File,COutSet &OutSet,UINT nBlockID,UINT nVarType,UINT nValCount)
{
	UINT nHashTableSize=(nBlockID==UBID_NODAL_RESULTS ? m_nExpectedNodeCount : m_nExpectedElemCount)*6/5;

	if(nBlockID==UBID_NODAL_RESULTS)
	{
		//Node results
		switch(nVarType)
		{
			case UNV_VAR_NODAL_DISPLACEMENTS:
			{
				UINT nVectorID = 1;
				MyString sCompExt[6] = {"X","Y","Z","RX","RY","RZ"};
				OutSet.ProvideNComponentOutVector(nVectorID,"Nodal Displacement", sCompExt,nVarType,NEU_NODE,nHashTableSize,nValCount);
				ImportNComponentOutVector(File, OutSet, nVectorID, 6, CEffectiveTranslation3D());
			}
				break;
			case UNV_VAR_NODAL_POTENTIALS:
			case UNV_VAR_NODAL_POTENTIALS_FS:
			case UNV_VAR_NODAL_ELECTRIC_POTENTIALS:
			{
				UINT nVectorID = 101;
				OutSet.ProvideOutVector(nVectorID,"Nodal Potential",UNV_VAR_NODAL_POTENTIALS,NEU_NODE,nHashTableSize);
				ImportOutVector(File, OutSet, nVectorID);
			}
				break;
			case UNV_VAR_NODAL_VELOCITIES:
			{
				UINT nVectorID = 201;
				MyString sCompExt[6] = {"X","Y","Z","RX","RY","RZ"};
				OutSet.ProvideNComponentOutVector(nVectorID,"Nodal Velocity", sCompExt,nVarType,NEU_NODE,nHashTableSize,6);
				if( nValCount == 2 )
					ImportNComponentOutVector(File, OutSet, nVectorID, nValCount, CEffectiveTranslation2D());
				else
					ImportNComponentOutVector(File, OutSet, nVectorID, nValCount, CEffectiveTranslation3D());
			}
				break;
			case UNV_VAR_NODAL_APPLIED_FORCES:
			{
				UINT nVectorID = 301;
				MyString sCompExt[6] = {"X","Y","Z","RX","RY","RZ"};
				OutSet.ProvideNComponentOutVector(nVectorID,"Nodal Force", sCompExt,nVarType,NEU_NODE,nHashTableSize,6);
				ImportNComponentOutVector(File, OutSet, nVectorID, 6,CEffectiveTranslation3D());
			}
				break;
			case UNV_VAR_NODAL_CONSTRAINT_FORCES:
			{
				UINT nVectorID = 351;
				MyString sCompExt[6] = {"X","Y","Z","RX","RY","RZ"};
				OutSet.ProvideNComponentOutVector(nVectorID,"Nodal Force", sCompExt,nVarType,NEU_NODE,nHashTableSize,6);
				ImportNComponentOutVector(File, OutSet, nVectorID, 6,CEffectiveTranslation3D());
			}
				break;
			case UNV_VAR_NODAL_SHEAR_STRESS:
			{
				UINT nVectorID = 401;
				MyString sCompExt[3] = {"X","Y","Z"};
				OutSet.ProvideNComponentOutVector(nVectorID,"Nodal Shear Stress", sCompExt,nVarType,NEU_NODE,nHashTableSize,3);
				ImportNComponentOutVector(File, OutSet, nVectorID, 3, CEffectiveTranslation3D());
			}
				break;
			case UNV_VAR_NODAL_PRESSURE:
			{
				UINT nVectorID = 501;
				OutSet.ProvideOutVector(nVectorID,"Nodal Pressure",nVarType,NEU_NODE,nHashTableSize);
				ImportOutVector(File, OutSet, nVectorID);
			}
				break;
			case UNV_VAR_NODAL_SEEPAGE:
			{
				UINT nVectorID = 601;
				OutSet.ProvideOutVector(nVectorID,"Nodal Seepage",nVarType,NEU_NODE,nHashTableSize);
				ImportOutVector(File, OutSet, nVectorID);
			}
				break;
			case UNV_VAR_NODAL_EIGENVECTORS:
			{
				UINT nVectorID = 701;
				MyString sCompExt[6] = {"X","Y","Z","RX","RY","RZ"};
				OutSet.ProvideNComponentOutVector(nVectorID,"Nodal eigenvectors", sCompExt,UNV_VAR_NODAL_DISPLACEMENTS,NEU_NODE,nHashTableSize,6);
				ImportNComponentOutVector(File, OutSet, nVectorID, 6, CEffectiveTranslation3D());
			}
				break;
			case UNV_VAR_NODAL_TEMPERATURES:
			{
				UINT nVectorID = 801;
				OutSet.ProvideOutVector(nVectorID,"Nodal Temperature",nVarType,NEU_NODE,nHashTableSize);
				ImportOutVector(File, OutSet, nVectorID);
			}
				break;
			case UNV_VAR_NODAL_STREAM_FUNCTION:
			{
				UINT nVectorID = 820;
				OutSet.ProvideOutVector(nVectorID,"Nodal Stream Function",nVarType,NEU_NODE,nHashTableSize);
				ImportOutVector(File, OutSet, nVectorID);
			}
				break;
			default:
			{
				MyString sMsg;
				sMsg.Format("Function ImportUNVOutBlock does not support importing node variable type %d.", nVarType);
				return(1);
			}
		}
	}
	else
	{
		//Element results
		UINT nNodeCount,nIntPointCount,nComponentCount, nTmp;
		MyString str;
		DWORD nCursorPosition = (DWORD)File.GetPosition();
		File.ReadString(str);
		sscanf(str,"%d%d%d%d",&nTmp,&nTmp,&nNodeCount,&nComponentCount);
		File.Seek(nCursorPosition, SEEK_SET);

		nIntPointCount = nNodeCount;
		
		//If element is Shell then there are two layers
		if(nComponentCount > 6)
		{
			nComponentCount = 6;
			nIntPointCount *= 2;
		}

		UINT nVectorID_Offset;
		switch(nNodeCount)
		{
			case 2: nVectorID_Offset = 3000;
				break;
			case 4: nVectorID_Offset = 6000;
				break;
			case 8: nVectorID_Offset = 60000;
				break;
			default:
			{
				MyString sMsg;
				sMsg.Format("Function ImportUNVOutBlock does not support %d node per elements.", nNodeCount);
				return(1);
			}
		}

		switch(nVarType)
		{
			case UNV_VAR_ELEM_STRESS:
			{
				UINT nVectorID = nVectorID_Offset + 1;
				MyString sCompExt[6] = {"XX","YY","ZZ","XY","YZ","ZX"};
				OutSet.ProvideElementNComponentOutVector(nVectorID,"Element Stress", sCompExt,nVarType,NEU_NODE,nHashTableSize,nIntPointCount,nComponentCount);
				ImportElementNComponentOutVector(File, OutSet, nVectorID, nNodeCount, nIntPointCount, nComponentCount, CEquivalentVonMisesStress(),TRUE);
			}
				break;
			case UNV_VAR_ELEM_STRAIN:
			{
				UINT nVectorID = nVectorID_Offset + 101;
				MyString sCompExt[6] = {"XX","YY","ZZ","XY","YZ","ZX"};
				OutSet.ProvideElementNComponentOutVector(nVectorID,"Element Strain", sCompExt,nVarType,NEU_NODE,nHashTableSize,nIntPointCount,nComponentCount);
				ImportElementNComponentOutVector(File, OutSet, nVectorID, nNodeCount, nIntPointCount, nComponentCount, CEquivalentStrain(),TRUE);
			}
				break;
			case UNV_VAR_ELEM_PLAST_STRAIN:
			{
				UINT nVectorID = nVectorID_Offset + 201;
				MyString sCompExt[6] = {"XX","YY","ZZ","XY","YZ","ZX"};
				OutSet.ProvideElementNComponentOutVector(nVectorID,"Element Plastic Strain", sCompExt,nVarType,NEU_NODE,nHashTableSize,nIntPointCount,nComponentCount);
				ImportElementNComponentOutVector(File, OutSet, nVectorID, nNodeCount, nIntPointCount, nComponentCount, CEquivalentStrain(),TRUE);
			}
				break;
			case UNV_VAR_ELEM_FORCES_2D:
			{
				UINT nVectorID = nVectorID_Offset + 301;
			}
				break;
			case UNV_VAR_ELEM_VELOCITIES:
			{
				UINT nVectorID = nVectorID_Offset + 401;
				MyString sCompExt[3] = {"X","Y","Z"};
				OutSet.ProvideElementNComponentOutVector(nVectorID,"Element Velocity", sCompExt,nVarType,NEU_NODE,nHashTableSize,nIntPointCount,nComponentCount);
				ImportElementNComponentOutVector(File, OutSet, nVectorID, nNodeCount, nIntPointCount, nComponentCount, CEffectiveTranslation3D(),FALSE);
			}
				break;
			case UNV_VAR_ELEM_FLUID_PRESSURE:
			{
				UINT nVectorID = nVectorID_Offset + 501;
				MyString sCompExt[6] = {"","","","","",""};
				OutSet.ProvideElementNComponentOutVector(nVectorID,"Element Fluid Pressure", sCompExt,nVarType,NEU_NODE,nHashTableSize,nIntPointCount,nComponentCount);
				ImportElementNComponentOutVector(File, OutSet, nVectorID, nNodeCount, nIntPointCount, nComponentCount, CEffectiveScalar(),TRUE);
			}
				break;
			case UNV_VAR_ELEM_SWELLING_PRESSURE:
			{
				UINT nVectorID = nVectorID_Offset + 551;
				MyString sCompExt[6] = {"","","","","",""};
				OutSet.ProvideElementNComponentOutVector(nVectorID,"Element Swelling Pressure", sCompExt,nVarType,NEU_NODE,nHashTableSize,nIntPointCount,nComponentCount);
				ImportElementNComponentOutVector(File, OutSet, nVectorID, nNodeCount, nIntPointCount, nComponentCount, CEffectiveScalar(),TRUE);
			}
				break;
			default:
			{
				MyString sMsg;
				sMsg.Format("Function ImportUNVOutBlock does not support importing element variable type %d.", nVarType);
				return(1);
			}
		}

	}

	return(0);
}

/*!
 * Imports output vector from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in] OutSet
 * Reference to the destination output set.
 * 
 * \param[in] nOutVectorID
 * ID of the output vector.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::ImportOutVector(MyFile &File, COutSet &OutSet, UINT nOutVectorID)
{
	UINT nID;
	double dValue;
	MyString str;

	COutVector &OutVector = OutSet.GetOutVector(nOutVectorID);

	File.ReadString(str);
	while(str.Left(6)!=UNV_BLOCK_END)
	{
		sscanf(str,"%d",&nID);
			
		//Ucitavanje rezultata za jedan cvor ili element
		fscanf(File,"%lf",&dValue);

		OutVector.SetValue(nID, dValue);

		//Iscitavanje kraja reda
		File.ReadString(str);

		//Sledeci cvor ili element
		File.ReadString(str);
	}

	return(0);
}

/*!
 * Imports N-component variable from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in] OutSet
 * Reference to the destination output set.
 * 
 * \param[in] nOutVectorID
 * ID of the destination output vector.
 * 
 * \param[in] nComponentCount
 * Number of components of variable.
 * 
 * \param[in] EVC
 * Reference to the object for calculation of effective value.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::ImportNComponentOutVector(MyFile &File, COutSet &OutSet, UINT nOutVectorID, UINT nComponentCount,const CEffectiveValueCalculator &EVC)
{
	ASSERT(nComponentCount <= 20);

	UINT nID;
	double dCompValues[20];
	double dEffValue;
	MyString str;
	UINT i;

	COutVector &OutVectorEff = OutSet.GetOutVector(nOutVectorID);
	COutVector *pOutVectorComp[20];

	for(i = 0; i < nComponentCount; i++)	pOutVectorComp[i] = &OutSet.GetOutVector(OutVectorEff.m_Comp[i]);
	for(i = 0; i < 20; i++) dCompValues[i] = 0.0;

	File.ReadString(str);
	while(str.Left(6)!=UNV_BLOCK_END)
	{
		sscanf(str,"%d",&nID);
			
		//Ucitavanje rezultata za jedan cvor ili element
		for(UINT i = 0; i < nComponentCount; i++)
		{
			fscanf(File,"%lf",&dCompValues[i]);

			pOutVectorComp[i]->SetValue(nID, dCompValues[i]);
		}
		dEffValue = EVC.Calculate(dCompValues);
		OutVectorEff.SetValue(nID,dEffValue);

		//Iscitavanje kraja reda
		File.ReadString(str);

		//Sledeci cvor ili element
		File.ReadString(str);
	}

	return(0);
}

/*!
 * Imports N-component elemental variable from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in] OutSet
 * Reference to the destination output set.
 * 
 * \param[in] nOutVectorID
 * ID of the destination output vector.
 * 
 * \param[in] nNodeCount
 * Number of nodes per element.
 * 
 * \param[in] nIntPointCount
 * Number of integration points.
 * 
 * \param[in] nComponentCount
 * Number of components of variable.
 * 
 * \param[in] EVC
 * Reference to the object for calculation of effective value.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::ImportElementNComponentOutVector(MyFile &File, COutSet &OutSet, UINT nOutVectorID, UINT nNodeCount, UINT nIntPointCount, UINT nComponentCount,const CEffectiveValueCalculator &EVC, bool bReorderComponents)
{
	//ASSERT(nNodeCount == 2 || nNodeCount == 4 || nNodeCount == 8);
	//ASSERT(nIntPointCount == 2 || nIntPointCount == 4 || nIntPointCount == 8);
	//ASSERT(nComponentCount <= 20);

	//UINT nID;
	//double dValue,dIntPointValues[8][20],dNodalValues[20];
	//double dEffValue;
	//UINT nTmp;
	//MyString str;
	//UINT nIntPointIndex, nComponentIndex;
	//UINT i, j, k;

	//COutVector &OutVectorCentroid = OutSet.GetOutVector(nOutVectorID);
	//COutVector *pOutVectorEff[21];
	//COutVector *pOutVectorComp[21][20];

	////Interpolation matrices
	//double H2[4][4];
	//double H4[4][4];
	//double H8[8][8];

	//double dSqrt3 = sqrt(3.0);
	////Natural coordinates of nodes relative to the element made from interpolation points
	//double dNodeNaturalCoords2[2] = {-dSqrt3,-dSqrt3};
	//double dNodeNaturalCoords4[4][2] = {{-dSqrt3,-dSqrt3},
	//									{dSqrt3,-dSqrt3},
	//									{dSqrt3,dSqrt3},
	//									{-dSqrt3,dSqrt3}};
	//double dNodeNaturalCoords8[8][3] = {{-dSqrt3,-dSqrt3,-dSqrt3},
	//									{dSqrt3,-dSqrt3,-dSqrt3},
	//									{dSqrt3,dSqrt3,-dSqrt3},
	//									{-dSqrt3,dSqrt3,-dSqrt3},
	//									{-dSqrt3,-dSqrt3,dSqrt3},
	//									{dSqrt3,-dSqrt3,dSqrt3},
	//									{dSqrt3,dSqrt3,dSqrt3},
	//									{-dSqrt3,dSqrt3,dSqrt3}};


	//if(m_bExtrapolateToNodes)
	//{
	//	if		( nIntPointCount == 2 )
	//	{
	//		for(i = 0; i < nIntPointCount; i++)
	//		{
	//			CMeshElem1D::InterpolationFunction(dNodeNaturalCoords2[i], H2[i]);
	//		}
	//	}
	//	else if		( nIntPointCount == 4 )
	//	{
	//		for(i = 0; i < nIntPointCount; i++)
	//		{
	//			CMeshElem2D::InterpolationFunction(dNodeNaturalCoords4[i][0], dNodeNaturalCoords4[i][1], H4[i]);
	//		}
	//	}
	//	else if ( nIntPointCount == 8 )
	//	{
	//		for(i = 0; i < nIntPointCount; i++)
	//		{
	//			CMeshElem3D::InterpolationFunction(dNodeNaturalCoords8[i][0], dNodeNaturalCoords8[i][1], dNodeNaturalCoords8[i][2], H8[i]);
	//		}
	//	}
	//}


	//for(i = 0; i < nIntPointCount; i++)
	//{
	//	pOutVectorEff[i] = &OutSet.GetOutVector(OutVectorCentroid.m_Comp[i]);
	//	for(UINT j = 0; j < nComponentCount; j++)	pOutVectorComp[i][j] = &OutSet.GetOutVector(pOutVectorEff[i]->m_Comp[j]);
	//}

	//File.ReadString(str);
	//while(str.Left(6)!=UNV_BLOCK_END)
	//{
	//	//Ucitavanje rezultata za jedan element
	//	sscanf(str,"%d%d%d%d",&nID, &nTmp, &nTmp, &nTmp);
	//		
	//	for( i = 0; i < nIntPointCount; i++)
	//	{
	//		for(j = 0; j < nComponentCount; j++)
	//		{
	//			fscanf(File,"%lf",&dValue);

	//			if		( nIntPointCount == 2 )
	//			{
	//				nIntPointIndex = UNV2FEMAP_NodeOrder1D[i];
	//				nComponentIndex = UNV2FEMAP_ComponentOrder1D[j];
	//			}
	//			else if		( nIntPointCount == 4 )
	//			{
	//				nIntPointIndex = UNV2FEMAP_NodeOrder2D_4[i];
	//				nComponentIndex = UNV2FEMAP_ComponentOrder2D[j];
	//			}
	//			else if ( nIntPointCount == 8 )
	//			{
	//				if		(nNodeCount == 8)
	//				{
	//					nIntPointIndex = UNV2FEMAP_NodeOrder3D[i];

	//					if(bReorderComponents)	nComponentIndex = UNV2FEMAP_ComponentOrder3D[j];
	//					else nComponentIndex = j;
	//				}
	//				else if	(nNodeCount == 4)	//Shell
	//				{
	//					// Results are in order "top, bottom, top, bottom..." and have to be reordered
	//					nIntPointIndex = UNV2FEMAP_NodeOrder3D[i/2+ (i%2 ? 4 : 0)];

	//					if(bReorderComponents) nComponentIndex = UNV2FEMAP_ComponentOrder3D[j];
	//					else nComponentIndex = j;
	//				}
	//			}

	//			dIntPointValues[nIntPointIndex][nComponentIndex] = dValue;
	//		}

	//		//Iscitavanje kraja reda
	//		File.ReadString(str);
	//	}

	//	//Storing results for the element
	//	double dCentroidValue = 0.0;

	//	if(!m_bExtrapolateToNodes)
	//	{ 
	//		//Storing results in integration points
	//		for(i = 0; i < nIntPointCount; i++)
	//		{
	//			for(j = 0; j < nComponentCount; j++)
	//			{
	//				pOutVectorComp[i][j]->SetValue(nID, dIntPointValues[i][j]);
	//			}
	//			dEffValue = EVC.Calculate(dIntPointValues[i]);
	//			pOutVectorEff[i]->SetValue(nID,dEffValue);

	//			dCentroidValue += dEffValue;
	//		}
	//	}
	//	else
	//	{
	//		for(i = 0; i < nIntPointCount; i++)
	//		{
	//			//Extrapolation from integration points to nodes
	//			for(j = 0; j < nComponentCount; j++)
	//			{
	//				dNodalValues[j] = 0.0;

	//				if		( nIntPointCount == 2 )
	//				{
	//					for(k = 0; k < nIntPointCount; k++)
	//					{
	//						dNodalValues[j] += H2[i][k]*dIntPointValues[k][j];
	//					}
	//				}
	//				else if		( nIntPointCount == 4 )
	//				{
	//					for(k = 0; k < nIntPointCount; k++)
	//					{
	//						dNodalValues[j] += H4[i][k]*dIntPointValues[k][j];
	//					}
	//				}
	//				else if ( nIntPointCount == 8 )
	//				{
	//					for(k = 0; k < nIntPointCount; k++)
	//					{
	//						dNodalValues[j] += H8[i][k]*dIntPointValues[k][j];
	//					}
	//				}

	//				pOutVectorComp[i][j]->SetValue(nID, dNodalValues[j]);
	//			}
	//			dEffValue = EVC.Calculate(dNodalValues);
	//			pOutVectorEff[i]->SetValue(nID,dEffValue);

	//			dCentroidValue += dEffValue;
	//		}
	//	}
	//	OutVectorCentroid.SetValue(nID,dCentroidValue/nIntPointCount);


	//	//Sledeci element
	//	File.ReadString(str);
	//}

	return(0);
}

/*!
 * Imports two 3-component variables from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in] OutSet
 * Reference to the destination output set.
 * 
 * \param[in] nOutVector1ID
 * ID of the first destination output vector.
 * 
 * \param[in] nOutVector2ID
 * ID of the second destination output vector.
 * 
 * \param[in] EVC
 * Reference to the object for calculation of effective value.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::ImportTwo3ComponentOutVector(MyFile &File, COutSet &OutSet, UINT nOutVector1ID, UINT nOutVector2ID,const CEffectiveValueCalculator &EVC)
{
	UINT nID;
	double dCompValues[3];
	double dEffValue;
	MyString str;

	COutVector *pOutVectorEff[2];
	pOutVectorEff[0] = &OutSet.GetOutVector(nOutVector1ID);
	pOutVectorEff[1] = &OutSet.GetOutVector(nOutVector2ID);

	COutVector *pOutVectorComp[2][3];

	for(UINT i = 0; i < 2; i++)
		for(UINT j = 0; j < 3; j++)	pOutVectorComp[i][j] = &OutSet.GetOutVector(pOutVectorEff[i]->m_Comp[j]);

	File.ReadString(str);
	while(str.Left(6)!=UNV_BLOCK_END)
	{
		sscanf(str,"%d",&nID);
			
		//Ucitavanje rezultata za jedan cvor ili element
		for(UINT i = 0; i < 2; i++)
		{
			for(UINT j = 0; j < 3; j++)
			{
				fscanf(File,"%lf",&dCompValues[j]);

				pOutVectorComp[i][j]->SetValue(nID, dCompValues[j]);
			}
			dEffValue = EVC.Calculate(dCompValues);
			pOutVectorEff[i]->SetValue(nID,dEffValue);
		}

		//Iscitavanje kraja reda
		File.ReadString(str);

		//Sledeci cvor ili element
		File.ReadString(str);
	}

	return(0);
}

/*!
 * Imports results from UNV file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in] nBlockID
 * Type of the result block.
 * 
 * \param[in,out] pExistingOutSet
 * Pointer to the existing out set. If not null, results are loaded into pExistingOutSet only.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::ImportOutput(MyFile &File,UINT nBlockID, COutSet *pExistingOutSet)
{
	MyString str;
	UINT tmp;

	MyString sTitle;
	UINT nStep;
	double dTime;
	UINT nValCount;
	UNV_VARIABLES VarType;

	if(!m_bExpectedNodeCount) m_nExpectedNodeCount=10000;
	if(!m_bExpectedElemCount) m_nExpectedElemCount=10000;

	SkipRows(File,1);
	File.ReadString(sTitle); // Naslov
	SkipRows(File,3);

	File.ReadString(str);
	sscanf(str,"%d%d%d%d%d%d",&tmp,&tmp,&tmp,&VarType,&tmp,&nValCount);

	if(!(
		 (nBlockID==UBID_NODAL_RESULTS && 
			(
			 VarType==UNV_VAR_NODAL_DISPLACEMENTS ||		
			 VarType==UNV_VAR_NODAL_POTENTIALS ||			
			 VarType==UNV_VAR_NODAL_POTENTIALS_FS ||		
			 VarType==UNV_VAR_NODAL_ELECTRIC_POTENTIALS ||			
			 VarType==UNV_VAR_NODAL_VELOCITIES	||		
			 VarType==UNV_VAR_NODAL_APPLIED_FORCES ||
			 VarType==UNV_VAR_NODAL_CONSTRAINT_FORCES ||
			 VarType==UNV_VAR_NODAL_SHEAR_STRESS ||		
			 VarType==UNV_VAR_NODAL_PRESSURE ||			
			 VarType==UNV_VAR_NODAL_SEEPAGE	||			
			 VarType==UNV_VAR_NODAL_EIGENVECTORS ||		
			 VarType==UNV_VAR_NODAL_TEMPERATURES ||		
			 VarType==UNV_VAR_NODAL_STREAM_FUNCTION		
		    )
		 ) ||		
		 (nBlockID==UBID_ELEMENT_RESULTS && 
			(
			 VarType==UNV_VAR_ELEM_STRESS || 
			 VarType==UNV_VAR_ELEM_STRAIN || 
//			 VarType==UNV_VAR_ELEM_PLAST_STRAIN || 
			 VarType==UNV_VAR_ELEM_FORCES_2D || 
			 VarType==UNV_VAR_ELEM_VELOCITIES ||
			 VarType==UNV_VAR_ELEM_FLUID_PRESSURE || 
			 VarType==UNV_VAR_ELEM_SWELLING_PRESSURE || 
			 VarType==9
			)
		 )	//Element results

		)) return(0);


	File.ReadString(str);
	sscanf(str,"%d%d%d%d",&tmp,&tmp,&nStep,&tmp);

	//OutSet ID
	UINT nOutSetID = nStep;

	//Check if out set can be loaded on demand
	if( m_nBlockDirectAccessPosition < 0 )
	{
		ASSERT(pExistingOutSet==NULL);
		MyString sMessage;
		sMessage.Format("Error loading step %u. File is to long.\nTurn of 'Import on demand' and try to import the range of interest only.",
							nStep);
		//AfxMessageBox(sMessage);
		printf(sMessage);

		if( m_pModelData->m_OutSetArray.IsExist(nOutSetID) )
		{
			m_pModelData->m_OutSetArray.Remove(nOutSetID);
		}

		return(1);
	}

	if( pExistingOutSet!=NULL && nOutSetID != pExistingOutSet->m_nID ) return(1);



	File.ReadString(str);
	sscanf(str,"%lf",&dTime);

	COutSet *pOutSet;

	if( pExistingOutSet==NULL )
	{
		UINT nIndex;
		if( !m_pModelData->m_OutSetArray.FindIndex(nOutSetID,nIndex))
		{
			COutSet NewOutSet;

			NewOutSet.m_nID=nOutSetID;
			NewOutSet.m_dValue=dTime;
			NewOutSet.m_sTitle.Format("Step %ld: %10lf",nStep,dTime);
			NewOutSet.m_nFrom_prog=APC_PAK;
			NewOutSet.m_sSourceFileName = File.GetFilePath();
			NewOutSet.m_nDirectAccessPosition = m_nBlockDirectAccessPosition;

			nIndex = m_pModelData->m_OutSetArray.Add(NewOutSet);
		}

		if(nOutSetID>1000)
		{
			return(0);
		}

		pOutSet = &(m_pModelData->m_OutSetArray[nIndex]);
	}
	else
	{
		pOutSet = pExistingOutSet;
	}
	
	
	ImportOutBlock(File,*pOutSet,nBlockID,VarType,nValCount);

	return(0);
}

/*!
 * Reloads results from UNV file into specified output set only .
 * 
 * \param[in,out] OutSet
 * Reference to the output set to be reloaded.
 * 
 * \param[in] nExpectedNodeCount
 * Expected number of nodes to import. Used to optimize loading speed. Optional.
 * 
 * \param[in] nExpectedElementCount
 * Expected number of elements to import. Used to optimize loading speed. Optional.
 * 
 * \returns
 * Zero if successful.
 */
UINT CImporterUNV::ReloadOutSet(COutSet &OutSet, UINT nExpectedNodeCount, UINT nExpectedElementCount)
{
	ASSERT( OutSet.m_OutVectors.GetSize() == 0 );

	MyFile File;

	//Open source file
	if(!File.Open( OutSet.m_sSourceFileName,"rt" ))
	{
		//AfxMessageBox(FILE_OPEN_ERROR);
		printf(FILE_OPEN_ERROR);
		return(0);	
	}

	//Seek start position
	File.Seek(OutSet.m_nDirectAccessPosition,SEEK_SET);

	UINT nBlockID;
	while((nBlockID=FindNextBlock(File))!=0)
	{
		if( nBlockID == UBID_NODAL_RESULTS || nBlockID == UBID_ELEMENT_RESULTS )
		{
			if( ImportOutput(File,nBlockID,&OutSet) != 0 ) break;
		}
		else
		{
			break;
		}
	}

	return(0);
}
