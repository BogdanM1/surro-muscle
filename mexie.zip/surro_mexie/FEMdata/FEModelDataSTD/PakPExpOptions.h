/*!
 * \file PakPExpOptions.h
 * Interface for the CPakPExportOptions class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PakPExportOptions.h: interface for the CPakPExportOptions class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAKPEXPORTOPTIONS_H__2BD55871_19C4_4903_9A5C_D44603A1B04F__INCLUDED_)
#define AFX_PAKPEXPORTOPTIONS_H__2BD55871_19C4_4903_9A5C_D44603A1B04F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/** Class containing options for exporting to PAK-P input file. */
class CPakPExpOptions  
{
public:
	CPakPExpOptions();
	virtual ~CPakPExpOptions();

	/// Indicator whether free surface calculation is performed
	bool m_bFreeSurface;
};

#endif // !defined(AFX_PAKPEXPORTOPTIONS_H__2BD55871_19C4_4903_9A5C_D44603A1B04F__INCLUDED_)
