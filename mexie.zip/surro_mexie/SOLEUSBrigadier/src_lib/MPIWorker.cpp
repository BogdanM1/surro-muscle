/*
 * MPIWorker.cpp
 *
 *  Created on: May 14, 2014
 *      Author: anakaplarevic
 */

#include "MPIWorker.h"
#include "MMChunkCalculator.h"
#include "MMChunkCUDA.h"
#include <string>

MPIWorker::MPIWorker(MMChunkCalculator* microModelChunk) {
	this->microModelChunk = microModelChunk;
#ifdef LOGON
    this->microModelChunk->setFileVelikiLog(&velikiLog);
#endif
}

MPIWorker::~MPIWorker() {

}

void MPIWorker::createFileForChunk(){
    FILE* pom;
    pom=fopen(createFileName(),"w");
    microModelChunk->setFile(pom);
    microModelChunk->setMPI(mpi_ID);		
}


void MPIWorker::run() {
#ifdef LOGON
    fprintf(velikiLog,"PROCESS %d\n",mpi_ID);
    fprintf(velikiLog,"MPIWorker::run ... start\n");
    fflush(velikiLog);
#endif
//	  int  i;//,num_elements, p=mpi_SIZE, NUM,flags[2];

//	  MPI_Bcast(&n_q_points_all,1,MPI_INT, 0,MPI_COMM_WORLD);

	  MPI_Bcast(podela,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(dispodela,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(podela3,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(dispodela3,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(podela33,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(dispodela33,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);

	microModelChunk->setStartID(dispodela[mpi_ID]);

	 //  double e[4][3],sigma[4][3],deltasigma[4][3][3];
	  double *e,*sigma,*deltasigma;
	  //int tipovi[n_q_points_all];
	  int* tipovi;
      tipovi = NULL; //stavljeno zbog warninga-a, njega worker i ne koristi
      std::vector<double> m_E;
      std::vector<double> m_ni;
      std::vector<double> m_fi;
  //    std::vector<double> m_f1;
      std::vector<_TIPF1> m_f1;
      int dim = Globals::getInstance()->dimOfSigmaVector;
      e = NULL; //stavljeno zbog warninga-a, njega worker i ne koristi
      sigma = NULL; //stavljeno zbog warninga-a, njega worker i ne koristi
      deltasigma = NULL; //stavljeno zbog warninga-a, njega worker i ne koristi

	  printf("init - ID %d\n",mpi_ID);

//	  double *e_part,*sigma_part,*deltasigma_part;
//	  int *tipovi_part;

	  tipovi_part=(int *)malloc(podela[mpi_ID]*sizeof(int));
      m_E_part.resize(podela[mpi_ID]);
      m_ni_part.resize(podela[mpi_ID]);
      m_fi_part.resize(podela[mpi_ID]);
      m_f1_part.resize(podela[mpi_ID]);

	  e_part=(double *)malloc(podela3[mpi_ID]*sizeof(double));
	  sigma_part=(double *)malloc(podela3[mpi_ID]*sizeof(double));
	  deltasigma_part=(double *)malloc(podela33[mpi_ID]*sizeof(double));

	  tipovi_part = (int*) malloc(sizeof(int)*podela[mpi_ID]);

	  printf("WorkerID %d dodeljeno tacaka %d\n",mpi_ID,podela[mpi_ID]);

	  MPI_Scatterv(tipovi, podela,dispodela, MPI_INT, tipovi_part,podela[mpi_ID], MPI_INT,0, MPI_COMM_WORLD);

      MPI_Scatterv((void *)&m_E[0], podela,dispodela, MPI_DOUBLE, (void *)&m_E_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
      MPI_Scatterv((void *)&m_ni[0], podela,dispodela, MPI_DOUBLE, (void *)&m_ni_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
      MPI_Scatterv((void *)&m_fi[0], podela,dispodela, MPI_DOUBLE, (void *)&m_fi_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
// ANAF1TIP MPI_Scatterv((void *)&m_f1[0], podela,dispodela, MPI_DOUBLE, (void *)&m_f1_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);

    #if num_TIPF1 == 1
        MPI_Scatterv(&m_f1[0], podela,dispodela, MPI_DOUBLE,&m_f1_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
    #else
        MPI_Scatterv(&m_f1[0], podela,dispodela, MPI_FLOAT,&m_f1_part[0],podela[mpi_ID], MPI_FLOAT,0, MPI_COMM_WORLD);
    #endif

// micro model
      microModelChunk->init(podela[mpi_ID],(MMType*)tipovi_part,m_E_part,m_ni_part,m_fi_part,m_f1_part);

/*	  for(int i=0;i<podela[mpi_ID];i++)
		  printf("tipovi_part[%d]=%d ",i,tipovi_part[i]);
	  printf("\n");
*/
	  int flags[2];
      FILE* f;
      char* nazivHvajla;
      nazivHvajla=(char*)malloc(sizeof(char)*20);

      char* sc;
      sc = (char*) malloc(sizeof(char));
      config_t cfg; //   const char *str;
      config_init(&cfg);

      if(!config_read_file(&cfg, CFGFAJL)) { printf("Neuspesno otvaranje FEM_MM.cfg fajla\n"); config_destroy(&cfg); exit(-1);}
      if(!config_lookup_string(&cfg, "RUN.scenario", (const char**)&sc)) fprintf(stderr, "Nema 'scenario' u konfiguracionom fajlu\n");
      printf("Procitao iz CFG-a %s \n",sc);
      char *cit;
      cit = (char*)malloc(sizeof(char)*(strlen(sc)-1));
      sscanf(sc,"%s",cit);
      config_destroy(&cfg);

      if(strcmp(cit,"MPImixCUDA")==0){
          switch(mpi_ID){
          case 0: strcpy(nazivHvajla,"ITER0.txt");
                  break;
          case 1: strcpy(nazivHvajla,"ITER1.txt");
                  break;
          case 2: strcpy(nazivHvajla,"ITER2.txt");
                  break;
          case 3: strcpy(nazivHvajla,"ITER3.txt");
                  break;
          default: strcpy(nazivHvajla,"empty.txt");
              break;
          }
      }
      else strcpy(nazivHvajla,"empty.txt");
      f=fopen(nazivHvajla,"w");
// DEBUG
//	  printf("WORKER primio tipove\n");
//    double primio,obradio;
	int rbr=0;
	char imeloga[40];
	sprintf(imeloga,"vremena%d.log",mpi_ID);
	FILE* log;
	log=fopen(imeloga,"w");
// ___DEBUG
    //Globals* g=Globals::getInstance();
//    std::vector<float> f1_part_float;
//    f1_part_float.resize(podela[mpi_ID]);
    while(1)
	  {
#ifdef LOGON
    fprintf(velikiLog,"MPIWorker::while(1) jedan prolaz ... start\n");
    fflush(velikiLog);
#endif
// DEBUG
//		  	  printf("slave %d ceka e\n",mpi_ID);
// __DEBUG

//	 BRISI	  MPI_Bcast(&t,1,MPI_DOUBLE, 0,MPI_COMM_WORLD);
//	 BRISI	  Globals::getInstance()->dt=t;

     //  for(int i=0;i<podela[mpi_ID];i++) f1_part_float[i]=(float)m_f1_part[i];
#if num_TIPF1 == 1
    MPI_Scatterv(&m_f1[0], podela,dispodela, MPI_DOUBLE, &m_f1_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
#else
    MPI_Scatterv(&m_f1[0], podela,dispodela, MPI_FLOAT, &m_f1_part[0],podela[mpi_ID], MPI_FLOAT,0, MPI_COMM_WORLD);
#endif
          microModelChunk->updateParameters(podela[mpi_ID],m_f1_part);
     //  microModelChunk->updateParameters(podela[mpi_ID],f1_part_float);
			  for(int i=0;i<podela3[mpi_ID];i++) e_part[i]=1;
	 MPI_Scatterv(e, podela3,dispodela3, MPI_DOUBLE, e_part,podela3[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
//	primio=MPI::Wtime();
// DEBUG
/*             for(int i=0;i<podela3[mpi_ID];i++)
                  printf("e_part[%d]=%f ",i,e_part[i]);
              printf("\n");*/
// _DEBUG

// micro model
// DEBUG	  printf("WORKER pre poziva calculateChunk \n");
              microModelChunk->calculateChunk((double*)e_part,(double*)sigma_part,(double*)deltasigma_part);
#ifdef LOGON
              fprintf(velikiLog,"MPIWorker:: ... primio od chunk calculatora ... \n");
              fprintf(velikiLog,"ID\te\tsigma\tdetasigma\n");
              for(int i=0;i<10;i++) fprintf(velikiLog,"%d\t%e\t%e\t%e\n",dispodela[mpi_ID]+i,*(e_part+i*dim),*(sigma_part+i*dim),*(deltasigma_part+i*dim*dim));
              fflush(velikiLog);
#endif
// DEBUG 	  printf("SID %d zavrsio\n",mpi_ID);
           //      int dim = Globals::getInstance()->dimOfSigmaVector;
              if(Globals::cudaRunTip==CUDARunCustom){
           //       for(int i=0;i<podela[mpi_ID];i++) fprintf(f,"%f %f %f %d\n",sigma_part[i*dim],deltasigma_part[i*dim*dim],e_part[i*dim],((MMChunkCUDA*)microModelChunk)->iterCount[i]);
          //     fprintf(f,"\n");
              }
 		 	  // slanje rezultata
// 	      obradio=MPI::Wtime();
			  	 MPI_Gatherv(sigma_part, podela3[mpi_ID], MPI_DOUBLE,sigma,podela3,dispodela3, MPI_DOUBLE, 0, MPI_COMM_WORLD);
// DEBUG  		 	  	 	 printf("Sakupio sigma_part-s\n");
			  	 MPI_Gatherv(deltasigma_part, podela33[mpi_ID], MPI_DOUBLE, deltasigma,podela33,dispodela33, MPI_DOUBLE, 0, MPI_COMM_WORLD);
// DEBUG  		 	  	 	 printf("Sakupio deltasigma_part-s\n");
		rbr++;
    //    fprintf(log,"%d %d %e %e\n",mpi_ID,rbr,primio,obradio);//MPI_ID rbr primio obradio
// provera nastavka i pamcenja stanja
			  	 MPI_Bcast(flags,2,MPI_INT, 0,MPI_COMM_WORLD);
			  	 	 	 microModelChunk->setToNew(flags[1]);
// DEBUG 			  	printf("ID %d zavrsio krug \n",mpi_ID);
#ifdef LOGON
    fprintf(velikiLog,"MPIWorker::while(1) jedan prolaz ... END\n");
    fflush(velikiLog);
#endif
    if (flags[0]==0) break;
    }
// DEBUG 	  printf("---------------------- SID zavrsio\n");
      fclose(log);  	
      fclose(f);
#ifdef LOGON
    fprintf(velikiLog,"MPIWorker::run ... END\n");
    fflush(velikiLog);
#endif
}
