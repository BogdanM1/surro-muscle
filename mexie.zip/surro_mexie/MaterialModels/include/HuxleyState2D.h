/*
 * HuxleyState2D.h
 *
 *  Created on: Nov 14, 2013
 *      Author: anakaplarevic
 *
 *      Klas namenjena samo 2D slucaju sa RAVNIM NAPONOM
 *      deformacija iz prethodnog vremenskog koraka je vektor
 *      e_t={e_xx,e_yy, g_xy}
 */

#ifndef HUXLEYSTATE2D_H_
#define HUXLEYSTATE2D_H_

#include <boost/numeric/ublas/vector.hpp>
#include "MaterialModelState.h"
#include "HuxleyState.h"
#include "HuxleyState2D.h"
#include "HuxleyParameters.h"
using namespace boost::numeric;
class HuxleyState2D:public MaterialModelState
{
public:
		ublas::vector<_TIP> X;
		ublas::vector<_TIP> N;
		ublas::vector<_TIP> e_t;  // TODO e_t u state-u ostavljen na DOUBLE, proveriti  {e_xx,e_yy, g_xy}
		
		_TIP v_t;
		double direction[2];
		
		ublas::vector<double> histogram; 

	        
public:
	HuxleyState2D();
	virtual ~HuxleyState2D();
	void init(MaterialModelParameters* p);
	void init(MaterialModelState* s);
	bool equal(MaterialModelState* s);
};

#endif /* HUXLEYSTATE2D_H_ */
