/*!
 * \file HNodes.cpp
 * Implementation of the HNodes class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HNodes.cpp: implementation of the HNodes class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "Femcon.h"
#include "HNodes.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL( HNodes,HDataBlock, VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
HNodes::HNodes()
{
	m_nID=0;
	m_uDefine_sys=0;
	m_uOutput_sys=0;
	m_uLayer=0;
	m_uColor=0;
	m_dX=m_dY=m_dZ=0.;
	for (int i=0;i<HNODES_MAX_DOF_COUNT;i++)
		m_bPermbc[i]=false;

	m_dInitTemp = 0.0;
}

/*!
 * Copy constructor.
 */
HNodes::HNodes(const HNodes & rc)
{
	(*this)=rc;
}


/*!
 * Destructor.
 */
HNodes::~HNodes()
{

}

/*!
 * Equalizes two objects of the HNodes class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
HNodes& HNodes::operator =(const HNodes & rp)
{
	m_uDataBlockID=rp.m_uDataBlockID;
	m_nID=rp.m_nID;
	m_uDefine_sys=rp.m_uDefine_sys;// ID of definition coordinate system
	m_uOutput_sys=rp.m_uOutput_sys;// ID of output coordinate system
	m_uLayer=rp.m_uLayer;
	m_uColor=rp.m_uColor;
	for (int i=0;i<HNODES_MAX_DOF_COUNT;i++)
		m_bPermbc[i]=rp.m_bPermbc[i];// the six permanent constaints
	m_dX=rp.m_dX;
	m_dY=rp.m_dY;
	m_dZ=rp.m_dZ;

	m_dInitTemp = rp.m_dInitTemp;

	return *this;

}

///*!
// * Serializes object of the HNodes class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void HNodes::Serialize(CArchive& ar)
//{
//	int i;
//	if (ar.IsStoring())
//	{	
//		ar << m_uDataBlockID;
//		ar << m_nID;
//		ar << m_uDefine_sys;// ID of definition coordinate system
//		ar << m_uOutput_sys;// ID of output coordinate system
//		ar << m_uLayer;
//		ar << m_uColor;
//		for (i=0;i<HNODES_MAX_DOF_COUNT;i++)
//			ar << m_bPermbc[i];// the six permanent constaints
//// Coordinates in Global Rectangular coordinate system:
//		ar << m_dX;
//		ar << m_dY;
//		ar << m_dZ;
//
//		ar << m_dInitTemp;
//	}
//	else
//	{
//		ar >> m_uDataBlockID;
//		ar >> m_nID;
//		ar >> m_uDefine_sys;// ID of definition coordinate system
//		ar >> m_uOutput_sys;// ID of output coordinate system
//		ar >> m_uLayer;
//		ar >> m_uColor;
//		for (i=0;i<HNODES_MAX_DOF_COUNT;i++)
//		{
//			ar >> m_bPermbc[i];
//		}
//// Coordinates in Global Rectangular coordinate system:
//		ar >> m_dX;
//		ar >> m_dY;
//		ar >> m_dZ;
//
//		ar >> m_dInitTemp;
//	}
//}

