/*
 * FEM.h
 *
 *  Created on: May 2, 2014
 *      Author: anakaplarevic
 */

#ifndef FEM2D_H_
#define FEM2D_H_

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/compressed_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/grid/grid_out.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <libconfig.h++>
#include <libconfig.h>
#include <cstdlib>
#include <vector>  // !!!!!!!!!!!!!!!!!  proveriti duplikate

#include <deal.II/lac/sparse_direct.h>

//#include "FEM.cpp"
#include "Globals.h"
 class QPointCalculator;

using namespace libconfig;
using namespace dealii;

class FEM2D{
public:
	FEM2D();
	virtual ~FEM2D();
	void run(QPointCalculator* qpoint_calculator);
//		void run ( Config& cfg);
	std::map<int, double> U_prescribed;
	std::map<int,double> F_prescribed;
	double T; 			// total simulation time
	QPointCalculator* qpoint_calculator;

private:
	void make_grid ();
	void setup_system ();
	void solve ();
	void simulate();
	void init ();

	FullMatrix<double> e_element(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,std::vector<unsigned int> dofIndex );
	  void stampa(const Vector<double> vektor, const char* naziv, const int POM);

	  Triangulation<2>     triangulation;
	  FESystem<2>              fe;				// FE_Q<2>              fe;
	  DoFHandler<2>        dof_handler;

	  ConstraintMatrix hanging_node_constraints;

	  SparsityPattern      sparsity_pattern;
	  SparseMatrix<double> system_matrix;
	  Vector<double>       solution;
	  Vector<double>       system_rhs;
	  std::map<unsigned int,double> boundary_values;

	  unsigned int   dofs_per_cell; // const
	  unsigned int   n_q_points; 	// const
	  unsigned int   n_dofs_all;	// const
	  unsigned int   n_q_points_all;	// const

	  unsigned int num_cells_x,num_cells_y;

	  Vector<double> R;
	  Vector<double> F;
	  Vector<double> U;

	  FullMatrix<double> R_matrix;
	  FullMatrix<double> F_matrix;
	  FullMatrix<double> U_matrix;


	  QGauss<2>  quadrature_formula;
	  FEValues<2> fe_values;

	  Globals* g;

	  std::ifstream _fInFPrescibed;
	  std::ifstream _fInUPrescribed;
	  std::ofstream fOut;
	  FILE* fUnv;

	 std::vector<Point<2> > cvorovi;
};

#endif /* FEM2D_H_ */
