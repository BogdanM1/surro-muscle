/*!
 * \file ImporterUNV.h
 * Interface for the CImporterUNV class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// ImporterUNV.h: interface for the CImporterUNV class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMPORTERUNV_H__82CB7E64_0518_49B5_A230_DE27A9592326__INCLUDED_)
#define AFX_IMPORTERUNV_H__82CB7E64_0518_49B5_A230_DE27A9592326__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyFile.h"

class COutSet;
class CEffectiveValueCalculator;
class CModelData;

//UNV Block markers
#define UNV_BLOCK_ID_LENGTH    6
#define UNV_BLOCK_BEGIN "    -1"
#define UNV_BLOCK_END   "    -1"

/** Class containing functions for importing data from PAK UNV file. */
class CImporterUNV  
{
protected:
	typedef enum
	{
		//UNV Block IDs
		UBID_NODES				=	15,
		UBID_ELEMENTS			=	71,
		UBID_LOADS				=	407,
		UBID_CONSTRAINTS		=	757,
		UBID_NODAL_RESULTS		=	55,
		UBID_ELEMENT_RESULTS	=	57
	} TUNV_BlockIDs;

public:
	UINT ReloadOutSet(COutSet &OutSet, UINT nExpectedNodeCount, UINT nExpectedElementCount);
	UINT Import(MyFile &File, CModelData &ModelData);
	CImporterUNV();
	virtual ~CImporterUNV();

	inline void SetExpectedNodeCount(UINT nExpectedNodeCount)
	{
		m_nExpectedNodeCount = nExpectedNodeCount;
		m_bExpectedNodeCount = TRUE;
	}

	inline void SetExpectedElemCount(UINT nExpectedElemCount)
	{
		m_nExpectedElemCount = nExpectedElemCount;
		m_bExpectedElemCount = TRUE;
	}

protected:
	UINT ImportNodes(MyFile &File);
	UINT ImportElements(MyFile &File);
	UINT ImportLoads(MyFile &File);
	UINT ImportConstraints(MyFile &File);
	UINT ImportOutput(MyFile &File,UINT nBlockID, COutSet *pExistingOutSet = NULL);
	UINT ImportOutBlock(MyFile &File,COutSet &OutSet,UINT nBlockID,UINT nVarType,UINT nValCount);
	UINT ImportOutVector(MyFile &File, COutSet &OutSet, UINT nOutVectorID);
	UINT ImportNComponentOutVector(MyFile &File, COutSet &OutSet, UINT nOutVectorID, UINT nComponentCount,const CEffectiveValueCalculator &EVC);
	UINT ImportElementNComponentOutVector(MyFile &File, COutSet &OutSet, UINT nOutVectorID, UINT nNodeCount, UINT nIntPointCount, UINT nComponentCount,const CEffectiveValueCalculator &EVC, bool bReorderComponents);
	UINT ImportTwo3ComponentOutVector(MyFile &File, COutSet &OutSet, UINT nOutVector1ID, UINT nOutVector2ID,const CEffectiveValueCalculator &EVC);
	UINT FindNextBlock(MyFile &File);
//	bool FindBlock(MyFile &File,UINT nBlockID);
//	bool FindHeader(MyFile &File,UINT nBlockID,UINT VarType);

public:
//	UINT ImportOutSet(COutSet &OutSet);
	/// Indicator whether geometry is imported
	bool m_bImportGeometry;
	/// Indicator whether results are imported
	bool m_bImportOutput;
	/// Indicator whether results at integration points have to be extrapolated to nodes.
	bool m_bExtrapolateToNodes;
	/// Indicator whether interelement average values have to be calculated.
	bool m_bInterelementAveraging;

protected:
	/// Pointer to ModelData where data have to be imported
	CModelData *m_pModelData;

	/// Conversion array defining relation between UNV and FEMAP result components on 1D elements
	static const UINT UNV2FEMAP_NodeOrder1D[2];
	/// Conversion array defining relation between UNV and FEMAP result components on 2D 4-nodes elements
	static const UINT UNV2FEMAP_NodeOrder2D_4[4];
	/// Conversion array defining relation between UNV and FEMAP result components on 2D 9-nodes elements
	static const UINT UNV2FEMAP_NodeOrder2D_9[9];
	/// Conversion array defining relation between UNV and FEMAP result components on 3D elements
	static const UINT UNV2FEMAP_NodeOrder3D[21];

	/// Conversion array defining relation between PAK and FEMAP result components on 1D elements
	static const UINT UNV2FEMAP_ComponentOrder1D[6];
	/// Conversion array defining relation between PAK and FEMAP result components on 2D elements
	static const UINT UNV2FEMAP_ComponentOrder2D[6];
	/// Conversion array defining relation between PAK and FEMAP result components on 3D elements
	static const UINT UNV2FEMAP_ComponentOrder3D[6];

	/// Poisition of block in the source file for direct access
	long m_nBlockDirectAccessPosition;

	/// Expected number of nodes to be imported. Used to improve performance.
	UINT m_nExpectedNodeCount;
	/// Indicator whether expected node count is set.
	bool m_bExpectedNodeCount;
	/// Expected number of elements to be imported. Used to improve performance.
	UINT m_nExpectedElemCount;
	/// Indicator whether expected element count is set.
	bool m_bExpectedElemCount;
};

#endif // !defined(AFX_IMPORTERUNV_H__82CB7E64_0518_49B5_A230_DE27A9592326__INCLUDED_)
