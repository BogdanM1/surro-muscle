/*
 * HuxleyMaterialModel.cpp
 *
 *  Created on: Aug 8, 2013
 *      Author: anakaplarevic
 */

#include "HuxleyModel.h"


HuxleyModel::HuxleyModel(HuxleyParameters* param){
	_param = param;
	_calculator = new HuxleyCalculator(param);
}

HuxleyModel::~HuxleyModel() {

}

void HuxleyModel::Calculate(MaterialModelState *s,double *e, double* sigma,double* dsigmade)
{
	_TIP force,forceP,V,Vpert,time;
	HuxleyState *stateP,*state;
	stateP = new HuxleyState();
	int coord = _param->direction;

	state = 	(HuxleyState*)s;
	printf("state->N.size()=%lu \t e_t = %lf\n",state->N.size(),state->e_t);

	Globals* g = Globals::getInstance();
	time = (_TIP) g->dt;
	printf("time = %f\n",time);
	stateP->init(state);

	printf("stateP->N.size()=%lu\n",stateP->N.size());

	V = ((_TIP)*e-(_TIP)stateP->e_t)*(_param->L0)/time;
	Vpert = ((_TIP)*e+_param->pertubacija-(_TIP)stateP->e_t)*(_param->L0)/time;
	
	_TIP O = (_param->stressStretchFunction).GetValue(e[coord]);
	printf("Korekcija %lf\n",O);

	_calculator->Calculate(state->X,state->N,(_TIP)V,time,(_TIP *)&force, (_TIP)O);
	_calculator->Calculate(stateP->X,stateP->N,(_TIP)Vpert,time,(_TIP *)&forceP, (_TIP)O);
	((HuxleyState*) state)->e_t = *e;

	printf("HuxleyModel - zavrsio init u calculate metodu\n");

	CalculateStress((_TIP*)&force,(_TIP*)&forceP,e,sigma,dsigmade);

}

void HuxleyModel::CalculateStress(_TIP *force,_TIP *forceP,double* e,double* sigma,double* dsigmade){
	_TIP sigmaP;
	*sigma = *force/_param->A;
	sigmaP = *forceP/_param->A;
	*dsigmade = (sigmaP-*sigma)/_param->pertubacija;
	printf("HuxleyModel.cpp \n");
}

MaterialModelParameters* HuxleyModel::getParameters(){
	return (MaterialModelParameters*) _param;
}
