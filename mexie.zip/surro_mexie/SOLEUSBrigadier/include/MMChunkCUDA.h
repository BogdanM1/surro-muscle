/*
 * MMChunkCUDA.h
 *
 *  Created on: May 22, 2014
 *      Author: anakaplarevic
 */

#ifndef MMCHUNKCUDA_H_
#define MMCHUNKCUDA_H_

#include "MMChunkCalculator.h"
class HuxleyCalculatorCuda;

class MMChunkCUDA: public MMChunkCalculator {
public:
    std::vector<int> iterCount;
    CUDARunType* _cudaTip;
    HuxleyCalculatorCuda* cudaHuxley;
	MMChunkCUDA();
    MMChunkCUDA(CUDARunType *cudaTip);
	virtual ~MMChunkCUDA();

//	void init(int num_points,MMType *types);
	void init(int num_points,
                  MMType *types,
                  std::vector<double> &m_E,
                  std::vector<double> &m_ni,
                  std::vector<double> &m_fi,
          std::vector<_TIPF1> &m_f1
        );
	void calculateChunk(double *e,double* sigma,double* dsigmade);
	void setToNew(int flag);
//    void updateParameters(int num_points,std::vector<_TIP> &m_f1);
        void fillArrays(int num_points,
			MMType *types,std::vector<double> &m_E,
			std::vector<double> &m_ni,
			std::vector<double> &m_fi,
            std::vector<_TIPF1> &m_f1);
};

#endif /* MMCHUNKCUDA_H_ */
