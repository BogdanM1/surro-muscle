// PAKExp.cpp: Functions for export to PAK's DAT file.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "FEModelData.h"
#include "PAKExp.h"
#include "PAKCSExp.h"
#include "BlockIDs.h"
#include "PakExpOption.h"
#include "math.h"
#include "StringAdvanced.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//	Export PakCS - Software for book bioengineering
UINT CModelData::ExportPAK_CS(MyFile& file,CPakExpOption *peo)
{
	MyString str;
	UINT uNGELEM;
	UINT i;
	long lGeneralDataPos;


	if((m_NodArray.GetSize())<=0)
	{
		//AfxMessageBox(PAKC_NO_NODES);
		printf(PAKC_NO_NODES);
		return(0);	
	};
	
	if((uNGELEM=m_PropArray.GetSize())<=0)
	{
		//AfxMessageBox(PAKC_NO_GROUPS);
		printf(PAKC_NO_GROUPS);
		return(0);	
	};

	//	Card /1/
	file.WriteString(PAKC_CardH1);
	file.WriteString(PAKC_CardV1);
	file.WriteString(m_PakGeneral.GetTitle()+"\n");

	//	Card /2/
	file.WriteString(PAKC_CardH2);
	file.WriteString(PAKC_CardV2);
	str.Format("%5u\n",PAKC_INDFOR);
	file.WriteString(str);

	//	Card /3/
 	file.WriteString(PAKC_CardH3);
	file.WriteString(PAKC_CardV3);
	lGeneralDataPos=file.GetPosition();
	str.Format("                                             \n");
	file.WriteString(str);

	//	Card /4/
 	file.WriteString(PAKC_CardH4);
	file.WriteString(PAKC_CardV4);
	str.Format("%5u%5u%5u%5u%10.6f%10.6f%5u\n",	PAKC_INTEB, PAKC_INDSC, PAKC_IFORM, PAKC_MAXIT,
												PAKC_EPSTA, PAKC_EPSTR, PAKC_NJRAP);
	file.WriteString(str);

	//	Card /5/
 	file.WriteString(PAKC_CardH5);
	file.WriteString(PAKC_CardV5);
	str.Format("%5u\n",PAKC_IREST);
	file.WriteString(str);

	//	Card /6/
 	file.WriteString(PAKC_CardH6);
//	file.WriteString(PAKC_CardV6);
	for(i = 1; i <= (UINT)m_PakGeneral.GetNumOfPeriods(); i++)
	{
		str.Format("%5u%10.6f\n", m_PakGeneral.GetNumSteps(i-1),m_PakGeneral.GetStep(i-1));
		file.WriteString(str);
	}

	//	Card /7/
	ExportPAKCS_Nodes(file);

	//	Card /8/
	MyMap<UINT,UINT,UINT,UINT> FEMAP2PAK_PropertyMap;
	ExportPAKCS_Elements_C(file,&uNGELEM,FEMAP2PAK_PropertyMap,peo);

	//	Card /9/
 	file.WriteString(PAKC_CardH9);
	ExportPAKCS_PrescribedValues(file);

	//	Card /10/ - Inicijalne vrednosti.
	double dQx = 0.0;
	double dQy = 0.0;
	double dQz = 0.0;
	double dP  = 0.0;
 	file.WriteString(PAKC_CardH10);
	file.WriteString(PAKC_CardV10);
	str.Format("%10.3lf%10.3lf%10.3lf%10.3lf\n",dQx, dQy, dQz, dP);
	file.WriteString(str);

	//	Card /11/
	ExportPAKCS_BoundaryConditions( file );

	//	Card /12/
	UINT nModelCount;
	ExportPAKCS_Materials(file,nModelCount,FEMAP2PAK_PropertyMap);

	//	Card /13/
	ExportPAKCS_TimeFunctions(file);

	//	Card /14/
	file.WriteString(PAKC_CardH14);
	file.WriteString(PAKC_CardV14);

	//	Card /15/
	ExportPAKCS_Forces(file);
	file.WriteString(PAKCS_CardH1);
	file.WriteString(PAKCS_CardV1);

	//	Upisivanje naknadno
	//	P R I V R E M E N O

	file.Seek(lGeneralDataPos,SEEK_SET);

	str.Format("%5u%5u%5u%5u%5u%5u%5u%5u%5u",m_NodArray.GetSize(),PAKC_NGET, PAKC_NMATM,
		(int)m_PakGeneral.GetDynamicAnIsSet(), m_PakGeneral.GetNumOfPeriods(),
		PAKC_NPRINT, PAKC_NKRT, PAKCS_IPAKS, PAKCS_KONTAKT);

	file.WriteString(str);
	file.Seek(0,SEEK_END);

	UINT nPakSModelCount;
	UINT nElemGroupCount;
	MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> FEMAP2PAK_MaterialMap;

	lGeneralDataPos=file.GetPosition();
	str.Format("               \n");
	file.WriteString(str);

	ExportPAKCS_MatModels_S(file,nPakSModelCount,FEMAP2PAK_MaterialMap);
	nElemGroupCount = 0;
	ExportPAKCS_Elements_S(file,nElemGroupCount,FEMAP2PAK_MaterialMap,peo);


	//	Upisivanje naknadno
	file.Seek(lGeneralDataPos,SEEK_SET);
	str.Format("%5u%5u%5u", nPakSModelCount, nElemGroupCount, 1);

	file.WriteString(str);
	file.Seek(0,SEEK_END);

	//	Card /16/
	file.WriteString(PAKC_CardH16);
	file.WriteString(PAKC_CardV16);

	return(-1);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

UINT CModelData::ExportPAKCS_Elements_C(MyFile& file,UINT *uNGELEM,MyMap<UINT,UINT,UINT,UINT> &FEMAP2PAK_PropertyMap,CPakExpOption *peo)
{
	MyString str;
	MyStringAdvanced PAKstr;
	UINT i,j,k;
	//UINT uNMODM,uMatIID;
	MyArray <UINT,UINT&> ElNum;
	MyMap<UINT,UINT,UINT,UINT> PropIndex; // relation between Property ID and it's position in ElNum;
	HElement el;
	UINT nMaterialCounter = 0;

	UINT nCounter = 0;
	HProperties Property;
	HMaterial Material;

	UINT nTotalMatCount = 0;
	for(i = 0; i < (UINT) m_PropArray.GetSize(); i++)
		if (m_MaterialsArray[i].m_uSubType == HMaterial::ST_PAK_POROUS_DEFORMABLE) 	nTotalMatCount++;

	//	Prebrojavanje PakC elemenata
	UINT nPakCElemCount = 0;
	for(i = 0; i < (UINT) m_PropArray.GetSize(); i++)	//Loop by properties (group of elements)
	{
		Property = m_PropArray[i];
		Material = m_MaterialsArray.Get(Property.m_uMatIID);
		
		if(Material.m_uSubType == HMaterial::ST_PAK_POROUS_DEFORMABLE)
		{
			for(UINT j = 0; j < (UINT)m_ElArray.GetSize(); j++)
			{
				if(m_ElArray[j].m_uPropID == Property.m_nID)
					nPakCElemCount++;
			}
		}
	}


	for(i = 0; i < (UINT) m_PropArray.GetSize(); i++)	//Loop by properties (group of elements)
	{
		Property = m_PropArray[i];
		Material = m_MaterialsArray.Get(Property.m_uMatIID);

		//	Mapiranje property-a
		if(Material.m_uSubType == HMaterial::ST_PAK_POROUS_DEFORMABLE)
			FEMAP2PAK_PropertyMap.SetAt(Property.m_uMatIID, ++nMaterialCounter);
		else
			continue;


//		bool bFound = FEMAP2PAK_MaterialMap.Lookup(Property.m_uMatIID, mms);	//Struktura cuva materijalni model i materijal
//		ASSERT(bFound);

		switch (Property.m_Type)
		{
		//****************************************************************************
		//****************************** 2D Elementi *********************************
		//****************************************************************************
/*
		case FET_SHEAR_LIN:case FET_SHEAR_PAR:
		case FET_MEMBRANE_LIN:case FET_MEMBRANE_PAR:
		case FET_BENDING_LIN:case FET_BENDING_PAR:
		case FET_PLATE_LIN:case FET_PLATE_PAR:
		case FET_PLANESTRAIN_LIN:case FET_PLANESTRAIN_PAR:
		case FET_LAMINATE_LIN:case FET_LAMINATE_PAR:
		case FET_AXISYM_LIN:case FET_AXISYM_PAR:
			{
				UINT uNE4=0,uNE3=0;

				switch (Property.m_uType)
				{
					case FET_SHEAR_LIN:case FET_SHEAR_PAR: uIETYP=4;
						break;
					case FET_MEMBRANE_LIN:case FET_MEMBRANE_PAR: uIETYP=0;
						break;
					case FET_PLANESTRAIN_LIN:case FET_PLANESTRAIN_PAR: uIETYP=2;
						break;
					case FET_AXISYM_LIN:case FET_AXISYM_PAR: uIETYP=1;
						break;
				}

				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				if(m_ElArray[j].m_uPropID==Property.m_nID)
					{
						if(m_ElArray[j].m_uTopology==FETO_QUAD4 || m_ElArray[j].m_uTopology==FETO_QUAD8) uNE4++;
						else uNE3++;
					}

				if(uNE4>0)	//Cetvorougaoni 2D Element
				{
				 //Card /8-1/
				 if(Property.m_uType==FET_BENDING_LIN || Property.m_uType==FET_BENDING_PAR ||
					Property.m_uType==FET_PLATE_LIN || Property.m_uType==FET_PLATE_PAR ||
					Property.m_uType==FET_LAMINATE_LIN || Property.m_uType==FET_LAMINATE_PAR) uNETIP=(peo->m_b4N2BD ? PAK_SHELL_BD : PAK_ISO_SHELL); 
				 else uNETIP=PAK_ISO_2D;

				 file.WriteString(PAKC_CardH13);
				 file.WriteString(PAKSC_CardV13);

//					 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE4,Property.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);
				 int iIALFA=0;		//Bez inkompatibilnih pomeranja: int iIALFA=-1;	

				 // Beta - angle of first material axis
				 double dBeta = 0.0;
				 if( Property.m_dValue.GetSize() >= 2 ) dBeta = Property.m_dValue[1];

				 if(uNETIP==PAK_ISO_2D)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,dBeta,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,iIALFA);
				 }
				 else
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5d%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					  PAKS_NGAUSX2,PAKS_NGAUSY2,(peo->m_bDrillShell ? -2 : PAKS_NGAUSZ2),
					  PAKS_MSET,dBeta,PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,iIALFA);
				 }
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==Property.m_nID)
					{
						el=m_ElArray[j];
//						Property = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8)
						{
							UINT uIPGS=1;
							str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,uIPGS,Property.m_dValue[0],
								PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<FEM_Top[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[k]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}

				if(uNE3>0)	// Trougaoni 2D Element
				{
				 if(uNE4>0) (*uNGELEM)++;
				 //Card /13/
				 if(Property.m_uType==FET_BENDING_LIN || Property.m_uType==FET_BENDING_PAR ||
					Property.m_uType==FET_PLATE_LIN || Property.m_uType==FET_PLATE_PAR ||
					Property.m_uType==FET_LAMINATE_LIN || Property.m_uType==FET_LAMINATE_PAR) uNETIP=PAK_ISO_TRI_SHELL; 
				 else uNETIP=PAK_ISO_TRI;

				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE3,Property.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);

				 if(uNETIP==PAK_ISO_TRI)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,PAKS_BETA,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,PAKS_IALFA);
				 }
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_NGAUSZ2,PAKS_MSET,PAKS_BETA,PAKS_MSLOJ,
					PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,PAKS_IALFA);
				 }
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==Property.m_nID)
					{
						el=m_ElArray[j];
//						Property = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_TRI3 || el.m_uTopology==FETO_TRI6)
						{
							str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,Property.m_dValue[0],
								PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<FEM_Top[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[k]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}				

			}
			break;


*/
//****************************************************************************
//******************************* 2D Elementi ********************************
//****************************************************************************
		case HProperties::PT_SHEAR_LIN:case HProperties::PT_SHEAR_PAR:
		case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:
		case HProperties::PT_BENDING_LIN:case HProperties::PT_BENDING_PAR:
		case HProperties::PT_PLATE_LIN:case HProperties::PT_PLATE_PAR:
		case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR:
		case HProperties::PT_LAMINATE_LIN:case HProperties::PT_LAMINATE_PAR:
		case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR: 
		case HProperties::PT_MEMBRANE_PAR_9: case HProperties::PT_MEMBRANE_LIN_5:
			{
				//Card /8/
				if(nCounter == 0)
				{
					file.WriteString(PAKC_CardH8);
					file.WriteString(PAKC_CardV8);

					UINT nINDAX  = 0;	//
					UINT nIATYP  = 0;	//
					UINT nNMODM  = 0;	//
					UINT nIPN	 = 0;	//
					UINT nIPOROS = 0;	//	Indicator for variable porosity
					UINT nISWELL = 0;	//	Indicator for swelling pressure

					UINT nMaterialModelCount = 1;		//
					UINT nMaterialCount = *uNGELEM;		//
					UINT nNodesPerElem = 0;				//

					nIPOROS = Property.m_uFlag[0];
					nISWELL = Property.m_uFlag[1];
					nINDAX = Property.m_uFlag[2];

					switch (Property.m_AnalysisType)
					{
						case HProperties::AT_LINEAR:				nIATYP = 1;	break;
						case HProperties::AT_TOTAL_LAGRANGIAN:		nIATYP = 2;	break;
						case HProperties::AT_UPDATED_LAGRANGIAN:	nIATYP = 3;	break;
						case HProperties::AT_LARGE_STRAIN_UL:		nIATYP = 4;	break;
						case HProperties::AT_LARGE_STRAIN_TL:		nIATYP = 4;	break;
					}

					switch (Property.m_Type)
					{
						case HProperties::PT_MEMBRANE_LIN:		nNodesPerElem = 4;		nIPN = 4;	break;
						case HProperties::PT_MEMBRANE_LIN_5:	nNodesPerElem = 4;		nIPN = 1;	break;
						case HProperties::PT_MEMBRANE_PAR_9:	nNodesPerElem = 9;		nIPN = 4;	break;
					}

					str.Format("%5u%5u%5u%5u%5u%5u%5u\n", PAK_ISO_2D, nPakCElemCount, nINDAX, nIATYP, nNMODM, nIPN, nIPOROS);
					file.WriteString(str);

					file.WriteString(PAKC_CardH8_1);
					file.WriteString(PAKC_CardV8_1);
					str.Format("%5u%5u%5u%5u\n", nMaterialModelCount, nTotalMatCount, nNodesPerElem, nISWELL);
					file.WriteString(str);



					if(nISWELL == 1)
					{
						// Constants for water-content approach (This card used if nISWELL == 1)
						double dSWELLA, dSWELLB, dSWELLC;
						// Initial swelling pressure
						double dPC0;

						dSWELLA = Property.m_dValue[1];
						dSWELLB = Property.m_dValue[2];
						dSWELLC = Property.m_dValue[3];
						dPC0  = Property.m_dValue[4];

						str.Format(PAKC_CardH8_3);
						file.WriteString(str);
						PAKstr.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n", dSWELLA, dSWELLB, dSWELLC, dPC0);
						file.WriteString(PAKstr);
					}

					if(nISWELL == 2)
					{
						// Coefficient of chemical contraction
						double dALFAC = 0.0;
						str.Format("%10.5lf", dALFAC);
						file.WriteString(str);
					}

					file.WriteString(PAKC_CardH8_2);
					file.WriteString(PAKC_CardV8_2);
				}

				nCounter++;

				for(j = 0; j < (UINT)m_ElArray.GetSize(); j++)
				{
					if(m_ElArray[j].m_uPropID == Property.m_nID)
					{
						el = m_ElArray[j];

						str.Format("%5u", el.m_nID);
						file.WriteString(str);
						for(k=0;k<4;k++) 
						{
							str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[k]]);
							file.WriteString(str);
						}
						if(el.m_uTopology==FETO_QUAD9)
						{
							for(k=4;k<9;k++) 
							{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[k]]);
								file.WriteString(str);
							}
				//			str.Format("%5u",el.m_uNode[5]);
				//			file.WriteString(str);
						}

						if(el.m_uTopology==FETO_QUAD5)
						{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[8]]);
								file.WriteString(str);
						}

						str.Format("%5u%10.5lf\n", nMaterialCounter, Property.m_dValue[0]);
						file.WriteString(str);
					}
				}

				break;
			}

	//****************************************************************************
	//******************************* 3D Elementi ********************************
	//****************************************************************************
		case HProperties::PT_3D_LIN_9: case HProperties::PT_3D_LIN:
			{
				//Card /8/
				if(nCounter == 0)
				{
					UINT nElCount = m_ElArray.GetSize();
					file.WriteString(PAKC_CardH8);
					file.WriteString(PAKC_CardV8);

					UINT nINDAX  = 0;	//
					UINT nIATYP  = 0;	//
					UINT nNMODM  = 0;	//
					UINT nIPN	 = 0;	//
					UINT nIPOROS = 0;	//	Indicator for variable porosity
					UINT nISWELL = 0;	//	Indicator for swelling pressure

					UINT nMaterialModelCount = 1;		//
					UINT nMaterialCount = *uNGELEM;		//
					UINT nNodesPerElem = 0;				//

					nIPOROS = Property.m_uFlag[0];
					nISWELL = Property.m_uFlag[1];

					switch (Property.m_AnalysisType)
					{
						case HProperties::AT_LINEAR:				nIATYP = 1;	break;
						case HProperties::AT_TOTAL_LAGRANGIAN:		nIATYP = 2;	break;
						case HProperties::AT_UPDATED_LAGRANGIAN:	nIATYP = 3;	break;
						case HProperties::AT_LARGE_STRAIN_UL:		nIATYP = 4;	break;
						case HProperties::AT_LARGE_STRAIN_TL:		nIATYP = 4;	break;
					}

					switch (Property.m_Type)
					{
						case HProperties::PT_3D_LIN_9:	nNodesPerElem = 8;		nIPN = 1;	break;
						case HProperties::PT_3D_LIN:	nNodesPerElem = 8;		nIPN = 8;	break;
					}


					str.Format("%5u%5u%5u%5u%5u%5u%5u\n", PAK_ISO_3D, nElCount, nINDAX, nIATYP, nNMODM, nIPN, nIPOROS);
					file.WriteString(str);
			
					file.WriteString(PAKC_CardH8_1);
					file.WriteString(PAKC_CardV8_1);
					str.Format("%5u%5u%5u%5u\n", nMaterialModelCount, nMaterialCount, nNodesPerElem, nISWELL);
					file.WriteString(str);



					if(nISWELL == 1)
					{
						// Constants for water-content approach (This card used if nISWELL == 1)
						double dSWELLA, dSWELLB, dSWELLC;
						// Initial swelling pressure
						double dPC0;

						dSWELLA = Property.m_dValue[1];
						dSWELLB = Property.m_dValue[2];
						dSWELLC = Property.m_dValue[3];
						dPC0  = Property.m_dValue[4];
						str.Format("%10.5lf%10.5lf%10.5lf%10.5lf", dSWELLA, dSWELLB, dSWELLC, dPC0);
						file.WriteString(str);
					}

					if(nISWELL == 2)
					{
						// Coefficient of chemical contraction
						double dALFAC = 0.0;
						str.Format("%10.5lf", dALFAC);
						file.WriteString(str);
					}

					file.WriteString(PAKC_CardH8_2);
					file.WriteString(PAKC_CardV8_2);
				}

				nCounter++;

				for(j = 0; j < (UINT)m_ElArray.GetSize(); j++)
				{
					if(m_ElArray[j].m_uPropID == Property.m_nID)
					{
						el = m_ElArray[j];

						str.Format("%5u", el.m_nID);
						file.WriteString(str);
						for(k=0;k<8;k++) 
						{
							str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder3D[k]]);
							file.WriteString(str);
						}
						if(el.m_uTopology==FETO_BRICK9)
						{
							str.Format("%5u",el.m_uNode[8]);
							file.WriteString(str);
						}

						str.Format("%5u\n", Property.m_uMatIID);
						file.WriteString(str);
					}
				}

				break;
			}
		}	// End of swich ( Property.m_uType )
	}		// End of loop over elements

	return(-1);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
//Vlada
UINT CModelData::ExportPAKCS_Nodes(MyFile& file)
{
	MyString str;
	MyStringAdvanced PakString;
	UINT i;
	HNodes nn;

	//	Card /10/
 	file.WriteString(PAKC_CardH7);
	file.WriteString(PAKC_CardV7);

	UINT nNodesPerElem = m_NodArray.GetSize();

	if (0)/*	fabs(m_NodArray[0].m_dX - m_NodArray[nNodesPerElem - 1].m_dX) > 0.0001	||
			fabs(m_NodArray[0].m_dY - m_NodArray[nNodesPerElem - 1].m_dY) > 0.0001	||
			fabs(m_NodArray[0].m_dZ - m_NodArray[nNodesPerElem - 1].m_dZ) > 0.0001		)*/
	{
		for(i = 0; i < nNodesPerElem; i++)
		{
			nn = m_NodArray[i];
		
			str.Format("%5u %2u%2u%2u%2u%2u%2u%2u%2u  %10.6lf%10.6lf%10.6lf%2u%2u%2u\n",
						nn.m_nID, nn.m_bPermbc[0],nn.m_bPermbc[1],nn.m_bPermbc[2],
						nn.m_bPermbc[3], nn.m_bPermbc[4], nn.m_bPermbc[5],
						nn.m_bPermbc[6], nn.m_bPermbc[7],
						nn.m_dX, nn.m_dY, nn.m_dZ,
						nn.m_bPermbc[8], nn.m_bPermbc[9], nn.m_bPermbc[10]);
			file.WriteString(str);
		}
	}
	else
	{
		for(i = 0; i < nNodesPerElem; i++)
		{
			nn = m_NodArray[i];

			PakString.Format("%5u %2u%2u%2u%2u%2u%2u%2u%2u  %10.3.2e%10.3.2e%10.3.2e%2u%2u%2u\n",
						nn.m_nID, nn.m_bPermbc[0],nn.m_bPermbc[1],nn.m_bPermbc[2],
						nn.m_bPermbc[3], nn.m_bPermbc[4], nn.m_bPermbc[5],
						nn.m_bPermbc[6], nn.m_bPermbc[7],
						nn.m_dX, nn.m_dY, nn.m_dZ,
						nn.m_bPermbc[8], nn.m_bPermbc[9], nn.m_bPermbc[10]);
			file.WriteString(PakString);
		}
	}

	return(-1);
}

UINT CModelData::ExportPAKCS_Materials(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,UINT,UINT> &FEMAP2PAK_PropertyMap)
{
	// PakC - /12-1/a: m_uFK[0] = INDJOT
	// PakC - /12-1/c:	m_dK[0] = Ro_f,  m_dK[1] = n,  m_dK[2] = k,
	//				m_dK[3] = Ks,    m_dK[4] = Kf, m_dK[5] = ;	Material constants
	// PAKC - /12-1/d:	m_dAlpha[0] = B11, m_dAlpha[1] = B12, 
	//				m_dAlpha[2] = B21, m_dAlpha[3] = B22;	Constants about electrokinetic coupling
	
	MyString str;
	MyStringAdvanced p_str;

	//	Card /12/
	file.WriteString(PAKC_CardH12);
	file.WriteString(PAKC_CardV12);

	UINT nMaterialCount = FEMAP2PAK_PropertyMap.GetCount();
	
	str.Format("%5u\n", nMaterialCount);
	file.WriteString(str);
	
	for(UINT i = 0; i < (UINT)m_PropArray.GetSize(); i++)
	{
		HMaterial& Material = m_MaterialsArray[i];;
		UINT nPakC_MaterialID = 0;

		if ( !FEMAP2PAK_PropertyMap.Lookup( m_PropArray[i].m_uMatIID, nPakC_MaterialID) )
			continue;

		switch (Material.m_uType)
		{
		case HMaterial::MT_FEMAP_OTHER:
			{
				switch (Material.m_uSubType)
				{
				case HMaterial::ST_PAK_POROUS_DEFORMABLE:
					{
						//	Card /12-1/
 						file.WriteString(PAKC_CardH12_1);
						str.Format(" %d\n", nPakC_MaterialID);
						file.WriteString(str);
						file.WriteString(PAKC_CardV12_1);

						UINT nINDJOT = Material.m_uFK[0];
						str.Format("%5u%5u%5u\n", 1, nPakC_MaterialID, nINDJOT);
						file.WriteString(str);

						file.WriteString(PAKC_CardV12_1_1_a);
						p_str.Format("%10.3.2e%10.3.2e%10.3.2e%10.3.2e\n",Material.m_dE[0], Material.m_dNu[0], Material.m_dDensity, Material.m_dK[0]);
						file.WriteString(p_str);

						file.WriteString(PAKC_CardV12_1_1_b);
						p_str.Format("%10.3.2e%10.3.2e%10.3.2e%10.3.2e\n",Material.m_dK[1], Material.m_dK[2], Material.m_dK[3], Material.m_dK[4]);
						file.WriteString(p_str);

						if ( nINDJOT == 1 )
						{
							file.WriteString(PAKC_CardV12_1_1_d);
							p_str.Format("%10.3.2e%10.3.2e%10.3.2e%10.3.2e\n",Material.m_dAlpha[0], Material.m_dAlpha[1], Material.m_dAlpha[2], Material.m_dAlpha[3]);
							file.WriteString(p_str);
						}
					}
					break;

				default:
					continue;
				}
			}
			break;

		default:
			ASSERT(FALSE);
		}
	}

	return(-1);
}

UINT CModelData::ExportPAKCS_MatModels_S(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT i,k;
	UINT PAK_Model, PAK_SubModel = 0;
	PAK_MaterialKey PAK_Material;



	//Determine appropriate PAK material for each FEMAP material
	FEMAP2PAK_MaterialMap.RemoveAll();
	MyMap<UINT,UINT,UINT,UINT> MaterialsInModel;
	MaterialsInModel.RemoveAll();

	for(i=0;i<(UINT)m_MaterialsArray.GetSize();i++)
	{
		HMaterial &Material = m_MaterialsArray[i];

		switch (Material.m_uType)
		{
		case HMaterial::MT_FEMAP_ISO: PAK_Model = PAKM_ELASTIC_ISO;
			break;
		case HMaterial::MT_FEMAP_2D_ORTHO: case HMaterial::MT_FEMAP_3D_ORTHO: PAK_Model = PAKM_ELASTIC_ORTHO;
			break;
		case HMaterial::MT_FEMAP_OTHER:
			{
				switch (Material.m_uSubType)
				{
				case HMaterial::ST_PAK_ELASTIC_ISO: 	PAK_Model = PAKM_ELASTIC_ISO;
					break;
				case HMaterial::ST_PAK_THERMO_ELASTIC_ISO: 	PAK_Model = PAKM_THERMO_ELASTIC_ISO;
					break;
				case HMaterial::ST_PAK_HYSTERELASTIC: 	PAK_Model = PAKM_HYSTERELASTIC;
					break;
				case HMaterial::ST_PAK_BIO32:		 	PAK_Model = PAKM_BIO32;
					break;
				case HMaterial::ST_PAK_MODEL_41:		PAK_Model = PAKM_TENSEGRITY;
					break;
				case HMaterial::ST_PAK_BIAXIAL:		 	PAK_Model = PAKM_BIAXIAL;
					break;
				case HMaterial::ST_PAK_MODEL_37:		PAK_Model = PAKM_MODEL_37;
					break;
				case HMaterial::ST_PAK_MODEL_38:		PAK_Model = PAKM_MODEL_38;
					break;
				case HMaterial::ST_PAK_MODEL_39:		PAK_Model = PAKM_MODEL_39;
					break;
				case HMaterial::ST_PAK_HILLS2002:	 	PAK_Model = PAKM_HILLS2002;
					break;
				case HMaterial::ST_PAK_HILLS:		 	PAK_Model = PAKM_USER_SUPPLIED; PAK_SubModel = PAKM_USER_SUPPLIED_HILLS;
					break;
				case HMaterial::ST_PAK_HILLS_2FIBER: 	PAK_Model = PAKM_USER_SUPPLIED; PAK_SubModel = PAKM_USER_SUPPLIED_HILLS_2FIBER;
					break;
				case HMaterial::ST_PAK_DELFINO_SEF_2D: 	PAK_Model = PAKM_DELFINO_SEF_2D;
					break;
				case HMaterial::ST_PAK_FUNG_SEF:	 	PAK_Model = PAKM_FUNG_SEF;
					break;
				default:
					continue;
				}
			}
			break;
		default:
			ASSERT(FALSE);
		}

		//Material count within PAK_Model
		UINT MaterialCount;
		if( !MaterialsInModel.Lookup(PAK_Model, MaterialCount) )	MaterialCount = 0;
		MaterialsInModel.SetAt(PAK_Model, ++MaterialCount);


		FEMAP2PAK_MaterialMap.SetAt(Material.m_nID, PAK_MaterialKey(PAK_Model,PAK_SubModel,MaterialCount));
	}


//Card /11/

	file.WriteString(PAKS_CardH11);
	file.WriteString(PAKS_CardV11);

	map<UINT, UINT>::const_iterator pos = MaterialsInModel.GetStartPosition();
	while( pos != MaterialsInModel.end() )
	{
		UINT nMaterialCount;

		MaterialsInModel.GetNextAssoc( pos, PAK_Model, nMaterialCount);
	
		str.Format("%5u%5u%5u\n",PAK_Model,nMaterialCount,PAKS_MODEL3);
		file.WriteString(str);

		if( PAK_Model == PAKM_USER_SUPPLIED )
		{
			//Find first material in PAKM_USER_SUPPLIED model
			for(k=0;k<(UINT)m_MaterialsArray.GetSize();k++)
			{
				HMaterial &Material = m_MaterialsArray[k];

				bool bFound;
				bFound = FEMAP2PAK_MaterialMap.Lookup(Material.m_nID, PAK_Material);
		//		ASSERT(bFound);

				if(PAK_Material.m_nModel == PAK_Model) break;
			}
		//	ASSERT( k < (UINT)m_MaterialsArray.GetSize() );

			switch( PAK_Material.m_nSubModel )
			{
			case PAKM_USER_SUPPLIED_HILLS:
			{
				str.Format("%5u%5u%5u%5u\n", 3 /*int*/, 8 /*double*/, 4 /*curve*/, 5 /*state variables*/);
				file.WriteString(str);
			}
			break;
			case PAKM_USER_SUPPLIED_HILLS_2FIBER:
			{
				str.Format("%5u%5u%5u%5u%5u\n", 3 /*int*/, 19 /*double*/, 8 /*curve*/, 10 /*state variables*/, 1 /*nodal variables*/);
				file.WriteString(str);
			}
			break;
			default:
				ASSERT(FALSE);
			}
		}


	}	
	
//Loop over material models

	pos = MaterialsInModel.GetStartPosition();
	while( pos != MaterialsInModel.end() )
	{
		UINT nMaterialCount;

		MaterialsInModel.GetNextAssoc( pos, PAK_Model, nMaterialCount);
		
		UINT nMaterialIndex=0;

		for(k=0;k<(UINT)m_MaterialsArray.GetSize();k++)
		{
			HMaterial &Material = m_MaterialsArray[k];

			bool bFound;
			bFound = FEMAP2PAK_MaterialMap.Lookup(Material.m_nID, PAK_Material);
	//		ASSERT(bFound);

			if(PAK_Material.m_nModel == PAK_Model)
			{
				nMaterialIndex++;
				
				//Card /12/
 				file.WriteString(PAKS_CardH12);
				file.WriteString(PAKS_CardV12);
				p_str.Format("%5u%5u%10.4.2e\n",PAK_Material.m_nModel,PAK_Material.m_nMaterial,Material.m_dDensity);
				file.WriteString(p_str);

				switch (PAK_Model)
				{
				case  PAKM_ELASTIC_ISO:
					{
					label_elastic_iso:
					//Card /12-1/
					if (fabs(Material.m_dAlpha[0])>PAKS_MAT_ALPHA_TOL) goto label_thermo_elastic_iso;
						file.WriteString(PAKS_CardH12_1);
						file.WriteString(PAKS_CardV12_1_1);
						file.WriteString(PAKS_CardV12_1_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_1_3);
						file.WriteString(PAKS_CardV12_1_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_THERMO_ELASTIC_ISO:
					{
					label_thermo_elastic_iso:
						file.WriteString(PAKS_CardH12_1);
						file.WriteString(PAKS_CardV12_1_1);
						file.WriteString(PAKS_CardV12_1_2);
						str.Format("%5d\n",1);
						file.WriteString(str);
						p_str.Format("%10.2f%10.2.2e\n",2000.,Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_1_3);
						file.WriteString(PAKS_CardV12_1_4);
						str.Format("%5d\n",1);
						p_str.Format("%10.2f%10.2.2e\n",2000.,Material.m_dNu[0]);
						file.WriteString(str);
						file.WriteString(p_str);
						str.Format("%5d\n",1);
						p_str.Format("%10.2f%10.2.2e\n",2000.,Material.m_dAlpha[0]);
						file.WriteString(str);
						file.WriteString(p_str);
						str.Format("%10f\n",Material.m_dTemperature);
						file.WriteString(str);
					}
					break;
				case PAKM_ELASTIC_ORTHO:
					{
			 			file.WriteString(PAKS_CardH12_2);
						file.WriteString(PAKS_CardV12_2_1);
						file.WriteString(PAKS_CardV12_2_2);
						str.Format("%10.3e%10.3e%10.3e\n",Material.m_dE[0],Material.m_dE[1],Material.m_dE[2]);
						file.WriteString(str);
						file.WriteString(PAKS_CardV12_2_3);
						file.WriteString(PAKS_CardV12_2_4);
						str.Format("%10.3e%10.3e%10.3e\n",Material.m_dNu[0],Material.m_dNu[1],Material.m_dNu[2]);
						file.WriteString(str);
						file.WriteString(PAKS_CardV12_2_5);
						file.WriteString(PAKS_CardV12_2_6);
						str.Format("%10.3e%10.3e%10.3e\n",Material.m_dG[0],Material.m_dG[1],Material.m_dG[2]);
						file.WriteString(str);
					}
					break;
				case  PAKM_MISES_PLASTIC:
					{
			 			if (Material.m_uNonlin_type==0) goto label_elastic_iso;
						file.WriteString(PAKS_CardH12_1);
						file.WriteString(PAKS_CardV12_1_1);
						file.WriteString(PAKS_CardV12_1_2_1);
						str.Format("%10.3e%10.3e\n",Material.m_dE[0],Material.m_dNu[0]);
						file.WriteString(str);
						str.Format("%10.3e%10.3e\n",Material.m_dPlastYieldLim[0],Material.m_dPlastHardSlope);
						file.WriteString(str);
					}
					break;
				case  PAKM_HYSTERELASTIC:
					{
						file.WriteString(PAKS_CardH12_37);
						file.WriteString(PAKS_CardV12_37_1);
						file.WriteString(PAKS_CardV12_37_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_37_3);
						file.WriteString(PAKS_CardV12_37_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Loading hysteresis function
						UINT i, nPointCount;
						//UINT nIndex;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(PAKS_CardV12_37_5);
						file.WriteString(PAKS_CardV12_37_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_37_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							p_str.Format("%10.4.1e\n",LoadFunc.m_FunctionEntry[i].m_dY);
							file.WriteString(p_str);
						}

						//Unloading hysteresis function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(PAKS_CardV12_37_8);
						file.WriteString(PAKS_CardV12_37_9);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_37_10);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							p_str.Format("%10.4.1e\n",UnloadFunc.m_FunctionEntry[i].m_dY);
							file.WriteString(p_str);
						}
					}
					break;
				case PAKM_HILLS2002:
					{
						file.WriteString(PAKS_CardV12_31_1);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0],Material.m_dNu[0],Material.m_dGMatrix_3D[0],Material.m_dGMatrix_3D[1]);
						file.WriteString(p_str);

						file.WriteString(PAKS_CardV12_31_2);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dGMatrix_3D[2],Material.m_dGMatrix_3D[3],Material.m_dGMatrix_3D[4],Material.m_dThermal_cap);
						file.WriteString(p_str);

						//Stress-Stretch function
						HFunctions &StressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[6]);
						ExportPAK_Function(file, StressStretchFunc, Material.m_dGMatrix_3D[6], "Stress-Stretch function", "Stretch", "Stress");

						//Activation function
						HFunctions &ActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[7]);
						ExportPAK_Function(file, ActivationFunc, Material.m_dGMatrix_3D[7], "Activation function", "Time", "Activation");
					}
					break;
				case  PAKM_BIO32:
					{
						file.WriteString(PAKS_CardH12_32);

						file.WriteString(PAKS_CardV12_32_1);
						file.WriteString(PAKS_CardV12_32_2);
						p_str.Format("%10.4.1e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						file.WriteString(PAKS_CardV12_32_3);
						p_str.Format("%10.4.1e",Material.m_dAlpha[0]);
						file.WriteString(p_str);
						p_str.Format("%10.4.1e\n",Material.m_dAlpha[1]);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_32_4);
						p_str.Format("%10.4.1e",Material.m_dAlpha[2]);
						file.WriteString(p_str);
						p_str.Format("%10.4.1e\n",Material.m_dAlpha[3]);
						file.WriteString(p_str);

					}
					break;				
				case  PAKM_TENSEGRITY:
					{
						file.WriteString(PAKS_CardH12_41);

						file.WriteString(PAKS_CardV12_41_1);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0], Material.m_dNu[0], Material.m_dK[0]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_BIAXIAL:
					{
						UINT i, nPointCount = 13;
						MyString str;
						file.WriteString(PAKS_CardH12_36);

						file.WriteString(PAKS_CardV12_36_1);
						p_str.Format("%10.4.1e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_36_2);
						p_str.Format("%10.4.1e\n",Material.m_dNu[0]);
						file.WriteString(p_str);
						
						//Uniaxial stress-stretch function
						HFunctions &UniaxialFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(PAKS_CardV12_36_3);

						nPointCount = UniaxialFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UniaxialFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UniaxialFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

						//Biaxial stress-stretch function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(PAKS_CardV12_36_4);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UnloadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[1];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}
						
					}
					break;
				case  PAKM_MODEL_37:
					{
						file.WriteString(PAKS_CardH12_37);
						file.WriteString(PAKS_CardV12_37_1);
						file.WriteString(PAKS_CardV12_37_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_37_3);
						file.WriteString(PAKS_CardV12_37_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Loading stress-stretch function
						UINT i, nPointCount;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(PAKS_CardV12_37_5);
						file.WriteString(PAKS_CardV12_37_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						file.WriteString(PAKS_CardV12_37_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = LoadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

						//Unloading stress-stretch function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(PAKS_CardV12_37_8);
						file.WriteString(PAKS_CardV12_37_9);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_37_10);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UnloadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[1];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}
					}
					break;				
				case  PAKM_MODEL_38:
					{
						file.WriteString(CardH12_38);
						file.WriteString(CardV12_38_3);
						file.WriteString(CardV12_38_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Stress-stretch function
						UINT i, nPointCount;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(CardV12_38_5);
						file.WriteString(CardV12_38_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						file.WriteString(CardV12_38_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = LoadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

					}
					break;
				case  PAKM_MODEL_39:
					{
						file.WriteString(CardH12_39);
						file.WriteString(CardV12_39_1);
						file.WriteString(CardV12_39_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(CardV12_39_3);
						file.WriteString(CardV12_39_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Loading stress-stretch function
						UINT i, nPointCount;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(CardV12_39_5);
						file.WriteString(CardV12_39_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						file.WriteString(CardV12_39_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = LoadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

						//Unloading stress-stretch function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(CardV12_39_8);
						file.WriteString(CardV12_39_9);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(CardV12_39_10);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UnloadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[1];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}
					}
					break;				
				case  PAKM_DELFINO_SEF_2D:
					{
						file.WriteString(PAKS_CardH12_81);
						file.WriteString(PAKS_CardV12_81_1);
						p_str.Format("%10.4.2e%10.4.2e\n",Material.m_dE[0],Material.m_dNu[0]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_FUNG_SEF:
					{
						file.WriteString(PAKS_CardH12_83);

						file.WriteString(PAKS_CardV12_83_1);
						p_str.Format("%10.4.2e%10.4.1e%10.4.2e%10.4.1e\n",Material.m_dE[0], Material.m_dNu[0], Material.m_dNu[1], Material.m_dNu[2]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_USER_SUPPLIED:
					{
						file.WriteString(PAKS_CardH12_92);

						switch( PAK_Material.m_nSubModel )
						{
						case PAKM_USER_SUPPLIED_HILLS:
						{
							file.WriteString(PAKS_CardV12_92_1_1);
							p_str.Format("%5u%5u%5u\n", PAKM_USER_SUPPLIED_HILLS, Material.m_uNonlin_type, Material.m_uFAlpha[0]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_1_2);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0],Material.m_dNu[0],Material.m_dGMatrix_3D[0],Material.m_dGMatrix_3D[1]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_1_3);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dGMatrix_3D[2],Material.m_dGMatrix_3D[3],Material.m_dGMatrix_3D[4],Material.m_dThermal_cap);
							file.WriteString(p_str);

							//Stress-Stretch function
							HFunctions &StressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[6]);
							ExportPAK_Function(file, StressStretchFunc, Material.m_dGMatrix_3D[6], "Stress-Stretch function", "Stretch", "Stress");

							//Activation function
							HFunctions &ActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[7]);
							ExportPAK_Function(file, ActivationFunc, Material.m_dGMatrix_3D[7], "Activation function", "Time", "Activation");

							//Fatigue function
							HFunctions &FatigueFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[8]);
							ExportPAK_Function(file, FatigueFunc, Material.m_dGMatrix_3D[8], "Fatigue function", "Time", "Fitness level");

							//Recovery function
							HFunctions &RecoveryFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[9]);
							ExportPAK_Function(file, RecoveryFunc, Material.m_dGMatrix_3D[9], "Recovery function", "Time", "Fitness level");

							break;
						}
						case PAKM_USER_SUPPLIED_HILLS_2FIBER:
						{
							file.WriteString(PAKS_CardV12_92_2_1);
							p_str.Format("%5u%5u%5u\n", PAKM_USER_SUPPLIED_HILLS_2FIBER, Material.m_uNonlin_type, PAKS_HILLS_FIBER_AXIS);
							file.WriteString(p_str);

							//Slow fiber doubles
							file.WriteString(PAKS_CardV12_92_2_11);

							file.WriteString(PAKS_CardV12_92_2_2);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[0],Material.m_dGMatrix_3D[1],
								Material.m_dGMatrix_3D[2],Material.m_dGMatrix_3D[3]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_2_3);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[4],0.0,0.0,0.0);
							file.WriteString(p_str);

							//Fast fiber doubles
							file.WriteString(PAKS_CardV12_92_2_12);

							file.WriteString(PAKS_CardV12_92_2_2);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[10],Material.m_dGMatrix_3D[11],
								Material.m_dGMatrix_3D[12],Material.m_dGMatrix_3D[13]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_2_3);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[14],0.0,0.0,0.0);
							file.WriteString(p_str);

							//Common doubles
							file.WriteString(PAKS_CardV12_92_2_4);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0],Material.m_dNu[0],Material.m_dThermal_cap);
							file.WriteString(p_str);

							//Slow fiber curves

							//Stress-Stretch function
							HFunctions &SlowStressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[6]);
							ExportPAK_Function(file, SlowStressStretchFunc, Material.m_dGMatrix_3D[6], "Slow fiber Stress-Stretch function", "Stretch", "Stress");

							//Activation function
							HFunctions &SlowActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[7]);
							ExportPAK_Function(file, SlowActivationFunc, Material.m_dGMatrix_3D[7], "Slow fiber Activation function", "Time", "Activation");

							//Fatigue function
							HFunctions &SlowFatigueFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[8]);
							ExportPAK_Function(file, SlowFatigueFunc, Material.m_dGMatrix_3D[8], "Slow fiber Fatigue function", "Time", "Fitness level");

							//Recovery function
							HFunctions &SlowRecoveryFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[9]);
							ExportPAK_Function(file, SlowRecoveryFunc, Material.m_dGMatrix_3D[9], "Slow fiber Recovery function", "Time", "Fitness level");


							//Fast fiber curves

							//Stress-Stretch function
							HFunctions &FastStressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[16]);
							ExportPAK_Function(file, FastStressStretchFunc, Material.m_dGMatrix_3D[16], "Fast fiber Stress-Stretch function", "Stretch", "Stress");

							//Activation function
							HFunctions &FastActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[17]);
							ExportPAK_Function(file, FastActivationFunc, Material.m_dGMatrix_3D[17], "Fast fiber Activation function", "Time", "Activation");

							//Fatigue function
							HFunctions &FastFatigueFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[18]);
							ExportPAK_Function(file, FastFatigueFunc, Material.m_dGMatrix_3D[18], "Fast fiber Fatigue function", "Time", "Fitness level");

							//Recovery function
							HFunctions &FastRecoveryFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[19]);
							ExportPAK_Function(file, FastRecoveryFunc, Material.m_dGMatrix_3D[19], "Fast fiber Recovery function", "Time", "Fitness level");


							//Nodal variables
							file.WriteString(PAKS_CardV12_92_2_5);
							file.WriteString(PAKS_CardV12_92_2_6);
							for(UINT i=0;i<(UINT)m_NodArray.GetSize();i++)
							{
								HNodes &Node=m_NodArray[i];

								double dValue = 0.0;
								for(UINT j = 0; j < (UINT)m_LoadArray[0].m_NodalTemps.GetSize(); j++)
										{
											NodalTemp &nt = m_LoadArray[0].m_NodalTemps[j];
											if(nt.m_uNdtempID == Node.m_nID)
											{
												dValue = nt.m_dNdtemp;
												break;
											}
										}
								
								p_str.Format("%5u%10.6f\n", Node.m_nID, dValue);
								file.WriteString(p_str);
							}

							break;
						}
						default:
							ASSERT(FALSE);
						}
					}
					break;
				}

			}
		}
	}

	nModelCount = MaterialsInModel.GetCount();
	return(-1);
}

UINT CModelData::ExportPAKCS_Elements_S(MyFile& file,UINT &nElemGroupCount,MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap,CPakExpOption *peo)
{
	MyString str;
	UINT i,j,k;
	//UINT uNMODM,uMatIID;
	MyArray <UINT,UINT&> ElNum;
	MyMap<UINT,UINT,UINT,UINT> PropIndex; // relation between Property ID and it's position in ElNum;
	HElement el;
	UINT uIETYP,uNETIP;
	PAK_MaterialKey mms;


	HProperties pr;
	HMaterial Material;
	for(i=0;i<(UINT)m_PropArray.GetSize();i++)	//Loop by properties (group of elements)
	{
		pr=m_PropArray[i];
		if((m_MaterialsArray.Get(pr.m_uMatIID)).m_uSubType == HMaterial::ST_PAK_POROUS_DEFORMABLE)	continue;
		else	nElemGroupCount++;

		FEMAP2PAK_MaterialMap.Lookup(pr.m_uMatIID, mms);	//Struktura cuva materijalni model i materijal
		switch (pr.m_Type)
		{
//****************************************************************************
//****************************** 1D Elementi *********************************
//****************************************************************************
		case HProperties::PT_ROD: case HProperties::PT_BEAM:
			{
				 //Card /13/
				UINT uNE2=0;
				
				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
					if(m_ElArray[j].m_uPropID==pr.m_nID) 
					{
						uNE2++;
					}
				 if(uNE2>0)
				 {
				 if(pr.m_Type==HProperties::PT_ROD)
				 {
					 uNETIP=PAK_TRUSS;

					 file.WriteString(PAKS_CardH13);
					 file.WriteString(PAKS_CardV13);
 			 		 
//					 NMODM=m_PakGeneral.GetMaterialModel(uNETIP);

 
					 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
					 uNETIP,uNE2,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
					 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
					 file.WriteString(str);

					 file.WriteString(PAKS_CardH13_1);
					 file.WriteString(PAKS_CardH13_1_a_1);
					 file.WriteString(PAKS_CardV13_1_a_2);
					 file.WriteString(PAKS_CardH13_1_b_1);
					 file.WriteString(PAKS_CardV13_1_b_2);

					 UINT nElemCounter = 0;
					 for(j=0;j<(UINT)m_ElArray.GetSize();j++)	//Loop by elements
					 if(m_ElArray[j].m_uPropID==pr.m_nID)
						{
							el=m_ElArray[j];
//							pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

							if(el.m_uTopology==FETO_LINE)
							{
				//				str.Format("%5u%5u%5u%10.6f%5u\n",
				//					el.m_nID,mms.m_nMaterial,PAKS_ISNA,pr.m_dValue[0],PAKS_KORC);
								nElemCounter++;
								str.Format("%5u%5u%5u%10.6f%5u\n",
									nElemCounter,mms.m_nMaterial,PAKS_ISNA,pr.m_dValue[0],PAKS_KORC);
								file.WriteString(str);

								for(k=0;k<FEMAP_Topology_NodeCount[el.m_uTopology];k++) 
								{
									str.Format("%5u",el.m_uNode[k]);
									file.WriteString(str);
								}
								file.WriteString("\n");
							}
						}
				 }
				 else if(pr.m_Type==HProperties::PT_BEAM)
				 {
					 uNETIP=PAK_THINWALED_B;

					 file.WriteString(PAKS_CardH13);
					 file.WriteString(PAKS_CardV13);

//					 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);
					 
					 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
					 uNETIP,uNE2,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,
					 PAKS_INDDTH,PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
					 file.WriteString(str);

					 file.WriteString(PAKS_CardH13_6);
					 file.WriteString(PAKS_CardH13_6_a_1);
					 file.WriteString(PAKS_CardV13_6_a_2);
  					 str.Format("%5u%5u%5u%5u%10.6f%10.6f%10.6f%10.6f%10.6f%5u\n",
									PAKS_NT,PAKS_NELM,PAKS_NTIP,PAKS_NKAR,PAKS_OY,PAKS_OZ,
									PAKS_YM,PAKS_ZM,PAKS_ALFAU,PAKS_INDOF);
					 file.WriteString(str);

// 					 pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

					 file.WriteString(PAKS_CardH13_6_b_1);
					 file.WriteString(PAKS_CardV13_6_b_2);
  					 str.Format("%10.6f%10.6f%10.6f%10.6f",
									pr.m_dValue[0], pr.m_dValue[1], pr.m_dValue[2], pr.m_dValue[4]);
					 file.WriteString(str);
  					 str.Format("%10.6f%10.6f%10.6f\n", PAKS_ALFA,PAKS_CAPAY,PAKS_CAPAZ);
					 file.WriteString(str);

 					 file.WriteString(PAKS_CardH13_6_h_1);
					 file.WriteString(PAKS_CardV13_6_h_2);

					 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
					 if(m_ElArray[j].m_uPropID==pr.m_nID)
						{
							el=m_ElArray[j];
//							pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

							if(el.m_uTopology==FETO_LINE)
							{
								str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
									el.m_nID,el.m_uNode[0],el.m_uNode[1],
									PAKS_NTIP_13_6,mms.m_nMaterial,PAKS_NAP_13_6,0,el.m_dOrient[0],el.m_dOrient[1],el.m_dOrient[2]);
								file.WriteString(str);
							}
						}
				 
				 }
				 }
			}
			break;


//****************************************************************************
//****************************** 2D Elementi *********************************
//****************************************************************************
		case HProperties::PT_SHEAR_LIN:case HProperties::PT_SHEAR_PAR:
		case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:
		case HProperties::PT_BENDING_LIN:case HProperties::PT_BENDING_PAR:
		case HProperties::PT_PLATE_LIN:case HProperties::PT_PLATE_PAR:
		case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR:
		case HProperties::PT_LAMINATE_LIN:case HProperties::PT_LAMINATE_PAR:
		case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR:
			{
				UINT uNE4=0,uNE3=0;

				switch (pr.m_Type)
				{
					case HProperties::PT_SHEAR_LIN:case HProperties::PT_SHEAR_PAR: uIETYP=4;
						break;
					case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:
					case HProperties::PT_BENDING_LIN: case HProperties::PT_BENDING_PAR: uIETYP=0;
						break;
					case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR: uIETYP=2;
						break;
					case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR: uIETYP=1;
						break;
					default:
						uIETYP=0;
				}

				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						if(m_ElArray[j].m_uTopology==FETO_QUAD4 || m_ElArray[j].m_uTopology==FETO_QUAD8) uNE4++;
						else uNE3++;
					}

				if(uNE4>0)	//Cetvorougaoni 2D Element
				{
				 //Card /13/
				 if(pr.m_Type==HProperties::PT_BENDING_LIN || pr.m_Type==HProperties::PT_BENDING_PAR ||
					pr.m_Type==HProperties::PT_PLATE_LIN || pr.m_Type==HProperties::PT_PLATE_PAR ||
					pr.m_Type==HProperties::PT_LAMINATE_LIN || pr.m_Type==HProperties::PT_LAMINATE_PAR) uNETIP=(peo->m_bShellAsBatheDvorkin ? PAK_SHELL_BD : PAK_ISO_SHELL); 
				 else uNETIP=PAK_ISO_2D;

				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//					 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE4,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);

				 // Beta - angle of first material axis
				 double dBeta = 0.0;
				 if( pr.m_dValue.GetSize() >= 2 ) dBeta = pr.m_dValue[1];

				 if(uNETIP==PAK_ISO_2D)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,dBeta,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 else
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5d%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					  PAKS_NGAUSX2,PAKS_NGAUSY2,(peo->m_bDrillShell ? -2 : PAKS_NGAUSZ2),
					  PAKS_MSET,dBeta,PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8)
						{
							UINT uIPGS=1;

							if( uIETYP == 0 ) //Plane stress
							{
								str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
									el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,uIPGS,pr.m_dValue[0],
									PAKS_KORC,PAKS_BTH,PAKS_DTH);
							}
							else
							{
								str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
									el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,uIPGS,0.0,
									PAKS_KORC,PAKS_BTH,PAKS_DTH);
							}

							file.WriteString(str);

							for(k=0;k<FEMAP_Topology_NodeCount[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}

				if(uNE3>0)	// Trougaoni 2D Element
				{
				 if(uNE4>0) nElemGroupCount++;
				 //Card /13/
				 if(pr.m_Type==HProperties::PT_BENDING_LIN || pr.m_Type==HProperties::PT_BENDING_PAR ||
					pr.m_Type==HProperties::PT_PLATE_LIN || pr.m_Type==HProperties::PT_PLATE_PAR ||
					pr.m_Type==HProperties::PT_LAMINATE_LIN || pr.m_Type==HProperties::PT_LAMINATE_PAR) uNETIP=PAK_ISO_TRI_SHELL; 
				 else uNETIP=PAK_ISO_TRI;

				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE3,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);

				 if(uNETIP==PAK_ISO_TRI)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,PAKS_BETA,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 else
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_NGAUSZ2,PAKS_MSET,PAKS_BETA,PAKS_MSLOJ,
					PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_TRI3 || el.m_uTopology==FETO_TRI6)
						{
							str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,pr.m_dValue[0],
								PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<FEMAP_Topology_NodeCount[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[k]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}				

			}
			break;
//****************************************************************************
// ****************************** 3D Elementi ********************************
//****************************************************************************
		case HProperties::PT_3D_LIN:case HProperties::PT_3D_PAR:
			{
				UINT uNE_3D=0,uNE_PRISM=0,uNE_TETRA=0;;

				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						switch (el.m_uTopology)
						{
							case FETO_BRICK8:case FETO_BRICK20: uNE_3D++;
								break;
							case FETO_WEDGE6:case FETO_WEDGE15: uNE_PRISM++;
								break;
							case FETO_TETRA4:case FETO_TETRA10: uNE_TETRA++;
								break;
						}
					}

				if(uNE_3D>0)	// 3D Element
				{
				 //Card /13/
				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 PAK_ISO_3D,uNE_3D,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,PAKS_INDKOV,
				 PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);
				 
				 file.WriteString(PAKS_CardH13_3);
				 file.WriteString(PAKS_CardV13_3_a_1);
				 file.WriteString(PAKS_CardV13_3_a_2);
				 str.Format("%5u%5u%5u   %10.6f                              %5d\n",
					PAKS_NGAUSX3,PAKS_NGAUSY3,PAKS_NGAUSZ3,PAKS_BETA, pr.m_IncompatibleModes);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_3_b_1);
				 file.WriteString(PAKS_CardV13_3_b_2);
				 file.WriteString(PAKS_CardV13_3_c_1);
				 file.WriteString(PAKS_CardV13_3_c_2);
				
				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 {
				    if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];
						double dBirth = 0.0;

						if(el.m_uTopology==FETO_BRICK8 || el.m_uTopology==FETO_BRICK20)
						{
							//Check if there is additional data for element
							if(mms.m_nModel == PAKM_USER_SUPPLIED && mms.m_nSubModel == PAKM_USER_SUPPLIED_HILLS_2FIBER)
							{
								for(UINT k = 0; k < (UINT)m_LoadArray[0].m_StructLoads.GetSize(); k++)
								{
									StructLoad &sl = m_LoadArray[0].m_StructLoads[k];
									if(sl.m_uLoadtype == StructLoad::LT_ELEM_HEAT_FL && sl.m_uLoadID == el.m_nID)
									{
										dBirth = sl.m_dValue[0];
										break;
									}
								}
							}

							str.Format("%5u%5u%5u%5u%5u%5u          %10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,PAKS_KORC,dBirth,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<8;k++) 
							{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder3D[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
							if(el.m_uTopology==FETO_BRICK20)
							 for(k=8;k<20;k++) 
							 {
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder3D[k]]);
								file.WriteString(str);
							 }
							file.WriteString("\n");
						}
					}
				 }
				}
				
				if(uNE_PRISM>0)	// 3D Prismatic Element
				{
//				 UINT node_order[15]={5,6,4,1,2,0,17,18,16,9,10,8,13,14,12};
				 UINT node_order[15]={4,5,6,0,1,2,16,17,18,8,9,10,12,13,14};
				 
				 if(uNE_3D>0) nElemGroupCount++;
				 //Card /13/
				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);
				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 PAK_ISO_PRISM,uNE_PRISM,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,
				 PAKS_INDDTH,PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);
				 
				 file.WriteString(PAKS_CardH13_3);
				 file.WriteString(PAKS_CardV13_3_a_1);
				 file.WriteString(PAKS_CardV13_3_a_2);
				 str.Format("%5u%5u%5u   %10.6f                              %5d\n",
					PAKS_NGAUSX3,PAKS_NGAUSY3,PAKS_NGAUSZ3,PAKS_BETA, pr.m_IncompatibleModes);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_3_b_1);
				 file.WriteString(PAKS_CardV13_3_b_2);
				 file.WriteString(PAKS_CardV13_3_c_1);
				 file.WriteString(PAKS_CardV13_3_c_2);
				
				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 {
					if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_WEDGE6 || el.m_uTopology==FETO_WEDGE15)
						{
							str.Format("%5u%5u%5u%5u%5u%5u          %10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<6;k++) 
							{
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
							if(el.m_uTopology==FETO_WEDGE15)
							 for(k=6;k<15;k++) 
							 {
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							 }
							file.WriteString("\n");
						}
					}
				 }
				}
			
				if(uNE_TETRA>0)	// 3D Tetra Element
				{
//				 UINT node_order[10]={4,1,2,0,9,10,8,13,14,12};
				 UINT node_order[10]={4,0,1,2,8,9,10,12,13,14};
				 
				 if(uNE_3D>0 || uNE_PRISM>0) nElemGroupCount++;
				 //Card /13/
				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 PAK_ISO_TETRA,uNE_TETRA,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,
				 PAKS_INDDTH,PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);
				 
				 file.WriteString(PAKS_CardH13_3);
				 file.WriteString(PAKS_CardV13_3_a_1);
				 file.WriteString(PAKS_CardV13_3_a_2);
				 str.Format("%5u%5u%5u   %10.6f                              %5d\n",
					PAKS_NGAUSX3,PAKS_NGAUSY3,PAKS_NGAUSZ3,PAKS_BETA, pr.m_IncompatibleModes);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_3_b_1);
				 file.WriteString(PAKS_CardV13_3_b_2);
				 file.WriteString(PAKS_CardV13_3_c_1);
				 file.WriteString(PAKS_CardV13_3_c_2);
				
				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 {
				    if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_TETRA4 || el.m_uTopology==FETO_TETRA10)
						{
							str.Format("%5u%5u%5u%5u%5u%5u          %10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<4;k++) 
							{
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
							if(el.m_uTopology==FETO_TETRA10)
							 for(k=4;k<10;k++) 
							 {
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							 }
							file.WriteString("\n");
						}
					}
				 }
				}
			}
			break;

		case HProperties::PT_RIGID_BODY:
			{
				nElemGroupCount--;
			}
		}
	}

	return(-1);
}

UINT CModelData::ExportPAKCS_TimeFunctions(MyFile& file)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT i,j,uMAXTFT=0;

	//Check the total number of time functions
	UINT nTimeFunctionCount = 0;
	for(i=0;i<(UINT)m_FunctionsArray.GetSize();i++)
	{
		if(m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_VS_TIME || m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME)
			nTimeFunctionCount++;
	}


	if(nTimeFunctionCount==0)
	{
		HFunctions new_function;
		FunctionEntry fun_entry;

		fun_entry.m_dX=0.;
		fun_entry.m_dY=1.;
		new_function.m_FunctionEntry.Add(fun_entry);
		fun_entry.m_dX=10000.;
		fun_entry.m_dY=1.;
		new_function.m_FunctionEntry.Add(fun_entry);

		new_function.m_nID = 1;
		new_function.m_uFunc_type = HFunctions::FT_VS_TIME;

		m_FunctionsArray.Add(new_function);
		nTimeFunctionCount++;
	}

	//Determine maximum number of points
	for(i=0;i<(UINT)m_FunctionsArray.GetSize();i++)
	{
		if((m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_VS_TIME) || (m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME))
		{
			if((UINT)m_FunctionsArray[i].m_FunctionEntry.GetSize()>uMAXTFT)
				uMAXTFT=m_FunctionsArray[i].m_FunctionEntry.GetSize();
		}
	}

	file.WriteString(PAKC_CardH13);
	file.WriteString(PAKC_CardV13);
	str.Format("%5u%5u\n", nTimeFunctionCount, uMAXTFT);
	file.WriteString(str);
	file.WriteString(PAKC_CardH13_1);
	UINT nPAKFuncID = 0;
	for(i = 0; i < (UINT)m_FunctionsArray.GetSize(); i++)
	{
		if((m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_VS_TIME) || (m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME))
		{
			nPAKFuncID++;
			file.WriteString(PAKC_CardV13_1_a_1);
			file.WriteString(PAKC_CardV13_1_a_2);
//			str.Format("%5u%5u\n",m_FunctionsArray[i].m_nID,m_FunctionsArray[i].m_FunctionEntry.GetSize());
			str.Format("%5u%5u\n",nPAKFuncID,m_FunctionsArray[i].m_FunctionEntry.GetSize());
			file.WriteString(str);
			file.WriteString(PAKC_CardV13_1_b_1);
			file.WriteString(PAKC_CardV13_1_b_2);
			for(j=0;j<(UINT)m_FunctionsArray[i].m_FunctionEntry.GetSize();j++)
			{
				p_str.Format("%10.3.2e%10.3.2e\n",m_FunctionsArray[i].m_FunctionEntry[j].m_dX,
											m_FunctionsArray[i].m_FunctionEntry[j].m_dY);
				file.WriteString(p_str);
			}
		}
	}
	return (-1);
}

UINT CModelData::ExportPAKCS_BoundaryConditions( MyFile& file )
{
	MyString str;
	MyStringAdvanced p_str;

	UINT nPresureCount2D=0, nPresureCount3D=0, nCurrentDensityCount2D=0, nCurrentDensityCount3D=0, i, j, k;
	
	HLoads lo;
	StructLoad sl;
	HElement el;

	UINT surface_nodes_3d[6][8]={   {0,3,2,1,11,10,9,8},
									{4,5,6,7,16,17,18,19},
									{0,1,5,4,8,13,16,12},
									{1,2,6,5,9,14,17,13},
									{2,3,7,6,10,15,18,14},
									{3,0,4,7,11,12,19,15}	};


	UINT surface_nodes_2d[4][3]={   {0,1,4},
									{1,2,5},
									{2,3,6},
									{3,0,7}	};

	if(m_LoadArray.GetSize()==0) 
	{
		//AfxMessageBox(PAKS_NO_LOADS);
		printf(PAKS_NO_LOADS);
		str.Format("\n");
		file.WriteString (str);

		return(0);
	}
	lo = m_LoadArray[0];	//Za sada samo prvi set

	for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
	{
		sl = lo.m_StructLoads[i];
		switch(sl.m_uLoadtype)
		{
		case StructLoad::LT_ELEM_PRESS:
			{
				j = sl.m_uDof_face[0] - 1;
				if(fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					if(j < 2) nPresureCount3D++;
					else
					{
						el=m_ElArray.Get(sl.m_uLoadID);
						if(el.m_uTopology==FETO_BRICK8 || el.m_uTopology==FETO_BRICK20 || el.m_uTopology==FETO_BRICK9) nPresureCount3D++;
						else nPresureCount2D++;
					}
				}
			}
		break;
		case StructLoad::LT_ELEM_CURRENT_DENSITY:
			{
				j = sl.m_uDof_face[0] - 1;
				if(fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					if(j < 2) nCurrentDensityCount3D++;
					else
					{
						el=m_ElArray.Get(sl.m_uLoadID);
						if(el.m_uTopology==FETO_BRICK8 || el.m_uTopology==FETO_BRICK20 || el.m_uTopology==FETO_BRICK9) nCurrentDensityCount3D++;
						else nCurrentDensityCount2D++;
					}
				}
			}
		break;
		}
	}

	//	Card /11/
	file.WriteString(PAKC_CardH11);
	file.WriteString(PAKC_CardV11);

	// Line pressure
	if(nPresureCount2D > 0)
	{
		UINT nPresureOnSurface = 0;
		str.Format("%5u%5u\n", nPresureCount2D, nPresureOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_PRESS)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0] - 1;
				if(j>1 && fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_QUAD4: case FETO_QUAD5: case FETO_QUAD8: case FETO_QUAD9:
						{
							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k = 0; k < 2; k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_2d[j-2][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	// Surface pressure
	else if(nPresureCount3D > 0)
	{
		UINT nPresureOnSurface = 0;
		str.Format("%5u%5u\n", nPresureCount3D, nPresureOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_PRESS)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0]-1;
				if(fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_BRICK8: case FETO_BRICK9: case FETO_BRICK20:
						{
							//VLADA 2006-10-23 Eksportovanje pritiska u PAKC

							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k=0;k<(UINT)(el.m_uTopology==FETO_BRICK9 ? 4:8);k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_3d[j][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	// Line current density
	else if(nCurrentDensityCount2D > 0)
	{
		UINT nCurrentDensityOnSurface = 1;
		str.Format("%5u%5u\n", nCurrentDensityCount2D, nCurrentDensityOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_CURRENT_DENSITY)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0] - 1;
				if(fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_QUAD4: case FETO_QUAD5: case FETO_QUAD8: case FETO_QUAD9:
						{
							//VLADA 2006-10-23 Eksportovanje pritiska u PAKC

							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k = 0; k < 2; k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_2d[j-2][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	// Surface current density
	else if (nCurrentDensityCount3D > 0)
	{
		UINT nCurrentDensityOnSurface = 1;
		str.Format("%5u%5u\n", nCurrentDensityCount3D, nCurrentDensityOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_CURRENT_DENSITY)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0]-1;
				if(fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_BRICK8: case FETO_BRICK9: case FETO_BRICK20:
						{
							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k=0;k<(UINT)(el.m_uTopology==FETO_BRICK9 ? 4:8);k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_3d[j][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	else
	{
		str.Format("    0    0\n");
		file.WriteString (str);
	}
	return (-1);
}

UINT CModelData::ExportPAKCS_Forces(MyFile& file)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT uNCF=0, uNPP2=0, uNPP3=0, uNZADP=0, nElectricCurrent=0, i, j;
	HLoads lo;
	StructLoad sl;
	HElement el;

	
	if(m_LoadArray.GetSize()==0) 
	{
		//AfxMessageBox(PAKS_NO_LOADS);
		printf(PAKS_NO_LOADS);
		str.Format("\n");
		file.WriteString (str);

		return(0);
	}
	lo = m_LoadArray[0];	//Za sada samo prvi set

	for( i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
	{
		sl = lo.m_StructLoads[i];

		switch(sl.m_uLoadtype)
		{
		case StructLoad::LT_NODAL_FORCE:
			{
				for(j = 0; j < 6; j++)
				{
					if( sl.m_uDof_face[j] && (fabs(sl.m_dValue[j]) >= PAKS_LOAD_FORCE_TOL) )
						uNCF++;
				}
				break;
			}
		case StructLoad::LT_NODAL_ELECTRIC_CURRENT:
			{
				for(j = 0; j < 6; j++)
				{
					if( sl.m_uDof_face[j] && (fabs(sl.m_dValue[j]) >= PAKS_LOAD_FORCE_TOL) )
						nElectricCurrent++;
				}
				break;
			}
		}
	}

	if(uNCF > 0)
	{
		str.Format("%5u\n", uNCF);
		file.WriteString(str);
		file.WriteString(PAKC_CardH14_1);
		file.WriteString(PAKC_CardV14_1);
		for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
		{
			sl=lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_NODAL_FORCE)
			{
				for(j = 0; j < 6; j++)
				{
					if(sl.m_uDof_face[j] && fabs(sl.m_dValue[j])>=PAKS_LOAD_FORCE_TOL)
					{
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = m_FunctionsArray.FindIndex(nc,nc);
						ASSERT(bFound);
						p_str.Format( "%5u%5u%5u%10.4.1e\n", sl.m_uLoadID, j+1, nc+1, sl.m_dValue[j] );
						file.WriteString(p_str);
					}
				}
			}
		}
	}
	else if(nElectricCurrent > 0)
	{
		str.Format("%5u\n", nElectricCurrent);
		file.WriteString(str);
		file.WriteString(PAKC_CardH14_1);
		file.WriteString(PAKC_CardV14_1);
		for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
		{
			sl=lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_NODAL_ELECTRIC_CURRENT)
			{
				for(j = 0; j < 6; j++)
				{
					if(sl.m_uDof_face[j] && fabs(sl.m_dValue[j]) >= PAKS_LOAD_FORCE_TOL)
					{
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = m_FunctionsArray.FindIndex(nc,nc);
						ASSERT(bFound);
						p_str.Format( "%5u%5u%5u%10.4.1e\n", sl.m_uLoadID, j+11, nc+1, sl.m_dValue[j] );
						file.WriteString(p_str);
					}
				}
			}
		}
	}
	else
	{
		str.Format("    0\n");
		file.WriteString (str);
	}

	return(-1);
}

UINT CModelData::ExportPAKCS_PrescribedValues(MyFile& file)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT nDisplacementCount=0, nVelocityCount=0, nPressureCount=0, nPotentialCount=0,i,j;
	HLoads lo;
	StructLoad sl;
	HElement el;

	
	if(m_LoadArray.GetSize()==0) 
	{
		//AfxMessageBox(PAKS_NO_LOADS);
		printf(PAKS_NO_LOADS);
		str.Format("\n");
		file.WriteString (str);

		return(0);
	}
	lo = m_LoadArray[0];	//Za sada samo prvi set

	// Prebrojavanje
	for( i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
	{
		sl = lo.m_StructLoads[i];

		switch(sl.m_uLoadtype)
		{
		case StructLoad::LT_NODAL_DISPL:
			{
				for(j = 0; j < 3; j++)
				{
					if( fabs(sl.m_dValue[j]) && sl.m_uDof_face[j])
						nDisplacementCount++;
				}
				break;
			}
		case StructLoad::LT_NODAL_VELOCITY:
			{
				for(j = 0; j < 3; j++)
				{
					if( fabs(sl.m_dValue[j]) )
						nVelocityCount++;
				}
				break;
			}
		case StructLoad::LT_NODAL_STATIC_FLUID_PRESSURE:
			{
				if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL )
					nPressureCount++;
				break;
			}
		case StructLoad::LT_NODAL_ELECTRIC_POTENTIAL:
			{
				if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_NDISP_TOL )
					nPotentialCount++;
				break;
			}
		}
	}

	// Export prescribed values
	UINT nPrescribedValuesCount = nDisplacementCount + nVelocityCount + nPressureCount + nPotentialCount;
	if( nPrescribedValuesCount > 0 )
	{
		file.WriteString(PAKC_CardH9);
		str.Format("%5u\n", nPrescribedValuesCount);
		file.WriteString(str);
		file.WriteString(PAKC_CardH9_1);

		UINT nCounter = 1;
		for( i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];

			UINT nfun;
			nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
			bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
			ASSERT(bFound);
		
			switch(sl.m_uLoadtype)
			{
			case StructLoad::LT_NODAL_DISPL:
				{
					for(j = 0; j < 3; j++)
					{
						if( fabs(sl.m_dValue[j]) >= PAKS_LOAD_NDISP_TOL && sl.m_uDof_face[j])
						{

							str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, j + 1, nfun+1, sl.m_dValue[j]);
							file.WriteString(str);
						}
					}
					break;
				}
			case StructLoad::LT_NODAL_VELOCITY:
				{
					for(j = 0; j < 3; j++)
					{
						if( fabs(sl.m_dValue[j]) >= PAKS_LOAD_NDISP_TOL )
						{
							str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, j + 5, nfun+1, sl.m_dValue[j]);
							file.WriteString(str);
						}
					}
					break;
				}
			case StructLoad::LT_NODAL_STATIC_FLUID_PRESSURE:
				{
					if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL )
					{
						UINT nINDPR = 4;
						str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, nINDPR, nfun+1, sl.m_dValue[0]);
						file.WriteString(str);
					}
					break;
				}
			case StructLoad::LT_NODAL_ELECTRIC_POTENTIAL:
				{
					if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL )
					{
						UINT nINDPR = 8;
						str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, nINDPR, nfun+1, sl.m_dValue[0]);
						file.WriteString(str);
					}
					break;
				}
			}
		}
	}
	else
	{
		str.Format("    0\n");
		file.WriteString (str);
	}

	return(-1);
}
/*
UINT CModelData::ExportPAK_Loads_FindType(HMaterial* mat, int uMODEL1)
{
	if (m_PakGeneral.GetAnalysisType()!=0) uMODEL1=5;

			switch (uMODEL1)
			{
			case  PAKM_ELASTIC_ISO:
				{
_label_elastic_iso:
					if (mat->m_dAlpha[0]!=0) goto _label_thermo_elastic_iso;
					uMODEL1=1;
				}
				break;
			case  PAKM_THERMO_ELASTIC_ISO:
				{
_label_thermo_elastic_iso:
					uMODEL1=3;
				}
				break;
			case PAKM_ELASTIC_ORTHO:
				{
					uMODEL1=2;
				}
			case  PAKM_MISES_PLASTIC:
				{
			 		if (mat->m_uNonlin_type==0) goto _label_elastic_iso;
				}
			}

	return uMODEL1;
}

UINT CModelData::ExportPAK_Function(MyFile &File, const HFunctions& Function, double dScaleFactor, const MyString& sTitle, const MyString& sXTitle, const MyString& sYTitle)
{
	MyStringAdvanced p_str;

	File.WriteString( MyString("C ") + sTitle + "\n");
	File.WriteString("C Point count\n");

	UINT nPointCount = Function.m_FunctionEntry.GetSize();
	p_str.Format("%5u\n", nPointCount);
	File.WriteString(p_str);


	File.WriteString(MyString("C ") + sXTitle + ", " + sYTitle + "\n");
	for(UINT i = 0; i < nPointCount; i++)
	{
		p_str.Format("%10.4.1e",Function.m_FunctionEntry[i].m_dX);
		File.WriteString(p_str);
		p_str.Format("%10.4.1e\n",Function.m_FunctionEntry[i].m_dY * dScaleFactor);
		File.WriteString(p_str);
	}

	return(0);
}
*/