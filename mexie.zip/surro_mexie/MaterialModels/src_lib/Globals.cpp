/*
 * Globals.cpp
 *
 *  Created on: Jul 22, 2013
 *      Author: anakaplarevic
 */

#include "Globals.h"
#include "MaterialModel.h"
#include "HuxleyParameters.h"
#include <stdio.h>
#include <stdlib.h>
#include <string>

// implements equations (10,11,12)
// from Hunter, Culloch: Modeling the mechanical properties of cardiac muscle
double CaToAct::Tref; 
double CaToAct::nref;
double CaToAct::pC50ref;
double CaToAct::beta0;
double CaToAct::beta1;
double CaToAct::beta2;
double CaToAct::getAct(double conc, double stretch)
{
	double n = nref*(1 + beta1*(stretch-1));
	double pC50 = pC50ref*(1+beta2*(stretch-1));
	double C50 = pow(10, 6-pC50);
	return (pow(conc,n)/(pow(conc,n) + pow(C50,n)));
}

//#include "HuxleyParameters.h"
//int Globals::step = 0;	// redni broj koraka simulacije u FEM-u
double	Globals::dt; // trajanje jednog simulacionog koraka
int Globals::dimOfSigmaVector;

CUDARunType Globals::cudaRunTip;
Scenario Globals::scenario;
ScheduleScenario Globals::scheduler;
int* Globals::cudaMPIID;
int* Globals::cudaMAX;
int Globals::numOfCUDA;
double* Globals::cudaV;
double Globals::mpiV;
_TIPF1 Globals::f1;
int Globals::nbins;
int Globals::iter;
std::string network;
std::string netname;
std::string simulation_id;
//MaterialModel** Globals::modeli=NULL;
//HuxleyParameters** Globals::parametri=NULL;

Globals* Globals::privateInstance = new Globals();
//HuxleyParameters* Globals::huxleyParameters =new HuxleyParameters();

Globals::Globals() {

	nbins  = 10;
/**/
	use_surro = 0; 
	use_time_series  = 0;
	fnet.open("network.txt");
	getline(fnet, network);
	getline(fnet, netname);
	fnet.close();
	fnet.open("simulation_id.txt");
	getline(fnet, simulation_id);
	fnet.close();	
/**/	
	modeli=NULL;
    parametri=NULL;
    namestiMapu();
 //   Globals* g = Globals::getInstance();
    config_t cfg;
    const config_setting_t *setting1,*setting2, *setting3;
    double pom;
    long ipom;
//printf("Globals: pre config_init(&cfg)\n");
    config_init(&cfg);
//printf("Globals: posle config_init(&cfg)\n");
    char *sc;
    sc = (char*) malloc(sizeof(char)*50);

    if(!config_read_file(&cfg, CFGFAJL)) { printf("Globals.cpp : main() / Neuspesno otvaranje FEM_MM.cfg fajla\n"); config_destroy(&cfg); exit(-1);}
//printf("Globals: posle config_read()\n");
// FEM citaj
    if(config_lookup_float(&cfg, "FEM.dt", &pom)) dt=pom;  else fprintf(stderr, "No 'FEM.dt' setting in configuration file.\n");
    if(config_lookup_int(&cfg, "FEM.dimSigmaVector", &ipom)) dimOfSigmaVector=(int)ipom;  else fprintf(stderr, "No 'FEM.dimSigmaVector' setting in configuration file.\n");
    
//printf("Globals: posle FEM citaj\n");
// RUN citaj
    if(config_lookup_string(&cfg, "RUN.scenario", (const char**)&sc)) scenario=enumMap[sc];	 else fprintf(stderr, "Nema 'scenario' u konfiguracionom fajlu\n");
    // printf("RUN.scenario = %s %d\n",sc,enumMap[sc]);

    setting1 = config_lookup(&cfg, "RUN.gdeSuCude");
    int i,countGde = config_setting_length(setting1);
    setting2 = config_lookup(&cfg, "RUN.maxCude");
    int countMax = config_setting_length(setting2);
    setting3 = config_lookup(&cfg, "RUN.brzinaCude");
    int countV = config_setting_length(setting3);
    numOfCUDA = countGde;
    if(config_lookup_string(&cfg, "RUN.CUDARunType", (const char**)&sc)) cudaRunTip=enumCudaRunTip[sc];	 else fprintf(stderr, "Nema 'RUN.CUDARunType' u konfiguracionom fajlu\n");
    if(config_lookup_string(&cfg, "RUN.scheduleType", (const char**)&sc)) scheduler=enumScheduleScenario[sc];	 else fprintf(stderr, "Nema 'RUN.scheduleType' u konfiguracionom fajlu\n");
    if(config_lookup_float(&cfg, "RUN.brzinaMPI", &pom)) mpiV=pom;	 else fprintf(stderr, "Nema 'RUN.brzinaMPI' u konfiguracionom fajlu\n");
    if(config_lookup_int(&cfg, "RUN.Surro", &ipom)) use_surro = (int)ipom;  else fprintf(stderr, "No 'RUN.Surro' setting in configuration file.\n");
	if(config_lookup_int(&cfg, "RUN.CaConc", &ipom)) use_ca_conc = (int)ipom;  else fprintf(stderr, "No 'RUN.CaConc' setting in configuration file.\n");
	if(config_lookup_int(&cfg, "RUN.TimeSeries", &ipom)) use_time_series = (int)ipom;  else fprintf(stderr, "No 'RUN.TimeSeries' setting in configuration file.\n");
    
	if(use_ca_conc==1)
	{
		 if(config_lookup_float(&cfg, "CaToAct.Tref", &pom)) CaToAct::Tref=pom; else fprintf(stderr, "Nema 'CaToAct.Tref' u konfiguracionom fajlu\n");
		 if(config_lookup_float(&cfg, "CaToAct.nref", &pom)) CaToAct::nref=pom; else fprintf(stderr, "Nema 'CaToAct.nref' u konfiguracionom fajlu\n");
		 if(config_lookup_float(&cfg, "CaToAct.pC50ref", &pom)) CaToAct::pC50ref=pom; else fprintf(stderr, "Nema 'CaToAct.pC50ref' u konfiguracionom fajlu\n");		 
		 if(config_lookup_float(&cfg, "CaToAct.beta0", &pom)) CaToAct::beta0=pom; else fprintf(stderr, "Nema 'CaToAct.beta0' u konfiguracionom fajlu\n");		 
		 if(config_lookup_float(&cfg, "CaToAct.beta1", &pom)) CaToAct::beta1=pom; else fprintf(stderr, "Nema 'CaToAct.beta1' u konfiguracionom fajlu\n");
		 if(config_lookup_float(&cfg, "CaToAct.beta2", &pom)) CaToAct::beta2=pom; else fprintf(stderr, "Nema 'CaToAct.beta2' u konfiguracionom fajlu\n");
	}
	
	int *cudaMPIID_loc,*cudaMAX_loc;
    double *cudaV_loc;
    cudaMPIID_loc = (int*)malloc(sizeof(int)*countGde);
    cudaMAX_loc = (int*)malloc(sizeof(int)*countMax);
    cudaV_loc = (double*)malloc(sizeof(double)*countV);

    for (i = 0; i < countGde; i++) {
           cudaMPIID_loc[i]=(int)config_setting_get_int_elem(setting1, i);
           cudaMAX_loc[i]=(int)config_setting_get_int_elem(setting2, i);
           cudaV_loc[i]=config_setting_get_float_elem(setting3, i);
    }
    cudaMPIID=cudaMPIID_loc;
    cudaMAX=cudaMAX_loc;
    cudaV=cudaV_loc;

    config_destroy(&cfg);
}

void Globals::namestiMapu(){
    enumMap["Sekvencijalno"]=Sekvencijalno;
    enumMap["MPIparalelno"]=MPIparalelno;
    enumMap["CUDAjedna"]=CUDAjedna;
    enumMap["MPImixCUDA"]=MPImixCUDA;
    enumCudaRunTip["CUDARunThrust"]=CUDARunThrust;
    enumCudaRunTip["CUDARunCustom"]=CUDARunCustom;
    enumCudaRunTip["CUDARunCublas"]=CUDARunCublas;
    enumScheduleScenario["BasicSchedule"]=BasicSchedule;
    enumScheduleScenario["Zorki0"]=Zorki0;
 //   printf("enumMap[Sekvencijalno]=%d; enumMap[MPIparalelno]=%d\n",enumMap["Sekvencijalno"],enumMap["MPIparalelno"]);
}

Globals::~Globals() {
	// TODO Auto-generated destructor stub
}

Globals* Globals::getInstance()
{
	if (Globals::privateInstance == NULL) Globals::privateInstance = new Globals();
	return Globals::privateInstance;
}
