/*
 * MPIWorker.h
 *
 *  Created on: May 14, 2014
 *      Author: anakaplarevic
 */

#ifndef MPIWORKER_H_
#define MPIWORKER_H_

#include "MPIProcess.h"
class MMChunkCalculator;

class MPIWorker: public MPIProcess {
public:
	MMChunkCalculator *microModelChunk;

	MPIWorker(MMChunkCalculator* microModelChunk);
	virtual ~MPIWorker();
	void run();
	
	void createFileForChunk();
};

#endif /* MPIWORKER_H_ */
