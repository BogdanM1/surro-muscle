/*!
 * \file BlockIDs.h
 * Constants
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

#ifndef BLOCKIDS
	#define BLOCKIDS

/*
	//UNV Block IDs
	#define UBID_NODES							15
	#define UBID_ELEMENTS						71
	#define UBID_LOADS							407
	#define UBID_CONSTRAINTS					757	
	#define UBID_NODAL_RESULTS					55
	#define UBID_ELEMENT_RESULTS				57
*/
	//UNV Variable types
	/*#define UNV_VAR_ELEM_FORCES_2D			4
	#define UNV_VAR_NODAL_DISPLACEMENTS		8
	#define UNV_VAR_NODAL_VELOCITIES		11
	#define UNV_VAR_NODAL_POTENTIALS		35
	#define UNV_VAR_NODAL_POTENTIALS_FS		30
	*/

	typedef enum 
	{
		UNV_VAR_ELEM_STRESS				=2,
		UNV_VAR_ELEM_STRAIN				=3,
		UNV_VAR_ELEM_PLAST_STRAIN		=0,
		UNV_VAR_ELEM_FORCES_2D			=4,
		UNV_VAR_ELEM_VELOCITIES			=111,
		UNV_VAR_NODAL_TEMPERATURES		=5,
		UNV_VAR_NODAL_DISPLACEMENTS		=8,
		UNV_VAR_NODAL_VELOCITIES		=11,
		UNV_VAR_NODAL_APPLIED_FORCES	=4,
		UNV_VAR_NODAL_CONSTRAINT_FORCES	=32,
		UNV_VAR_NODAL_POTENTIALS		=35,
		UNV_VAR_NODAL_POTENTIALS_FS		=30,
		UNV_VAR_NODAL_ELECTRIC_POTENTIALS		=21,
		UNV_VAR_NODAL_SEEPAGE			=75,
		UNV_VAR_NODAL_SHEAR_STRESS		=12,
		UNV_VAR_NODAL_PRESSURE			=13,
		UNV_VAR_ELEM_FLUID_PRESSURE			=20,
		UNV_VAR_ELEM_SWELLING_PRESSURE			=22,
		UNV_VAR_NODAL_EIGENVECTORS		=6,
		UNV_VAR_NODAL_STREAM_FUNCTION	=135
	} UNV_VARIABLES;

/*
	//UNV Blocks
	#define UNV_BLOCK_BEGIN "    -1"
	#define UNV_BLOCK_END   "    -1"
*/
	//FEMAP Topology
	#define FETO_LINE		0
	#define FETO_TRI3		2
	#define FETO_TRI6		3
	#define FETO_QUAD4		4
	#define FETO_QUAD5		41
	#define FETO_QUAD8		5
	#define FETO_QUAD9		51
	#define FETO_TETRA4		6
	#define FETO_WEDGE6		7
	#define FETO_BRICK8		8
	#define FETO_BRICK9		81
	#define FETO_POINT		9
	#define FETO_TETRA10	10
	#define FETO_WEDGE15	11
	#define FETO_BRICK20	12
	#define FETO_BRICK21	121
	#define FETO_RIGIDLIST	13
	#define FETO_MULTILIST	15

	/*
	//FEMAP Material types
	#define FEMT_ISO			0
	#define FEMT_2D_ORTHO		1
	#define FEMT_3D_ORTHO		2
	#define FEMT_2D_ANISO		3
	#define FEMT_3D_ANISO		4
	#define FEMT_HYPERELASTIC	5
	#define FEMT_HYSTERELASTIC	6
	*/


	//NEU entities
	#define NEU_NODE	7
	#define NEU_ELEM	8


	//PAK Types
	#define PAK_TRUSS			1
	#define PAK_ELASTIC_SUPPORT	11
	#define PAK_ISO_2D			2
	#define PAK_ISO_TRI			21
	#define PAK_ISO_3D			3
	#define PAK_ISO_PRISM		31
	#define PAK_ISO_PYR			32
	#define PAK_ISO_TETRA		33
	#define PAK_THINWALED_B		6
	#define PAK_AXISYM_SHELL	7
	#define PAK_ISO_SHELL		8
	#define PAK_ISO_TRI_SHELL	81
	#define PAK_SHELL_BD		84
	#define PAK_BEAM_SUPER		9
	#define PAK_CONTACT			93
	#define PAK_EFG_2D			20

	//PAK Material models
	#define PAKM_ELASTIC_ISO		1
	#define PAKM_ELASTIC_ORTHO		2
	#define PAKM_THERMO_ELASTIC_ISO 3
	#define PAKM_MISES_PLASTIC		5
	#define PAKM_HYSTERELASTIC	   100
	#define PAKM_HILLS2002			31
	#define PAKM_BIO32				32
	#define PAKM_BIAXIAL			36
	#define PAKM_MODEL_37			37
	#define PAKM_MODEL_38			38
	#define PAKM_MODEL_39			39
	#define PAKM_MODEL_62			62
	#define PAKM_DELFINO_SEF_2D		81
	#define PAKM_FUNG_SEF			83
	#define PAKM_TENSEGRITY		    41
	#define PAKM_USER_SUPPLIED		92

	//PAK User supplied submodels
	#define PAKM_USER_SUPPLIED_HILLS		1
	#define PAKM_USER_SUPPLIED_HILLS_2FIBER	12

	//PAK-T Types
	#define PAKT_ISO_1D			1
	#define PAKT_ISO_2D			2
	#define PAKT_ISO_3D			3

	//Analysis program codes
	#define APC_Unknown			0
	#define APC_FEMAP_Generated	1
	#define APC_PAL				2
	#define APC_PAL_2			3
	#define APC_MSC_NASTRAN		4
	#define APC_ANSYS			5
	#define APC_STARDYNE		6
	#define APC_COSMOS			7
	#define APC_PATRAN			8
	#define APC_FEMAP_Neutral	9
	#define APC_ALGOR			10
	#define APC_SSS_NASTRAN		11
	#define APC_Comma_Separated	12
	#define APC_UAI_NASTRAN		13
	#define APC_Cosmic_NASTRAN	14
	#define APC_STAAD			15
	#define APC_ABAQUS			16
	#define APC_WECAN			17
	#define APC_PAK				33
#endif