/*!
 * \file HDataBlock.cpp
 * Implementation of the HDataBlock class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HDataBlock.cpp: implementation of the HDataBlock class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "HDataBlock.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "ExtraData.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL( HDataBlock, CObject, VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
HDataBlock::HDataBlock()
{
	m_pExtraData = NULL;
}

/*!
 * Destructor.
 */
HDataBlock::~HDataBlock()
{
	if(m_pExtraData) delete m_pExtraData;
	m_pExtraData = NULL;
}

///*!
// * serializes object of the HConstraints class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void HDataBlock::Serialize(CArchive& ar)
//{
///*	if (ar.IsStoring())
//	{
//	}
//	else
//	{
//	}*/
//}

/*!
 * Equalizes two objects of the HDataBlock class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
HDataBlock& HDataBlock::operator = (const HDataBlock& rp)
{
	if(m_pExtraData) DetachExtraData();

	if(rp.m_pExtraData)	AttachExtraData(*rp.m_pExtraData);

	return *this;
}

/*!
 * Attaches extra data to the data block.
 * 
 * \param[in] ExtraData
 * Reference to the extra data object to be attached.
 */
void HDataBlock::AttachExtraData(CExtraData &ExtraData)
{
	//if(m_pExtraData) DetachExtraData();

	//m_pExtraData = (CExtraData*) ExtraData.GetRuntimeClass()->CreateObject();
	//(*m_pExtraData) = ExtraData;
}

/*!
 * Detaches extra data (if any) from the data block.
 */
void HDataBlock::DetachExtraData()
{
	//ASSERT(m_pExtraData);

	//delete m_pExtraData;
	//m_pExtraData = NULL;
}