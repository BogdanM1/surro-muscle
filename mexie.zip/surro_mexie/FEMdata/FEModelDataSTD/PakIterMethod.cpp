/*!
 * \file PakIterMethod.cpp
 * Implementation of the CPakIterMethod class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PakIterMethod.cpp: implementation of the CPakIterMethod class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "CAD.h"
#include "PakIterMethod.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*!
 * Default constructor.
 */
CPakIterMethod::CPakIterMethod()
{

}

/*!
 * Destructor.
 */
CPakIterMethod::~CPakIterMethod()
{

}

CPakIterMethod& CPakIterMethod::operator =(const CPakIterMethod &other)
{
	m_iIterMethod =  other.m_iIterMethod;
	m_nMaxIterCount = other.m_nMaxIterCount;

	m_bConvEnergy = other.m_bConvEnergy;
	m_bConvForce = other.m_bConvForce;
	m_bConvMoment = other.m_bConvMoment;
	m_dTOLE = other.m_dTOLE;
	m_dTOLS = other.m_dTOLS;
	m_dTOLM = other.m_dTOLM;
	m_dTOLA = other.m_dTOLA;

	m_nOptimalIterCount = other.m_nOptimalIterCount;
	m_iDirection = other.m_iDirection;
	m_dValue = other.m_dValue;
	m_dAG = other.m_dAG;
	m_dDS = other.m_dDS;
	m_strMethod = other.m_strMethod;
	m_uNodeNumber = other.m_uNodeNumber;

	return(*this);
}
