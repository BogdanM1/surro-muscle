/*
 * HuxleyParameters.cpp
 *
 *  Created on: Jul 24, 2013
 *      Author: anakaplarevic
 */

#include "HuxleyParameters.h"

HuxleyParameters::HuxleyParameters()
{
}

HuxleyParameters::~HuxleyParameters()
{
}

HuxleyParameters::HuxleyParameters(string inS)
{
	// TODO Auto-generated constructor stub
	strFileIn = inS;
	InputData();
	CheckInputData();
}

void HuxleyParameters::InputData()
{

	  config_t cfg;   config_setting_t *setting;   const char *str;
	  double dt,h,f1,g1,g2,cL0,cA,Kxb,cxmin,cxmax,Zahalak;
	  long ng,leftng,rightng;
	  long cleftng,crightng;
	  config_init(&cfg);

	  if(!config_read_file(&cfg, CFGFAJL))
	  {
	//	  fprintf(stderr, "%s:%d - %s\n", config_error_file(&cfg),  config_error_line(&cfg), config_error_text(&cfg));
          printf("HuxleyParameters::Neuspesno otvaranje FEM_MM.cfg fajla\n");
		  config_destroy(&cfg);
	     exit(0);//return(EXIT_FAILURE);
	  }


	 if(config_lookup_float(&cfg, "HuxleyParameters.m_dt", &dt)) m_dt= (_TIP)dt;	 else fprintf(stderr, "Nema 'm_dt' u konfiguracionom fajlu\n");
	 if(config_lookup_int(&cfg, "HuxleyParameters.m_ng", &ng)) m_ng=ng;  else fprintf(stderr, "No 'm_ng' setting in configuration file.\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.m_h", &h)) m_h= (_TIP)h;	 else fprintf(stderr, "Nema 'm_h' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.m_f1", &f1)) m_f1= (_TIP)f1;	 else fprintf(stderr, "Nema 'm_f1' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.m_g1", &g1)) m_g1= (_TIP)g1;	 else fprintf(stderr, "Nema 'm_g1' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.m_g2", &g2)) m_g2= (_TIP)g2;	 else fprintf(stderr, "Nema 'm_g2' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.L0", &cL0)) L0= (_TIP)cL0;	 else fprintf(stderr, "Nema 'L0' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.A", &cA)) A= (_TIP)cA;	 else fprintf(stderr, "Nema 'A' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.m_Kxb", &Kxb)) m_Kxb= (_TIP)Kxb;	 else fprintf(stderr, "Nema 'm_Kxb' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.m_Zahalak", &Zahalak)) m_Zahalak= (_TIP)Zahalak;	 else fprintf(stderr, "Nema 'm_Zahalak' u konfiguracionom fajlu\n");
	 	//printf("m_Zahalak = %lf\n",m_Zahalak);
		//getchar();

	step = m_h/m_ng;
	printf("step = %f %lf\n",step,step);
	 if(config_lookup_int(&cfg, "HuxleyParameters.leftng", &cleftng)) m_leftng=(int)cleftng;  else fprintf(stderr, "No 'leftng' setting in configuration file.\n");
	 if(config_lookup_int(&cfg, "HuxleyParameters.rightng", &crightng)) m_rightng=(int)crightng;  else fprintf(stderr, "No 'rightng' setting in configuration file.\n");

	 if(config_lookup_float(&cfg, "HuxleyParameters.xmin", &cxmin)) xmin= (_TIP)cxmin;	 else fprintf(stderr, "Nema 'xmin' u konfiguracionom fajlu\n");
	 if(config_lookup_float(&cfg, "HuxleyParameters.xmax", &cxmax)) xmax= (_TIP)cxmax;	 else fprintf(stderr, "Nema 'xmax' u konfiguracionom fajlu\n");
//	printf("%f  %d  %f  %f  %f  %f  %f  %f  %d  %d  %f  %f  \n",m_dt,m_ng,m_h,m_f1,m_g1,m_g2,L0,A,m_Kxb,m_leftng,m_rightng,xmin,xmax);

	  double pom;
	  long ipom;
	  if(config_lookup_float(&cfg, "pertubacija", &pom)) pertubacija= pom;  else fprintf(stderr, "Nema 'pertubacija' u konfiguracionom fajlu\n");
	  if(config_lookup_float(&cfg, "MM2D.E", &pom)) _E=pom;   else fprintf(stderr, "No 'E' setting in configuration file.\n");
	  if(config_lookup_float(&cfg, "MM2D.ni", &pom)) _ni=pom;  else fprintf(stderr, "No 'ni' setting in configuration file.\n");
	  if(config_lookup_float(&cfg, "MM2D.fi", &pom)) _fi=pom;   else fprintf(stderr, "No 'fi' setting in configuration file.\n");

      if(config_lookup_float(&cfg, "MM2D.x0", &pom)) x[0]=pom;   else fprintf(stderr, "No 'x0' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.x1", &pom)) x[1]=pom;   else fprintf(stderr, "No 'x1' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.x2", &pom)) x[2]=pom;   else fprintf(stderr, "No 'x2' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.x3", &pom)) x[3]=pom;   else fprintf(stderr, "No 'x3' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.x4", &pom)) x[4]=pom;   else fprintf(stderr, "No 'x4' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.x5", &pom)) x[5]=pom;   else fprintf(stderr, "No 'x5' setting in configuration file.\n");

      if(config_lookup_float(&cfg, "MM2D.y0", &pom)) y[0]=pom;   else fprintf(stderr, "No 'y0' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.y1", &pom)) y[1]=pom;   else fprintf(stderr, "No 'y1' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.y2", &pom)) y[2]=pom;   else fprintf(stderr, "No 'y2' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.y3", &pom)) y[3]=pom;   else fprintf(stderr, "No 'y3' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.y4", &pom)) y[4]=pom;   else fprintf(stderr, "No 'y4' setting in configuration file.\n");
      if(config_lookup_float(&cfg, "MM2D.y5", &pom)) y[5]=pom;   else fprintf(stderr, "No 'y5' setting in configuration file.\n");

      /*for(int i=0; i<6; i++)
          printf("x:    %lf y:  %lf\n",x[i],y[i]);
      getchar();*/

      stressStretchFunction.SetValue(x,y,6);

      /*printf("x:    %lf y:  %lf\n",0.98,stressStretchFunction.GetValue(0.98));
      getchar();*/

	  if(config_lookup_float(&cfg, "HuxleyParameters.EpsXerr", &pom)) EpsXerr=(_TIP)pom;   else fprintf(stderr, "No 'EpsXerr' setting in configuration file.\n");
	  if(config_lookup_float(&cfg, "HuxleyParameters.EpsNerr", &pom)) EpsNerr=(_TIP)pom;   else fprintf(stderr, "No 'EpsNerr' setting in configuration file.\n");
	  if(config_lookup_int(&cfg, "HuxleyParameters.maxIter", &ipom)) maxIter=(int)ipom;   else fprintf(stderr, "No 'maxIter' setting in configuration file.\n");
	  if(config_lookup_int(&cfg, "MM2D.direction", &ipom)) direction=(int)ipom;   else fprintf(stderr, "No 'maxIter' setting in configuration file.\n");

	  printf("%lf  %lf %d  \n",EpsXerr,EpsNerr,maxIter);
	 config_destroy(&cfg);
}

void HuxleyParameters::CheckInputData()
{

}
