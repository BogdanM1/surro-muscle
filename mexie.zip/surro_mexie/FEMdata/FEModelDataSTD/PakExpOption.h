/*!
 * \file PakExpOption.h
 * Interface for the CPakExpOption class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PakExpOption.h: interface for the CPakExpOption class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAKEXPOPTION_H__D1352845_B120_11D6_8623_5254AB509DC9__INCLUDED_)
#define AFX_PAKEXPOPTION_H__D1352845_B120_11D6_8623_5254AB509DC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/** Class containing options for exporting to PAK input file. */
class CPakExpOption  
{
public:
	void Init();

	CPakExpOption();
	virtual ~CPakExpOption();

	/// Indicator whether shella are exported as Bathe-Dvorkin shell
	bool	m_bShellAsBatheDvorkin;
	/// Indicator whether shells are 6-DOF shells
	bool	m_bDrillShell;

protected:

};

#endif // !defined(AFX_PAKEXPOPTION_H__D1352845_B120_11D6_8623_5254AB509DC9__INCLUDED_)
