/*!
 * \file HConstraints.cpp
 * Implementation of the HConstraints class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HConstraints.cpp: implementation of the HConstraints class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "Femcon.h"
#include "HConstraints.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL(HConstraints,HDataBlock, VERSIONABLE_SCHEMA)
/*
template <> void AFXAPI SerializeElements <HConstraints> ( CArchive& ar, HConstraints* pHConstraints, int nCount )
{
    for ( int i = 0; i < nCount; i++, pHConstraints++ )
    {
        pHConstraints->Serialize( ar );
    }
}
*/

/*!
 * Default constructor.
 */
HConstraints::HConstraints()
{

/*	m_ConsNodes.SetSize(0,10);
	m_ConsEqs.SetSize(0,10);*/
	Init();

}

/*!
 * Copy constructor.
 */
HConstraints::HConstraints (const HConstraints& rc)
{
	(*this)=rc;
}

/*!
 * Equalizes two objects of the HConstraints class.
 * 
 * \param[in] rc
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
HConstraints& HConstraints::operator =(const HConstraints& rc)
{
	m_uDataBlockID=rc.m_uDataBlockID;
	m_nID=rc.m_nID;
	m_strTitle=rc.m_strTitle;

	int i,j;
	for(i=0;i<HNODES_MAX_DOF_COUNT;i++) m_GlobalConstraints[i]=rc.m_GlobalConstraints[i];

	m_ConsNodes.SetSize(rc.m_ConsNodes.GetSize());
	for (i=0;i<m_ConsNodes.GetSize();i++)
	{
		ConsNode& node=m_ConsNodes[i];
		node.m_uNodeID=rc.m_ConsNodes[i].m_uNodeID;
		node.m_uColor=rc.m_ConsNodes[i].m_uColor;
		node.m_uLayer=rc.m_ConsNodes[i].m_uLayer;
		for (j=0;j<6;j++)
			node.m_bDOF[j]=rc.m_ConsNodes[i].m_bDOF[j];

	}

	m_ConsEqs.SetSize(rc.m_ConsEqs.GetSize());
	for (i=0;i<m_ConsEqs.GetSize();i++)
	{
		ConsEq& eq=m_ConsEqs[i];
		eq.m_uEqnID=rc.m_ConsEqs[i].m_uEqnID;
		eq.m_uColor=rc.m_ConsEqs[i].m_uColor;
		eq.m_uLayer=rc.m_ConsEqs[i].m_uLayer;
		eq.m_EqCoefs.SetSize(rc.m_ConsEqs[i].m_EqCoefs.GetSize());
		for (j=0;j<eq.m_EqCoefs.GetSize();j++)
		{
			EqCoeff& ec=eq.m_EqCoefs[j];
			ec.m_uEqn_nodeID=rc.m_ConsEqs[i].m_EqCoefs[j].m_uEqn_nodeID;
			ec.m_uEqn_dof=rc.m_ConsEqs[i].m_EqCoefs[j].m_uEqn_dof;
			ec.m_dCoeff=rc.m_ConsEqs[i].m_EqCoefs[j].m_dCoeff;
		}
	}

	return *this;
}

/*!
 * Destructor.
 */
HConstraints::~HConstraints()
{
	m_ConsNodes.RemoveAll();

//	for (int i=0;i<m_ConsEqs.GetSize();i++)
//		m_ConsEqs[i].m_EqCoefs.RemoveAll();
	m_ConsEqs.RemoveAll();
}

///*!
// * Serializes object of the HConstraints class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void HConstraints::Serialize(CArchive& ar)
//{
//	int i;
//	if (ar.IsStoring())
//	{
//		ar << m_uDataBlockID;
//		ar << m_nID;
//		ar << m_strTitle;
//
//		for (i=0;i<HNODES_MAX_DOF_COUNT;i++)
//			ar << m_GlobalConstraints[i];// the six permanent constaints
//	}
//	else
//	{
//		ar >> m_uDataBlockID;
//		ar >> m_nID;
//		ar >> m_strTitle;
//
//		for (i=0;i<HNODES_MAX_DOF_COUNT;i++)
//			ar >> m_GlobalConstraints[i];
//	}
//
//	m_ConsNodes.Serialize(ar);
//	m_ConsEqs.Serialize(ar);
//
//}

/*!
 * Default constructor.
 */
ConsNode::ConsNode()
{
	
}

/*!
 * Copy constructor.
 */
ConsNode::ConsNode(const ConsNode & rc)
{
	(*this)=rc;
}

/*!
 * Destructor.
 */
ConsNode::~ConsNode()
{
	;
}

/*!
 * Equalizes two objects of the ConsNode class.
 * 
 * \param[in] rc
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
ConsNode& ConsNode::operator =(const ConsNode & rc)
{
	m_uNodeID=rc.m_uNodeID;
	m_uColor=rc.m_uColor;
	m_uLayer=rc.m_uLayer;
	for (int i=0;i<6;i++)
		m_bDOF[i]=rc.m_bDOF[i];
	return *this;
}

/*!
 * Default constructor.
 */
ConsEq::ConsEq ()
{
	m_EqCoefs.SetSize(0,1);
}

/*!
 * Destructor.
 */
ConsEq::~ConsEq ()
{
	m_EqCoefs.RemoveAll();
}

/*!
 * Copy constructor.
 */
ConsEq::ConsEq(const ConsEq & rc)
{
	(*this)=rc;
}

/*!
 * Equalizes two objects of the ConsEq class.
 * 
 * \param[in] rc
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
ConsEq& ConsEq::operator =(const ConsEq & rc)
{
	m_uColor=rc.m_uColor;
	m_uEqnID=rc.m_uEqnID;
	m_uLayer=rc.m_uLayer;
	m_EqCoefs.Copy(rc.m_EqCoefs);

	return *this;
}

/*!
 * Sets global constraints.
 * 
 * \param[in] GlobalConstraints
 * Array representing global constraints.
 */
void HConstraints::SetGlobalConstraints(bool GlobalConstraints[])
{
	for(UINT i=0;i<HNODES_MAX_DOF_COUNT;i++)
		m_GlobalConstraints[i]=GlobalConstraints[i];
}

/*!
 * Gets global constraints.
 * 
 * \param[in] GlobalConstraints
 * Array representing global constraints.
 */
void HConstraints::GetGlobalConstraints(bool GlobalConstraints[])
{
	for(UINT i=0;i<HNODES_MAX_DOF_COUNT;i++)
		GlobalConstraints[i]=m_GlobalConstraints[i];
}

/*!
 * Initializes constraints.
 */
void HConstraints::Init()
{
	UINT i;
	m_ConsNodes.SetSize(0,10);
	m_ConsEqs.SetSize(0,10);
	for (i = 0; i < HNODES_MAX_DOF_COUNT; i++) m_GlobalConstraints[i] = FALSE;
}
