/*!
 * \file OutSet.h
 * Interface for the COutSet class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// OutSet.h: interface for the COutSet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OUTSET_H__77248E44_BA76_11D6_8623_5254AB509DC9__INCLUDED_)
#define AFX_OUTSET_H__77248E44_BA76_11D6_8623_5254AB509DC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OutVector.h"
#include "BlockIDs.h"
#include "MyArray.h"

/** Class representing output set. */
class COutSet //: public CObject  
{
public:
//	UINT WriteContent();
	bool FindOutVectorByOutType(UINT OutType,UINT& OutVectorID);
//	UINT ProvideSetOfOutVectors(bool ElemVar,MyString& Title,UINT &VectorID,UINT VarType, UINT NodeCount,UINT SumCompCount,COutVector* &ovTotal,COutVector *ovNodal[25],COutVector *ovComp[25][6],UINT nHashTableSize);
	UINT ProvideElementNComponentOutVector(UINT nVectorID, const MyString &sTitle, MyString sCompExtensions[], UINT nVarType, UINT nEntityType,UINT nHashTableSize, UINT nIntPointCount, UINT nComponentCount);
	UINT ProvideNComponentOutVector(UINT nVectorID, MyString sTitle, MyString sCompExtensions[3], UINT nVarType, UINT nEntityType,UINT nHashTableSize,UINT nComponentCount);
	UINT ProvideOutVector(UINT nVectorID, const MyString &sTitle, UINT nVarType, UINT nEntityType, UINT nHashTableSize);
	bool IsOutVectorExist(UINT ID);
	bool FindOutVector(UINT ID, UINT &nIndex);
	COutVector& GetOutVector(UINT ID);
	UINT DeleteContents();

	COutSet();
	COutSet(const COutSet &p);
	virtual ~COutSet();
	COutSet& operator = (const COutSet& other);
	//void Serialize( CArchive& ar );

	/// ID of the output set
	UINT m_nID;
	/// Title of the output set
	MyString m_sTitle;
	/// Code of the program from wich results are obtained
	UINT m_nFrom_prog;
	/// Type of performed analysis
	UINT m_nAnal_type;
	/// Value related to the output set (time, load...).
	double m_dValue;
	/// Number of lines in the notes
	UINT m_nNLines;
	/// Notes
	MyString m_sNotes; //Ovo je u FEMAPU niz od m_nNLines stringova

	/// Source file name
	MyString m_sSourceFileName;
	/// Poistion in the source file for direc access
	DWORD m_nDirectAccessPosition;

//Ovde ubacujem i Out vektore iako oni u FEMAPU idu nezavisno od seta	BOBAN
	/// Collection of output vectors
	MyArray<COutVector,COutVector&> m_OutVectors;
protected:
	//DECLARE_SERIAL(COutSet)
};

#endif // !defined(AFX_OUTSET_H__77248E44_BA76_11D6_8623_5254AB509DC9__INCLUDED_)
