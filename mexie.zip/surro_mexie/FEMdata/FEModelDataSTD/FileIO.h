/*!
 * \file FileIO.h
 * File input/output constants.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

#include "MyFile.h"

#define NODE_ARRAY_NEW_SIZE					  0
#define NODE_ARRAY_GROW_BY					50000
#define ELEMENT_ARRAY_NEW_SIZE				  0
#define ELEMENT_ARRAY_GROW_BY				50000
#define PROPERTIES_ARRAY_NEW_SIZE			  0
#define PROPERTIES_ARRAY_GROW_BY			 10
#define LOADS_ARRAY_NEW_SIZE				  0
#define LOADS_ARRAY_GROW_BY			         50
#define CONSTRAINTS_ARRAY_NEW_SIZE			  0
#define CONSTRAINTS_ARRAY_GROW_BY			 50
#define OUTSETS_ARRAY_NEW_SIZE				  0
#define OUTSETS_ARRAY_GROW_BY				1000

#define FILE_OPEN_ERROR						"Error in opening the file."
#define FILE_CREATION_ERROR					"Can not create the file."
#define FILE_READ_ERROR						"Error in reading the file."


#define FEMAP_FILE_CURRENT_VERSION			"4.4"
#define FB_SEPARATOR						"   -1"
#define FBID_NODES							403
#define FBID_ELEMENTS						404
#define FBID_PROPERTIES						402
#define FBID_LOADS							407
#define FBID_CONSTRAINTS					406			
#define FBID_MATERIALS						401			
#define FBID_FUNCTIONS						420
#define FBID_OUTSETS						450
#define FBID_OUTVECTORS						451

#define IMPORT_FEMAP_WRONG_VERSION			"Sorry, only the FEMAP 4.4 version is supported!"

//IO functions
UINT SkipRows(MyFile &File,UINT RowCount);
