#include <cuda.h>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>
#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/for_each.h>
#include <thrust/reduce.h>
#include <thrust/iterator/zip_iterator.h>

#include <sys/time.h>
#include <stdio.h>
#include <vector>
#include <cublas_v2.h>


#include "HuxleyParameters.h"
#include "HuxleyCalculatorCuda.h"



#define _TIP float
//#define NDIM 8192
#define MAX_ITER 1000

#define THREADS 1024
#define BLOCKS (NDIM/THREADS)


class HuxleyCalculatorCudaCustom : public HuxleyCalculatorCuda
{
private:


	HuxleyParameters* _param;
	cudaError_t cudaStat; 
	// cublasStatus_t cublasStat; 
	// cublasHandle_t handle;
	cudaStream_t *streams;

	int nstreams;

	float *temp;
	float *NDIM_0;

	float *hostTemp;


	float *h_X_remash, *h_X;
	
	float* d_X;
	float* d_N;
	float* d_V;
	float* d_FX;

	std::vector< float* > d_X0;
	std::vector< float* > d_N0;

	float* e;
	float* e_curr;

	float *NDIM_vel;



	std::vector< float* > X_curr;
	std::vector< float* > N_curr;
	float* V_curr;
	float* FX_curr;

	float* X_next;
	float* N_next;
	float* V_next;
	float* FX_next;

	float* X_remash;
	float* N_remash;

    std::vector<int> Iter_count;


//	thrust::device_vector<_TIP> transf;

	int _k;
	FILE *f;
	FILE *rawLog;

public:
	HuxleyCalculatorCudaCustom();
	HuxleyCalculatorCudaCustom(int k);
	HuxleyCalculatorCudaCustom(int k, HuxleyParameters* param);
	virtual ~HuxleyCalculatorCudaCustom();
	
    void getIter_count(std::vector<int>& iterCount);
	void Initialize();
	void Initialize(int);
	void Initialize(int k, HuxleyParameters* param);
	void Remash(int);
	// int Iteration(int, float, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2);
	int Iteration(int, float);
	// void Simulate(int i, float v, float time, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2);
	void Simulate(int, float, float);
	// void Calculate(std::vector<float> es, float time, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2);
	void Calculate(std::vector<float>, float);
	void SetToNew(int);
	void SetToNew();
	float getForce(int);
	void getForce(std::vector<float>&);
	void check();
	
	std::vector<_TIP> Get_X(int);
	std::vector<_TIP> Get_N(int);
	void Get_X(int i,std::vector<_TIP>& r);
	void Get_N(int i,std::vector<_TIP>& r);


	void cudaCheck();
	// void cublasCheck();
};
