/*
 * Math3d - The 3D Computer Graphics Math Library
 * Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
 * All rights reserved.
 *
 * This program is  free  software;  you can redistribute it and/or modify it
 * under the terms of the  GNU Lesser General Public License  as published by 
 * the  Free Software Foundation;  either version 2.1 of the License,  or (at 
 * your option) any later version.
 *
 * This  program  is  distributed in  the  hope that it will  be useful,  but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
 * License for more details.
 *
 * You should  have received  a copy of the GNU Lesser General Public License
 * along with  this program;  if not, write to the  Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: m2d.cpp,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
 */
#include "Stdafx.h"
#define _MATH3D_EXPORT
#include "m2d.h"
#include "m3d.h"
#include <math.h>
//#include <iostream>


const Math3d::M2d Math3d::M2d::AxisX(1,0);
const Math3d::M2d Math3d::M2d::AxisY(0,1);


/*!
 *
 */
Math3d::M2d::M2d(const M2d& A)
{
  x=A.x;
  y=A.y;
}


/*!
 * Construction from homogenous coordinates
 * ([W*X, W*Y, W] with scale factor W !=0 -> [X, Y]).
 *
 * \param A 4-dimensional vector. 
 */
Math3d::M2d::M2d(const M3d& A) 
{
  /*if (fabs(A.z)<EPSILON) {
    ASSERT(false);
    x=y=0.0;
  }

  double c=1/A.z;*/
  x=A.x;//*c;
  y=A.y;//*c;
}


/*!
 *
 */
const Math3d::M2d&
Math3d::M2d::operator=(const M2d& A)
{
  x=A.x;
  y=A.y;
  return(*this);
}


/*!
 *
 */
void
Math3d::M2d::zero()
{
  x=y=0.0;
}


/*!
 *
 */
void
Math3d::M2d::copy(const M2d& A)
{
  x=A.x;
  y=A.y;
}


/*!
 *
 */
double&
Math3d::M2d::get(int i)
{
  ASSERT(i>=0 && i<2);
  return((&x)[i]);
}


Math3d::M2d
Math3d::M2d::operator+(const M2d& A)
{
  return(M2d(
    x+A.x,
    y+A.y
  ));
}


/*!
 *
 */
Math3d::M2d
Math3d::M2d::operator+()
{
  return(*this);
}


/*!
 *
 */
const Math3d::M2d&
Math3d::M2d::operator+=(const M2d& A)
{
  x+=A.x;
  y+=A.y;
  return(*this);
}


/*!
 *
 */
Math3d::M2d
Math3d::M2d::operator-(const M2d& A) const
{
  return(M2d(x-A.x, y-A.y));
}


/*!
 *
 */
Math3d::M2d
Math3d::M2d::operator-()
{
  return(M2d(-x,-y));
}


/*!
 *
 */
const Math3d::M2d&
Math3d::M2d::operator-=(const M2d& A)
{
  x-=A.x;
  y-=A.y;
  return(*this);
}


/*!
 *
 */
Math3d::M2d
Math3d::M2d::operator*(double k)
{
  return(M2d(
    x*k,
    y*k
  ));
}


/*!
 *
 */
const Math3d::M2d&
Math3d::M2d::operator*=(double k)
{
  x*=k;
  y*=k;
  return(*this);
}


/*!
 *
 */
void
Math3d::M2d::neg()
{
  x=-x;
  y=-y;
}


/*!
 *
 */
void
Math3d::M2d::abs()
{
  x=fabs(x);
  y=fabs(y);
}


/*!
 *
 */
void
Math3d::M2d::add(const M2d& A, const M2d& B)
{
  x=A.x + B.x; 
  y=A.y + B.y; 
}


/*!
 *
 */
void
Math3d::M2d::sub(const M2d& A, const M2d& B)
{
  x=A.x - B.x; 
  y=A.y - B.y; 
}


/*!
 *
 */
void
Math3d::M2d::scalar(double k)
{
  x*=k;
  y*=k;
}


/*!
 *
 */
void
Math3d::M2d::normalize()
{
	double de = NormSqr();
	if (de <= EPSILON) {
		x=y=0;
	} else {
		de = sqrt(de);
		x /= de;
		y /= de;
	}
}


/*!
 *
 */
void
Math3d::M2d::lerp(const M2d& A, const M2d& B, double t)
{
  x=A.x+t*(B.x-A.x);
  y=A.y+t*(B.y-A.y);
}


/*!
 *
 */
void
Math3d::M2d::Min(const M2d& min)
{
  if (x > min.x) x = min.x;
  if (y > min.y) y = min.y;
}


/*!
 *
 */
void
Math3d::M2d::Max(const M2d& max)
{
  if (x < max.x) x = max.x;
  if (y < max.y) y = max.y;
}


/*!
 *
 */
void
Math3d::M2d::cubic(const M2d& A, const M2d& TA, const M2d& TB, 
  const M2d& B, double t)
{
  double a,b,c,d;   

  a=2*t*t*t - 3*t*t + 1;
  b=-2*t*t*t + 3*t*t;
  c=t*t*t - 2*t*t + t;
  d=t*t*t - t*t;
  x=a*A.x + b*B.x + c*TA.x + d*TB.x;
  y=a*A.y + b*B.y + c*TA.y + d*TB.y;
}


/*!
 *
 */
double
Math3d::M2d::get(int i) const
{
  ASSERT(i>=0 && i<2);
  return((&x)[i]);
}


/*!
 *
 */
bool
Math3d::M2d::operator==(const M2d& A) const
{
  return(cmp(A));
}


/*!
 *
 */
bool
Math3d::M2d::operator!=(const M2d& A) const
{
  return(!cmp(A));
}


/*!
 *
 */
double
Math3d::M2d::operator*(const M2d& A) const
{
  return(x*A.x + y*A.y);
}


/*!
 *
 */
double 
Math3d::M2d::dot(const M2d& A) const
{
  return(x*A.x + y*A.y);
}


/*!
 *
 */
bool 
Math3d::M2d::cmp(const M2d& A, double epsilon) const
{
  return(
    (fabs(x-A.x)<epsilon) &&
    (fabs(y-A.y)<epsilon)
  );
}


/*!
 *
 */
double
Math3d::M2d::squared() const
{
  return(x*x + y*y);
}


/*!
 *
 */
double
Math3d::M2d::length() const
{
  return(sqrt(x*x + y*y));
}

//void Math3d::M2d::Serialize(CArchive& ar)
//{
//	if( ar.IsStoring() )
//	{
//		ar << x;
//		ar << y;
//	}
//	else
//	{
//		ar >> x;
//		ar >> y;
//	}
//}


/*!
 *
 */
/*std::ostream& 
Math3d::operator << (std::ostream& co, const M2d& v)
{
  co << "(" << v[0] << ", " << v[1] << ")";
  return co;
}
*/
