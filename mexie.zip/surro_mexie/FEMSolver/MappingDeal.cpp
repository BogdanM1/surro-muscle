/*
 * MappingDeal.cpp
 *
 *  Created on: Jul 8, 2014
 *      Author: marina
 */

#include"MappingDeal.h"
#include"FEModelData.h"
using namespace dealii;


MappingDeal::MappingDeal()
{

}

MappingDeal::~MappingDeal() {

}

void MappingDeal::mappingNodes(CModelData &ModelData, std::vector<Point<2> > &cvorovi)
{

	int nPoint = ModelData.m_NodArray.GetSize();

	for (int i=0; i< nPoint; i++)
	{
		for (int j=0; j< nPoint; j++)
		{
			if (fabs(cvorovi[i][0] - ModelData.m_NodArray[j].m_dX) < 1.0e-6 && fabs(cvorovi[i][1] - ModelData.m_NodArray[j].m_dY) < 1.0e-6)
			{
                mapNod[j] = i;
			}

		}
	}

}

void MappingDeal::mappingElem(CModelData &ModelData,   FESystem<2>    &fe, Triangulation<2>     &triangulation,  FEValues<2> & fe_values, DoFHandler<2>        &dof_handler)
{
		unsigned int k;
		double x,y;
		std::vector<unsigned int> dofIndex (fe.dofs_per_cell);

        DoFHandler<2>::active_quad_iterator    cell = dof_handler.begin_active(),   endc = dof_handler.end();
		int ic=0;
        for (; cell!=endc; ++cell)
			 {
				 fe_values.reinit(cell);
				 cell->get_dof_indices (dofIndex);
				 for (int i=0; i<ModelData.m_ElArray.GetSize(); i++)
				 {
                     int br=0;
                     if(ModelData.m_ElArray[i].m_uType==4)
                     {

                         for(unsigned int j=0;j<4;j++)
                         {
                             x=ModelData.m_NodArray.GetByIndex(ModelData.m_ElArray[i].m_uNode[j]).m_dX;
                             y=ModelData.m_NodArray.GetByIndex(ModelData.m_ElArray[i].m_uNode[j]).m_dY;
                             for(unsigned int k=0;k<4;k++)
                             if (fabs(cell->vertex(k)[0] - x) < 1.0e-6 && fabs(cell->vertex(k)[1] - y)< 1.0e-6)
                                        {
                                            br++;
                                        }
                         }
                            if (br==4)
                            {
                                mapElem[ic]=ModelData.m_ElArray[i].m_nID; //bilo je i
                                break;
                            }
                     }


				 }
				 ic++;

         }

         //obrnuto mapiranje
        /*for (int i=0; i<ModelData.m_ElArray.GetSize(); i++)
          {
                 ic=0;
                 cell = dof_handler.begin_active(),   endc = dof_handler.end();
                 for (; cell!=endc; ++cell)
                 {
                     fe_values.reinit(cell);
                     cell->get_dof_indices (dofIndex);
                     int br=0;

                     for(unsigned int j=0;j<4;j++)
                     {
                         x=ModelData.m_NodArray.GetByIndex(ModelData.m_ElArray[i].m_uNode[j]).m_dX;
                         y=ModelData.m_NodArray.GetByIndex(ModelData.m_ElArray[i].m_uNode[j]).m_dY;
                         for(unsigned int k=0;k<4;k++)
                         if (fabs(cell->vertex(k)[0] - x) < 1.0e-6 && fabs(cell->vertex(k)[1] - y)< 1.0e-6)
                                    {
                                        br++;
                                    }
                     }
                        if (br==4)
                        {
                            mapElem[i]=ic;
                            break;
                        }
                     ic++;
                 }


         }*/

}

