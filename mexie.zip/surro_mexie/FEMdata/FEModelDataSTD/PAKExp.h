#define PAKS_CardH1 "C /1/ HEADING CARD (80A1)\n"
#define PAKS_CardV1 "C NASLOV\n"
#define PAKS_CardH2 "C /2/ FORMAT FOR INPUT DATA (free format)\n"
#define PAKS_CardV2 "C INDFOR\n"
#define PAKS_CardH3 "C /3/ BASIC DATA FOR THE PROBLEM (5I5)\n"

#define PAKS_CardH3_1 "C /3-1/ CARD WITH BASIC DATA ABOUT RIGID BODIES (4I5)\n"
#define PAKS_CardV3_1 "C KT3D,NLNC,MXVEZ,MXRAC\n"

#define PAKS_CardV3 "C NP,NGELEM,NMATM,NPER,NKRT\n"
#define PAKS_CardH4 "C /4/ BASIC DATA FOR THE PROBLEM (6I2,3X,3I5)\n"
#define PAKS_CardV4 "C (IOPGL(I),I=1,6),NDIN,ISOPS,ICVEL\n"
#define PAKS_CardH5 "C /5/ DATA FOR POST-PROCESSING (10I5)\n"
#define PAKS_CardV5 "C NULAZ,NBLPR,NBLGR,ISTKO,NCVPR,ISTEM,ISTVN,ISTSI,ISTDE,ISTNA\n"
#define PAKS_CardH6 "C /6/ CARD WITH DATA FOR BLOCKS (5I5)\n"
#define PAKS_CardV6 "C NBL,(NPRGR(NBL,I),I=1,4)\n"
#define PAKS_CardH7 "C /7/ DATA FOR RESTART (I5,10X,2I5,2F10.0)\n"
#define PAKS_CardV7 "C IREST,       NMODS,ICCGG,    TOLG,    ALFAG\n"
#define PAKS_CardH8 "C /8/ DATA FOR TIME STEPS (2I5,F10.0)\n"
#define PAKS_CardV8 "C   I,NKDT(I),DTDT(I)    (I=1,NPER)\n"
#define PAKS_CardH9 "C /9/ DATA FOR EQULIBRIUM ITERATIONS (5I5,3F10.0,10X,I5)\n"
#define PAKS_CardV9 "C METOD,MAXIT,KONVE,KONVS,KONVM,TOLE,    TOLS,     TOLM,     TOLA,NBRCR\n"
#define PAKS_CardH9_1 "C /9-1/ DATA FOR AUTOMATIC LOAD STEPPING (3I5,3F10.0)\n"
#define PAKS_CardV9_1 "C ITEOPT,KPNNOD,KPDIR,DTUK,ALFG,DELS\n"
#define PAKS_CardH10 "C /10/ INPUT NODAL DATA (I5,A1,6I2,2X,3F10.0,2I5)   (K=1,NP)\n"
#define PAKS_CardV10 "C  N,CH,(ID(N,I),I=1,6),   (CORD(N,J),J=1,3),      KORC,INDS\n"

#define PAKS_CardH10_02 "C /10-02/ DATA ABOUT DEPENDENT DISPLACEMENT\n"
#define PAKS_CardH10_02_a "C  a) Basic data about linear dependence (2I5)\n"
#define PAKS_CardV10_02_a "C  MMP,NEZAV\n"
#define PAKS_CardH10_02_b "C  b) Data for coefficients in linear relations (I5,6F10.0)\n"
#define PAKS_CardV10_02_b "C  IPC,FMPC1,FMPC2,FMPC3,FMPC4,FMPC5,FMPC6\n"
#define PAKS_CardH10_02_c "C  c) Degree of freedom in linear relation (14I5)\n"
#define PAKS_CardV10_02_c "C  IMP, IZC, IZS, NC1, NS1, NC2, NS2, NC3, NS3, NC4, NS4, NC5, NS5, NC6, NS6\n"

#define PAKS_CardH10_03 "C /10-03/ DATA ABOUT RIGID BODIES\n"
#define PAKS_CardH10_03_a "C Data about chain of rigid bodies\n"
#define PAKS_CardV10_03_a "C NKTLNC,LNCVZ,NBVEZ\n"
#define PAKS_CardH10_03_b "C Data about rigid bodies within chain\n"
#define PAKS_CardV10_03_b "C NCGL,NVEZ\n"
#define PAKS_CardH10_03_d "C Data about contour nodes of rigid bodies\n"
#define PAKS_CardV10_03_d "C BOUNDARY NODES (NCVEZ(I,K),K=1,NVEZ)\n"

#define PAKS_CardH11 "C /11/ DATA FOR MATERIAL MODELS (3I5)\n"
#define PAKS_CardV11 "C (MODEL(I,K),I=1,3)    (K=1,NMATM)\n"

//Card /12/
#define PAKS_CardH12 "C /12/ DATA FOR MATERIAL (2I5,F10.0)\n"
#define PAKS_CardV12 "C MOD  MAT     GUST\n"

#define PAKS_CardH12_1 "C /12-1/ MATERIAL MODEL 1 (ELASTIC-ISOTROPIC)\n"
#define PAKS_CardV12_1_1 "C YOUNGS MODULUS (F10.0)\n"
#define PAKS_CardV12_1_2 "C        E\n"
#define PAKS_CardV12_1_2_1 "C        E         V\n"
#define PAKS_CardV12_1_3 "C POISSONS RATIO (F10.0)\n"
#define PAKS_CardV12_1_4 "C        V\n"

#define PAKS_CardH12_2 "C /12-1/ MATERIAL MODEL 2 (ELASTIC-ORTHOTROPIC)\n"
#define PAKS_CardV12_2_1 "C YOUNGS MODULUS  (3F10.0)\n"
#define PAKS_CardV12_2_2 "C       Ex        Ey        Ez\n"
#define PAKS_CardV12_2_3 "C POISSONS RATIO (3F10.0)\n"
#define PAKS_CardV12_2_4 "C      Vxy       Vyz       Vzx\n"
#define PAKS_CardV12_2_5 "C SHEAR MODULUS (3F10.0)\n"
#define PAKS_CardV12_2_6 "C      Gxy       Gyz       Gzx\n"

#define PAKS_CardH12_31 "C /12-31/ MATERIAL MODEL 31 (HILLS MODEL (2002))\n"
#define PAKS_CardV12_31_1 "C      E       ANI     ALPHA     BETA\n"
#define PAKS_CardV12_31_2 "C      A   STRN_RATE     K     FRACTION\n"

#define PAKS_CardH12_36 "C /12-36/ MATERIAL MODEL 36 (BIAXIAL)\n"
#define PAKS_CardV12_36_1 "C SURFACTANT FRACTION (F10.0)\n"
#define PAKS_CardV12_36_2 "C POISSONS RATIO (F10.0)\n"
#define PAKS_CardV12_36_3 "C   UNIAXIAL CURVE\n"
#define PAKS_CardV12_36_4 "C   BIAXIAL CURVE\n"

#define PAKS_CardH12_37 "C /12-37/ MATERIAL MODEL 37 (ELASTIC WITH HYSTERESIS)\n"
#define PAKS_CardV12_37_1 "C YOUNGS MODULUS (F10.0)\n"
#define PAKS_CardV12_37_2 "C        E\n"
#define PAKS_CardV12_37_2_1 "C        E         V\n"
#define PAKS_CardV12_37_3 "C POISSONS RATIO (F10.0)\n"
#define PAKS_CardV12_37_4 "C        V\n"
#define PAKS_CardV12_37_5 "C LOADING HYSTERESIS FUNCTION\n"
#define PAKS_CardV12_37_6 "C Number of points\n"
#define PAKS_CardV12_37_7 "C    X         Y\n"
#define PAKS_CardV12_37_8 "C UNLOADING HYSTERESIS FUNCTION\n"
#define PAKS_CardV12_37_9 "C Number of points\n"
#define PAKS_CardV12_37_10 "C    X         Y\n"

//Model 38
#define CardH12_38 "C /12-38/ MATERIAL MODEL 38 (MULTILINEAR STRESS-STRETCH)\n"
#define CardV12_38_3 "C POISSONS RATIO (F10.0)\n"
#define CardV12_38_4 "C        V\n"
#define CardV12_38_5 "C STRESS-STRETCH FUNCTION\n"
#define CardV12_38_6 "C Number of points\n"
#define CardV12_38_7 "C  Stretch   Stress\n"

//Model 39
#define CardH12_39 "C /12-39/ MATERIAL MODEL 39 "
#define CardV12_39_1 "C YOUNGS MODULUS (F10.0)\n"
#define CardV12_39_2 "C        E\n"
#define CardV12_39_3 "C POISSONS RATIO (F10.0)\n"
#define CardV12_39_4 "C        V\n"
#define CardV12_39_5 "C LOADING STRESS-STRETCH FUNCTION\n"
#define CardV12_39_6 "C Number of points\n"
#define CardV12_39_7 "C  Stretch   Stress\n"
#define CardV12_39_8 "C UNLOADING STRESS-STRETCH FUNCTION\n"
#define CardV12_39_9 "C Number of points\n"
#define CardV12_39_10 "C  Stretch   Stress\n"

#define PAKS_CardH12_32 "C /12-32/ MATERIAL MODEL 32 (BIOLOGICAL 32)\n"
#define PAKS_CardV12_32_1 "C POISSONS RATIO (F10.0)\n"
#define PAKS_CardV12_32_2 "C        V\n"
#define PAKS_CardV12_32_3 "C   AYP       BYP (2F10.0)\n"
#define PAKS_CardV12_32_4 "C   AXP       BXP (2F10.0)\n"

#define PAKS_CardH12_41 "C /12-41/ MATERIAL MODEL 41 (TENSEGRITY)\n"
#define PAKS_CardV12_41_1 "C   E(F10.0)  Ni(F10.0)  Sigma0(F10.0)\n"

#define PAKS_CardH12_62 "C /12-41/ MATERIAL MODEL 62 (CARTER&HAYES BONE MODEL)\n"
#define PAKS_CardV12_62_1 "C-  E_long    E_tran      Nu_lt     Nu_lt     G\n"
#define PAKS_CardV12_62_2 "C      Rho     Rho_c Strain rate   Main axes\n"

#define PAKS_CardH12_81 "C /12-81/ MATERIAL MODEL 81 (DELFINO SEF)\n"
#define PAKS_CardV12_81_1 "C    A         B  (2F10.0)\n"

#define PAKS_CardH12_83 "C /12-83/ MATERIAL MODEL 83 (FUNG SEF 1979)\n"
#define PAKS_CardV12_83_1 "C-    C         a1        a2       a4     (4F10.0)\n"

#define PAKS_CardH12_92 "C /12-92/ MATERIAL MODEL 92 (USER MODEL)\n"
#define PAKS_CardV12_92_1_1 "C IND INDFAT AXIS\n"
#define PAKS_CardV12_92_1_2 "C      E       ANI     ALPHA     BETA\n"
#define PAKS_CardV12_92_1_3 "C      A   STRN_RATE     K     FRACTION\n"

#define PAKS_CardV12_92_2_1 "C IND INDFAT AXIS\n"
#define PAKS_CardV12_92_2_11 "C SLOW FIBER TYPE (I)\n"
#define PAKS_CardV12_92_2_12 "C FAST FIBER TYPE (II)\n"
#define PAKS_CardV12_92_2_2 "C   Alpha     Beta      A     StrainRate\n"
#define PAKS_CardV12_92_2_3 "C     K     NotUsed   NotUsed   NotUsed \n"
#define PAKS_CardV12_92_2_4 "C     E       Nu     MuscFract\n"
#define PAKS_CardV12_92_2_5 "C Nodal variables\n"
#define PAKS_CardV12_92_2_6 "C Node Variable1 Variable2 Variable3 Variable4\n"

//Card /13/
#define PAKS_CardH13       "C /13/ INPUT DATA FOR ELEMENT GROUP (8I5,3F10.0)    (I=1,NGELEM)\n"
#define PAKS_CardV13       "C NETIP,NE,IATYP,NMODM,INDBTH,INDDTH,INDKOV,ICOEF,COEF1,COEF2,   COEF3\n"
#define PAKS_CardH13_1     "C /13-1/ DATA FOR TRUSS ELEMENTS\n"
#define PAKS_CardH13_1_a_1 "C a) First card with basic data for the element group (3I5,F10.0,I5)\n"
#define PAKS_CardV13_1_a_2 "C NN,NMAT,ISNA,APR,KORC\n"
#define PAKS_CardH13_1_b_1 "C b) Card wiht data for the current element (2I5)\n"
#define PAKS_CardV13_1_b_2 "C NEL(NN,1),NEL(NN,2)\n"
#define PAKS_CardH13_2     "C /13-2/ DATA FOR 2/D ISOPARAMETRIC ELEMENTS\n"
#define PAKS_CardV13_2_a_1 "C a) First card with basic data for the element group (4I5,F10.0,I5,3F10.0,I5)\n"
#define PAKS_CardV13_2_a_2 "C IETYP,NGAUSR,NGAUSS,MSET,BETA,MSLOJ,CPP1,CPP2,CPP3,IALFA\n"
#define PAKS_CardV13_2_b_1 "C b) Card wiht data for the current element (5I5,F10.0,I5,2F10.0)\n"
#define PAKS_CardV13_2_b_2 "C NN,NMAT,IPRCO,ISNA,IPGS,THI,KORC,BTH,DTH\n"
#define PAKS_CardV13_2_c_1 "C c) Card with nodal point data for the current element (9I5)\n"
#define PAKS_CardV13_2_c_2 "C (NEL(NN,I),I=1,9)\n"
#define PAKS_CardH13_6     "C /13-1/ DATA ABOUT THIN-WALLED BEAM ELEMENTS\n"
#define PAKS_CardH13_6_a_1 "C a) First card with basic data for the element group (4I5,4F10.0,2I5)\n"
#define PAKS_CardV13_6_a_2 "C NT,NELM,NTIP,NKAR,OY,OZ,YM,ZM,ALFAU,INDOF\n"
#define PAKS_CardH13_6_b_1 "C b) Card wiht cross-section characteristics. (7F10.0,2I1)\n"
#define PAKS_CardV13_6_b_2 "C POVR,YI,ZI,TK,ALFA,CAPAY,CAPAZ,ILU,ICP\n"
#define PAKS_CardH13_6_h_1 "C h) Data about thin-walled beam element. (6I5,5X,3F10.0)\n"
#define PAKS_CardV13_6_h_2 "C NN,NEL(NN,1),NEL(NN,2),NTIP,MAT,NAP,CTR(NN,1),CTR(NN,2),CTR(NN,3)\n"


#define PAKS_CardH13_3 "C /13-3/ DATA FOR 3/D ISOPARAMETRIC ELEMENTS\n"
#define PAKS_CardV13_3_a_1 "C Card with basic data about 3D elements (3I5,5X,F10.0,35X,I5\n"
#define PAKS_CardV13_3_a_2 "C NGAUSX,NGAUSY,NGARSZ,BETA,IALFA\n"

#define PAKS_CardV13_3_b_1 "C Card with data about the current element (^I5,10X,2F10.0)\n"
#define PAKS_CardV13_3_b_2 "C NN,NMAT,IPRCO,ISNA,IPGS,KORC,BTH,DTH\n"
#define PAKS_CardV13_3_c_1 "C Card with nodal data (1 to K) of the element (8I5)\n"
#define PAKS_CardV13_3_c_2 "C (NEL(NN,I),I=1,8)\n"

#define PAKS_CardV13_8_a_2 "C NGAUSX,NGAUSY,NGAUSZ,MSET,BETA,MSLOJ,CPP1,CPP2,CPP3,IALFA\n"

#define PAKS_CardH14 "C /14/ DATA ABOUT TIME FUNCTIONS (2I5)\n"
#define PAKS_CardV14 "C NTABFT,MAXTFT\n"
#define PAKS_CardH14_1 "C /14-1/ GROUP OF CARDS WITH TABLES FOR TIME FUNCTIONS\n"
#define PAKS_CardV14_1_a_1 "C a) data about function in a table form (2I5)\n"
#define PAKS_CardV14_1_a_2 "C IBR,IMAX    (IMAX.LE.MAXTFT)\n"
#define PAKS_CardV14_1_b_1 "C b) values for argument - function (2F10.0)\n"
#define PAKS_CardV14_1_b_2 "C ((FN(I,IBR,J),I=1,2),J=1,IMAX)\n"

#define PAKS_CardH15 "C /15/ GENERAL DATA ABOUT LOADS (4I5,5X,5I5)\n"
#define PAKS_CardV15 "C NCF,NPP2,NPP3, NPGR,    NPLJ,NTEMP,NZADP,INDZS,ICERNE\n"
#define PAKS_CardH15_1 "C /15-1/ CONCENTRATED LOADS DATA (3I5,F10.0,I5,F10.0)\n"
#define PAKS_CardV15_1 "C    N   IP   NC   FAK     KORC    FPOM\n"
#define PAKS_CardH15_2 "C /15-2/ LINE LOADING\n"
#define PAKS_CardV15_2_a_1 "C a) Data about line loading (pressure) along line (A-B) (3I5,3F10.0,I5)\n"
#define PAKS_CardV15_2_a_2 "C ITIPE,NFUN,IPRAV,(FAKP(J),J=1,2),THICV,KORC\n"
#define PAKS_CardV15_2_b_1 "C Data for nodes of the line A-B (3I5)\n"
#define PAKS_CardV15_2_b_2 "C (NODPR(J),J=1,3)\n"
#define PAKS_CardH15_3 "C /15-3/ SURFACE LOADING\n"
#define PAKS_CardV15_3_a_1 "C Data for surface loading (pressure) on surface ABCD (2I5,4F10.0,I5)\n"
#define PAKS_CardV15_3_a_2 "C NFUN,IPRAV,(FAKP(J),J=1,4),KORC\n"
#define PAKS_CardV15_3_b_1 "C Data for nodes of the surface ABCD (8I5)\n"
#define PAKS_CardV15_3_b_2 "C (NODPR(J),J=1,8)\n"
#define PAKS_CardH15_7 "C /15-7/ DATA FOR TEMPERATURES (2I5,F10.0,I5)\n"
#define PAKS_CardV15_7 "C    N   NC   FAK     KORC\n"
#define PAKS_CardH15_8 "C /15-8/ DATA FOR PRESCRIBED DISPLACEMENTS (3I5,F10.0,I5)\n"
#define PAKS_CardV15_8 "C    N   IP   NC   FAK     KORC\n"
#define CardH15_9 "C /15-9/ DATA ABOUT BODY FORCES (I5,3F10.0)\n"
#define CardV15_9 "C   NF        GX        GY        GZ\n"


#define PAKS_CardH16 "C /16/ FINAL CARD (A4)\n"
#define PAKS_CardV16 "STOP"


//Default values

//Card /2/
#define PAKS_INDFOR		2
//Card /3/
#define PAKS_NPER		1
#define PAKS_NKRT		0
//Card /4/
#define PAKS_NDIN		0
#define PAKS_ISOPS		0
#define PAKS_ICVEL		1
//Card /5/
#define PAKS_NULAZ		0
#define PAKS_NBLPR		1
#define PAKS_NBLGR		1
#define PAKS_ISTKO		0
#define PAKS_NCVPR		0
#define PAKS_ISTEM		0
#define	PAKS_ISTVN		0
#define PAKS_ISTSI		0
#define PAKS_ISTDE		0
#define PAKS_ISTNA		0
#define PAKS_IGRAPH		0
//Card /6/
#define PAKS_NPRGR1		1
#define PAKS_NPRGR2		1
#define PAKS_NPRGR3	 9000
#define PAKS_NPRGR4	    0
//Card /7/
#define PAKS_IREST		0
#define PAKS_NMODS		0
#define PAKS_ICCGG		0
#define PAKS_TOLG		0.
#define PAKS_ALFAG		0.
//Card /8/
#define PAKS_NKDT		1
#define PAKS_DTDT		1.
//Card /9/
#define PAKS_METOD		1
#define	PAKS_KONVE		1
#define	PAKS_KONVS		0
#define	PAKS_KONVM		0
#define	PAKS_TOLE		0.000001
#define	PAKS_TOLS		0.
#define	PAKS_TOLM		0.
#define	PAKS_NBRCR		2
//Card /10/
#define PAKS_CH			' '
#define PAKS_KORC		0
#define PAKS_LJ			0
//Card /11/
#define PAKS_MODEL2		1
#define PAKS_MODEL3		20
//Card /12/
#define PAKS_MOD			1
#define PAKS_MAT			1
#define PAKS_GUST		0.
//Card /12-1/
#define PAKS_FUNMAT1_1	1.e+5
#define PAKS_FUNMAT2_1	0
//Card /12-92/
#define PAKS_HILLS_FIBER_AXIS	3
//Card /13/
#define PAKS_IATYP		0
//#define NMODM		1
#define PAKS_INDBTH		0
#define PAKS_INDDTH		0
#define	PAKS_INDKOV		0
#define PAKS_COEF1		0.
#define PAKS_COEF2		0.
#define PAKS_COEF3		0.
//Card /13-2/a
#define PAKS_NGAUSX2		2
#define PAKS_NGAUSY2		2
#define PAKS_NGAUSZ2		2
#define PAKS_MSET		0
#define PAKS_BETA		0.
#define PAKS_MSLOJ		0
#define PAKS_CPP1		0.
#define PAKS_CPP2		0.
#define PAKS_CPP3		0.
//Card /13-2/b, /13-3/b
#define PAKS_IPRCO		0
#define PAKS_ISNA		2
#define PAKS_IPGS		0
#define PAKS_THI			1.
#define PAKS_KORC		0
#define PAKS_BTH			0.
#define PAKS_DTH			0.
//Card /13-3/a
#define PAKS_NGAUSX3		2
#define	PAKS_NGAUSY3		2
#define PAKS_NGAUSZ3		2
#define PAKS_BETA		0.
//Card /13-6
#define PAKS_NT			0
#define PAKS_NELM        0
#define PAKS_NTIP		0
#define PAKS_NKAR		0
#define PAKS_OY			0.
#define PAKS_OZ			0.
#define PAKS_YM			0.
#define PAKS_ZM			0.
#define PAKS_ALFAU		0.
#define PAKS_INDOF		0
#define PAKS_ALFA		0.
#define PAKS_CAPAY		0.
#define PAKS_CAPAZ		0.
#define PAKS_ILU 		0
#define PAKS_ICP 		0
#define PAKS_NTIP_13_6   0
#define PAKS_NAP_13_6    0



//Card /14/
#define PAKS_MAXTFT		100
//Card /15/
#define	PAKS_NPP2		0
#define PAKS_NPP3		0
#define PAKS_NPGR		0
#define PAKS_NPLJ		0
#define PAKS_NTEMP		0
#define PAKS_NZADP		0
#define PAKS_INDZS		0
#define PAKS_ICERNE		0
//Card /15-1/
#define PAKS_NC			0
#define PAKS_KORC		0
#define PAKS_FPOM		0.0
//Card /15-3/
#define PAKS_NFUN		1
#define PAKS_IPRAV		0

//Errors

#define PAKS_NO_NODES		"There are no nodes."
#define PAKS_NO_GROUPS		"There are no groups of elements."
#define PAKS_NO_LOADS		"There are no loads."


//Tolerancije
#define PAKS_LOAD_FORCE_TOL		1.e-8
#define PAKS_LOAD_PRESS_TOL		1.e-8
#define PAKS_LOAD_NDISP_TOL		1.e-12

#define PAKS_MAT_ALPHA_TOL		1.e-12