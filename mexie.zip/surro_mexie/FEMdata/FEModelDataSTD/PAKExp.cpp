// PAKExp.cpp: Functions for export to PAK's DAT file.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "FEModelData.h"
#include "PAKExp.h"
#include "BlockIDs.h"
#include "PakExpOption.h"
#include "math.h"
#include "StringAdvanced.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


UINT CModelData::ExportPAK_S(MyFile& file,CPakExpOption *peo)
{
	MyString str;
	UINT nGroupCount;
	UINT i;
	long lGeneralDataPos;


	if((m_NodArray.GetSize())<=0)
	{
		//AfxMessageBox(PAKS_NO_NODES);
		printf(PAKS_NO_NODES);
		return(0);	
	};
	
	if((nGroupCount=m_PropArray.GetSize())<=0)
	{
		//AfxMessageBox(PAKS_NO_GROUPS);
		printf(PAKS_NO_GROUPS);
		return(0);	
	};

//	Card /1/
	file.WriteString(PAKS_CardH1);
	file.WriteString(PAKS_CardV1);
	file.WriteString(m_PakGeneral.GetTitle()+"\n");

//Card /2/
	file.WriteString(PAKS_CardH2);
	file.WriteString(PAKS_CardV2);
	str.Format("%5u\n",PAKS_INDFOR);
	file.WriteString(str);
//Card /3/
 	file.WriteString(PAKS_CardH3);
	file.WriteString(PAKS_CardV3);
	lGeneralDataPos=file.GetPosition();
	str.Format("                              \n");
	file.WriteString(str);

//Card /3-1/
	UINT nRigidBodyCount;
	ExportPAK_RigidBodiesBasicData(file,nRigidBodyCount,peo);

//Card /4/
 	file.WriteString(PAKS_CardH4);
	file.WriteString(PAKS_CardV4);


//*****************************************************************************************************
//Ovo je dodato za DrillShell i to mora da se napravi drugacije jer ovako nema pojma
//Ne sme da se brlja po globalnim stepenima slobode jer to nikakve veze nema sa elementima
//Za sada je reseno tako sto ako je sesti stepen slobode -1 onda je ljuska Drill (Ziletova varijanta)
//*****************************************************************************************************
	bool GC[HNODES_MAX_DOF_COUNT];
	m_ConsArray[0].GetGlobalConstraints(GC);
	if(!peo->m_bDrillShell)
	{

		str.Format("%2u%2u%2u%2u%2u%2u   %5u%5u%5u\n",	GC[0],GC[1],GC[2],GC[3],GC[4],GC[5],
														(int)m_PakGeneral.GetDynamicAnIsSet(),
														(int)m_PakGeneral.GetEigenvalueIsSet(),
														m_PakGeneral.m_bFreeNumeration ? 1 : 0);
	}
	else
		//Ovo je taj deo koji ne valja
		str.Format("%2u%2u%2u%2u%2u%2d   %5u%5u%5u\n",	GC[0],GC[1],GC[2],GC[3],GC[4],-1,
														(int)m_PakGeneral.GetDynamicAnIsSet(),
														(int)m_PakGeneral.GetEigenvalueIsSet(),
														m_PakGeneral.m_bFreeNumeration ? 1 : 0);
//*****************************************************************************************************
//Kraj komentara


	file.WriteString(str);
//Card /5/
 	file.WriteString(PAKS_CardH5);
	file.WriteString(PAKS_CardV5);
	str.Format("%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u\n",PAKS_NULAZ,PAKS_NBLPR,PAKS_NBLGR,PAKS_ISTKO,
		PAKS_NCVPR,PAKS_ISTEM,PAKS_ISTVN,PAKS_ISTSI,PAKS_ISTDE,PAKS_ISTNA, PAKS_IGRAPH);
	file.WriteString(str);
//Card /6/
 	file.WriteString(PAKS_CardH6);
	file.WriteString(PAKS_CardV6);
	for(i=1;i<=PAKS_NBLPR;i++)
	{
		str.Format("%5u%5u%5u%5u%5u\n",i,PAKS_NPRGR1,PAKS_NPRGR2,PAKS_NPRGR3,PAKS_NPRGR4);
		file.WriteString(str);
	}
	for(i=1;i<=PAKS_NBLGR;i++)
	{
		str.Format("%5u%5u%5u%5u%5u\n",i,PAKS_NPRGR1,PAKS_NPRGR2,PAKS_NPRGR3,PAKS_NPRGR4);
		file.WriteString(str);
	}
//Card /7/
 	file.WriteString(PAKS_CardH7);
	file.WriteString(PAKS_CardV7);
//	str.Format("%5u          %5u%5u%10.6f%10.6f\n",IREST,NMODS,ICCGG,TOLG,ALFAG);
	str.Format("%5u          %5u%5u%10.6f%10.6f\n",m_PakGeneral.GetProgramStart(),PAKS_NMODS,PAKS_ICCGG,
		PAKS_TOLG,PAKS_ALFAG);
	file.WriteString(str);
//Card /8/
 	file.WriteString(PAKS_CardH8);
	file.WriteString(PAKS_CardV8);
	for(i=1;i<=(UINT)m_PakGeneral.GetNumOfPeriods();i++)
	{
		str.Format("%5u%5u%10.6f\n",i,m_PakGeneral.GetNumSteps(i-1),m_PakGeneral.GetStep(i-1));
		file.WriteString(str);
	}
    
	
	if (m_PakGeneral.GetDynamicAnIsSet())
	{
//Card /8.1/
		str.Format("%5u\n",1);
		file.WriteString (str);
	}

	if (m_PakGeneral.GetEigenvalueIsSet())
	{
//Card /8.3/
		str.Format("%5u%5u\n",1,m_PakGeneral.GetNSOPV());
		file.WriteString (str);
	}
	else
	{
		if (m_PakGeneral.GetDynamicAnIsSet())
		{
//Card /8.2/
			str.Format("\n");
			file.WriteString (str);
		}
	}
	
//Card /9/
 	file.WriteString(PAKS_CardH9);
	file.WriteString(PAKS_CardV9);
	
	str.Format("%5u%5u%5u%5u%5u%10.2e%10.2e%10.2e%10.2e%5u\n",m_PakGeneral.GetIterMethod(),
		m_PakGeneral.m_IterMethod.m_nMaxIterCount,m_PakGeneral.m_IterMethod.m_bConvEnergy,m_PakGeneral.m_IterMethod.m_bConvForce,m_PakGeneral.m_IterMethod.m_bConvMoment,
		m_PakGeneral.m_IterMethod.m_dTOLE,m_PakGeneral.m_IterMethod.m_dTOLS,m_PakGeneral.m_IterMethod.m_dTOLM,m_PakGeneral.m_IterMethod.m_dTOLA,PAKS_NBRCR);
	
	file.WriteString(str);

	if (m_PakGeneral.GetIterMethod()>=61)
	{
	 	file.WriteString(PAKS_CardH9_1);
		file.WriteString(PAKS_CardV9_1);
		
		str.Format("%5u%5u%5u%10.6f%10.6f%10.6f\n",m_PakGeneral.m_IterMethod.m_nOptimalIterCount,m_PakGeneral.GetNodeNumber(),m_PakGeneral.GetDirection(),
					m_PakGeneral.GetValue(),m_PakGeneral.GetAG(),m_PakGeneral.GetDS());
		file.WriteString(str);		
	}

	ExportPAK_Nodes(file);

	if (m_PakGeneral.GetDynamicAnIsSet() && !(m_PakGeneral.GetEigenvalueIsSet()))
	{
		//Card /10.1/
		str.Format("\n");
		file.WriteString (str);
	}

	if(m_ConsArray.GetSize() && m_ConsArray[0].m_ConsEqs.GetSize()>0)
	{
		//Card /10-02/
		ExportPAK_Equations(file);
	}

	if( nRigidBodyCount>0 )
	{
		//Card /10-03/
		ExportPAK_RigidBodies(file,nRigidBodyCount,peo);
	}

	UINT nModelCount;
	MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> FEMAP2PAK_MaterialMap;
	ExportPAK_MatModels(file,nModelCount,FEMAP2PAK_MaterialMap);
	ExportPAK_Elements(file,nGroupCount,FEMAP2PAK_MaterialMap,peo);

//Card /14/
	MyMap<UINT,UINT,UINT,UINT> FunctionMap;
	ExportPAK_TimeFunctions(file,FunctionMap);

//Card /15/
	ExportPAK_Loads(file,FunctionMap);


//Card /16/
 	file.WriteString(PAKS_CardH16);
	file.WriteString(PAKS_CardV16);

//Upisivanje naknadno

	file.Seek(lGeneralDataPos,SEEK_SET);

//	MyMap<UINT,UINT,UINT,UINT> TypesOfEl;
//	TypesOfEl.RemoveAll();

//	for(i=0;i<(UINT)m_ElArray.GetSize();i++)
//	{
//		TypesOfEl[m_PropArray[m_nPropIndex[m_ElArray[i].m_uPropID]].m_uType]++;
//	}
	
//	P R I V R E M E N O
	str.Format("%5u%5u%5u%5u     %5u",m_NodArray.GetSize(),nGroupCount, nModelCount, m_PakGeneral.GetNumOfPeriods(),
				nRigidBodyCount);
//	str.Format("%5u%5u%5u%5u",m_NodArray.GetSize(),TypesOfEl.GetCount(),1,m_PakGeneral.GetNumOfPeriods(),NKRT);

	file.WriteString(str);
	file.Seek(0,SEEK_END);

	return(-1);
}

UINT CModelData::ExportPAK_Elements(MyFile& file,UINT &nGroupCount,MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap,CPakExpOption *peo)
{
	MyString str;
	UINT i,j,k;
	//UINT uNMODM,uMatIID;
	MyArray <UINT,UINT&> ElNum;
	MyMap<UINT,UINT,UINT,UINT> PropIndex; // relation between Property ID and it's position in ElNum;
	HElement el;
	UINT uIETYP,uNETIP;
	PAK_MaterialKey mms;


	HProperties pr;
	for(i=0;i<(UINT)m_PropArray.GetSize();i++)	//Loop by properties (group of elements)
	{
		pr=m_PropArray[i];
		FEMAP2PAK_MaterialMap.Lookup(pr.m_uMatIID, mms);	//Struktura cuva materijalni model i materijal
		switch (pr.m_Type)
		{
//****************************************************************************
//****************************** 1D Elementi *********************************
//****************************************************************************
		case HProperties::PT_ROD: case HProperties::PT_BEAM:
			{
				 //Card /13/
				UINT uNE2=0;
				
				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
					if(m_ElArray[j].m_uPropID==pr.m_nID) 
					{
						uNE2++;
					}
				 if(uNE2>0)
				 {
				 if(pr.m_Type==HProperties::PT_ROD)
				 {
					 uNETIP=PAK_TRUSS;

					 file.WriteString(PAKS_CardH13);
					 file.WriteString(PAKS_CardV13);
 			 		 
//					 NMODM=m_PakGeneral.GetMaterialModel(uNETIP);

 
					 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
					 uNETIP,uNE2,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
					 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
					 file.WriteString(str);

					 file.WriteString(PAKS_CardH13_1);
					 file.WriteString(PAKS_CardH13_1_a_1);
					 file.WriteString(PAKS_CardV13_1_a_2);
					 file.WriteString(PAKS_CardH13_1_b_1);
					 file.WriteString(PAKS_CardV13_1_b_2);

					 for(j=0;j<(UINT)m_ElArray.GetSize();j++)	//Loop by elements
					 if(m_ElArray[j].m_uPropID==pr.m_nID)
						{
							el=m_ElArray[j];
//							pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

							if(el.m_uTopology==FETO_LINE)
							{
								str.Format("%5u%5u%5u%10.6f%5u\n",
									el.m_nID,mms.m_nMaterial,PAKS_ISNA,pr.m_dValue[0],PAKS_KORC);
								file.WriteString(str);

								for(k=0;k<FEMAP_Topology_NodeCount[el.m_uTopology];k++) 
								{
									str.Format("%5u",el.m_uNode[k]);
									file.WriteString(str);
								}
								file.WriteString("\n");
							}
						}
				 }
				 else if(pr.m_Type==HProperties::PT_BEAM)
				 {
					 uNETIP=PAK_THINWALED_B;

					 file.WriteString(PAKS_CardH13);
					 file.WriteString(PAKS_CardV13);

//					 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);
					 
					 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
					 uNETIP,uNE2,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,
					 PAKS_INDDTH,PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
					 file.WriteString(str);

					 file.WriteString(PAKS_CardH13_6);
					 file.WriteString(PAKS_CardH13_6_a_1);
					 file.WriteString(PAKS_CardV13_6_a_2);
  					 str.Format("%5u%5u%5u%5u%10.6f%10.6f%10.6f%10.6f%10.6f%5u\n",
									PAKS_NT,PAKS_NELM,PAKS_NTIP,PAKS_NKAR,PAKS_OY,PAKS_OZ,
									PAKS_YM,PAKS_ZM,PAKS_ALFAU,PAKS_INDOF);
					 file.WriteString(str);

// 					 pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

					 file.WriteString(PAKS_CardH13_6_b_1);
					 file.WriteString(PAKS_CardV13_6_b_2);
  					 str.Format("%10.6f%10.6f%10.6f%10.6f",
									pr.m_dValue[0], pr.m_dValue[1], pr.m_dValue[2], pr.m_dValue[4]);
					 file.WriteString(str);
  					 str.Format("%10.6f%10.6f%10.6f\n", PAKS_ALFA,PAKS_CAPAY,PAKS_CAPAZ);
					 file.WriteString(str);

 					 file.WriteString(PAKS_CardH13_6_h_1);
					 file.WriteString(PAKS_CardV13_6_h_2);

					 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
					 if(m_ElArray[j].m_uPropID==pr.m_nID)
						{
							el=m_ElArray[j];
//							pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

							if(el.m_uTopology==FETO_LINE)
							{
								str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
									el.m_nID,el.m_uNode[0],el.m_uNode[1],
									PAKS_NTIP_13_6,mms.m_nMaterial,PAKS_NAP_13_6,0,el.m_dOrient[0],el.m_dOrient[1],el.m_dOrient[2]);
								file.WriteString(str);
							}
						}
				 
				 }
				 }
			}
			break;


//****************************************************************************
//****************************** 2D Elementi *********************************
//****************************************************************************
		case HProperties::PT_SHEAR_LIN:case HProperties::PT_SHEAR_PAR:
		case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:
		case HProperties::PT_BENDING_LIN:case HProperties::PT_BENDING_PAR:
		case HProperties::PT_PLATE_LIN:case HProperties::PT_PLATE_PAR:
		case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR:
		case HProperties::PT_LAMINATE_LIN:case HProperties::PT_LAMINATE_PAR:
		case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR:
		case HProperties::PT_EFG_2D:
			{
				UINT uNE4=0,uNE3=0;

				switch (pr.m_Type)
				{
					case HProperties::PT_SHEAR_LIN:case HProperties::PT_SHEAR_PAR: uIETYP=4;
						break;
					case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:
					case HProperties::PT_BENDING_LIN: case HProperties::PT_BENDING_PAR: uIETYP=0;
						break;
					case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR: uIETYP=2;
						break;
					case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR: uIETYP=1;
						break;
					default:
						uIETYP=0;
				}

				UINT nPAKS_ISNA = PAKS_ISNA;

				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						if(m_ElArray[j].m_uTopology==FETO_QUAD4 || m_ElArray[j].m_uTopology==FETO_QUAD8) uNE4++;
						else uNE3++;
					}

				if(uNE4>0)	//Cetvorougaoni 2D Element
				{
				 //Card /13/
				 switch(pr.m_Type)
				 {
					 case HProperties::PT_BENDING_LIN: case HProperties::PT_BENDING_PAR:
					 case HProperties::PT_PLATE_LIN: case HProperties::PT_PLATE_PAR:
					 case HProperties::PT_LAMINATE_LIN: case HProperties::PT_LAMINATE_PAR:
					 {
						 uNETIP=(peo->m_bShellAsBatheDvorkin ? PAK_SHELL_BD : PAK_ISO_SHELL); 
						 nPAKS_ISNA = pr.m_PrintStressShell;
					 }
						 break;
					 case HProperties::PT_EFG_2D: uNETIP = 20;
						 break;
					 default: uNETIP=PAK_ISO_2D;
				 }

				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//					 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE4,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);

				 // Beta - angle of first material axis
				 double dBeta = 0.0;
				 if( pr.m_dValue.GetSize() >= 2 ) dBeta = pr.m_dValue[1];

				 if(uNETIP==PAK_ISO_2D || uNETIP==PAK_EFG_2D)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,dBeta,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 else
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5d%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					  PAKS_NGAUSX2,PAKS_NGAUSY2,(peo->m_bDrillShell ? -2 : PAKS_NGAUSZ2),
					  PAKS_MSET,dBeta,PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 file.WriteString(str);

				 if(pr.m_Type == HProperties::PT_EFG_2D)
				 {
					 str.Format("%5d%5d%5d%10.3f\n",3,this->m_NodArray.GetSize(),this->m_NodArray.GetSize(),2.0);
					file.WriteString(str);
				 }

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8)
						{
							UINT uIPGS=1;

							if( uIETYP == 0 ) //Plane stress
							{
								str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
									el.m_nID,mms.m_nMaterial,PAKS_IPRCO,nPAKS_ISNA,uIPGS,pr.m_dValue[0],
									PAKS_KORC,PAKS_BTH,PAKS_DTH);
							}
							else
							{
								str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
									el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,uIPGS,0.0,
									PAKS_KORC,PAKS_BTH,PAKS_DTH);
							}

							file.WriteString(str);

							for(k=0;k<FEMAP_Topology_NodeCount[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}

				if(uNE3>0)	// Trougaoni 2D Element
				{
				 if(uNE4>0) nGroupCount++;
				 //Card /13/
				 if(pr.m_Type==HProperties::PT_BENDING_LIN || pr.m_Type==HProperties::PT_BENDING_PAR ||
					pr.m_Type==HProperties::PT_PLATE_LIN || pr.m_Type==HProperties::PT_PLATE_PAR ||
					pr.m_Type==HProperties::PT_LAMINATE_LIN || pr.m_Type==HProperties::PT_LAMINATE_PAR) uNETIP=PAK_ISO_TRI_SHELL; 
				 else uNETIP=PAK_ISO_TRI;

				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE3,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);

				 if(uNETIP==PAK_ISO_TRI)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,PAKS_BETA,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 else
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_NGAUSZ2,PAKS_MSET,PAKS_BETA,PAKS_MSLOJ,
					PAKS_CPP1,PAKS_CPP2,PAKS_CPP3, pr.m_IncompatibleModes);
				 }
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_TRI3 || el.m_uTopology==FETO_TRI6)
						{
							str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,pr.m_dValue[0],
								PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<FEMAP_Topology_NodeCount[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[k]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}				

			}
			break;
//****************************************************************************
// ****************************** 3D Elementi ********************************
//****************************************************************************
		case HProperties::PT_3D_LIN:case HProperties::PT_3D_PAR:
			{
				UINT uNE_3D=0,uNE_PRISM=0,uNE_TETRA=0;;

				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						switch (el.m_uTopology)
						{
							case FETO_BRICK8:case FETO_BRICK20: uNE_3D++;
								break;
							case FETO_WEDGE6:case FETO_WEDGE15: uNE_PRISM++;
								break;
							case FETO_TETRA4:case FETO_TETRA10: uNE_TETRA++;
								break;
						}
					}

				if(uNE_3D>0)	// 3D Element
				{
				 //Card /13/
				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 PAK_ISO_3D,uNE_3D,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,PAKS_INDKOV,
				 PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);
				 
				 file.WriteString(PAKS_CardH13_3);
				 file.WriteString(PAKS_CardV13_3_a_1);
				 file.WriteString(PAKS_CardV13_3_a_2);
				 str.Format("%5u%5u%5u     %10.6f                                   %5d\n",
					PAKS_NGAUSX3,PAKS_NGAUSY3,PAKS_NGAUSZ3,PAKS_BETA, pr.m_IncompatibleModes);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_3_b_1);
				 file.WriteString(PAKS_CardV13_3_b_2);
				 file.WriteString(PAKS_CardV13_3_c_1);
				 file.WriteString(PAKS_CardV13_3_c_2);
				
				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 {
				    if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];
						double dBirth = 0.0;

						if(el.m_uTopology==FETO_BRICK8 || el.m_uTopology==FETO_BRICK20)
						{
							//Check if there is additional data for element
							if(mms.m_nModel == PAKM_USER_SUPPLIED && mms.m_nSubModel == PAKM_USER_SUPPLIED_HILLS_2FIBER)
							{
								for(UINT k = 0; k < (UINT)m_LoadArray[0].m_StructLoads.GetSize(); k++)
								{
									StructLoad &sl = m_LoadArray[0].m_StructLoads[k];
									if(sl.m_uLoadtype == StructLoad::LT_ELEM_HEAT_FL && sl.m_uLoadID == el.m_nID)
									{
										dBirth = sl.m_dValue[0];
										break;
									}
								}
							}

							str.Format("%5u%5u%5u%5u%5u%5u          %10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,PAKS_KORC,dBirth,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<8;k++) 
							{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder3D[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
							if(el.m_uTopology==FETO_BRICK20)
							 for(k=8;k<20;k++) 
							 {
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder3D[k]]);
								file.WriteString(str);
							 }
							file.WriteString("\n");
						}
					}
				 }
				}
				
				if(uNE_PRISM>0)	// 3D Prismatic Element
				{
//				 UINT node_order[15]={5,6,4,1,2,0,17,18,16,9,10,8,13,14,12};
				 UINT node_order[15]={4,5,6,0,1,2,16,17,18,8,9,10,12,13,14};
				 
				 if(uNE_3D>0) nGroupCount++;
				 //Card /13/
				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);
				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 PAK_ISO_PRISM,uNE_PRISM,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,
				 PAKS_INDDTH,PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);
				 
				 file.WriteString(PAKS_CardH13_3);
				 file.WriteString(PAKS_CardV13_3_a_1);
				 file.WriteString(PAKS_CardV13_3_a_2);
				 str.Format("%5u%5u%5u     %10.6f                                   %5d\n",
					PAKS_NGAUSX3,PAKS_NGAUSY3,PAKS_NGAUSZ3,PAKS_BETA, pr.m_IncompatibleModes);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_3_b_1);
				 file.WriteString(PAKS_CardV13_3_b_2);
				 file.WriteString(PAKS_CardV13_3_c_1);
				 file.WriteString(PAKS_CardV13_3_c_2);
				
				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 {
					if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_WEDGE6 || el.m_uTopology==FETO_WEDGE15)
						{
							str.Format("%5u%5u%5u%5u%5u%5u          %10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<6;k++) 
							{
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
							if(el.m_uTopology==FETO_WEDGE15)
							 for(k=6;k<15;k++) 
							 {
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							 }
							file.WriteString("\n");
						}
					}
				 }
				}
			
				if(uNE_TETRA>0)	// 3D Tetra Element
				{
//				 UINT node_order[10]={4,1,2,0,9,10,8,13,14,12};
				 UINT node_order[10]={4,0,1,2,8,9,10,12,13,14};
				 
				 if(uNE_3D>0 || uNE_PRISM>0) nGroupCount++;
				 //Card /13/
				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 PAK_ISO_TETRA,uNE_TETRA,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,
				 PAKS_INDDTH,PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);
				 
				 file.WriteString(PAKS_CardH13_3);
				 file.WriteString(PAKS_CardV13_3_a_1);
				 file.WriteString(PAKS_CardV13_3_a_2);
				 str.Format("%5u%5u%5u     %10.6f                                   %5d\n",
					PAKS_NGAUSX3,PAKS_NGAUSY3,PAKS_NGAUSZ3,PAKS_BETA, pr.m_IncompatibleModes);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_3_b_1);
				 file.WriteString(PAKS_CardV13_3_b_2);
				 file.WriteString(PAKS_CardV13_3_c_1);
				 file.WriteString(PAKS_CardV13_3_c_2);
				
				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 {
				    if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_TETRA4 || el.m_uTopology==FETO_TETRA10)
						{
							str.Format("%5u%5u%5u%5u%5u%5u          %10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<4;k++) 
							{
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
							if(el.m_uTopology==FETO_TETRA10)
							 for(k=4;k<10;k++) 
							 {
								str.Format("%5u",el.m_uNode[node_order[k]]);
								file.WriteString(str);
							 }
							file.WriteString("\n");
						}
					}
				 }
				}
			}
			break;

		case HProperties::PT_RIGID_BODY:
			{
				nGroupCount--;
			}
		}
	}

	return(-1);
}

UINT CModelData::ExportPAK_Nodes(MyFile& file)
{

	MyString str;
	UINT i;
	UINT ci,cj;
	int nConstraints[HNODES_MAX_DOF_COUNT];

	//Card /10/
 	file.WriteString(PAKS_CardH10);
	file.WriteString(PAKS_CardV10);
	for(i=0;i<(UINT)m_NodArray.GetSize();i++)
	{
		HNodes &Node = m_NodArray[i];
		
		for(cj=0;cj<HNODES_MAX_DOF_COUNT;cj++) nConstraints[cj] = (Node.m_bPermbc[cj] ? 1 : 0 );

		if(m_ConsArray.GetSize()>0)
		{
			for(ci=0;ci<(UINT)m_ConsArray[0].m_ConsNodes.GetSize();ci++)
				if(m_ConsArray[0].m_ConsNodes[ci].m_uNodeID==Node.m_nID)
				{
					for(cj=0;cj<6;cj++)
						if(m_ConsArray[0].m_ConsNodes[ci].m_bDOF[cj]) nConstraints[cj] = 1;
					break;
				}

			//Equations
			for(ci=0;ci<(UINT)m_ConsArray[0].m_ConsEqs.GetSize();ci++)
			{
				ConsEq &Eq = m_ConsArray[0].m_ConsEqs[ci];

				if(Eq.m_EqCoefs[0].m_uEqn_nodeID == Node.m_nID)
				{
					nConstraints[Eq.m_EqCoefs[0].m_uEqn_dof-1] = -1;
				}
			}
		}

		str.Format("%5u%c%2d%2d%2d%2d%2d%2d  %10.5f%10.5f%10.5f%5u%5u\n",
			Node.m_nID,PAKS_CH,	nConstraints[0],nConstraints[1],nConstraints[2],
							nConstraints[3],nConstraints[4],nConstraints[5],
			Node.m_dX,Node.m_dY,Node.m_dZ,PAKS_KORC,PAKS_LJ);
		file.WriteString(str);
	}


	return(-1);
}

UINT CModelData::ExportPAK_RigidBodiesBasicData(MyFile& file,UINT &nRigidBodyCount, CPakExpOption *peo)
{
	MyString str;
	UINT i;

	//Determine rigid body count
	nRigidBodyCount = 0;
	UINT nMaxRigidBodyNodeCount = 0;
	for(i = 0; i < (UINT)m_ElArray.GetSize(); i++)
	{
		HElement &Elem = m_ElArray[i];
		HProperties &Property = m_PropArray.Get(Elem.m_uPropID);

		if( Property.m_Type == HProperties::PT_RIGID_BODY )
		{
			nRigidBodyCount++;
			if( (UINT)Elem.m_NodeList.GetSize() > nMaxRigidBodyNodeCount )	nMaxRigidBodyNodeCount = Elem.m_NodeList.GetSize();
		}
	}

	if( nRigidBodyCount == 0 ) return(0);

	//Determine rigid body type (2D or 3D)
	UINT nRigidBodyType = 0;
	const double Z_TOLERANCE = 1.e-10;

	for(i = 0; i < (UINT)m_NodArray.GetSize(); i++)
	{
		HNodes &Node = m_NodArray[i];

		if( fabs(Node.m_dZ) > Z_TOLERANCE )
		{
			nRigidBodyType = 1;	// 3D
			break;
		}
	}

	//Card /3-1/
 	file.WriteString(PAKS_CardH3_1);
	file.WriteString(PAKS_CardV3_1);

	str.Format("%5u%5u%5u%5u\n",nRigidBodyType,1,nMaxRigidBodyNodeCount,0);
	file.WriteString(str);

	return(0);
}

UINT CModelData::ExportPAK_RigidBodies(MyFile& file, UINT nRigidBodyCount, CPakExpOption *peo)
{
	MyString str;
	UINT i;

	//Card /10-03/
 	file.WriteString(PAKS_CardH10_03);
	file.WriteString(PAKS_CardH10_03_a);
	file.WriteString(PAKS_CardV10_03_a);

	str.Format("%5u%5u%5u\n",nRigidBodyCount,0,0);
	file.WriteString(str);

	for(i = 0; i < (UINT)m_ElArray.GetSize(); i++)
	{
		HElement &Elem = m_ElArray[i];
		HProperties &Property = m_PropArray.Get(Elem.m_uPropID);

		if( Property.m_Type == HProperties::PT_RIGID_BODY )
		{
			file.WriteString(PAKS_CardH10_03_b);
			file.WriteString(PAKS_CardV10_03_b);

			str.Format("%5u%5u\n", Elem.m_uNode[0], Elem.m_NodeList.GetSize());
			file.WriteString(str);

			file.WriteString(PAKS_CardH10_03_d);
			file.WriteString(PAKS_CardV10_03_d);
			for(UINT j = 0; j < (UINT)Elem.m_NodeList.GetSize(); j++)
			{
				str.Format("%5u", Elem.m_NodeList[j]);
				file.WriteString(str);
				if( ((j+1)%14 == 0) || (j == (UINT)Elem.m_NodeList.GetSize()-1) )	file.WriteString("\n");
			}
		}
	}

	return(0);
}

UINT CModelData::ExportPAK_MatModels(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap)
{

	MyString str;
	MyStringAdvanced p_str;
	UINT i,k;
	UINT PAK_Model, PAK_SubModel=0;
	PAK_MaterialKey PAK_Material;



	//Determine appropriate PAK material for each FEMAP material
	FEMAP2PAK_MaterialMap.RemoveAll();
	MyMap<UINT,UINT,UINT,UINT> MaterialsInModel;
	MaterialsInModel.RemoveAll();

	for(i=0;i<(UINT)m_MaterialsArray.GetSize();i++)
	{
		HMaterial &Material = m_MaterialsArray[i];

		switch (Material.m_uType)
		{
		case HMaterial::MT_FEMAP_ISO: PAK_Model = PAKM_ELASTIC_ISO;
			break;
		case HMaterial::MT_FEMAP_2D_ORTHO: case HMaterial::MT_FEMAP_3D_ORTHO: PAK_Model = PAKM_ELASTIC_ORTHO;
			break;
		case HMaterial::MT_FEMAP_OTHER:
			{
				switch (Material.m_uSubType)
				{
				case HMaterial::ST_PAK_ELASTIC_ISO: 	PAK_Model = PAKM_ELASTIC_ISO;
					break;
				case HMaterial::ST_PAK_THERMO_ELASTIC_ISO: 	PAK_Model = PAKM_THERMO_ELASTIC_ISO;
					break;
				case HMaterial::ST_PAK_HYSTERELASTIC: 	PAK_Model = PAKM_HYSTERELASTIC;
					break;
				case HMaterial::ST_PAK_BIO32:		 	PAK_Model = PAKM_BIO32;
					break;
				case HMaterial::ST_PAK_MODEL_41:		PAK_Model = PAKM_TENSEGRITY;
					break;
				case HMaterial::ST_PAK_BIAXIAL:		 	PAK_Model = PAKM_BIAXIAL;
					break;
				case HMaterial::ST_PAK_MODEL_37:		PAK_Model = PAKM_MODEL_37;
					break;
				case HMaterial::ST_PAK_MODEL_38:		PAK_Model = PAKM_MODEL_38;
					break;
				case HMaterial::ST_PAK_MODEL_39:		PAK_Model = PAKM_MODEL_39;
					break;
				case HMaterial::ST_PAK_HILLS2002:	 	PAK_Model = PAKM_HILLS2002;
					break;
				case HMaterial::ST_PAK_HILLS:		 	PAK_Model = PAKM_USER_SUPPLIED; PAK_SubModel = PAKM_USER_SUPPLIED_HILLS;
					break;
				case HMaterial::ST_PAK_HILLS_2FIBER: 	PAK_Model = PAKM_USER_SUPPLIED; PAK_SubModel = PAKM_USER_SUPPLIED_HILLS_2FIBER;
					break;
				case HMaterial::ST_PAK_MODEL_62:	 	PAK_Model = PAKM_MODEL_62;
					break;
				case HMaterial::ST_PAK_DELFINO_SEF_2D: 	PAK_Model = PAKM_DELFINO_SEF_2D;
					break;
				case HMaterial::ST_PAK_FUNG_SEF:	 	PAK_Model = PAKM_FUNG_SEF;
					break;
				default:
					continue;
				}
			}
			break;
		default:
			ASSERT(FALSE);
		}

		//Material count within PAK_Model
		UINT MaterialCount;
		if( !MaterialsInModel.Lookup(PAK_Model, MaterialCount) )	MaterialCount = 0;
		MaterialsInModel.SetAt(PAK_Model, ++MaterialCount);


		FEMAP2PAK_MaterialMap.SetAt(Material.m_nID, PAK_MaterialKey(PAK_Model,PAK_SubModel,MaterialCount));
	}


//Card /11/

	file.WriteString(PAKS_CardH11);
	file.WriteString(PAKS_CardV11);

	map<UINT,UINT>::const_iterator pos = MaterialsInModel.GetStartPosition();
	while( pos != MaterialsInModel.end() )
	{
		UINT nMaterialCount;

		MaterialsInModel.GetNextAssoc( pos, PAK_Model, nMaterialCount);
	
		str.Format("%5u%5u%5u\n",PAK_Model,nMaterialCount,PAKS_MODEL3);
		file.WriteString(str);

		if( PAK_Model == PAKM_USER_SUPPLIED )
		{
			//Find first material in PAKM_USER_SUPPLIED model
			for(k=0;k<(UINT)m_MaterialsArray.GetSize();k++)
			{
				HMaterial &Material = m_MaterialsArray[k];

				bool bFound;
				bFound = FEMAP2PAK_MaterialMap.Lookup(Material.m_nID, PAK_Material);
				ASSERT(bFound);

				if(PAK_Material.m_nModel == PAK_Model) break;
			}
			ASSERT( k < (UINT)m_MaterialsArray.GetSize() );

			switch( PAK_Material.m_nSubModel )
			{
			case PAKM_USER_SUPPLIED_HILLS:
			{
				str.Format("%5u%5u%5u%5u\n", 3 /*int*/, 8 /*double*/, 4 /*curve*/, 5 /*state variables*/);
				file.WriteString(str);
			}
			break;
			case PAKM_USER_SUPPLIED_HILLS_2FIBER:
			{
				str.Format("%5u%5u%5u%5u%5u\n", 3 /*int*/, 19 /*double*/, 8 /*curve*/, 10 /*state variables*/, 1 /*nodal variables*/);
				file.WriteString(str);
			}
			break;
			default:
				ASSERT(FALSE);
			}
		}


	}	
	
//Loop over material models

	pos = MaterialsInModel.GetStartPosition();
	while( pos != MaterialsInModel.end() )
	{
		UINT nMaterialCount;

		MaterialsInModel.GetNextAssoc( pos, PAK_Model, nMaterialCount);
		
		UINT nMaterialIndex=0;

		for(k=0;k<(UINT)m_MaterialsArray.GetSize();k++)
		{
			HMaterial &Material = m_MaterialsArray[k];

			bool bFound;
			bFound = FEMAP2PAK_MaterialMap.Lookup(Material.m_nID, PAK_Material);
			ASSERT(bFound);

			if(PAK_Material.m_nModel == PAK_Model)
			{
				nMaterialIndex++;
				
				//Card /12/
 				file.WriteString(PAKS_CardH12);
				file.WriteString(PAKS_CardV12);
				p_str.Format("%5u%5u%10.4.2e\n",PAK_Material.m_nModel,PAK_Material.m_nMaterial,Material.m_dDensity);
				file.WriteString(p_str);

				switch (PAK_Model)
				{
				case  PAKM_ELASTIC_ISO:
					{
					label_elastic_iso:
					//Card /12-1/
					if (fabs(Material.m_dAlpha[0])>PAKS_MAT_ALPHA_TOL) goto label_thermo_elastic_iso;
						file.WriteString(PAKS_CardH12_1);
						file.WriteString(PAKS_CardV12_1_1);
						file.WriteString(PAKS_CardV12_1_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_1_3);
						file.WriteString(PAKS_CardV12_1_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_THERMO_ELASTIC_ISO:
					{
					label_thermo_elastic_iso:
						file.WriteString(PAKS_CardH12_1);
						file.WriteString(PAKS_CardV12_1_1);
						file.WriteString(PAKS_CardV12_1_2);
						str.Format("%5d\n",1);
						file.WriteString(str);
						p_str.Format("%10.2f%10.2.2e\n",2000.,Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_1_3);
						file.WriteString(PAKS_CardV12_1_4);
						str.Format("%5d\n",1);
						p_str.Format("%10.2f%10.2.2e\n",2000.,Material.m_dNu[0]);
						file.WriteString(str);
						file.WriteString(p_str);
						str.Format("%5d\n",1);
						p_str.Format("%10.2f%10.2.2e\n",2000.,Material.m_dAlpha[0]);
						file.WriteString(str);
						file.WriteString(p_str);
						str.Format("%10f\n",Material.m_dTemperature);
						file.WriteString(str);
					}
					break;
				case PAKM_ELASTIC_ORTHO:
					{
			 			file.WriteString(PAKS_CardH12_2);
						file.WriteString(PAKS_CardV12_2_1);
						file.WriteString(PAKS_CardV12_2_2);
						str.Format("%10.3e%10.3e%10.3e\n",Material.m_dE[0],Material.m_dE[1],Material.m_dE[2]);
						file.WriteString(str);
						file.WriteString(PAKS_CardV12_2_3);
						file.WriteString(PAKS_CardV12_2_4);
						str.Format("%10.3e%10.3e%10.3e\n",Material.m_dNu[0],Material.m_dNu[1],Material.m_dNu[2]);
						file.WriteString(str);
						file.WriteString(PAKS_CardV12_2_5);
						file.WriteString(PAKS_CardV12_2_6);
						str.Format("%10.3e%10.3e%10.3e\n",Material.m_dG[0],Material.m_dG[1],Material.m_dG[2]);
						file.WriteString(str);
					}
					break;
				case  PAKM_MISES_PLASTIC:
					{
			 			if (Material.m_uNonlin_type==0) goto label_elastic_iso;
						file.WriteString(PAKS_CardH12_1);
						file.WriteString(PAKS_CardV12_1_1);
						file.WriteString(PAKS_CardV12_1_2_1);
						str.Format("%10.3e%10.3e\n",Material.m_dE[0],Material.m_dNu[0]);
						file.WriteString(str);
						str.Format("%10.3e%10.3e\n",Material.m_dPlastYieldLim[0],Material.m_dPlastHardSlope);
						file.WriteString(str);
					}
					break;
				case  PAKM_HYSTERELASTIC:
					{
						file.WriteString(PAKS_CardH12_37);
						file.WriteString(PAKS_CardV12_37_1);
						file.WriteString(PAKS_CardV12_37_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_37_3);
						file.WriteString(PAKS_CardV12_37_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Loading hysteresis function
						UINT i, nPointCount;
						//UINT nIndex;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(PAKS_CardV12_37_5);
						file.WriteString(PAKS_CardV12_37_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_37_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							p_str.Format("%10.4.1e\n",LoadFunc.m_FunctionEntry[i].m_dY);
							file.WriteString(p_str);
						}

						//Unloading hysteresis function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(PAKS_CardV12_37_8);
						file.WriteString(PAKS_CardV12_37_9);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_37_10);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							p_str.Format("%10.4.1e\n",UnloadFunc.m_FunctionEntry[i].m_dY);
							file.WriteString(p_str);
						}
					}
					break;
				case PAKM_HILLS2002:
					{
						file.WriteString(PAKS_CardV12_31_1);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0],Material.m_dNu[0],Material.m_dGMatrix_3D[0],Material.m_dGMatrix_3D[1]);
						file.WriteString(p_str);

						file.WriteString(PAKS_CardV12_31_2);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dGMatrix_3D[2],Material.m_dGMatrix_3D[3],Material.m_dGMatrix_3D[4],Material.m_dThermal_cap);
						file.WriteString(p_str);

						//Stress-Stretch function
						HFunctions &StressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[6]);
						ExportPAK_Function(file, StressStretchFunc, Material.m_dGMatrix_3D[6], "Stress-Stretch function", "Stretch", "Stress");

						//Activation function
						HFunctions &ActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[7]);
						ExportPAK_Function(file, ActivationFunc, Material.m_dGMatrix_3D[7], "Activation function", "Time", "Activation");
					}
					break;
				case  PAKM_BIO32:
					{
						file.WriteString(PAKS_CardH12_32);

						file.WriteString(PAKS_CardV12_32_1);
						file.WriteString(PAKS_CardV12_32_2);
						p_str.Format("%10.4.1e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						file.WriteString(PAKS_CardV12_32_3);
						p_str.Format("%10.4.1e",Material.m_dAlpha[0]);
						file.WriteString(p_str);
						p_str.Format("%10.4.1e\n",Material.m_dAlpha[1]);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_32_4);
						p_str.Format("%10.4.1e",Material.m_dAlpha[2]);
						file.WriteString(p_str);
						p_str.Format("%10.4.1e\n",Material.m_dAlpha[3]);
						file.WriteString(p_str);

					}
					break;				
				case  PAKM_TENSEGRITY:
					{
						file.WriteString(PAKS_CardH12_41);

						file.WriteString(PAKS_CardV12_41_1);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0], Material.m_dNu[0], Material.m_dK[0]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_BIAXIAL:
					{
						UINT i, nPointCount = 13;
						MyString str;
						file.WriteString(PAKS_CardH12_36);

						file.WriteString(PAKS_CardV12_36_1);
						p_str.Format("%10.4.1e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_36_2);
						p_str.Format("%10.4.1e\n",Material.m_dNu[0]);
						file.WriteString(p_str);
						
						//Uniaxial stress-stretch function
						HFunctions &UniaxialFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(PAKS_CardV12_36_3);

						nPointCount = UniaxialFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UniaxialFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UniaxialFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

						//Biaxial stress-stretch function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(PAKS_CardV12_36_4);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UnloadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[1];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}
						
					}
					break;
				case  PAKM_MODEL_37:
					{
						file.WriteString(PAKS_CardH12_37);
						file.WriteString(PAKS_CardV12_37_1);
						file.WriteString(PAKS_CardV12_37_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_37_3);
						file.WriteString(PAKS_CardV12_37_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Loading stress-stretch function
						UINT i, nPointCount;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(PAKS_CardV12_37_5);
						file.WriteString(PAKS_CardV12_37_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						file.WriteString(PAKS_CardV12_37_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = LoadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

						//Unloading stress-stretch function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(PAKS_CardV12_37_8);
						file.WriteString(PAKS_CardV12_37_9);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(PAKS_CardV12_37_10);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UnloadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[1];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}
					}
					break;				
				case  PAKM_MODEL_38:
					{
						file.WriteString(CardH12_38);
						file.WriteString(CardV12_38_3);
						file.WriteString(CardV12_38_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Stress-stretch function
						UINT i, nPointCount;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(CardV12_38_5);
						file.WriteString(CardV12_38_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						file.WriteString(CardV12_38_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = LoadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

					}
					break;
				case  PAKM_MODEL_39:
					{
						file.WriteString(CardH12_39);
						file.WriteString(CardV12_39_1);
						file.WriteString(CardV12_39_2);
						p_str.Format("%10.4.2e\n",Material.m_dE[0]);
						file.WriteString(p_str);
						file.WriteString(CardV12_39_3);
						file.WriteString(CardV12_39_4);
						p_str.Format("%10.4.2e\n",Material.m_dNu[0]);
						file.WriteString(p_str);

						//Loading stress-stretch function
						UINT i, nPointCount;

						HFunctions &LoadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[0]);

						file.WriteString(CardV12_39_5);
						file.WriteString(CardV12_39_6);

						nPointCount = LoadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);

						double dFunctionY;
						file.WriteString(CardV12_39_7);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",LoadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = LoadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[0];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}

						//Unloading stress-stretch function
						HFunctions &UnloadFunc = m_FunctionsArray.Get(Material.m_uFAlpha[1]);

						file.WriteString(CardV12_39_8);
						file.WriteString(CardV12_39_9);

						nPointCount = UnloadFunc.m_FunctionEntry.GetSize();
						p_str.Format("%5u\n", nPointCount);
						file.WriteString(p_str);


						file.WriteString(CardV12_39_10);
						for(i = 0; i < nPointCount; i++)
						{
							p_str.Format("%10.4.1e",UnloadFunc.m_FunctionEntry[i].m_dX);
							file.WriteString(p_str);
							dFunctionY = UnloadFunc.m_FunctionEntry[i].m_dY * Material.m_dAlpha[1];
							p_str.Format("%10.4.1e\n",dFunctionY);
							file.WriteString(p_str);
						}
					}
					break;				
				case  PAKM_MODEL_62:
					{
						file.WriteString(PAKS_CardH12_62);
						file.WriteString(PAKS_CardV12_62_1);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0],Material.m_dE[1],Material.m_dNu[0],Material.m_dNu[1], Material.m_dG[0]);
						file.WriteString(p_str);
						file.WriteString(PAKS_CardV12_62_2);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10d\n",Material.m_dDensity, Material.m_dK[0], Material.m_dK[1], Material.m_uColor);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_DELFINO_SEF_2D:
					{
						file.WriteString(PAKS_CardH12_81);
						file.WriteString(PAKS_CardV12_81_1);
						p_str.Format("%10.4.2e%10.4.2e\n",Material.m_dE[0],Material.m_dNu[0]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_FUNG_SEF:
					{
						file.WriteString(PAKS_CardH12_83);

						file.WriteString(PAKS_CardV12_83_1);
						p_str.Format("%10.4.2e%10.4.1e%10.4.2e%10.4.1e\n",Material.m_dE[0], Material.m_dNu[0], Material.m_dNu[1], Material.m_dNu[2]);
						file.WriteString(p_str);
					}
					break;
				case  PAKM_USER_SUPPLIED:
					{
						file.WriteString(PAKS_CardH12_92);

						switch( PAK_Material.m_nSubModel )
						{
						case PAKM_USER_SUPPLIED_HILLS:
						{
							file.WriteString(PAKS_CardV12_92_1_1);
							p_str.Format("%5u%5u%5u\n", PAKM_USER_SUPPLIED_HILLS, Material.m_uNonlin_type, Material.m_uFAlpha[0]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_1_2);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0],Material.m_dNu[0],Material.m_dGMatrix_3D[0],Material.m_dGMatrix_3D[1]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_1_3);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dGMatrix_3D[2],Material.m_dGMatrix_3D[3],Material.m_dGMatrix_3D[4],Material.m_dThermal_cap);
							file.WriteString(p_str);

							//Stress-Stretch function
							HFunctions &StressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[6]);
							ExportPAK_Function(file, StressStretchFunc, Material.m_dGMatrix_3D[6], "Stress-Stretch function", "Stretch", "Stress");

							//Activation function
							HFunctions &ActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[7]);
							ExportPAK_Function(file, ActivationFunc, Material.m_dGMatrix_3D[7], "Activation function", "Time", "Activation");

							//Fatigue function
							HFunctions &FatigueFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[8]);
							ExportPAK_Function(file, FatigueFunc, Material.m_dGMatrix_3D[8], "Fatigue function", "Time", "Fitness level");

							//Recovery function
							HFunctions &RecoveryFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[9]);
							ExportPAK_Function(file, RecoveryFunc, Material.m_dGMatrix_3D[9], "Recovery function", "Time", "Fitness level");

							break;
						}
						case PAKM_USER_SUPPLIED_HILLS_2FIBER:
						{
							file.WriteString(PAKS_CardV12_92_2_1);
							p_str.Format("%5u%5u%5u\n", PAKM_USER_SUPPLIED_HILLS_2FIBER, Material.m_uNonlin_type, PAKS_HILLS_FIBER_AXIS);
							file.WriteString(p_str);

							//Slow fiber doubles
							file.WriteString(PAKS_CardV12_92_2_11);

							file.WriteString(PAKS_CardV12_92_2_2);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[0],Material.m_dGMatrix_3D[1],
								Material.m_dGMatrix_3D[2],Material.m_dGMatrix_3D[3]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_2_3);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[4],0.0,0.0,0.0);
							file.WriteString(p_str);

							//Fast fiber doubles
							file.WriteString(PAKS_CardV12_92_2_12);

							file.WriteString(PAKS_CardV12_92_2_2);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[10],Material.m_dGMatrix_3D[11],
								Material.m_dGMatrix_3D[12],Material.m_dGMatrix_3D[13]);
							file.WriteString(p_str);

							file.WriteString(PAKS_CardV12_92_2_3);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
								Material.m_dGMatrix_3D[14],0.0,0.0,0.0);
							file.WriteString(p_str);

							//Common doubles
							file.WriteString(PAKS_CardV12_92_2_4);
							p_str.Format("%10.4.1e%10.4.1e%10.4.1e\n",Material.m_dE[0],Material.m_dNu[0],Material.m_dThermal_cap);
							file.WriteString(p_str);

							//Slow fiber curves

							//Stress-Stretch function
							HFunctions &SlowStressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[6]);
							ExportPAK_Function(file, SlowStressStretchFunc, Material.m_dGMatrix_3D[6], "Slow fiber Stress-Stretch function", "Stretch", "Stress");

							//Activation function
							HFunctions &SlowActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[7]);
							ExportPAK_Function(file, SlowActivationFunc, Material.m_dGMatrix_3D[7], "Slow fiber Activation function", "Time", "Activation");

							//Fatigue function
							HFunctions &SlowFatigueFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[8]);
							ExportPAK_Function(file, SlowFatigueFunc, Material.m_dGMatrix_3D[8], "Slow fiber Fatigue function", "Time", "Fitness level");

							//Recovery function
							HFunctions &SlowRecoveryFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[9]);
							ExportPAK_Function(file, SlowRecoveryFunc, Material.m_dGMatrix_3D[9], "Slow fiber Recovery function", "Time", "Fitness level");


							//Fast fiber curves

							//Stress-Stretch function
							HFunctions &FastStressStretchFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[16]);
							ExportPAK_Function(file, FastStressStretchFunc, Material.m_dGMatrix_3D[16], "Fast fiber Stress-Stretch function", "Stretch", "Stress");

							//Activation function
							HFunctions &FastActivationFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[17]);
							ExportPAK_Function(file, FastActivationFunc, Material.m_dGMatrix_3D[17], "Fast fiber Activation function", "Time", "Activation");

							//Fatigue function
							HFunctions &FastFatigueFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[18]);
							ExportPAK_Function(file, FastFatigueFunc, Material.m_dGMatrix_3D[18], "Fast fiber Fatigue function", "Time", "Fitness level");

							//Recovery function
							HFunctions &FastRecoveryFunc = m_FunctionsArray.Get(Material.m_uFGMatrix3D[19]);
							ExportPAK_Function(file, FastRecoveryFunc, Material.m_dGMatrix_3D[19], "Fast fiber Recovery function", "Time", "Fitness level");


							//Nodal variables
							file.WriteString(PAKS_CardV12_92_2_5);
							file.WriteString(PAKS_CardV12_92_2_6);
							for(UINT i=0;i<(UINT)m_NodArray.GetSize();i++)
							{
								HNodes &Node=m_NodArray[i];

								double dValue = 0.0;
								for(UINT j = 0; j < (UINT)m_LoadArray[0].m_NodalTemps.GetSize(); j++)
										{
											NodalTemp &nt = m_LoadArray[0].m_NodalTemps[j];
											if(nt.m_uNdtempID == Node.m_nID)
											{
												dValue = nt.m_dNdtemp;
												break;
											}
										}
								
								p_str.Format("%5u%10.6f\n", Node.m_nID, dValue);
								file.WriteString(p_str);
							}

							break;
						}
						default:
							ASSERT(FALSE);
						}
					}
					break;
				}

			}
		}
	}

	nModelCount = MaterialsInModel.GetCount();
	return(-1);
}

UINT CModelData::ExportPAK_TimeFunctions(MyFile& file, MyMap<UINT,UINT,UINT,UINT> &FunctionMap)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT i,j;
	HFunctions IncFunction;

	//Check the total number of time functions
	UINT nTimeFunctionCount = 0;
	for(i=0;i<(UINT)m_FunctionsArray.GetSize();i++)
	{
		HFunctions &Function = m_FunctionsArray[i];
		if(	Function.m_uFunc_type == HFunctions::FT_VS_TIME ||
			Function.m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME )
		{
			nTimeFunctionCount++;
		}
	}

	if(nTimeFunctionCount==0)
	{
		HFunctions DefaultFunction;

		DefaultFunction.m_nID = 1;
		DefaultFunction.m_uFunc_type = HFunctions::FT_VS_TIME;

                FunctionEntry f1(1, 0.0, 1.0);
		DefaultFunction.m_FunctionEntry.Add(f1);
                
                FunctionEntry f2(2, 1.e+9, 1.0);
		DefaultFunction.m_FunctionEntry.Add(f2);

		m_FunctionsArray.Add(DefaultFunction);
		nTimeFunctionCount++;
	}

	//Determine maximum number of points
	UINT nMaxPointCount = 0;
	for(i=0;i<(UINT)m_FunctionsArray.GetSize();i++)
	{
		HFunctions &Function = m_FunctionsArray[i];
		if		(	Function.m_uFunc_type == HFunctions::FT_VS_TIME )
		{
			if( (UINT)Function.m_FunctionEntry.GetSize() > nMaxPointCount )
				nMaxPointCount = Function.m_FunctionEntry.GetSize();
		}
		else if ( Function.m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME )
		{
			UINT nPointCount = m_PakGeneral.m_TimeSteps.GetTotalStepCount()+2;
			if( nPointCount > nMaxPointCount )
				nMaxPointCount = nPointCount;
		}
	}


	file.WriteString(PAKS_CardH14);
	file.WriteString(PAKS_CardV14);
	str.Format("%5u%5u\n", nTimeFunctionCount, nMaxPointCount);
	file.WriteString(str);

	UINT nPAKFuncID = 0;
	for(i = 0; i < (UINT)m_FunctionsArray.GetSize(); i++)
	{
		HFunctions *pFunction = &m_FunctionsArray[i];

		if( pFunction->m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME )
		{
			//Convert to incremental function
			pFunction->ConvertToIncremental(m_PakGeneral.m_TimeSteps, IncFunction);
			pFunction = &IncFunction;
		}

		if( pFunction->m_uFunc_type == HFunctions::FT_VS_TIME ||
			pFunction->m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME )
		{
			nPAKFuncID++;
			FunctionMap.SetAt(pFunction->m_nID, nPAKFuncID);

			file.WriteString(PAKS_CardV14_1_a_1);
			file.WriteString(PAKS_CardV14_1_a_2);
//			str.Format("%5u%5u\n",m_FunctionsArray[i].m_nID,m_FunctionsArray[i].m_FunctionEntry.GetSize());
			str.Format("%5u%5u\n",nPAKFuncID, pFunction->m_FunctionEntry.GetSize());
			file.WriteString(str);

			file.WriteString(PAKS_CardV14_1_b_1);
			file.WriteString(PAKS_CardV14_1_b_2);
			for(j = 0; j < (UINT)pFunction->m_FunctionEntry.GetSize(); j++)
			{
				FunctionEntry &FE = pFunction->m_FunctionEntry[j];
				p_str.Format("%10.3.2e%10.3.2e\n",	FE.m_dX, FE.m_dY);
				file.WriteString(p_str);
			}
		}

	}
	return (-1);
}

UINT CModelData::ExportPAK_Loads(MyFile& file, MyMap<UINT,UINT,UINT,UINT> &FunctionMap)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT uNCF=0,uNPP2=0,uNPP3=0,uNZADP=0,i,j,k;
	HLoads lo;
	HElement el;

	UINT surface_nodes_3d[6][8]={   {0,3,2,1,11,10,9,8},
									{4,5,6,7,16,17,18,19},
									{0,1,5,4,8,13,16,12},
									{1,2,6,5,9,14,17,13},
									{2,3,7,6,10,15,18,14},
									{3,0,4,7,11,12,19,15}};

/*
	UINT surface_nodes_prism[5][8]={{0,2,1,1,8,7,1,6},
									{3,4,5,5,12,13,5,14},
									{0,1,4,3,6,10,12,9},
									{1,2,5,4,7,11,13,10},
									{2,0,3,5,8,9,14,11}};

	UINT surface_nodes_tetra[4][8]={{0,2,1,1,6,5,1,4},
									{0,1,3,3,4,8,3,7},
									{1,2,3,3,5,9,3,8},
									{2,0,3,3,6,7,3,9}};
*/
	UINT surface_nodes_shell[2][8]={{0,3,2,1,7,6,5,4},
									{0,1,2,3,4,5,6,7}};

	UINT surface_nodes_tshell[2][8]={{0,2,1,1,5,4,1,3},
									{0,1,2,2,3,4,2,5}};
/*
Ovo su pritisci na linijama 2d elementa i elemenata ljuski i oni se pisu u
/15-2/ i ima ih NPP2. Kada su zadati pritisci na povrsinama ciji je broj veci 
od 2 onda su to linijski pritisci i treba ih staviti u ovu grupu za povrsine od 3 do 6.
Ovo je prva kartica: za ITIPE treba da je isti kao IETYP za 2d element.
						NFUN je broj funkcije a ako nema staviti 1
						IPRAV za sada je 0
						FAKP pritisci u cvoru 1 i 2
						THICV debljina koja je zadata u property kod elementa
						KORC = 0

(1)(2)   1-5   	ITIPE(I)    Type of 2D element loaded by line loading (I)
                               						EQ. 0; PLANE STRESS
                               						EQ. 1; AXISYMMETRIC
                               						EQ. 2; PLANE STRAIN
(3)	     6-10   NFUN(I)   	Time function for line loading (I)
(7)	    11-15   IPRAV(I)  	Indicator for loading direction
                             						EQ. 0; Total line loading 
                                      						 in X-Y plane
                               						EQ. 1; X-direction
                               						EQ. 2; Y-direction
                               						EQ. 3; Z-direction
(3)    	16-25   	FAKP(I,1)   		Proportionality factor for node 1
(3)		26-35   	FAKP(I,2)   		Proportionality factor for node 2
(4)    	36-45   	THICV(I)    		Element thickness  for  line  (A-B) 
                            					subjected to line load (I) 
(5)    	46-50   	KORC        		Increment for data generation

Ovo je druga kartica: samo cvorovi po datom redosledu dole
(6)     1-5    	NODPR(I,1)  		First node of line (A-B)
(6)	    6-10   	NODPR(I,2)  		Second node of line (A-B)
(6)	   11-15  	NODPR(I,3)  		Third (middle) node of line (A-B)

								 
*/
	UINT surface_nodes_2d[4][3]={   {0,1,4},
									{1,2,5},
									{2,3,6},
									{3,0,7}};

	UINT surface_nodes_t2d[3][3]={  {0,1,3},
									{1,2,4},
									{2,0,5}};
	

//	int t;

	if(m_LoadArray.GetSize()==0) 
	{
		//AfxMessageBox(PAKS_NO_LOADS);
		printf(PAKS_NO_LOADS);
		str.Format("\n");
		file.WriteString (str);

		return(0);
	}
	lo=m_LoadArray[0];	//Za sada samo prvi set
	for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
	{
		StructLoad &sl = lo.m_StructLoads[i];
		switch(sl.m_uLoadtype)
		{
		case StructLoad::LT_NODAL_FORCE:
			for(j=0;j<6;j++) if(sl.m_uDof_face[j] && (fabs(sl.m_dValue[j])>=PAKS_LOAD_FORCE_TOL)) uNCF++;
		break;
		case StructLoad::LT_ELEM_PRESS:
			{
			    j=sl.m_uDof_face[0]-1;
				if(fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
				{
			     if(j<2) uNPP3++;
				 else
				 {
//MyMappedArray					el=m_ElArray[m_nElemIndex[sl.m_uLoadID]];
					el=m_ElArray.Get(sl.m_uLoadID);
					if(el.m_uTopology==FETO_BRICK8 || el.m_uTopology==FETO_BRICK20) uNPP3++;
					else uNPP2++;
				 } 
				}
			}
		break;
		case StructLoad::LT_NODAL_DISPL:
//			for(j=0;j<6;j++) if(sl.m_uDof_face[j] && (fabs(sl.m_dValue[j])>=LOAD_NDISP_TOL)) uNZADP++;
			for(j=0;j<6;j++) if(sl.m_uDof_face[j]) uNZADP++;
		break;
		}
	}

	//Card 15
		file.WriteString(PAKS_CardH15);
		file.WriteString(PAKS_CardV15);
		str.Format("%5u%5u%5u%5u     %5u%5u%5u%5u%5u\n",uNCF,uNPP2,uNPP3,PAKS_NPGR,PAKS_NPLJ,
			lo.m_NodalTemps.GetSize(),uNZADP,(lo.m_bGrav_on ? 1:0),PAKS_ICERNE);
		file.WriteString(str);
	
	//Card 15-1
		if(uNCF>0)
		{
			file.WriteString(PAKS_CardH15_1);
			file.WriteString(PAKS_CardV15_1);
		 	for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
			{
				StructLoad &sl=lo.m_StructLoads[i];
				if(sl.m_uLoadtype==StructLoad::LT_NODAL_FORCE)
					for(j=0;j<6;j++) 
					 if(sl.m_uDof_face[j] && fabs(sl.m_dValue[j])>=PAKS_LOAD_FORCE_TOL)
					 {
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = FunctionMap.Lookup(nc,nc);
						ASSERT(bFound);
						p_str.Format("%5u%5u%5u%10.4.1e%5u%10.4f\n",sl.m_uLoadID,j+1,nc,sl.m_dValue[j],
							PAKS_KORC,PAKS_FPOM);
						file.WriteString(p_str);
					 }
			}
		}

	//Card 15-2
	//Line pressure
		if(uNPP2>0)
		{
			UINT uITIPE;
			file.WriteString(PAKS_CardH15_2);
			file.WriteString(PAKS_CardV15_2_a_1);
			file.WriteString(PAKS_CardV15_2_a_2);
			file.WriteString(PAKS_CardV15_2_b_1);
			file.WriteString(PAKS_CardV15_2_b_2);
		 	for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
			{
				StructLoad &sl=lo.m_StructLoads[i];
				if(sl.m_uLoadtype==StructLoad::LT_ELEM_PRESS)
				{
					el=m_ElArray.Get(sl.m_uLoadID);
				   if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8 ||
					  el.m_uTopology==FETO_TRI3 || el.m_uTopology==FETO_TRI6)
				   {
					j=sl.m_uDof_face[0]-1;
					if(j>1 && fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
					{
						HProperties pr = m_PropArray.Get(el.m_uPropID);

						switch (el.m_uType)
						{
							case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:
							case HProperties::PT_PLATE_LIN:case HProperties::PT_PLATE_PAR: 
							case HProperties::PT_EFG_2D: uITIPE=0;
								break;
							case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR: uITIPE=2;
								break;
							case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR: uITIPE=1;
								break;
						}
						
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = FunctionMap.Lookup(nc,nc);
						ASSERT(bFound);
						
						double dThickness = ( uITIPE == 0 ? pr.m_dValue[0] : 1.0 );

						p_str.Format("%5u%5u%5u%10.4.1e%10.4.1e%10.4.1e%5u\n",uITIPE,nc,PAKS_IPRAV,
							sl.m_dValue[0],sl.m_dValue[0],dThickness,PAKS_KORC);
						file.WriteString(p_str);
						for(k=0;k<(UINT)((el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_TRI3)? 2:3);k++)
						{
							if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8)
								str.Format("%5u",el.m_uNode[surface_nodes_2d[j-2][k]]);
							else
								str.Format("%5u",el.m_uNode[surface_nodes_t2d[j-2][k]]);
							file.WriteString(str);
						}
						file.WriteString("\n");
					}
				   }
				}
			}
		}
		
	//Card 15-3
	//Surface pressure
		if(uNPP3>0)
		{
			file.WriteString(PAKS_CardH15_3);
			file.WriteString(PAKS_CardV15_3_a_1);
			file.WriteString(PAKS_CardV15_3_a_2);
			file.WriteString(PAKS_CardV15_3_b_1);
			file.WriteString(PAKS_CardV15_3_b_2);
		 	for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
			{
				StructLoad &sl=lo.m_StructLoads[i];
				if(sl.m_uLoadtype==StructLoad::LT_ELEM_PRESS)
				{
					el=m_ElArray.Get(sl.m_uLoadID);
					j=sl.m_uDof_face[0]-1;
					 if(fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
					 {
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = FunctionMap.Lookup(nc,nc);
						ASSERT(bFound);
						
						switch(el.m_uTopology)
						{
						case FETO_BRICK8: case FETO_BRICK20:
						{
							p_str.Format("%5u%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e%5u\n",nc,PAKS_IPRAV,
						 		sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],PAKS_KORC);
							file.WriteString(p_str);
							for(k=0;k<(UINT)(el.m_uTopology==FETO_BRICK8 ? 4:8);k++)
							{
								str.Format("%5u",el.m_uNode[surface_nodes_3d[j][k]]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
							break;
						case FETO_QUAD4: case FETO_QUAD8: case FETO_TRI3: case FETO_TRI6:
							if(j<2)
							{
								p_str.Format("%5u%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e%5u\n",nc,PAKS_IPRAV,
							 		sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],PAKS_KORC);
								file.WriteString(p_str);
								for(k=0;k<(UINT)((el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_TRI3)? 4:8);k++)
								{
			 						if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8)
										str.Format("%5u",el.m_uNode[surface_nodes_shell[j][k]]);
									else
										str.Format("%5u",el.m_uNode[surface_nodes_tshell[j][k]]);
									file.WriteString(str);
								}
								file.WriteString("\n");
							}
							break;
						}
					 }
				}
			}
		}
	
	//Card 15-7
		if(lo.m_NodalTemps.GetSize()>0)
		{
			file.WriteString(PAKS_CardH15_1);
			file.WriteString(PAKS_CardV15_1);
		 	for(i=0;i<(UINT)lo.m_NodalTemps.GetSize();i++)
			{
				NodalTemp &nt = lo.m_NodalTemps[i];
				UINT nc;
				nc=(nt.m_uNdt_funcID ? nt.m_uNdt_funcID : 1);
				bool bFound = FunctionMap.Lookup(nc,nc);
				ASSERT(bFound);
				
				//nc=(lo.m_NodalTemps[i].m_dNdf_funcID ? lo.m_NodalTemps[i].m_dNdf_funcID : 1);
	
				str.Format("%5d%5d%10.6f%5d\n",nt.m_uNdtempID,nc,
					nt.m_dNdtemp,PAKS_KORC);
				file.WriteString(str);
			}
		}
	
	//Card 15-8
		if(uNZADP>0)
		{
			file.WriteString(PAKS_CardH15_8);
			file.WriteString(PAKS_CardV15_8);
		 	for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
			{
				StructLoad &sl=lo.m_StructLoads[i];
				if(sl.m_uLoadtype==StructLoad::LT_NODAL_DISPL)
					for(j=0;j<6;j++) 
					 //if(sl.m_uDof_face[j] && fabs(sl.m_dValue[j])>=LOAD_NDISP_TOL)
					 if(sl.m_uDof_face[j])
					 {
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = FunctionMap.Lookup(nc,nc);
						ASSERT(bFound);
						p_str.Format("%5u%5u%5u%10.3.2e%5u%10.6f\n",sl.m_uLoadID,j+1,nc,sl.m_dValue[j],PAKS_KORC);
						file.WriteString(p_str);
					 }
			}
	}

	//Card 15-9
	if(lo.m_bGrav_on)
	{
		file.WriteString(CardH15_9);
		file.WriteString(CardV15_9);
		str.Format("%5u%10.4f%10.4f%10.4f\n",m_FunctionsArray.GetSize(),lo.m_dGrav[0],lo.m_dGrav[1],lo.m_dGrav[2]);
		file.WriteString(str);
	}

	return (-1);
}

/*
UINT CModelData::ExportPAK_Loads_FindType(HMaterial* mat, int uMODEL1)
{
	if (m_PakGeneral.GetAnalysisType()!=0) uMODEL1=5;

			switch (uMODEL1)
			{
			case  PAKM_ELASTIC_ISO:
				{
_label_elastic_iso:
					if (mat->m_dAlpha[0]!=0) goto _label_thermo_elastic_iso;
					uMODEL1=1;
				}
				break;
			case  PAKM_THERMO_ELASTIC_ISO:
				{
_label_thermo_elastic_iso:
					uMODEL1=3;
				}
				break;
			case PAKM_ELASTIC_ORTHO:
				{
					uMODEL1=2;
				}
			case  PAKM_MISES_PLASTIC:
				{
			 		if (mat->m_uNonlin_type==0) goto _label_elastic_iso;
				}
			}

	return uMODEL1;
}
*/

UINT CModelData::ExportPAK_Function(MyFile &File, const HFunctions& Function, double dScaleFactor, const MyString& sTitle, const MyString& sXTitle, const MyString& sYTitle)
{
	MyStringAdvanced p_str;

	File.WriteString( MyString("C ") + sTitle + "\n");
	File.WriteString("C Point count\n");

	UINT nPointCount = Function.m_FunctionEntry.GetSize();
	p_str.Format("%5u\n", nPointCount);
	File.WriteString(p_str);


	File.WriteString(MyString("C ") + sXTitle + ", " + sYTitle + "\n");
	for(UINT i = 0; i < nPointCount; i++)
	{
		p_str.Format("%10.4.1e",Function.m_FunctionEntry[i].m_dX);
		File.WriteString(p_str);
		p_str.Format("%10.4.1e\n",Function.m_FunctionEntry[i].m_dY * dScaleFactor);
		File.WriteString(p_str);
	}

	return(0);
}

UINT CModelData::ExportPAK_Equations(MyFile& file)
{
	MyString str;
	UINT i,j;
	
	//Za sada samo prvi set
	HConstraints &co=m_ConsArray[0];;
	

	//Card /10-02/
	file.WriteString(PAKS_CardH10_02);


	//Card /10-02_a/
	file.WriteString(PAKS_CardH10_02_a);
	file.WriteString(PAKS_CardV10_02_a);
	str.Format("%5u%5u\n",co.m_ConsEqs.GetSize(),6);
	file.WriteString(str);

	//Card /10-02_b/
	file.WriteString(PAKS_CardH10_02_b);
	file.WriteString(PAKS_CardV10_02_b);

	for(i=0;i<(UINT)co.m_ConsEqs.GetSize();i++)
	{
		ConsEq &eq=co.m_ConsEqs[i];

		str.Format("%5u",eq.m_uEqnID);
		file.WriteString(str);

		j=1;
		while(j<(UINT)eq.m_EqCoefs.GetSize() && eq.m_EqCoefs[j].m_uEqn_nodeID>0)
		{
			str.Format("%10.4f",eq.m_EqCoefs[j].m_dCoeff);
			file.WriteString(str);
			j++;
		}
		file.WriteString("\n");
	}

	//Card /10-02_c/
	file.WriteString(PAKS_CardH10_02_c);
	file.WriteString(PAKS_CardV10_02_c);

	for(i=0;i<(UINT)co.m_ConsEqs.GetSize();i++)
	{
		ConsEq &eq=co.m_ConsEqs[i];

		str.Format("%5u",eq.m_uEqnID);
		file.WriteString(str);

		j=0;
		while(j<(UINT)eq.m_EqCoefs.GetSize() && eq.m_EqCoefs[j].m_uEqn_nodeID>0)
		{
			str.Format("%5u%5u",eq.m_EqCoefs[j].m_uEqn_nodeID,eq.m_EqCoefs[j].m_uEqn_dof);
			file.WriteString(str);
			j++;
		}
		file.WriteString("\n");
	}

	return(-1);
}