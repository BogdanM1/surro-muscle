/*!
 * \file FEModelData.h
 * Interface for the CModelData class.
 * 
 * \author Boban Stojanovic, Nikola Milivojevic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// FEModelData.h: interface for the CModelData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FEMODELDATA_H__F0632FFA_A3E0_4978_8FEC_1F152CF300E8__INCLUDED_)
#define AFX_FEMODELDATA_H__F0632FFA_A3E0_4978_8FEC_1F152CF300E8__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "HNodes.h"
#include "HElement.h"
#include "HProperties.h"
#include "HConstraints.h"
#include "HLoads.h"
#include "HMaterial.h"
#include "HFunctions.h"
#include "OutSet.h"

#include "FileIO.h"
#include "PAKExp.h"
#include "PAKPExp.h"
#include "PakExpOption.h"
#include "PakPExpOptions.h"
#include "PakGeneral.h"
#include "PAKP_Material.h"

#include <math.h>
//#include "..\CSKClasses\MappedArray.h"
#include "MappedArray.h"

class CEffectiveValueCalculator;

struct PAK_MaterialKey
{
	PAK_MaterialKey()
	{
	}
	PAK_MaterialKey(UINT nModel, UINT nSubModel, UINT nMaterial)
	{
		m_nModel = nModel;
		m_nSubModel = nSubModel;
		m_nMaterial = nMaterial;
	}

	/// Material model
	UINT m_nModel;
	/// Material submodel
	UINT m_nSubModel;
	/// ID of the material
	UINT m_nMaterial;
};

/** Class containing all data about an finite element model. */
class CModelData//: public CObject
{
public:
	UINT AddConst(HConstraints &Const);
	UINT AddMaterial(HMaterial &Mat);
	UINT AddFunction(HFunctions &Func);
	UINT AddLoad(HLoads &Load);
	UINT AddProperty(HProperties &Prop);
	UINT AddElem(HElement &Elem);
	UINT AddNode(HNodes &Node);

	CModelData();
	virtual ~CModelData();

/*
	MyArray <HNodes,HNodes&> m_NodArray;
	MyArray <HElement,HElement&> m_ElArray;
	MyArray <HProperties,HProperties&> m_PropArray;
	MyArray <HConstraints,HConstraints&> m_ConsArray;
	MyArray <HLoads,HLoads&> m_LoadArray;
	MyArray <HMaterial,HMaterial&> m_MaterialsArray;
	MyArray <HFunctions,HFunctions&> m_FunctionsArray;
	MyArray <COutSet,COutSet&> m_OutSetArray;
	
	MyMap<UINT,UINT,UINT,UINT> m_nNodeIndex; // relation between Node ID and it's position in NodArray
	MyMap<UINT,UINT,UINT,UINT> m_nElemIndex; // relation between Element ID and it's position in ElArray
	MyMap<UINT,UINT,UINT,UINT> m_nPropIndex; // relation between Property ID and it's position in PropArray
	MyMap<UINT,UINT,UINT,UINT> m_nFuncIndex; // relation between Function ID and it's position in FunMyArray
	MyMap<UINT,UINT,UINT,UINT> m_nOutSetIndex; // relation between OutSet ID and it's position in SetOutArray
*/	
	/// Collection of nodes
	MappedArray <UINT,HNodes> m_NodArray;
	/// Collection of elements
	MappedArray <UINT,HElement> m_ElArray;
	/// Collection of properties
	MappedArray <UINT,HProperties> m_PropArray;
	/// Collection of constraints
	MappedArray <UINT,HConstraints> m_ConsArray;
	/// Collection of loads
	MappedArray <UINT,HLoads> m_LoadArray;
	/// Collection of materials
	MappedArray <UINT,HMaterial> m_MaterialsArray;
	/// Collection of functions
	MappedArray <UINT,HFunctions> m_FunctionsArray;
	/// Collection of output sets
	MappedArray <UINT,COutSet> m_OutSetArray;

	UINT RenumNodes(UINT AxisOrder[3]);

	UINT ImportFemap(MyFile& file,UINT ExpectedNodeCount=0,UINT ExpectedElemCount=0);
	UINT ImportFemap_DataBlock(MyFile& file, int nDataBlockType,UINT &ExpectedNodeCount,UINT &ExpectedElemCount);
	UINT ImportFemap_Nodes(MyFile& file);
	UINT ImportFemap_Elements(MyFile& file);
	UINT ImportFemap_Loads(MyFile& file);
	UINT ImportFemap_Constraints(MyFile& file);
	UINT ImportFemap_Properties(MyFile& file);
	UINT ImportFemap_Materials(MyFile& file);
	UINT ImportFemap_Functions(MyFile& file);
	UINT ImportFemap_OutSets(MyFile& file);
	UINT ImportFemap_OutVectors(MyFile& file,UINT ExpectedNodeCount,UINT ExpectedElemCount);

	UINT ExportFemap(MyFile& file);
	UINT ExportFemap_Nodes(MyFile& file);
	UINT ExportFemap_Elements(MyFile& file);
	UINT ExportFemap_Loads(MyFile& file);
	UINT ExportFemap_Constraints(MyFile& file);
	UINT ExportFemap_Properties(MyFile& file);
	UINT ExportFemap_Materials(MyFile& file);
	UINT ExportFemap_Functions(MyFile& file);
	UINT ExportFemap_Output(MyFile& file);
	UINT ExportFemap_OutputSets(MyFile& file);
	UINT ExportFemap_OutputVectors(MyFile& file);
	


	UINT DeleteContents();
	UINT OnNewDocument();

	UINT ImportUNV(MyFile &File,bool bImportGeometry, bool bImportOutput,UINT nExpectedNodeCount=0,UINT nExpectedElemCount=0);
	
	UINT ExportPAK_S(MyFile& file,CPakExpOption *peo);
	UINT ExportPAK_T(MyFile& file,CPakExpOption *peo);
	UINT ExportPAK_F(MyFile& file,CPakExpOption *peo);
	UINT ExportPAK_P(MyFile& file,CPakPExpOptions *peo);
	UINT ExportPAK_C(MyFile& file,CPakExpOption *peo);
	UINT ExportPAK_CS(MyFile& file,CPakExpOption *peo);

	UINT InterelementAveraging(UNV_VARIABLES ElemVariable, UNV_VARIABLES NodeVariable, UINT nNodeVectorID, const CEffectiveValueCalculator &EVC);

	/// General options about exporting to PAK format
	CPakGeneral m_PakGeneral;

	CModelData& operator =(const CModelData &other);

	/// Conversion array defining relation between PAK and FEMAP node order on 2D elements
	static UINT PAK2FEMAP_NodeOrder2D[9];
	/// Conversion array defining relation between PAK and FEMAP node order on 3D elements
	static UINT PAK2FEMAP_NodeOrder3D[21];

private:

	typedef struct
	{ 
		UINT nElem; 
		UINT nNode; 
		UINT nSlFuncID; 
		double dValue; 
	} TElemNode;//Mileta intervention

	UINT ExportPAKF_SurrTract(MyFile&file);//Mileta intervention
	UINT PressVectorF(StructLoad &sl,UINT i, MyArray<TElemNode,TElemNode&> &ElemNodes, UINT &nPressCount);//Mileta Intervention

	UINT ExportPAK_Nodes(MyFile& file);
	UINT ExportPAK_Elements(MyFile& file,UINT &nGroupCount,MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap,CPakExpOption *peo);
	UINT ExportPAK_MatModels(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap);
	UINT ExportPAK_TimeFunctions(MyFile& file, MyMap<UINT,UINT,UINT,UINT> &FunctionMap);
	UINT ExportPAK_Loads(MyFile& file, MyMap<UINT,UINT,UINT,UINT> &FunctionMap);
//	UINT ExportPAK_Loads_FindType(HMaterial* mat, int uMODEL1);
	UINT ExportPAK_RigidBodiesBasicData(MyFile& file,UINT &nRigidBodyCount, CPakExpOption *peo);
	UINT ExportPAK_RigidBodies(MyFile& file, UINT nRigidBodyCount, CPakExpOption *peo);

	UINT ExportPAKT_Nodes(MyFile& file);
	UINT ExportPAKT_Elements(MyFile& file,UINT *uNGELEM,CPakExpOption *peo);
	UINT ExportPAKT_MatModels(MyFile& file);
	UINT ExportPAKT_Loads(MyFile& file);
	UINT ExportPAKT_PrescTemp(MyFile& file);
	UINT ExportPAKT_TimeFunctions(MyFile& file);
	UINT ExportPAK_Function(MyFile &File, const HFunctions& Function, double dScaleFactor, const MyString& sTitle, const MyString& sXTitle, const MyString& sYTitle);
	UINT ExportPAK_Equations(MyFile& file);


	UINT ExportPAKF_2DElements(MyFile& file);
	UINT ExportPAKF_3DElements(MyFile& file);
	UINT ExportPAKF_Nodes(MyFile& file);
	UINT ExportPAKF_Elements(MyFile& file,UINT *uNGELEM,CPakExpOption *peo);
//	UINT ExportPAKF_MatModels(MyFile& file);
	UINT ExportPAKF_PrescVals(MyFile& file);
	UINT ExportPAKF_SurfaceTraction(MyFile &file);


	UINT ExportPAKP_Nodes(MyFile& file);
	UINT ExportPAKP_Elements_Without_Groups(MyFile& file,UINT *uNGELEM,CPakPExpOptions *ppeo);
	UINT ExportPAKP_PrescTemp(MyFile& file);
	UINT ExportPAKP_Loads(MyFile& file, UINT n1D_ElementGroups, CPakPExpOptions *ppeo);
	UINT ExportPAKP_MatModels(MyFile& file);
	UINT ExportPAKP_1D_Elements(MyFile& file,UINT &n1D_Element_Groups,CPakPExpOptions *ppeo);
	UINT ExportPAKP_InitialPotential(MyFile& file);

	UINT ExportPAKC_Nodes(MyFile& file);
	UINT ExportPAKC_Elements(MyFile& file,UINT *uNGELEM,MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap,CPakExpOption *peo);
	UINT ExportPAKC_BoundaryConditions(MyFile& file);
	UINT ExportPAKC_Materials(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap);
	UINT ExportPAKC_TimeFunctions(MyFile& file);
	UINT ExportPAKC_Forces(MyFile& file);
	UINT ExportPAKC_PrescribedValues(MyFile& file);

	UINT ExportPAKCS_Nodes(MyFile& file);
	UINT ExportPAKCS_Elements_C(MyFile& file,UINT *uNGELEM,MyMap<UINT,UINT,UINT,UINT> &FEMAP2PAK_PropertyMap,CPakExpOption *peo);
	UINT ExportPAKCS_BoundaryConditions(MyFile& file);
	UINT ExportPAKCS_Materials(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,UINT,UINT> &FEMAP2PAK_PropertyMap);
	UINT ExportPAKCS_TimeFunctions(MyFile& file);
	UINT ExportPAKCS_Forces(MyFile& file);
	UINT ExportPAKCS_PrescribedValues(MyFile& file);
	UINT ExportPAKCS_MatModels_S(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap);
	UINT ExportPAKCS_Elements_S(MyFile& file,UINT &nGroupCount,MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap,CPakExpOption *peo);

protected:
	UINT FEMAP_Topology_NodeCount[1000];
};


#endif // !defined(AFX_FEMODELDATA_H__F0632FFA_A3E0_4978_8FEC_1F152CF300E8__INCLUDED_)
