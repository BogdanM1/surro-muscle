/*!
 * \file PAKP_Material.h
 * Interface for the CPAKP_Material class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PAKP_Material.h: interface for the CPAKP_Material class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAKP_MATERIAL_H__FBAA1113_B74E_4086_84A6_B6A424AFC659__INCLUDED_)
#define AFX_PAKP_MATERIAL_H__FBAA1113_B74E_4086_84A6_B6A424AFC659__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ExtraData.h"

/** Class representing material specific for PAKP. */
class CPAKP_Material : public CExtraData 
{
public:
	CPAKP_Material();
	/*!
	 * Constructor.
	 * 
	 * \param[in] dKx
	 * Permeability in global X direction.
	 * 
	 * \param[in] dKy
	 * Permeability in global Y direction.
	 * 
	 * \param[in] dKz
	 * Permeability in global Z direction.
	 * 
	 * \param[in] dSs
	 * Specific storage.
	 * 
	 * \param[in] dSyield
	 * Specific yield.
	 */
	CPAKP_Material(double dKx, double dKy, double dKz, double dSs, double dSyield)
	{
		 m_dKx = dKx;
		 m_dKy = dKy;
		 m_dKz = dKz;

		 m_dSs = dSs;
		 m_dSyield = dSyield;
	};
	virtual ~CPAKP_Material();
	/*!
	 * Copy constructor.
	 */
	CPAKP_Material(CPAKP_Material& other)
	{
		(*this) = other;
	}

	/*!
	 * Equalizes two objects of the CPAKP_Material class.
	 * 
	 * \param[in] other
	 * Reference to the right-hand side operand.
	 * 
	 * \returns
	 * Reference to this object.
	 */
	CPAKP_Material& operator=(CPAKP_Material& other)
	{
		m_dKx = other.m_dKx;
		m_dKy = other.m_dKy;
		m_dKz = other.m_dKz;
		m_dSs = other.m_dSs;
		m_dSyield = other.m_dSyield;
		
		m_dAquiferTop = other.m_dAquiferTop;
		m_dAquiferBottom = other.m_dAquiferBottom;

		return(*this);
	}

	/*!
	 * Equalizes two objects of the CPAKP_Material class.
	 * 
	 * \param[in] other
	 * Reference to the right-hand side operand (reference to the CExtraData object).
	 * 
	 * \returns
	 * Reference to this object (reference to CExtraData object).
	 */
	CExtraData& operator=(CExtraData& other)
	{
		CPAKP_Material *pMat = (CPAKP_Material*)(&other);

		*this = *pMat;

		return(*this);
	}

	/*!
	 * Calculates difference between this object and right-hand side CPAKP_Material object.
	 * 
	 * \param[in] other
	 * Reference to the right-hand side operand.
	 * 
	 * \returns
	 * Resulting CPAKP_Material object.
	 */
	CPAKP_Material operator-(CPAKP_Material& other)
	{
		
			CPAKP_Material m( m_dKx - other.m_dKx, m_dKy - other.m_dKy,
			m_dKz - other.m_dKz,
			m_dSs - other.m_dSs,
			m_dSyield - other.m_dSyield);
		 	
                return m;
	}

	/*!
	 * Calculates sum of this object and right-hand side CPAKP_Material object.
	 * 
	 * \param[in] other
	 * Reference to the right-hand side operand.
	 * 
	 * \returns
	 * Resulting CPAKP_Material object.
	 */
	CPAKP_Material operator+(CPAKP_Material& other)
	{
		
			CPAKP_Material m( m_dKx + other.m_dKx, m_dKy + other.m_dKy,
			m_dKz + other.m_dKz,
			m_dSs + other.m_dSs,
			m_dSyield + other.m_dSyield);
		 	return m;
	}

	/*!
	 * Multiplies this object with the specified scalar.
	 * 
	 * \param[in] dK
	 * Multiplier.
	 * 
	 * \returns
	 * Resulting CPAKP_Material object.
	 */
	CPAKP_Material operator*(double dK)
	{
		
			CPAKP_Material m( m_dKx * dK, m_dKy * dK,
			m_dKz * dK,
			m_dSs* dK,
			m_dSyield * dK);
		 	return m;
	}

	/*!
	 * Sets permeability, specific storage and specific yield.
	 * 
	 * \param[in] dKx
	 * Permeability in global X direction.
	 * 
	 * \param[in] dKy
	 * Permeability in global Y direction.
	 * 
	 * \param[in] dKz
	 * Permeability in global Z direction.
	 * 
	 * \param[in] dSs
	 * Specific storage.
	 * 
	 * \param[in] dSyield
	 * Specific yield.
	 */
	void Set(double dKx, double dKy, double dKz, double dSs, double dSyield)
	{
		m_dKx = dKx;
		m_dKy = dKy;
		m_dKz = dKz;

		m_dSs = dSs;
		m_dSyield = dSyield;
	};
	inline void SetKx(double dKx) { m_dKx = dKx; };
	inline void SetKy(double dKy) { m_dKy = dKy; };
	inline void SetKz(double dKz) { m_dKz = dKz; };
	inline void SetSs(double dSs) { m_dSs = dSs; };
	inline void SetSyield(double dSyield) { m_dSyield = dSyield; };

	inline double GetKx() { return m_dKx; };
	inline double GetKy() { return m_dKy; };
	inline double GetKz() { return m_dKz; };
	inline double GetSs() { return m_dSs; };
	inline double GetSyield() { return m_dSyield; };


public:
	
	/// Permeability in X direction
	double m_dKx;
	/// Permeability in Y direction
	double m_dKy;
	/// Permeability in Z direction
	double m_dKz;

	/// Specific storage
	double m_dSs;
	/// Specific yield
	double m_dSyield;

public:
	/// Aquifer
	double m_dAquiferTop;
	double m_dAquiferBottom;

protected:
	//DECLARE_SERIAL(CPAKP_Material)
};

#endif // !defined(AFX_PAKP_MATERIAL_H__FBAA1113_B74E_4086_84A6_B6A424AFC659__INCLUDED_)
