/*
 * MMChunkCPU.h
 *
 *  Created on: May 13, 2014
 *      Author: anakaplarevic
 */

#ifndef MMCHUNKCPU_H_
#define MMCHUNKCPU_H_

#include "MMChunkCalculator.h"

class MMChunkCPU: public MMChunkCalculator {
	int *countV; 	
	int *countVP;	 
	double *Vend;
	double *Eend;
	int* countVniz[30];
	int iter;
	int korak;
public:
	MMChunkCPU();
	virtual ~MMChunkCPU();

        void init(int num_points,MMType *types,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1);
	void calculateChunk(double *e,double* sigma,double* dsigmade);
	void setToNew(int flag);

};

#endif /* MMCHUNKCPU_H_ */
