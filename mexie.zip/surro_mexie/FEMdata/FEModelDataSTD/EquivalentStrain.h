/*!
 * \file EquivalentStrain.h
 * Interface for the CEquivalentStrain class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// EquivalentStrain.h: interface for the CEquivalentStrain class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EQUIVALENTSTRAIN_H__6585250F_036B_4103_80D6_553067131AAF__INCLUDED_)
#define AFX_EQUIVALENTSTRAIN_H__6585250F_036B_4103_80D6_553067131AAF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Stdafx.h"

#include "EffectiveValueCalculator.h"

class CEquivalentStrain : public CEffectiveValueCalculator  
{
public:
	CEquivalentStrain() {};
	virtual ~CEquivalentStrain() {};

	/*!
	 * Calculates strain effective value.
	 * 
	 * \param[in] dCompValues
	 * 6-element array of strain components.
	 * 
	 * \returns
	 * Strain effective value.
	 */
	inline double Calculate(double dCompValues[]) const
	{
		double s[6];
		double dSigma,dEq;

		dSigma = (dCompValues[0]+dCompValues[1]+dCompValues[2])/3.;
		s[0]=dCompValues[0]-dSigma;
		s[1]=dCompValues[1]-dSigma;
		s[2]=dCompValues[2]-dSigma;
		s[3]=dCompValues[3];
		s[4]=dCompValues[4];
		s[5]=dCompValues[5];

		dEq=sqrt((2./3.)*(s[0]*s[0] +s[1]*s[1] +s[2]*s[2] + 0.5*(s[3]*s[3] +s[4]*s[4] +s[5]*s[5])));
		return(dEq);
	}
};

#endif // !defined(AFX_EQUIVALENTSTRAIN_H__6585250F_036B_4103_80D6_553067131AAF__INCLUDED_)
