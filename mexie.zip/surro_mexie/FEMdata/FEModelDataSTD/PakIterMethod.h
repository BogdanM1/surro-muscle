/*!
 * \file PakIterMethod.h
 * Interface for the CPakIterMethod class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PakIterMethod.h: interface for the CPakIterMethod class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAKITERMETHOD_H__D1352844_B120_11D6_8623_5254AB509DC9__INCLUDED_)
#define AFX_PAKITERMETHOD_H__D1352844_B120_11D6_8623_5254AB509DC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyString.h"
#include "Stdafx.h"

/** Class representing PAK iterative method. */
class CPakIterMethod  
{
public:
	CPakIterMethod();
	virtual ~CPakIterMethod();
	CPakIterMethod& operator =(const CPakIterMethod &other);

	/// Iterative method
	int m_iIterMethod;

	//Maximal number of iterations
	UINT m_nMaxIterCount;

	/// Tolerance for the energy convergence criterion
	double	m_dTOLE;
	/// Tolerance for the force convergence criterion
	double	m_dTOLS;
	/// Tolerance for the moment convergence criterion
	double	m_dTOLM;
	/// Absolute tolerance for the convergence criterion
	double	m_dTOLA;

	UINT	m_nOptimalIterCount;
	UINT	m_uNodeNumber;
	int		m_iDirection;
	double	m_dValue;
	double	m_dAG;
	double	m_dDS;
	/// Title of the iterative method
	MyString	m_strMethod;
	/// Indicator whether energy convergence criterion is used
	bool	m_bConvEnergy;
	/// Indicator whether force convergence criterion is used
	bool	m_bConvForce;
	/// Indicator whether moment convergence criterion is used
	bool	m_bConvMoment;

protected:

};

#endif // !defined(AFX_PAKITERMETHOD_H__D1352844_B120_11D6_8623_5254AB509DC9__INCLUDED_)
