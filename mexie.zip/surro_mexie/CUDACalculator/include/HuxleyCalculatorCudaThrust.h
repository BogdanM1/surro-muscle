#include <cuda.h>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>
#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/for_each.h>
#include <thrust/reduce.h>
#include <thrust/transform_reduce.h>
#include <thrust/iterator/zip_iterator.h>

#include <sys/time.h>
#include <stdio.h>
#include <vector>

#include "HuxleyParameters.h"
#include "HuxleyCalculatorCuda.h"


#define _TIP float
//#define NDIM 8000
#define MAX_ITER 1000

class HuxleyCalculatorCudaThrust : public HuxleyCalculatorCuda
{
private:


	HuxleyParameters* _param;

	thrust::device_vector<_TIP> d_X;
	thrust::device_vector<_TIP> d_N;

	std::vector< thrust::device_vector<_TIP> > d_X0;
	std::vector< thrust::device_vector<_TIP> > d_N0;

	//thrust::device_vector<_TIP> d_X;
	//thrust::device_vector<_TIP> d_N;

/*	std::vector< _TIP > e;
	std::vector< _TIP > e_curr;
*/

	thrust::device_vector<_TIP> e;
	thrust::device_vector<_TIP> e_curr;


	thrust::device_vector<_TIP> d_V;
	thrust::device_vector<_TIP> d_FX;


	std::vector< thrust::device_vector<_TIP> > X_curr;
	std::vector< thrust::device_vector<_TIP> > N_curr;

	//thrust::device_vector<_TIP> X_curr;
	//thrust::device_vector<_TIP> N_curr;

	thrust::device_vector<_TIP> V_curr;
	thrust::device_vector<_TIP> FX_curr;

	thrust::device_vector<_TIP> X_next;
	thrust::device_vector<_TIP> N_next;
	thrust::device_vector<_TIP> V_next;
	thrust::device_vector<_TIP> FX_next;

	thrust::device_vector<_TIP> X_remash;
	thrust::device_vector<_TIP> N_remash;

	/*
	thrust::host_vector<_TIP> X;
	thrust::host_vector<_TIP> N;
	thrust::host_vector<_TIP> V;
	*/

	thrust::device_vector<_TIP> transf;

	int _k;
	FILE *f;

public:
	HuxleyCalculatorCudaThrust();
	HuxleyCalculatorCudaThrust(int k);
	HuxleyCalculatorCudaThrust(int k, HuxleyParameters* param);
	virtual ~HuxleyCalculatorCudaThrust();
	
	void Initialize();
	void Initialize(int);
	void Initialize(int k, HuxleyParameters* param);
	void Remash(int);
	// int Iteration(int, float);
	// void Simulate(int, float, float);
	// void Calculate(std::vector<float>, float);

	// int Iteration(int, float, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2);
	int Iteration(int, float);
	// void Simulate(int i, float v, float time, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2);
	void Simulate(int, float, float);
	// void Calculate(std::vector<float> es, float time, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2);
	void Calculate(std::vector<float>, float);
	
	void SetToNew(int);
	void SetToNew();
	float getForce(int);
	void getForce(std::vector<float>&);
	void check();
	
	std::vector<_TIP> Get_X(int);
	std::vector<_TIP> Get_N(int);
	void Get_X(int i,std::vector<_TIP>& r);
	void Get_N(int i,std::vector<_TIP>& r);
	

};
