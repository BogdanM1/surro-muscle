/*
 * MaterialModelParameters.cpp
 *
 *  Created on: Sep 12, 2013
 *      Author: anakaplarevic
 */

#include "MaterialModelParameters.h"

MaterialModelParameters::MaterialModelParameters() {
	// TODO Auto-generated constructor stub

}

MaterialModelParameters::~MaterialModelParameters() {
	// TODO Auto-generated destructor stub
}

