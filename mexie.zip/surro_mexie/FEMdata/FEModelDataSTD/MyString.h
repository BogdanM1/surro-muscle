#pragma once

#include <string>
#include<stdarg.h>
#include<algorithm>
#include<stdio.h>

using namespace std;

class MyString : public string
{
public:
	MyString() : string()
	{
	}

	MyString(const char *str) : string(str)
	{
	}

	MyString(const string &str) : string(str)
	{
	}

	void Format(const char *format, ...)
	{
		va_list argList;
		va_start(argList, format);

		FormatV(format, argList);

		va_end(argList);
	}

	void FormatV(const char *format, va_list &argList)
	{
		static char s[1000];
		vsprintf(s, format, argList);
		*this = s;
	}

	void ReleaseBuffer()
	{
		resize(0);
	}

	void Delete(int position, int length)
	{
		this->erase(position, length);
	}

	operator const char *()
	{
		return this->data();
	}

	void Replace(char oldChar, char newChar)
	{
		std::replace(begin(), end(), oldChar, newChar);
	}

	string Left(int length)
	{
		return substr(0,length);
	}
};