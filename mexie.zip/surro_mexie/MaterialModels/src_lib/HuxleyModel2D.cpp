/*
 * HuxleyModel2D.cpp
 *
 *  Created on: Nov 14, 2013
 *      Author: anakaplarevic
 */

#include "HuxleyModel2D.h"
#include "histogram.h"

_TIP pomV,pomVP;
using namespace boost::numeric::ublas;

HuxleyModel2D::HuxleyModel2D(HuxleyParameters* param) {
	_param = param;
	_calculator = new HuxleyCalculator(param);
    stateP = new HuxleyState2D();
}

HuxleyModel2D::~HuxleyModel2D() {
}

size_t CurlWrite_CallbackFunc_StdString(void *contents, size_t size, size_t nmemb, std::string *s)
{
    size_t newLength = size*nmemb;
    size_t oldLength = s->size();
    try
    {
        s->resize(oldLength + newLength);
    }
    catch(std::bad_alloc &e)
    {
        //handle memory problem
        return 0;
    }

    std::copy((char*)contents, (char*)contents+newLength, s->begin()+oldLength);
    return size*nmemb;
}

void HuxleyModel2D::calculate_surogat(ublas::vector<double>&  distrib, double v, double activation)
{	
	CURL *curl;
    CURLcode res;
	ostringstream stream;
    std::string endpoint = "http://147.91.204.14:8000/hux";
	int nsize = distrib.size();	
	stream << "distrib=";
	for(int i = 0; i < (nsize - 1); i++) stream << distrib[i] << "#";
	stream << distrib[nsize-1];
	stream << "&v=" << v;
	stream << "&activation=" << activation ; 
	string response, post_request = stream.str();
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if (curl) 
    {
        curl_easy_setopt(curl, CURLOPT_URL, endpoint.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_request.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, &CurlWrite_CallbackFunc_StdString);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        res = curl_easy_perform(curl);
		if (res != CURLE_OK) fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        curl_easy_cleanup(curl);
    }	
	
	replace (response.begin(), response.end(), '['  ,' ');
	replace (response.begin(), response.end(), ']'  ,' ');
	replace (response.begin(), response.end(), ','  ,' ');
	replace (response.begin(), response.end(), '\"' ,' ');
	stringstream ss(response);	
	// vrati u distrib 
	//printf("Dobijam:\n");
	for(int i=0; i<nsize; i++)
	{	
		ss >> distrib[i];
		if(distrib[i] < 0) distrib[i] = 0;
	//	printf("%lf ", distrib[i]);
	}
//	printf("\n");
}

void HuxleyModel2D::Calculate(MaterialModelState *s,double* e,double* sigma,double* dsigmade)
{
	int bUseSurogat = 0;
	if(bUseSurogat)
	{
		HuxleyState2D *state;
		state = (HuxleyState2D*)s;
		int coord = _param->direction;
		double V = (e[coord]- state->e_t[coord]) *(_param->L0)/Globals::getInstance()->dt; 
		int nsize         = state->histogram.size();
		double activation = (_param->m_f1/Globals::f1);	
		/*
	    fprintf(Globals::getInstance()->fsurro, "%d, %d,",Globals::getInstance()->step,Globals::getInstance()->iter);

		for(int i=0; i <  Globals::nbins; i++)
			fprintf(Globals::getInstance()->fsurro,"%lf,",state->histogram[i] );
        fprintf(Globals::getInstance()->fsurro,"%lf,%20.10lf,",V,activation);
		*/
		calculate_surogat(state->histogram, V, activation);
		/*
		for(int i=0; i <  Globals::nbins; i++)
			fprintf(Globals::getInstance()->fsurro,"%lf,",state->histogram[i] );
		fprintf(Globals::getInstance()->fsurro,"\n");	
		fflush(Globals::getInstance()->fsurro);	
		*/
		
		double xmin = -16, xmax = 16;
		double chunk_size = (xmax-xmin)/Globals::nbins;
		double ds = 0, s = 0;
		
		for(int i=0; i <  Globals::nbins; i++)
		{
			double lower_bound = xmin + (i-1)*chunk_size;
			double upper_bound = lower_bound + chunk_size; 
            double x = (lower_bound + upper_bound)/2;				
			s += chunk_size * state->histogram[i] * x; 
		}
        s = (s * _param->m_Kxb)/_param->A;

		for(int i = 1; i < Globals::nbins; i++)
		{		
			ds +=  (state->histogram[i]);
		}
		ds               = ds * chunk_size * _param->m_Kxb *e[coord]*_param->L0/_param->A;
		sigma[coord]    = s;
		dsigmade[coord] = ds;
		
	}
	else
	{		
	//	double force,forceP,sigmaP,V,Vpert;
	// DEBUG printf("HuxleyModel2D usao u calculate \n");
			int coord = _param->direction;
			_TIP force,forceP,sigmaP,V,Vpert;
			
		/*for(int j=0;j<3;j++)
		printf("%lf \n",sigma[j]);
		getchar();*/


			// HuxleyState2D *stateP,*state;
			HuxleyState2D *state;
			//stateP = new HuxleyState2D();
			state = (HuxleyState2D*)s;
			stateP->init(s);

			Globals* g = Globals::getInstance();

			printf("HuxleyModel2D::Calculate ----  g->dt = %lf\n",g->dt);
			_TIP  t = (_TIP) g->dt;
			int br=0;
			for (int i=0;i<(state->X).size();i++)
			{
				if(fabs(state->N[i] - 0.0)>1.0E-3) br++;
				//printf("%lf\n",state->N[i]);
			}

	//e_ing
			//V = (e[coord]-stateP->e_t[coord])*(_param->L0)/t;
			//Vpert = (e[coord]+_param->pertubacija-stateP->e_t[coord])*(_param->L0)/t;
			//V = (e[coord]-stateP->e_t[coord])*(_param->L0)*exp(stateP->e_t[coord])/t;
			//Vpert = (e[coord]+_param->pertubacija-stateP->e_t[coord])*exp(stateP->e_t[coord])*(_param->L0)/t;

	//prirodna deformacija	
			//V = (exp(e[coord])-exp(state->e_t[coord]))*(_param->L0)/t;
			//Vpert = (exp(e[coord]+_param->pertubacija)-exp(stateP->e_t[coord]))*(_param->L0)/t;
			
			V = (e[coord]-stateP->e_t[coord])*(_param->L0)/t;
			Vpert = (e[coord]+_param->pertubacija-stateP->e_t[coord])*(_param->L0)/t;
			
			/*FILE *pom;
			pom = fopen("huxley_V.txt","a");
			fprintf(pom,"\t%d\t%f\t%f\t%f\n ",g->step+1,e[coord],V,force);
			fclose(pom);*/
		 
			_TIP O = (_param->stressStretchFunction).GetValue(e[coord]);
			printf("Korekcija %lf\n",O);
			ublas::vector<double> rez_prev = createHistogram(state->X,state->N, Globals::nbins);


		pomV=V;
		pomVP=Vpert;
		if (_param->_fi>0)
			{
			_calculator->Calculate(state->X,state->N,(_TIP)V,t,(_TIP *)&force, (_TIP)O);
				lastPointIterCount_V = _calculator->getBrojac();
				*dsigmade = _calculator->getSigmaTangent(e[coord]);
			//_calculator->Calculate(stateP->X,stateP->N,(_TIP)Vpert,t,(_TIP *)&forceP, (_TIP)O);
				lastPointIterCount_VPert = _calculator->getBrojac();

			// _calculator->Calculate(state->X,state->N,state->v_t,(_TIP)V,t,(_TIP *)&force);
					// lastPointIterCount_V = _calculator->getBrojac();
			// *dsigmade = _calculator->getSigmaTangent(e[coord]);
			// _calculator->Calculate(stateP->X,stateP->N,stateP->v_t,(_TIP)Vpert,t,(_TIP *)&forceP);
					// lastPointIterCount_VPert = _calculator->getBrojac();
		}
		else
		{
			force = 0; lastPointIterCount_V = 0;
			forceP = 0; lastPointIterCount_VPert = 0;
		}
			//printf("*\t%f\t%f\t%f\n ",e[coord],V,force);

		
		state->e_t[coord]=e[coord];
		//	for (int i=0;i<3;i++) printf("%lf \t",e[i]);
		//	printf("\n");
			CalculateStress((_TIP*)&force,(_TIP*)&forceP,e,sigma,dsigmade);
			//FILE *f=fopen("Test.dat","a");
			//fprintf(f,"%d\t%lf\t%lf\t%lf\t%lf\t%f\n",br,_param->m_f1,e[coord],sigma[0],dsigmade[0],V);
			//fclose(f);
		

		ublas::vector<double> rez = createHistogram(state->X,state->N, Globals::nbins);
	}

}

// void HuxleyModel2D::CalculateStress(_TIP *force,_TIP *forceP,double* e,double* sigma,double* dsigmade){
	// double sigmaP;
	// int coord = _param->direction;
	// double C_matrix [3][3];
	// double Sigma_vector[3];
	// for (int i = 0; i < 3; ++i) Sigma_vector[i]=0;

    // C_matrix[0][0]=1.0; 	C_matrix[0][1]=_param->_ni; C_matrix[0][2]=0.0;
    // C_matrix[1][0]=_param->_ni;		C_matrix[1][1]=1.0;	C_matrix[1][2]=0.0;
    // C_matrix[2][0]=0.0; 	C_matrix[2][1]=0.0;		C_matrix[2][2]=(1-_param->_ni)/2;
	
	// for (int i = 0; i < 3; ++i)
		// for (int j = 0; j < 3; ++j)
            // C_matrix[i][j]*=(1-_param->_fi)*_param->_E/(1-_param->_ni*_param->_ni);
	// for(int i=0;i<3;i++)
		// for(int j=0;j<3;j++)
			// Sigma_vector[i]+=C_matrix[i][j]*e[j];

	// double sigma_muscle = *force/_param->A;
    // //Gordon korekcija sigma_muscle i sigmaP    sigma * f(stretch)   stretch=1+e
	// double stretch = exp(e[coord]);
	// double GordonFactor = (_param->stressStretchFunction).GetValue(stretch);
    // sigma_muscle = sigma_muscle * GordonFactor;

	// FILE *pom;
	// pom = fopen("stretch_huxley.txt","a");
			// fprintf(pom,"\t%f\n ",stretch);
	// fclose(pom);

	
	// double stretchP = exp(e[coord] + _param->pertubacija);
	// double GordonFactorP = (_param->stressStretchFunction).GetValue(stretchP);
    // sigmaP = *forceP/_param->A  * GordonFactorP;


    // /*printf("x:    %lf y:  %lf\n",stretch, (_param->stressStretchFunction).GetValue(stretch));
    // getchar();*/

    // double dsigmade_muscle = (sigmaP-sigma_muscle)/_param->pertubacija;
    // //double dsigmade_muscle = *dsigmade;
    // //dsigmade_muscle = 1.1513500389;
    // //sigma_muscle = 0.0278924542 + (e[coord]) * dsigmade_muscle;

    // /*FILE *f=fopen("Test.dat","a");
    // fprintf(f,"%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t",_param->m_f1,e[0],e[1],(1-_param->_fi)*Sigma_vector[0],_param->_fi*sigma_muscle,(1-_param->_fi)*C_matrix[0][0],_param->_fi*dsigmade_muscle);*/

    // Sigma_vector[coord]=Sigma_vector[coord]+_param->_fi*sigma_muscle;
    // C_matrix[coord][coord]=C_matrix[coord][coord]+_param->_fi*dsigmade_muscle;



// for(int i=0;i<3;i++) sigma[i]=Sigma_vector[i];
// for(int i=0;i<3;i++)
	// for(int j=0;j<3;j++)
        // *(dsigmade+i*3+j) = C_matrix[i][j];


// /*fprintf(f,"%lf\t%lf\n",sigma[0],dsigmade[0]);
// fclose(f);*/


// //printf("Koristio f1 = %lf, a ucitano je f=%lf   E= %lf\n",_param->m_f1,Globals::f1,_param->_E);
// printf("HuxleyModel2D V6 ::Calculate ---  force = %lf \t  forceP=%lf\n",*force, *forceP);
// printf("HuxleyModel2D V6 ::Calculate ---  sigma[0] = %lf \t  C_matrix[0][0]=%lf\n",sigma[0], C_matrix[0][0]);
// }


void HuxleyModel2D::CalculateStress(_TIP *force,_TIP *forceP,double* e,double* sigma,double* dsigmade){
	double sigmaP;
	int coord = _param->direction;
	double C_matrix [3][3];
	double Sigma_vector[3];
	for (int i = 0; i < 3; ++i) Sigma_vector[i]=0;

	for (int i = 0; i < 3; ++i)
		for (int j = 0; j < 3; ++j)
            C_matrix[i][j] =0.0;

	double sigma_muscle = *force/_param->A;
    //Gordon korekcija sigma_muscle i sigmaP    sigma * f(stretch)   stretch=1+e
	//double stretch = exp(e[coord]);
	double stretch = e[coord];
	double GordonFactor = (_param->stressStretchFunction).GetValue(stretch);
    sigma_muscle = sigma_muscle;// * GordonFactor;

	//double stretchP = exp(e[coord] + _param->pertubacija);
    double stretchP = e[coord] * exp(_param->pertubacija);
	double GordonFactorP = (_param->stressStretchFunction).GetValue(stretchP);
    //sigmaP = *forceP/_param->A;//  * GordonFactorP;


    /*printf("x:    %lf y:  %lf\n",stretch, (_param->stressStretchFunction).GetValue(stretch));
    getchar();*/

    //double dsigmade_muscle = (sigmaP-sigma_muscle)/_param->pertubacija;

    //dsigmade_muscle = 1.1513500389;
	double dsigmade_muscle = *dsigmade;

    //sigma_muscle = 0.0278924542 + (e[coord]) * dsigmade_muscle;

    /*FILE *f=fopen("Test.dat","a");
    fprintf(f,"%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t",_param->m_f1,e[0],e[1],(1-_param->_fi)*Sigma_vector[0],_param->_fi*sigma_muscle,(1-_param->_fi)*C_matrix[0][0],_param->_fi*dsigmade_muscle);*/

    Sigma_vector[coord]=Sigma_vector[coord]+sigma_muscle;
    C_matrix[coord][coord]=C_matrix[coord][coord]+dsigmade_muscle;



for(int i=0;i<3;i++) sigma[i]=Sigma_vector[i];
for(int i=0;i<3;i++)
	for(int j=0;j<3;j++)
        *(dsigmade+i*3+j) = C_matrix[i][j];


/*fprintf(f,"%lf\t%lf\n",sigma[0],dsigmade[0]);
fclose(f);*/


//printf("Koristio f1 = %lf, a ucitano je f=%lf   E= %lf\n",_param->m_f1,Globals::f1,_param->_E);
printf("HuxleyModel2D V6 ::Calculate ---  force = %lf \t  forceP=%lf\n",*force, *forceP);
printf("HuxleyModel2D V6 ::Calculate ---  sigma[0] = %lf \t  C_matrix[0][0]=%lf\n",sigma[0], C_matrix[0][0]);
}

void HuxleyModel2D::getCountOfIterations(int& countV, int& countVpert)
{
    countV = lastPointIterCount_V;
    countVpert = lastPointIterCount_VPert;
}

_TIP HuxleyModel2D::getCurrForce(MaterialModelState *s)
{	
	_TIP force;
	HuxleyState2D *state;
	 state = (HuxleyState2D*)s;
	//_calculator->Calculate(state->X,state->N,(_TIP)0,0,(_TIP *)&force);
	return force;
}

void HuxleyModel2D::getV(_TIP* V,_TIP* VP)
{
	*V=pomV;
      	*VP=pomVP;
}


MaterialModelParameters* HuxleyModel2D::getParameters(){
	return (MaterialModelParameters*) _param;
}

