/*!
 * \file HFunctions.cpp
 * Implementation of the HFunctions class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HFunctions.cpp: implementation of the HFunctions class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "PAKExp.h"
#include "HFunctions.h"
#include "TimeSteps.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL( HFunctions,HDataBlock, VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
HFunctions::HFunctions()
{
	m_FunctionEntry.SetSize(0,5);
}

/*!
 * Copy constructor.
 */
HFunctions::HFunctions (const HFunctions& rc)
{
	(*this)=rc;
}

/*!
 * Equalizes two objects of the HFunctions class.
 * 
 * \param[in] rc
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
HFunctions& HFunctions::operator =(const HFunctions& rc)
{
	m_uDataBlockID=rc.m_uDataBlockID;
	m_nID=rc.m_nID;
	m_uFunc_type=rc.m_uFunc_type;
	m_strTitle=rc.m_strTitle;

	m_FunctionEntry.RemoveAll();
	m_FunctionEntry.Copy( rc.m_FunctionEntry );

	return *this;
}

/*!
 * Destructor.
 */
HFunctions::~HFunctions()
{
	m_FunctionEntry.RemoveAll();
}

///*!
// * serializes object of the HFunctions class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// * 
// * \returns
// * Reference to this object.
// */
//void HFunctions::Serialize(CArchive& ar)
//{
//	if (ar.IsStoring())
//	{
//		ar << m_nID;//ID of function
//		ar << m_uFunc_type;//Type of function (0=Dimensionless, 1=vs. Time, 2=vs. Temp)
//		ar << m_strTitle;//Function title (max 25 char)
//		ar << m_FunctionEntry.GetSize();
//		for (int i=0;i<m_FunctionEntry.GetSize();i++)
//		{
//			ar << m_FunctionEntry[i].m_uEntryID;
//			ar << m_FunctionEntry[i].m_dX;
//			ar << m_FunctionEntry[i].m_dY;
//		}
//	}
//	else
//	{
//		ar >> m_nID;//ID of function
//
//		int nFuncType;
//		ar >> nFuncType;
//		m_uFunc_type = (FunctionType)nFuncType;//Type of function (0=Dimensionless, 1=vs. Time, 2=vs. Temp)
//
//		ar >> m_strTitle;//Function title (max 25 char)
//		
//		UINT nFunctionEntryCount;
//		ar >> nFunctionEntryCount;
//
//		m_FunctionEntry.SetSize(nFunctionEntryCount);
//		FunctionEntry fe;
//		for (UINT i=0; i < nFunctionEntryCount; i++)
//		{
//			ar >> fe.m_uEntryID;
//			ar >> fe.m_dX;
//			ar >> fe.m_dY;
//			m_FunctionEntry.SetAt(i,fe);
//		}
//	}
//}

/*!
 * Gets minimum and maximum values at X and Y axes.
 * 
 * \param[out] dXmin
 * Minimum X value.
 * 
 * \param[out] dXmax
 * Maximum X value.
 * 
 * \param[out] dYmin
 * Minimum Y value.
 * 
 * \param[out] dYmax
 * Maximum Y value.
 * 
 * \returns
 * Reference to this object.
 */
bool HFunctions::GetRange(double &dXmin, double &dXmax, double &dYmin, double &dYmax)
{
	UINT nPointCount = m_FunctionEntry.GetSize();

	if(nPointCount > 1)
	{
		FunctionEntry &Point = m_FunctionEntry[0];
		dXmin = Point.m_dX;
		dXmax = Point.m_dX;
		dYmin = Point.m_dY;
		dYmax = Point.m_dY;
	}
	else
	{
		return(FALSE);
	}

	for(UINT i = 1; i < nPointCount; i++)
	{
		FunctionEntry Point = m_FunctionEntry[i];

		if( Point.m_dX < dXmin ) dXmin = Point.m_dX;
		if( Point.m_dX > dXmax ) dXmax = Point.m_dX;
		if( Point.m_dY < dYmin ) dYmin = Point.m_dY;
		if( Point.m_dY > dYmax ) dYmax = Point.m_dY;
	}

	return(TRUE);
}

/*!
 * Calculates sum of this function and right-hand side function. Resulting function contains sum of Y values of operands.
 * 
 * \param[in] Right
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to the resulting function.
 */
HFunctions HFunctions::operator +(const HFunctions &Right)
{
	HFunctions &Left = *this;
	HFunctions Sum;

	int nLeftIndex = 0, nRightIndex = 0;

	while(	nLeftIndex < Left.m_FunctionEntry.GetSize() ||
			nRightIndex < Right.m_FunctionEntry.GetSize() )
	{
		//If both function still have points
		if( nLeftIndex < Left.m_FunctionEntry.GetSize() && 
			nRightIndex < Right.m_FunctionEntry.GetSize() )
		{
			const FunctionEntry &LeftPoint = Left.m_FunctionEntry[nLeftIndex];
			const FunctionEntry &RightPoint = Right.m_FunctionEntry[nRightIndex];

			//If the next point is point on the left hand operand function
			if( LeftPoint.m_dX <= RightPoint.m_dX )
			{
				double dY;
				if( !GetY(LeftPoint.m_dX,dY) ) dY = 0.0;

				
					FunctionEntry m(	Sum.m_FunctionEntry.GetSize()+1,
									LeftPoint.m_dX,
									LeftPoint.m_dY + dY);
					Sum.m_FunctionEntry.Add(m);
				
				nLeftIndex++;
				if( LeftPoint.m_dX == RightPoint.m_dX ) nRightIndex++;
			}
			//If the next point is point on the right hand operand function
			else
			{
				double dY;
				if( !GetY(RightPoint.m_dX,dY) ) dY = 0.0;

				
					FunctionEntry m(	Sum.m_FunctionEntry.GetSize()+1, 
									RightPoint.m_dX,
									RightPoint.m_dY + dY);
					Sum.m_FunctionEntry.Add(m);
				
				nRightIndex++;
			}
		}
		//If only left function still have points
		else if ( nLeftIndex < Left.m_FunctionEntry.GetSize() )
		{
			FunctionEntry &LeftPoint = Left.m_FunctionEntry[nLeftIndex];

			
				FunctionEntry m(	Sum.m_FunctionEntry.GetSize()+1,
								LeftPoint.m_dX,
								LeftPoint.m_dY);
				Sum.m_FunctionEntry.Add(m);
				
			nLeftIndex++;
		}
		//If only right function still have points
		else
		{
			const FunctionEntry &RightPoint = Right.m_FunctionEntry[nRightIndex];

			
				FunctionEntry m(	Sum.m_FunctionEntry.GetSize()+1,
								RightPoint.m_dX,
								RightPoint.m_dY);
				Sum.m_FunctionEntry.Add(m);
			
			nRightIndex++;
		}
	}

	return( Sum );
}
#define FUN_ENTRY_TOL 1.e-8
/*!
 * Gets Y value for the corresponding X value.
 * 
 * \param[in] dX
 * X value.
 * 
 * \param[out] dY
 * Y value.
 * 
 * \returns
 * TRUE if interpolation is successful.
 */
bool HFunctions::GetY(double dX, double &dY) const
{
	UINT i;
	double dLeftTestPointX, dRightTestPointX;

	UINT nFunctionEntryCount = (UINT)m_FunctionEntry.GetSize();
	for( i = 0; i < nFunctionEntryCount - 1; i++)
	{
		const FunctionEntry &Left = m_FunctionEntry[i];
		const FunctionEntry &Right = m_FunctionEntry[i+1];

		if(i == 0) dLeftTestPointX = Left.m_dX - (Right.m_dX - Left.m_dX)*FUN_ENTRY_TOL;
		else dLeftTestPointX = Left.m_dX;

		if(i == (nFunctionEntryCount - 2)) dRightTestPointX = Right.m_dX + (Right.m_dX - Left.m_dX)*FUN_ENTRY_TOL;
		else dRightTestPointX = Right.m_dX;

		if( dX >= dLeftTestPointX && dX < dRightTestPointX )
		{
			dY = Left.m_dY + (dX-Left.m_dX)*(Right.m_dY-Left.m_dY)/(Right.m_dX-Left.m_dX);
			return(TRUE);
		}
	}

	return(FALSE);
}

/*!
 * Calculates product of this function and scalar. Resulting function contains product of Y values of this function and scalar.
 * 
 * \param[in] dK
 * Multiplying scalar.
 * 
 * \returns
 * Reference to the resulting function.
 */
HFunctions HFunctions::operator *(double dK)
{
	UINT i;
	HFunctions Product;

	for(i = 0; i < (UINT)m_FunctionEntry.GetSize(); i++)
	{
		FunctionEntry &Point = m_FunctionEntry[i];

		
			FunctionEntry m( Point.m_uEntryID, Point.m_dX, Point.m_dY * dK);
			Product.m_FunctionEntry.Add(m);
	}

	return( Product );
}

void HFunctions::ConvertToIncremental(CTimeSteps &TimeSteps, HFunctions &IncFunction)
{
	UINT i, j;

	IncFunction.m_nID = m_nID;
	IncFunction.m_strTitle = m_strTitle;
	IncFunction.m_uFunc_type = m_uFunc_type;

	IncFunction.m_FunctionEntry.RemoveAll();

	double dY, dPrevY=0.0;
	UINT nPointCount = TimeSteps.GetTotalStepCount()+1;
	IncFunction.m_FunctionEntry.SetSize(nPointCount+1, 0);
	IncFunction.m_FunctionEntry[0] = FunctionEntry(1, 0.0, 0.0);

	double dTime = 0.0;
	UINT nPointIndex = 1;

	for(i = 0; i < TimeSteps.GetTimePeriodsCount(); i++)
	{
		CTimeSteps::TimePeriod &TP = TimeSteps.GetTimePeriod(i);

		for(j = 0; j < TP.nSteps; j++)
		{
			dTime += TP.dStepDuration;
			GetY(dTime, dY);

			IncFunction.m_FunctionEntry[nPointIndex] = FunctionEntry(nPointIndex+1, dTime, dY-dPrevY);

			nPointIndex++;
			dPrevY = dY;
		}
	}

	// Extrapolate function to avoid error due to comparison of decimal numbers
	IncFunction.m_FunctionEntry[nPointCount]=FunctionEntry(nPointCount+1,dTime+1.0,dPrevY);

}

