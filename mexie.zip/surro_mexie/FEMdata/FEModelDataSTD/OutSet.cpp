/*!
 * \file OutSet.cpp
 * Implementation of the COutSet class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// OutSet.cpp: implementation of the COutSet class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "OutSet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//IMPLEMENT_SERIAL(COutSet,CObject,VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
COutSet::COutSet()
{
	m_nNLines = 1;
}

/*!
 * Copy constructor.
 */
COutSet::COutSet(const COutSet &p)
{
	(*this)=p;
}

/*!
 * Destructor.
 */
COutSet::~COutSet()
{

}

/*!
 * Removes all contents from output set.
 * 
 * \returns
 * Zero if successful.
 */
UINT COutSet::DeleteContents()
{
	m_OutVectors.RemoveAll();	
	return(0);
}

/*!
 * Equalizes two objects of the COutSet class.
 * 
 * \param[in] other
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
COutSet& COutSet::operator =(const COutSet &other)
{
	m_nID=other.m_nID;
	m_sTitle=other.m_sTitle;
	m_nFrom_prog=other.m_nFrom_prog;
	m_nAnal_type=other.m_nAnal_type;
	m_dValue=other.m_dValue;
	m_nNLines=other.m_nNLines;
	m_sNotes=other.m_sNotes;
	
	m_sSourceFileName = other.m_sSourceFileName;
	m_nDirectAccessPosition = other.m_nDirectAccessPosition;

/*	m_OutVectors.RemoveAll();
	m_OutVectors.InitHashTable(other.m_OutVectors.GetHashTableSize());
	POSITION pos=other.m_OutVectors.GetStartPosition();
	UINT key;
	COutVector val;
	while (pos != NULL)
	{
		other.m_OutVectors.GetNextAssoc( pos, key, val );
		m_OutVectors.SetAt(key,val);
    }
*/
	m_OutVectors.RemoveAll();
	m_OutVectors.Copy(other.m_OutVectors);

	return *this;
}


///*!
// * Serializes object of the COutSet class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void COutSet::Serialize(CArchive& ar)
//{
//	if (ar.IsStoring())
//	{
//		ar << m_nID;
//		ar << m_sTitle;
//		ar << m_nFrom_prog;
//		ar << m_nAnal_type;
//		ar << m_dValue;
//		ar << m_nNLines;
//		ar << m_sNotes;
//		
//		ar << m_sSourceFileName;
//		ar << m_nDirectAccessPosition;
//	}
//	else
//	{
//		ar >> m_nID;
//		ar >> m_sTitle;
//		ar >> m_nFrom_prog;
//		ar >> m_nAnal_type;
//		ar >> m_dValue;
//		ar >> m_nNLines;
//		ar >> m_sNotes; 
//
//		ar >> m_sSourceFileName;
//		ar >> m_nDirectAccessPosition;
//	}
//
//	m_OutVectors.Serialize(ar);
//
//}

/*!
 * Gets output vector with specified ID.
 * 
 * \param[in] ID
 * ID of the vector.
 * 
 * \returns
 * Reference to the output vector.
 */
COutVector& COutSet::GetOutVector(UINT ID)
{
	UINT OutVectorCount=m_OutVectors.GetSize();
	UINT i;
	for(i=0;i<OutVectorCount;i++)
		if(m_OutVectors[i].m_nID==ID) break;

	if(i>=OutVectorCount)
	{
		MyString msg;
		msg.Format("Internal error: Function GetVector(Vector %u does not exist)!", ID);
		//AfxMessageBox(msg);
		printf(msg);
	}

	return(m_OutVectors[i]);
}

/*!
 * Checks if output vector with specified ID exists.
 * 
 * \param[in] ID
 * ID of the vector.
 * 
 * \returns
 * TRUE if output vector exists. Otherwise FALSE.
 */
bool COutSet::IsOutVectorExist(UINT ID)
{
	UINT OutVectorCount=m_OutVectors.GetSize();

	for(UINT i=0;i<OutVectorCount;i++)
		if(m_OutVectors[i].m_nID==ID) return(TRUE);

	return(FALSE);
}

/*!
 * Searches for the index of the output vector with specified ID.
 * 
 * \param[in] ID
 * ID of the ouptut vector.
 * 
 * \param[out] nIndex
 * Index of the output vector.
 * 
 * \returns
 * TRUE if output vector is found. Otherwise FALSE.
 */
bool COutSet::FindOutVector(UINT ID, UINT &nIndex)
{
	UINT OutVectorCount=m_OutVectors.GetSize();

	for(nIndex=0;nIndex<OutVectorCount;nIndex++)
		if(m_OutVectors[nIndex].m_nID==ID) return(TRUE);

	return(FALSE);
}

/*!
 * Searches for the ID of the output vector with specified type.
 * 
 * \param[in] OutType
 * Type of the output vector.
 * 
 * \param[out] OutVectorID
 * ID of the output vector.
 * 
 * \returns
 * TRUE if output vector is found. Otherwise FALSE.
 */
bool COutSet::FindOutVectorByOutType(UINT OutType,UINT& OutVectorID)
{
	UINT OutVectorCount=m_OutVectors.GetSize();

	for(UINT i=0;i<OutVectorCount;i++)
		if(m_OutVectors[i].m_nOut_type==OutType)
		{
			OutVectorID=m_OutVectors[i].m_nID;
			return(TRUE);
		}

	return(FALSE);
}

/*
//Obezbedjuje vektore za totale, cvorne vrednosti i componente
UINT COutSet::ProvideSetOfOutVectors(bool ElemVar,MyString &Title,UINT &VectorID,UINT VarType,UINT NodeCount,UINT SumCompCount,COutVector* &ovTotal,COutVector *ovNodal[25],COutVector *ovComp[25][6],UINT HashTableSize)
{
	UINT j,k;
	MyString DirStr[3]={"X","Y","Z"};
	MyString str;

	UINT ovTotalID,ovNodalID[25],ovCompID[25][6];
	
	
	//Kreiranje vektora za smestanje efektivnih vrednosti
//	for(i=0;i<TotalCount;i++)	
//	{

		if(IsOutVectorExist(VectorID)) ovTotalID=VectorID;
		else
		{
			UINT Pos=m_OutVectors.Add(COutVector());

			COutVector *ov=&(m_OutVectors[Pos]);
			ov->m_Values.InitHashTable(HashTableSize);

			ov->m_nID=VectorID;
			ov->m_sTitle="Total "+Title;
			ov->m_nOut_type=VarType;

			if(ElemVar)
			{
				ov->m_nEnt_type=NEU_ELEM;
				ov->m_nComp_dir=0;
				ov->m_bCent_total=TRUE;
			}
			else
			{
				ov->m_nEnt_type=NEU_NODE;
				ov->m_nComp_dir=1;
				ov->m_bCent_total=FALSE;
			}

			ovTotalID=ov->m_nID;
		}

		VectorID++;
		//Kreiranje vektora za smestanje efektivnih vrednosti po cvorovima elementa
		for(j=0;j<NodeCount;j++) 
		{
			if(NodeCount>1)	//Ako su rezultati na nivou elementa
			{
				if(IsOutVectorExist(VectorID)) ovNodalID[j]=VectorID;
				else
				{
					UINT Pos=m_OutVectors.Add(COutVector());

					COutVector *ov=&(m_OutVectors[Pos]);
					ov->m_Values.InitHashTable(HashTableSize);
					
					ov->m_nID=VectorID;

					str.Format("Node %ld ",j+1);
					ov->m_sTitle=str+"Total "+Title;
					ov->m_nOut_type=VarType;
	
					ov->m_nEnt_type=NEU_ELEM;
					ov->m_nComp_dir=1;
					ov->m_bCent_total=FALSE;

					ovNodalID[j]=ov->m_nID;
					GetOutVector(ovTotalID).m_Comp[j]=ov->m_nID;
				}
				VectorID++;
			}
			else str="";
			
			//Kreiranje vektora za smestanje vrednosti po komponentama
			for(k=0;k<SumCompCount;k++)	
			{
				if(IsOutVectorExist(VectorID)) ovCompID[j][k]=VectorID;
				else
				{
					UINT Pos=m_OutVectors.Add(COutVector());

					COutVector *ov=&(m_OutVectors[Pos]);
					ov->m_Values.InitHashTable(HashTableSize);
					
					ov->m_nID=VectorID;

					ov->m_sTitle=str+Title+DirStr[k];
					ov->m_nOut_type=VarType;

					for(UINT l=0;l<20;l++) ov->m_Comp[l]=0;
					ov->m_Comp[k]=ov->m_nID;

					if(ElemVar)
					{
						ov->m_nEnt_type=NEU_ELEM;
					}
					else
					{
						ov->m_nEnt_type=NEU_NODE;
					}
					ov->m_bCent_total=FALSE;
					ov->m_nComp_dir=0;

					ovCompID[j][k]=ov->m_nID;

					if(NodeCount>1) GetOutVector(ovNodalID[j]).m_Comp[k]=ov->m_nID;
					else GetOutVector(ovTotalID).m_Comp[k]=ov->m_nID;
				}

				VectorID++;

			}// Kraj: Kreiranje vektora za smestanje vrednosti po komponentama
			
			if(NodeCount>1) for(k=SumCompCount;k<20;k++) GetOutVector(ovNodalID[j]).m_Comp[k]=0;
			else for(k=SumCompCount;k<20;k++) GetOutVector(ovTotalID).m_Comp[k]=0;

		} //Kraj: Kreiranje vektora za smestanje vrednosti po cvorovima elementa

		if(NodeCount>1) for(j=NodeCount;j<20;j++) GetOutVector(ovTotalID).m_Comp[j]=0;

//	}//Kraj: Kreiranje vektora za smestanje efektivnih vrednosti

	//Pointeri na OutVectore zbog brzeg pristupa
//	for(i=0;i<TotalCount;i++)
//	{

		ovTotal=&(GetOutVector(ovTotalID));

		for(j=0;j<NodeCount;j++)
		{
			if(NodeCount>1) ovNodal[j]=&(GetOutVector(ovNodalID[j]));

			for(k=0;k<SumCompCount;k++) 
				ovComp[j][k]=&(GetOutVector(ovCompID[j][k]));
		}
//	}
	

	return(0);
}
*/

/*!
 * Creates output vector with specified ID, title, variable type and entity type. If output vector with the specified ID already exists, function does not take effect.
 * 
 * \param[in] nVectorID
 * Output vector ID.
 * 
 * \param[in] sTitle
 * Output vector title.
 * 
 * \param[in] nVarType
 * Type of the variable represented by output vector.
 * 
 * \param[in] nEntityType
 * Type of the entity (node or element) which output vector corresponds to.
 * 
 * \param[in] nHashTableSize
 * Size of the hash table. Used to optimize search (see literature about hash tables).
 * 
 * \returns
 * Zero if successful
 */
UINT COutSet::ProvideOutVector(UINT nVectorID, const MyString &sTitle, UINT nVarType, UINT nEntityType,UINT nHashTableSize)
{
	if( !IsOutVectorExist(nVectorID) )
	{
		//UINT nIndex = m_OutVectors.Add(COutVector());
		COutVector OutVector; //= m_OutVectors[nIndex];
		//OutVector.m_Values.InitHashTable(nHashTableSize);

		OutVector.m_nID = nVectorID;
		OutVector.m_sTitle = sTitle;
		OutVector.m_nOut_type = nVarType;
		OutVector.m_nEnt_type = nEntityType;
		OutVector.m_nComp_dir=0;
		OutVector.m_bCent_total=TRUE;
                m_OutVectors.Add(OutVector);

	}

	return(0);
}

/*!
 * Creates N-component output vector with specified ID, title, component extensions, variable type and entity type. If output vector with the specified ID already exists, function does not take effect.
 * 
 * \param[in] nVectorID
 * Output vector ID.
 * 
 * \param[in] sTitle
 * Output vector title.
 * 
 * \param[in] sCompExtensions
 * N-element array of extensions for the component titles.
 * 
 * \param[in] nVarType
 * Type of the variable represented by output vector.
 * 
 * \param[in] nEntityType
 * Type of the entity (node or element) which output vector corresponds to.
 * 
 * \param[in] nHashTableSize
 * Size of the hash table. Used to optimize search (see literature about hash tables).
 * 
 * \param[in] nComponentCount
 * Number of components of the variable.
 * 
 * \returns
 * Zero if successful
 */
UINT COutSet::ProvideNComponentOutVector(UINT nVectorID, MyString sTitle, MyString sCompExtensions[], UINT nVarType, UINT nEntityType,UINT nHashTableSize, UINT nComponentCount)
{
	ASSERT(nComponentCount <= 20);

	UINT i;

	if( !IsOutVectorExist(nVectorID) )
	{
		COutVector OutVector;

		//Effective
		OutVector.m_nID = nVectorID;
		OutVector.m_sTitle = sTitle;
		OutVector.m_nOut_type = nVarType;
		OutVector.m_nEnt_type = nEntityType;
		OutVector.m_nComp_dir=1;
		OutVector.m_bCent_total=TRUE;
		for(i = 0; i < nComponentCount; i++) OutVector.m_Comp[i] = nVectorID+i+1;
		for(i = nComponentCount; i < 20; i++) OutVector.m_Comp[i] = 0;

		UINT nIndex = m_OutVectors.Add(OutVector);
		COutVector &OutVectorTotal = m_OutVectors[nIndex];
		//OutVectorTotal.m_Values.InitHashTable(nHashTableSize);


		//Components
		OutVector.m_nComp_dir=0;
		for(i = 0; i < nComponentCount; i++) OutVector.m_Comp[i] = 0;

		for(i = 0; i < nComponentCount; i++)
		{
			OutVector.m_nID = nVectorID+i+1;
			OutVector.m_sTitle = sTitle + " " + sCompExtensions[i];

			UINT nIndex = m_OutVectors.Add(OutVector);
			COutVector &OutVectorComp = m_OutVectors[nIndex];
			//OutVectorComp.m_Values.InitHashTable(nHashTableSize);
		}
	}

	return(0);
}

/*!
 * Creates element N-component output vector with specified ID, title, component extensions, variable type and entity type. If output vector with the specified ID already exists, function does not take effect.
 * 
 * \param[in] nVectorID
 * Output vector ID.
 * 
 * \param[in] sTitle
 * Output vector title.
 * 
 * \param[in] sCompExtensions
 * N-element array of extensions for the component titles.
 * 
 * \param[in] nVarType
 * Type of the variable represented by output vector.
 * 
 * \param[in] nEntityType
 * Type of the entity (node or element) which output vector corresponds to.
 * 
 * \param[in] nHashTableSize
 * Size of the hash table. Used to optimize search (see literature about hash tables).
 * 
 * \param[in] nNodeCount
 * Number of nodes per element.
 * 
 * \param[in] nComponentCount
 * Number of components of the variable.
 * 
 * \returns
 * Zero if successful
 */
UINT COutSet::ProvideElementNComponentOutVector(UINT nVectorID, const MyString &sTitle, MyString sCompExtensions[], UINT nVarType, UINT nEntityType,UINT nHashTableSize, UINT nIntPointCount, UINT nComponentCount)
{
	ASSERT(nComponentCount <= 20);

	UINT i;

	if( !IsOutVectorExist(nVectorID) )
	{
		COutVector OutVector;

		//Element centroid
		OutVector.m_nID = nVectorID;
		OutVector.m_sTitle = sTitle;
		OutVector.m_nOut_type = nVarType;
		OutVector.m_nEnt_type = nEntityType;
		OutVector.m_nComp_dir=0;
		OutVector.m_bCent_total=TRUE;
		for(i = 0; i < nIntPointCount; i++) OutVector.m_Comp[i] = nVectorID+i*(nComponentCount+1)+1;
		for(i = nIntPointCount; i < 20; i++) OutVector.m_Comp[i] = 0;

		UINT nIndex = m_OutVectors.Add(OutVector);
		COutVector &OutVectorCentroid = m_OutVectors[nIndex];
		//OutVectorCentroid.m_Values.InitHashTable(nHashTableSize);

		//Out vectors for each integration point
		for(UINT i = 0; i < nIntPointCount; i++)
		{
			ProvideNComponentOutVector(nVectorID+i*(nComponentCount+1)+1,sTitle,sCompExtensions,nVarType,nEntityType,nHashTableSize,nComponentCount);
		}
	}

	return(0);
}

/*
UINT COutSet::WriteContent()
{
	MyString msg;

	for(UINT i = 0; i < m_OutVectors.GetSize(); i++)
	{
		COutVector &OV=m_OutVectors[i];

		//if(OV.m_nID < 6300) continue;

		MyString strID;
		strID.Format("Vector %5u  %40s  %2d:  ", OV.m_nID, OV.m_sTitle, OV.m_nOut_type);
		msg+=strID;

		for(UINT j = 0; j < 20; j++)
		{
			MyString strComp;

			strComp.Format("%5u",OV.m_Comp[j]);

			msg+=strComp;

		}

		msg+="\n";
	}

	AfxMessageBox(msg);

	return(0);
}
*/