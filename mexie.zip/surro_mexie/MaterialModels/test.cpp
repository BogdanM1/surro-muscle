/*
 * test.cpp
 *
 *  Created on: May 12, 2014
 *      Author: anakaplarevic
 */

#include <cstdio>
#include "Globals.h"
#include "HuxleyModel.h"
#include "HuxleyState.h"
#include "HuxleyState2D.h"
#include "HuxleyModel2D.h"
#include "HuxleyParameters.h"
#include "MaterialModel.h"
#include "MaterialModelParameters.h"
#include "MaterialModelState.h"
#include <map>
#include <string.h>
#include "histogram.h"

int main()
{
	
	Globals* g = Globals::getInstance();
    double e=-0.021651,*sigma,*dsigmade;
	sigma =(double*)malloc(3*sizeof(double));
	dsigmade = (double *)malloc(9*sizeof(double));
 	g->dt=0.01;
 	HuxleyParameters hp;
 	hp.InputData();	
	
	HuxleyState2D s2D;
	s2D.init(&hp);
	HuxleyCalculator calcTest(&hp);
	HuxleyModel2D model2D(&hp); 
	double ev[3];
     ev[0]=0; ev[1]=0; ev[2]=0;	
	model2D.Calculate(&s2D,ev,sigma,dsigmade);
	fprintf(stdout,"\n naponi\n");
	fprintf(stdout,"%lf %lf\n",sigma[0], dsigmade[0]);
     ev[0] = 0.5; ev[1] = 0; ev[2] = 0;	
	model2D.Calculate(&s2D,ev,sigma,dsigmade);
	fprintf(stdout,"\n naponi\n");
	fprintf(stdout,"%lf %lf\n",sigma[0], dsigmade[0]);	
	
  /*  long DIM = ceil((hp.xmax-hp.xmin)/hp.step);
     DIM = DIM + hp.m_leftng + hp.m_rightng;
     ublas::zero_vector<_TIP> _0(DIM+1);
     ublas::vector<_TIP> X(DIM+1),N(DIM+1);*/


/* test histogram */
/*
	double x_array[] = {-20, -18, -15, -5, -2, 0, 1, 2, 3, 4, 10};
	vector<double> x (x_array, x_array + sizeof(x_array) / sizeof(double));
	
	double y_array[] = {  3,   1,   2,  1,  2, 1, 2, 1, 2,  1,  1};
	vector<double> y (y_array, y_array + sizeof(y_array) / sizeof(double));
	
	vector<double> rez = createHistogram(x, y, 3);
	int N = rez.size();
	
	for(int i =0; i < N; i++)
		printf("%lf\n", rez[i]);
/**/
}

/*
int main()
{
// 	   double ev[3];
//        ev[0]=0; ev[1]=0; ev[2]=0;
//     Globals* g = Globals::getInstance();
//     double e=-0.021651,*sigma,*dsigmade;
// sigma =(double*)malloc(3*sizeof(double));
// dsigmade = (double *)malloc(9*sizeof(double));
//     // staro	g->huxleyParameters  = new HuxleyParameters();
// 	g->dt=0.01;
// 	HuxleyParameters hp;
//     printf ("TEST 01\n");
// 	hp.InputData();
	
	
// 	//  TESTIRANJE ZAVISNOSTI
//     //HuxleyCalculatorTestITER calcTestITER(&hp);
// 	//HuxleyCalculator calcTest(&hp);
//     long DIM = ceil((hp.xmax-hp.xmin)/hp.step);
// 	long LEVO = 0, DESNO = 14500;
//     DIM = DIM + hp.m_leftng + hp.m_rightng;
//     ublas::zero_vector<_TIP> _0(DIM+1);
//     ublas::vector<_TIP> X(DIM+1),N(DIM+1),X1(DIM+LEVO+DESNO+1),N1(DIM+LEVO+DESNO+1);
// 	float force,forceNew,stiff;
	
// 	char ulaz[100];
// 	_TIP pom, pomX, pomN;
// 	FILE *fNX = fopen("X_N.txt","r");
//     _TIP poc = hp.xmin - hp.m_leftng*hp.step;
//     printf("%d\n",DIM);
	
//     for(unsigned int i = 0; i <= DIM; i++) {
//         //X(i) = poc + hp.step * i;
// 		fgets (ulaz, 100, fNX);
// 		//printf("%s",ulaz);
// 		sscanf (ulaz,"%f%f",&X(i),&N(i));
// 		//printf("%lf  %lf\n",X(i),N(i));
//     }
// 	_TIP poc2 = X(0) - LEVO*hp.step;
// 	for(int i=0;i<LEVO;i++){
// 		X1(i)=poc2+i*hp.step;
// 		N1(i)=0;
// 		}
// 	int k = 0;
// 	for(int i=LEVO;i<=LEVO+DIM;i++){
// 		X1(i)=X(k);
// 		N1(i)=N(k);
// 		k++;
// 		}
// 	for(int i=LEVO+DIM+1;i<=DIM+LEVO+DESNO;i++){
// 		X1(i)=poc2+i*hp.step;
// 		N1(i)=0;
// 		}


		
//     _TIP Vp = 1845069.25;
//   //  _TIP Vp = 7500;
// 	//calcTest.Calculate(X1,N1,(_TIP)Vp,0.001,(_TIP *)&force);
//     //calcTest.Calculate(X,N,(_TIP)Vp,0.001,(_TIP *)&force);
//     fclose(fNX);
  
//     getchar();
}	
// // Globals IZMENA       g->huxleyParameters = &hp;

	// HuxleyState s;
	// printf ("TEST 02\n");
// //	Globals IZMENA      s.init(g->huxleyParameters);
    // s.init(&hp);
	// printf ("TEST 03\n");
// //	Globals IZMENA      HuxleyModel model(g->huxleyParameters);
    // HuxleyModel model(&hp);
	// printf ("TEST 04\n");
	// //model.Calculate(&s,&e,sigma,dsigmade);
	// printf("sigma=%lf\n",*sigma);
    // //getchar();
    // //printf("____________________________ Test me! %lf \n",g->dt);
    // HuxleyState2D s2D;
// //	Globals IZMENA      s2D.init(g->huxleyParameters);
    // s2D.init(&hp);
// //	Globals IZMENA      HuxleyModel2D model2D(g->huxleyParameters);
    // HuxleyModel2D model2D(&hp);
    // model2D.Calculate(&s2D,ev,sigma,dsigmade);
	// printf("sigma=%lf\n",*sigma);

// //	printf("____________________________ Test me! %lf \n",g->dt);

	// MMType nizTipovaModela[2];
	// nizTipovaModela[0]=Huxley2D;
	// nizTipovaModela[1]=Huxley2D;
   // MaterialModel** mm;
   // MaterialModelState** state_t;
   // mm = (MaterialModel**) malloc(2*sizeof(MaterialModel*));
   // state_t = (MaterialModelState**) malloc(2*sizeof(MaterialModelState*));

   // map<MMType,MaterialModel*> mapaModela;
// //	Globals IZMENA      mapaModela[Huxley1D] = new HuxleyModel(g->huxleyParameters);
   // mapaModela[Huxley1D] = new HuxleyModel(&hp);
   // mapaModela[Huxley2D] = new HuxleyModel2D(&hp);

   // printf ("TEST pre inita\n");
   // for (int i=0;i<2;i++)
   // {

	   // switch (nizTipovaModela[i])
	   // {
	   	   // case Huxley1D: mm[i]=&model;
	   	   	   	   	   	   	   	   // state_t[i] = new HuxleyState();
// //	Globals IZMENA                 state_t[i]->init(g->huxleyParameters);
                                   // state_t[i]->init(&hp);
	   	   	   	   	   	   	   	   // break;
           // case Huxley2D: mm[i]=new HuxleyModel2D(&hp);//g->huxleyParameters);//'&model2D;
	   	   	   	   	   	   	   // state_t[i] = new HuxleyState2D();
                               // state_t[i]->init(&hp);//g->huxleyParameters);
	   	   	   	   	   	   	   // break;
	   	   	   // default: printf("Nije nista od datog\n");
	   	   	   // break;
	   // }
    // }

     // printf ("TEST pre inita\n");
     // mapaModela[nizTipovaModela[0]]->Calculate(state_t[0],ev,sigma,dsigmade);
 	// printf("sigma=%lf\n",*sigma);

     // printf ("TEST pre inita\n");
     // mapaModela[nizTipovaModela[1]]->Calculate(state_t[1],ev,sigma,dsigmade);
 	// printf("sigma=%lf\n",*sigma);

// // //  TESTIRANJE ZAVISNOSTI
    // // HuxleyCalculatorTestITER calcTestITER(&hp);
    // // long DIM = ceil((hp.xmax-hp.xmin)/hp.step);
    // // DIM = DIM + hp.m_leftng + hp.m_rightng;
    // // ublas::zero_vector<_TIP> _0(DIM+1);
    // // ublas::vector<_TIP> X(DIM+1),N(DIM+1);
    // // float force,forceNew,stiff;
// // /*    for (float V=)
    // // {
     // // N = _0;
    // // _TIP poc = hp.xmin - hp.m_leftng*hp.step;
    // // for(unsigned int i = 0; i <= DIM; i++) {
        // // X(i) = poc + hp.step * i;
    // // }

      // // _calculator->Calculate(state->X,state->N,(_TIP)V,t,(_TIP *)&force);
    // // }
  // // */
    // printf("CalculateV zavrsio\n");
    // char *nazivHvajla,*osn;
    // nazivHvajla=(char*)malloc(sizeof(char)*20);
    // FILE *fIter;
    // fIter=NULL;
    // for(float e=-0.017f;e<(-0.017f+0.001f*35);e+=0.001f)
    // {  // printf("%lf \n",(-0.017+0.001*i)*1074/0.01);
        // printf("Radim za brzinu %f \n",e*1074/0.01f);
        // float V=e*1074/0.01f;
// //        sprintf(nazivHvajla,"infoStiffV%.4f.dat",V);
        // sprintf(nazivHvajla,"Stifness_all_01",V);
        // printf("nazivHvajla %s \n",nazivHvajla);

        // fIter=fopen(nazivHvajla,"a+");
 // //       fprintf(fIter,"e\t V\t t\t f\t siffness\t iter\n");
        // N = _0;
       // _TIP poc = hp.xmin - hp.m_leftng*hp.step;
        // for(unsigned int i = 0; i <= DIM; i++) {
           // X(i) = poc + hp.step * i;
        // }
        // force=0;
        // stiff=0;
        // for(int i=0;i<200;i++){
         // calcTestITER.Calculate(X,N,(_TIP)V,0.001f,(_TIP *)&forceNew);
         // //printf("t=%lf prethodna_force=%lf iter=%d\n",0.001*i,force,calcTestITER.getBrojac());
         // fprintf(fIter,"%f\t%f\t%f\t%f\t%f\t%d\n",e,V,0.001f*i,force,stiff,calcTestITER.getBrojac());
         // stiff=calcTestITER.getStiffness();
         // force=forceNew;
        // }
        // fclose(fIter);
    // }
    // /*for(float e=0.017f;e>=(+0.017f-0.001f*5);e-=0.002f)
      // {  // printf("%lf \n",(-0.017+0.001*i)*1074/0.01);
          // printf("Radim za brzinu %f \n",e*1074/0.01f);
          // float V=e*1074/0.01f;
          // float VN=-V;
          // sprintf(nazivHvajla,"prelazV%.4f.dat",V);
          // printf("nazivHvajla %s \n",nazivHvajla);

          // if ((fIter=fopen(nazivHvajla,"w"))==NULL) printf("Nije otvorio\n");
          // fprintf(fIter,"e\t V\t t\t f_i-1\t iter\n");

          // N = _0;
         // _TIP poc = hp.xmin - hp.m_leftng*hp.step;
          // for(unsigned int i = 0; i <= DIM; i++) {
             // X(i) = poc + hp.step * i;
          // }
          // force=0;
            // printf("VN %f V %f \n",VN,V);
          // for(int i=0;i<20;i++)
          // {
            // calcTestITER.Calculate(X,N,(_TIP)V,0.001f,(_TIP *)&forceNew);
            // fprintf(fIter,"%f\t%f\t%f\t%f\t%d\n",e,V,0.01f,force,calcTestITER.getBrojac());
            // force=forceNew;
          // }
          // for(int i=0;i<10;i++)
          // {
            // calcTestITER.Calculate(X,N,(_TIP)2*VN,0.001f,(_TIP *)&forceNew);
            // fprintf(fIter,"%f\t%f\t%f\t%f\t%d\n",e,VN,0.01f,force,calcTestITER.getBrojac());
            // force=forceNew;
          // }
        // fclose(fIter);
    // }*/
// /*   for (int i=0;i<2;i++)
      // {
		// state_t[i]->init(&hp);
// //		mm[i]->Calculate(state_t[i],&e,&sigma,&dsigmade);
		// mapaModela[nizTipovaModela[i]]->Calculate(state_t[i],&e,&sigma,&dsigmade);
		// printf("sigma=%lf\n",sigma);
      // }
      // */
// } 
