#pragma once
#include <algorithm> 
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <math.h>

#include <boost/numeric/ublas/vector.hpp>
using namespace boost::numeric;
using namespace std;

ublas::vector<double> createHistogram(ublas::vector<double> x, ublas::vector<double> y, int division);