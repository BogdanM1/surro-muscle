#ifndef KERNELS_H_
#define KERNELS_H_ 2

#include <cuda.h>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>
#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/for_each.h>
#include <thrust/reduce.h>
#include <thrust/iterator/zip_iterator.h>



__global__ void fx_kernel(float _f1, float _g1, float _g2, float _h, float *d_X, float *d_N, float *d_FX, int n);
__global__ void xvdt_kernel(float _dt, float *X_curr, float *d_X, float *d_V, int n);
__global__ void nfdt_kernel(float _dt, float *N_curr, float *d_N, float *d_FX, int n);
__global__ void xnext_kernel(float _dt, float *X_next, float *d_X, float *V_curr, float *d_V, int n);
__global__ void vnext_kernel(float _dt, float *V_next, float *X_next, float *d_X, int n);
__global__ void nnext_kernel(float _dt, float *N_next, float* d_N, float *FX_next, float *d_FX, int n);
__global__ void xremash_kernel(float k, float *N_remash, float *N, float *N_1, int n);
__global__ void xremash_kernel_2_0(float k, float *N_remash, float *N, int n, int ir, int i);
__global__ void initX(float poc, float step, float *x, int n);
__global__ void minusSquareReduce_kernel(float *V_next, float *V_curr, float *out);
__global__ void forceReduce_kernel(float *N, float *X, float delta_x, float *out, int n);
__global__ void reduce_kernel(float *in, float *out);
__global__ void initConst(float *arr, float val, int n);



// static const char *_cudaGetErrorEnum(cublasStatus_t error)
// {
//     switch (error)
//     {
//         case CUBLAS_STATUS_SUCCESS:
//             return "CUBLAS_STATUS_SUCCESS";

//         case CUBLAS_STATUS_NOT_INITIALIZED:
//             return "CUBLAS_STATUS_NOT_INITIALIZED";

//         case CUBLAS_STATUS_ALLOC_FAILED:
//             return "CUBLAS_STATUS_ALLOC_FAILED";

//         case CUBLAS_STATUS_INVALID_VALUE:
//             return "CUBLAS_STATUS_INVALID_VALUE";

//         case CUBLAS_STATUS_ARCH_MISMATCH:
//             return "CUBLAS_STATUS_ARCH_MISMATCH";

//         case CUBLAS_STATUS_MAPPING_ERROR:
//             return "CUBLAS_STATUS_MAPPING_ERROR";

//         case CUBLAS_STATUS_EXECUTION_FAILED:
//             return "CUBLAS_STATUS_EXECUTION_FAILED";

//         case CUBLAS_STATUS_INTERNAL_ERROR:
//             return "CUBLAS_STATUS_INTERNAL_ERROR";
//     }

//     return "<unknown>";
// }


#endif
