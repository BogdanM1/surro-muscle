/*!
 * \file FileIO.cpp
 * File input/output common functions.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

#include "Stdafx.h"
#include "MyFile.h"
#include "MyString.h"

/*!
 * Skips rows in the ASCII file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in] RowCount
 * Number of rows to be skipped.
 * 
 * \returns
 * Zero if successful.
 */
UINT SkipRows(MyFile &File,UINT RowCount)
{
	MyString str;

	for(UINT i=0;i<RowCount;i++) File.ReadString(str);

	return(0);
}