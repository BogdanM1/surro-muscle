/*
 * Sequential.h
 *
 *  Created on: May 21, 2014
 *      Author: anakaplarevic
 */

#ifndef SEQUENTIAL_H_
#define SEQUENTIAL_H_

#include "QPointCalculator.h"

class Sequential: public QPointCalculator {
public:
	Sequential(FEM2D* makroModel,MMChunkCalculator* mikroModelChunk);
	virtual ~Sequential();

    void init(int number_of_q_points,MMType *mmtypes,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1);
	void calculate(double* e,double* sigma,double* dsigmade);
	void saveAndcontinue(int* flags);
};

#endif /* SEQUENTIAL_H_ */
