#define PAKF_CardH1 "C /1/ HEADING PAKF_Card (80A1)\n"
#define PAKF_CardV1 "C NASLOV\n"
#define PAKF_CardH2 "C /2/ FORMAT FOR INPUT DATA (free format)\n"
#define PAKF_CardV2 "C INDFOR\n"
#define PAKF_CardH3 "C /3/ BASIC DATA FOR THE PROBLEM (7I5)\n"
#define PAKF_CardV3 "C NP,NGET,NMATM,NSTAC,NPER,NPRINT,INDF,IPENAL,IALE,IBOUND\n"
#define PAKF_CardH4 "C /4/ BASIC DATA FOR THE PROBLEM (4I5,2F10.0,2I5)\n"
#define PAKF_CardV4 "C INTEB,INDSC,IFORM,MAXIT,EPSTA,EPSTR,NJRAP,MBAND\n"
#define PAKF_CardH5 "C /5/ DATA FOR RESTART (I5)\n"
#define PAKF_CardV5 "C IREST INIT\n"
#define PAKF_CardH6 "C /6/ DATA FOR TIME STEPS\n"
#define PAKF_CardV6 "C NDT(I),TIME(I)\n"
#define PAKF_CardH7 "C /7/ DATA FOR NODAL POINT DATA (I5,5I5,3F10.6)\n"
#define PAKF_CardV7 "C   N,    (ID(N,I),I=1,5)     CORD(1,N), CORD(2,N), CORD(3,N)\n"

//PAKF_Card /8/
#define PAKF_CardH8 "C /8/ ELEMENT GROUP DATA (4I5)\n"
#define PAKF_CardV8 "C NETIP,NET,INDAX,IZIP\n"
//Raca 2008-09-09
#define PAKF_CardV8_1 "C REYNOLDS NUMBER (F10.3)\n"

//2D Elements
#define PAKF_CardH8_1 "C /8-2/ DATA FOR 2/D ELEMENT\n"
#define PAKF_CardV8_1_a_1 "C a) PAKF_Card with data about 2D element\n"
#define PAKF_CardV8_1_a_2 "C NMAT2D,MAT2D,NP2DMX,PENALT (4I5)\n"
#define PAKF_CardV8_1_b_1 "C b) Data for each element in group (11I5,F10.0)\n"
#define PAKF_CardV8_1_b_2 "C NN,   (NEL(NN,I),I=1,4)\n"
#define PAKF_CardV8_1_c_1 "C c) Midnodes for 2D 9-node element (5I5)\n"
#define PAKF_CardV8_1_c_2 "C (NEL(NN,I),I=5,9)\n"


//3D Elements
#define PAKF_CardH8_1_3D "C /8-2/ DATA FOR 3/D ELEMENT\n"
#define PAKF_CardV8_1_a_1_3D "C a) PAKF_Card with data about 3D element\n"
#define PAKF_CardV8_1_a_2_3D "C NMAT2D,MAT2D,NP2DMX,PENALT (4I5)\n"
#define PAKF_CardV8_1_b_1_3D "C b) Data for each element in group (11I5,F10.0)\n"
#define PAKF_CardV8_1_b_2_3D "C NN,   (NEL(NN,I),I=1,8)\n"
#define PAKF_CardV8_1_c_1_3D "C c) Midnodes for 3D 9-node element (5I5)\n"
#define PAKF_CardV8_1_c_2_3D "C (NEL(NN,I),I=5,9)\n"

//PAKF_Card /9/
#define PAKF_CardH9 "C /9/ DATA FOR MATERIAL CONSTANTS\n"
#define PAKF_CardH9_1 "C /9-1/ DATA ABOUT FLUID DENSITY, INDICATOR FOR NON-NEWTONIAN FLUID (F10.2,I5)\n"
#define PAKF_CardV9_1 "C DENSIT, INDAMI\n"

#define PAKF_CardH9_2 "C /9-2/ DATA ABOUT CONDUCTION COEFFICIENT (F10.2)\n"
#define PAKF_CardV9_2 "C  CONDUC\n"
#define PAKF_CardH9_3 "C /9-3/ SPECIFIC HEAT AT CONSTANT PRESSURE (F10.2)\n"
#define PAKF_CardV9_3 "C   SPECH\n"
#define PAKF_CardH9_4_1 "C /9-4/ GRAVITY ACCELERATION IN X, Y AND Z DIRECTIONS, DYNAMIC VISCOSITY,\n"
#define PAKF_CardH9_4_2 "C THERMAL EXPANSION, REFERENCE TEMPERATURE (6D10.5)\n"
#define PAKF_CardV9_4 "C      GX,       GY,       GZ,      AMI,     BETA,     TETA0\n"

//PAKF_Card /10/
#define PAKF_CardH10 "C /10/ DATA FOR PRESCRIBED VALUES (2I5)\n"
#define PAKF_CardV10 "C NUMZAD, NUMST, NLOADTYPE\n"
#define PAKF_CardH10_1 "C /10-1/ PRESCRIBED VALUES AT NODES (3I5,F10.3)\n"
#define PAKF_CardV10_1 "C NNODE, INDPR, ITIMF, VALUE\n"

//PAKF_Card /11/
#define PAKF_CardH11 "C /11/ DATA ABOUT INITIAL VALUES (5F10.3)\n"
#define PAKF_CardV11 "C   UINIT,    VINIT,    WINIT,    PINIT,     TINIT\n"

//PAKF_Card /12/
#define PAKF_CardH12 "C /10/ DATA ABOUT TIME FUNCTIONS (2I5)\n"
#define PAKF_CardV12 "C NTABFT,MAXTFT\n"
#define PAKF_CardH12_1 "C /10-1/ GROUP OF PAKF_CardS WITH TABLES FOR TIME FUNCTIONS\n"
#define PAKF_CardV12_1_a_1 "C a) data about function in a table form (2I5)\n"
#define PAKF_CardV12_1_a_2 "C IBR,IMAX    (IMAX.LE.MAXTFT)\n"
#define PAKF_CardV12_1_b_1 "C b) values for argument - function (2F10.0)\n"
#define PAKF_CardV12_1_b_2 "C ((FN(I,IBR,J),I=1,2),J=1,IMAX)\n"

//PAKF_Card /13/
#define PAKF_CardH13 "C /13/ DATA ABOUT BOUNDARY CONDITIONS - SURFACE TRACTIONS\n"
#define PAKF_CardH13_1 "C E1.	n1	n2	fx,fy\n"
#define PAKF_CardH13_2 "C ELEMENT NODE1 NODE2 TIME FUNCT. VALUE1 VALUE2\n"

//PAKF_Card /13/

#define PAKF_CardH13_3D "C /13/ DATA ABOUT SURFACE TRACTION (6I5, 4F10.0)\n"
#define PAKF_CardV13_3D "C Elem.ID,Node1.ID,Node2.ID,Node3.ID,Node4.ID,TimeFunctionID,Node1Value,Node2Value,Node3Value,Node4Value\n"



//PAKF_Card /14/
#define PAKF_CardH16 "C /16/ FINAL PAKF_Card (A4)\n"
#define PAKF_CardV16 "STOP"


//Default values

//Card /2/
#define PAKF_INDFOR		2

//Card /3/
#define PAKF_NGET		0
#define PAKF_NSTAC		1
#define PAKF_NPER		1
#define PAKF_NPRINT		0
#define PAKF_INDF		1
#define PAKF_IPENAL		0
//Raca 2008-09-09
//#define	PAKF_IALE		0
//Vlada 2008-08-08
//#define	PAKF_IBOUND		1
//Raca 2008-10-01
//#define	PAKF_IBOUND		0


//Card /4/
#define PAKF_INTEB		1
#define PAKF_INDSC		0
#define PAKF_IFORM		0
#define PAKF_MAXIT		90
#define PAKF_EPSTA		0.
#define PAKF_EPSTR		1.e-2
#define PAKF_NJRAP		1
#define PAKF_METOD		2
#define PAKF_MBAND		0

//Card /5/
#define PAKF_IREST		1

//Card /6/
#define PAKF_NDT		1
#define PAKF_TIME		1.

//Card /7/
#define PAKF_IP			0
#define PAKF_IT			0

//Card /8/
#define PAKF_INDAX		0
#define PAKF_IZIP		0
//Card /8-2/
#define PAKF_NMAT2D		1
#define PAKF_MAT2D		1
#define PAKF_NP2DMX		9
#define PAKF_PENALTY	0.e+0

//Card /9/
#define PAKF_INDPR		1

#define PAKF_DENSIT		1.05e+0
#define PAKF_INDAMI		0

#define	PAKF_CONDUC		0.0e+0
#define PAKF_SPECH		0.0e+0

#define PAKF_GR_ACCELX	0.0
#define PAKF_GR_ACCELY	0.0
#define PAKF_GR_ACCELZ	0.0
#define PAKF_DIN_VISC	3.675e-2
#define PAKF_T_EXPANSION 0
#define PAKF_REF_TEMP	0
//Card /10/
#define PAKF_NUMST		0
//Card /11/
#define PAKF_UINIT		0.
#define PAKF_VINIT		0.
#define PAKF_WINIT		0.
#define PAKF_PINIT		0.
#define PAKF_TINIT		0.


//Errors

#define PAKF_NO_NODES		"There are no nodes."
#define PAKF_NO_GROUPS		"There are no groups of elements."
#define PAKF_NO_LOADS		"There are no loads."

//Maximalni broj funkcija
#define PAKF_MAX_TF		100

//Tolerancije
#define PAKF_VELOCITY_TOL		1.e-8