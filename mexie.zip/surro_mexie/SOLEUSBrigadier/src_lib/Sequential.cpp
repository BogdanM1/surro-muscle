/*
 * Sequential.cpp
 *
 *  Created on: May 21, 2014
 *      Author: anakaplarevic
 */

#include "Sequential.h"

Sequential::Sequential(FEM2D* macroModel,MMChunkCalculator* microModelChunk) {
		this->macroModel = macroModel;
		this->microModelChunk = microModelChunk;
}

Sequential::~Sequential() {
}

void Sequential::init(int number_of_q_points,MMType *mmtypes,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1){
		n_q_points_all = number_of_q_points;
        microModelChunk->init(number_of_q_points,mmtypes,m_E,m_ni,m_fi,m_f1);
}

void Sequential::calculate(double* e_original,double* sigma,double* dsigmade){

	  double* e;
	  int dim = Globals::getInstance()->dimOfSigmaVector;
	  e = (double*)malloc(sizeof(double)*dim*n_q_points_all);

		 for (int ii=0;ii<dim;ii++){
			 for (int jj=0;jj<n_q_points_all;jj++) {
				 	 *(e + jj*dim + ii)=*(e_original+ii*n_q_points_all+jj);
                     printf("e=%f \t", *(e + jj*dim + ii));
			 }
			 printf("\n");
		 }
	   microModelChunk->calculateChunk(e,sigma,dsigmade);

}

void Sequential::saveAndcontinue(int* flags){
		microModelChunk->setToNew(flags[1]);
}

