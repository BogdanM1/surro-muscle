/*
 * Math3d - The 3D Computer Graphics Math Library
 * Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
 * All rights reserved.
 *
 * This program is  free  software;  you can redistribute it and/or modify it
 * under the terms of the  GNU Lesser General Public License  as published by 
 * the  Free Software Foundation;  either version 2.1 of the License,  or (at 
 * your option) any later version.
 *
 * This  program  is  distributed in  the  hope that it will  be useful,  but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
 * License for more details.
 *
 * You should  have received  a copy of the GNU Lesser General Public License
 * along with  this program;  if not, write to the  Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: mquat.cpp,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
 */
#include "Stdafx.h"
#define _MATH3D_EXPORT
#include "mquat.h"
#include "m2d.h"
#include "m3d.h"
#include "m4x4.h"
#include <math.h>
//#include <iostream>


/*!
 *
 */
Math3d::MQuat::MQuat(const MQuat& q)
{
  x=q.x;
  y=q.y;
  z=q.z;
  w=q.w;
}


/*!
 *
 */
Math3d::MQuat::MQuat(double x, double y, double z, double w) 
{
  x=x; 
  y=y; 
  z=z; 
  w=w;
}


/*!
 *  
 */
Math3d::MQuat::MQuat(const float q[4])
{
  x=q[0]; 
  y=q[1]; 
  z=q[2]; 
  w=q[3];
}


/*!
 *  
 */
Math3d::MQuat::MQuat(const double q[4])
{
  x=q[0]; 
  y=q[1]; 
  z=q[2]; 
  w=q[3];
}


/*!
 *
 */
Math3d::MQuat::MQuat(const M3d& axis, double angle)
{
  set(axis,angle);
}


/*!
 *
 */
Math3d::MQuat::MQuat(const M4x4& m)
{
  set(m);
}


/*!
 *
 */
const Math3d::MQuat&
Math3d::MQuat::operator=(const MQuat& q)
{
  x=q.x;
  y=q.y;
  z=q.z;
  w=q.w;
  return(*this);
}


/*!
 *
 */
void
Math3d::MQuat::zero()
{
  x=y=z=w=0.0;
}


/*!
 *
 */
void
Math3d::MQuat::identity()
{
  x=y=z=0.0;
  w=1.0;
}


/*!
 * Constructuin by standard matrix - quaternion conversion.
 * The matrix is supposed to have its last column and row equal 
 * to (0,0,0,1) otherwise, the result is undefined.
 */
void
Math3d::MQuat::set(double x, double y, double z, double w) 
{
  x=x; 
  y=y; 
  z=z; 
  w=w;
}


/*!
 *
 */
void
Math3d::MQuat::set(const M3d& axis, double angle)
{
  double omega,s;
  double l;

  l=sqrt(axis.x*axis.x + axis.y*axis.y + axis.z*axis.z);
  if (l<EPSILON) {
    x=y=z=0.0f;
    w=1.0f;
    return;
  }
  omega=-0.5f*angle;
  s=sin(omega)/l;
  x=s*axis.x;
  y=s*axis.y;
  z=s*axis.z;
  w=cos(omega);
}


/*!
 * Standard matrix - quaternion conversion.
 * The matrix is supposed to have its last column and row equal 
 * to (0,0,0,1) otherwise, the result is undefined.
 */
void
Math3d::MQuat::set(const M4x4& M)
{
  double tr,s;
  int i,j,k;
  static int nxt[3] = {1,2,0};

  tr = M.d_m[0][0] + M.d_m[1][1] + M.d_m[2][2];
  if (tr > 0.0) {
    s = sqrt(tr + 1.0);
    w = s * 0.5;
    s = 0.5 / s;
    x = (M.d_m[1][2] - M.d_m[2][1]) * s;
    y = (M.d_m[2][0] - M.d_m[0][2]) * s;
    z = (M.d_m[0][1] - M.d_m[1][0]) * s;
  }
  else {
    i = 0;
    if (M.d_m[1][1] > M.d_m[0][0]) i = 1;
    if (M.d_m[2][2] > M.d_m[i][i]) i = 2;
    j = nxt[i];
    k = nxt[j];
    s = sqrt((M.d_m[i][i]-(M.d_m[j][j]+M.d_m[k][k]))+1.0);
    (&x)[i] = s * 0.5f;
    if (fabs(s)<EPSILON) {
      identity();
    }
    else {
      s = 0.5f /s;
      w = (M.d_m[j][k] - M.d_m[k][j]) * s;
      (&x)[j] = (M.d_m[i][j] + M.d_m[j][i]) * s;
      (&x)[k] = (M.d_m[i][k] + M.d_m[k][i]) * s;
    }
  }
}


/*!
 *
 */
void 
Math3d::MQuat::copy(const MQuat& q)
{
  x=q.x; 
  y=q.y; 
  z=q.z; 
  w=q.w;
}


/*!
 *
 */
double&
Math3d::MQuat::get(int i)
{
  ASSERT(i>=0 && i<4);
  return((&x)[i]);
}


/*!
 *
 */
Math3d::MQuat
Math3d::MQuat::operator*(const MQuat& q)  const
{
  return(MQuat(
    w*q.x + x*q.w + y*q.z - z*q.y,
    w*q.y + y*q.w + z*q.x - x*q.z,
    w*q.z + z*q.w + x*q.y - y*q.x,
    w*q.w - x*q.x - y*q.y - z*q.z
  ));
}


/*!
 *
 */
const Math3d::MQuat&
Math3d::MQuat::operator*=(const MQuat& q)
{
  double px,py,pz,pw;

  px=x;
  py=y;
  pz=z;
  pw=w;
  x=pw*q.x + px*q.w + py*q.z - pz*q.y;
  y=pw*q.y + py*q.w + pz*q.x - px*q.z;
  z=pw*q.z + pz*q.w + px*q.y - py*q.x;
  w=pw*q.w - px*q.x - py*q.y - pz*q.z;
  return(*this);
}


/*!
 *
 */
Math3d::MQuat
Math3d::MQuat::operator*(double k)  const
{
  return(MQuat(
    x*k,
    y*k,
    z*k,
    w*k
  ));
}


/*!
 *
 */
const Math3d::MQuat&
Math3d::MQuat::operator*=(double k)
{
  x*=k;
  y*=k;
  z*=k;
  w*=k;
  return(*this);
}


/*!
 *
 */
void
Math3d::MQuat::neg()
{
  x=-x;
  y=-y;
  z=-z;
  w=-w;
}


/*!
 *
 */
void
Math3d::MQuat::abs()
{
  x=fabs(x);
  y=fabs(y);
  z=fabs(z);
  w=fabs(w);
}


/*!
 *
 */
void
Math3d::MQuat::cnj()
{
  x=-x;
  y=-y;
  z=-z;
}


/*!
 *
 */
void
Math3d::MQuat::mul(const MQuat& p, const MQuat& q)
{
  x=p.w*q.x + p.x*q.w + p.y*q.z - p.z*q.y;
  y=p.w*q.y + p.y*q.w + p.z*q.x - p.x*q.z;
  z=p.w*q.z + p.z*q.w + p.x*q.y - p.y*q.x;
  w=p.w*q.w - p.x*q.x - p.y*q.y - p.z*q.z;
}


/*!
 *
 */
void
Math3d::MQuat::scalar(double k)
{
  x*=k;
  y*=k;
  z*=k;
  w*=k;
}


/*!
 *
 */
void
Math3d::MQuat::normalize()
{
  double l,c;

  l=sqrt(x*x + y*y + z*z + w*w);
  if (fabs(l)<EPSILON) {
    w=1.0f; 
    x=y=z=0.0f;
  }
  else {  
    c=1.0f/l;
    x*=c;
    y*=c;
    z*=c;
    w*=c;
  }
}


/*!
 *
 */
void
Math3d::MQuat::inv()
{
  double l,c;

  l=sqrt(x*x + y*y + z*z + w*w);
  if (fabs(l)<EPSILON) {
    x=y=z=0.0f;
    w=1.0f;
  }
  else {
    c=1.0f/l;
    x*=-c;
    y*=-c;
    z*=-c;
    w*=c;
  }
}


/*!
 *
 */
void
Math3d::MQuat::ln()
{
  double om,s,c;

  s=sqrt(x*x + y*y + z*z);
  om=atan2(s,w);
  if (fabs(s)<EPSILON) {
    c=0.0f;
  }
  else {
    c=om/s;
  }
  x=x*c;
  y=y*c;
  z=z*c;
  w=0.0f;
}


/*!
 *
 */
void
Math3d::MQuat::lnDif(const MQuat& p, const MQuat& q)
{
  MQuat invp;

  invp=p;
  invp.inv();
  mul(invp,q);
  ln();
}


/*!
 *
 */
void
Math3d::MQuat::exp()
{
  double om,sinom;

  om=sqrt(x*x + y*y + z*z);
  if (fabs(om)<EPSILON) {
    sinom=1.0f;
  }
  else {
    sinom=sin(om)/om;
  }
  x*=sinom;
  y*=sinom;
  z*=sinom;
  w=cos(om);
}


/*!
 *
 */
void
Math3d::MQuat::slerp(const MQuat& p, const MQuat& q, double t)
{
  double l;
  double om,sinom;
  double sp,sq;
  MQuat qq;

  l=p.x*q.x + p.y*q.y + p.z*q.z + p.w*q.w;
  if ((1.0+l)>EPSILON) {
    if (fabs(l)>1.0) l/=fabs(l);
    om=acos(l);
    sinom=sin(om);
    if (fabs(sinom)>EPSILON) {
      sp=sin((1.0f-t)*om)/sinom;
      sq=sin(t*om)/sinom;
    }
    else {
      sp=1.0f-t;
      sq=t;
    }
    x=sp*p.x + sq*q.x;
    y=sp*p.y + sq*q.y;
    z=sp*p.z + sq*q.z;
    w=sp*p.w + sq*q.w;
  }
  else {
    qq.x=-p.y;
    qq.y=p.x;
    qq.z=-p.w;
    qq.w=p.z;
    sp=sin((1.0-t)*HALFPI);
    sq=sin(t*HALFPI);
    x=sp*p.x + sq*qq.x;
    y=sp*p.y + sq*qq.y;
    z=sp*p.z + sq*qq.z;
    w=sp*p.w + sq*qq.w;
  }
}


/*!
 *
 */
void
Math3d::MQuat::squad(const MQuat& p, const MQuat& Tp, const MQuat& Tq, const MQuat& q, double t)
{
  MQuat pq,ab;

  pq.slerp(p,q,t);
  ab.slerp(Tp,Tq,t);
  slerp(pq,ab,2*t*(1-t));
}


/*!
 *
 */
void
Math3d::MQuat::tangent(const MQuat& qp, const MQuat& q, const MQuat& qn)
{
  MQuat invq, dn,dp,x;
  int i;

  invq=q;
  invq.inv();

  dn.lnDif(q,qn);
  dp.lnDif(q,qp);
  for (i=0; i<4; i++) {
    x[i]=-1.0/4.0*(dn[i]+dp[i]);
  }
  x.exp();
  mul(q,x);
}


static double
project_to_sphere(double r, double x, double y)
{
  double d, t, z;

  d = sqrt(x*x + y*y);
  if (d < r * 0.70710678118654752440) {    
    // Inside sphere 
    z = sqrt(r*r - d*d);
  } else { 
    // On hyperbola
    t = r / 1.41421356237309504880;
    z = t*t / d;
  }
  return(z);
}


/*!
 * Implementation of a virtual trackball.
 * Implemented by Gavin Bell, lots of ideas from Thant Tessman and
 *   the August '88 issue of Siggraph's "Computer Graphics," pp. 121-129.
 *
 * Simulate a track-ball.  Project the points onto the virtual
 * trackball, then figure out the axis of rotation, which is the cross
 * product of P1 P2 and O P1 (O is the center of the ball, 0,0,0)
 * Note:  This is a deformed trackball-- is a trackball in the center,
 * but is deformed into a hyperbolic sheet of rotation away from the
 * center.  This particular function was chosen after trying out
 * several variations.
 *
 * It is assumed that the arguments to this routine are in the range
 * (-1.0 ... 1.0)
 */
void
Math3d::MQuat::trackball(const M2d& p, const M2d q)
{
  M3d a;           // Axis of rotation
  double phi;      // how much to rotate about axis
  M3d p1, p2, d;
  double t;

  if ((fabs(p[0]-q[0])<EPSILON) && (fabs(p[1]-q[1])<EPSILON)) {
    //Zero rotation
    identity();
    return;
  }

  // First, figure out z-coordinates for projection of P1 and P2 to
  // deformed sphere
  p1.set(p[0], project_to_sphere(0.8,p[0],p[1]), p[1]);
  p2.set(q[0], project_to_sphere(0.8,q[0],q[1]), q[1]);
  
  // Now, we want the cross product of P1 and P2
  a.cross(p2,p1);
  
  // Figure out how much to rotate around that axis.
  d.sub(p1,p2);
  t = d.length() / (2.0*0.8);
  
  // Avoid problems with out-of-control values...
  if (t > 1.0) t = 1.0;
  if (t < -1.0) t = -1.0;
  phi = 2.0 * asin(t);

  set(a,phi);
}


/*!
 *
 */
double
Math3d::MQuat::get(int i) const
{
  ASSERT(i>=0 && i<4);
  return((&x)[i]);
}


/*!
 *
 */
bool
Math3d::MQuat::operator==(const MQuat& q) const
{
  return(cmp(q));
}


/*!
 *
 */
bool
Math3d::MQuat::operator!=(const MQuat& q) const
{
  return(!cmp(q));
}


/*!
 *
 */
double
Math3d::MQuat::dot(const MQuat& q) const
{
  return(x*q.x + y*q.y + z*q.z + w*q.w);
}


/*!
 *
 */
bool
Math3d::MQuat::cmp(const MQuat& q, double epsilon) const
{
  return(
    (fabs(x-q.x)<epsilon) &&
    (fabs(y-q.y)<epsilon) &&
    (fabs(z-q.z)<epsilon) &&
    (fabs(w-q.w)<epsilon)
  );
}


/*!
 *
 */
double
Math3d::MQuat::squared() const
{
  return(x*x + y*y + z*z + w*w);
}


/*!
 *
 */
double
Math3d::MQuat::length() const
{
  return(sqrt(x*x + y*y + z*z + w*w));
}


/*!
 *  
 */
/*std::ostream& 
Math3d::operator << (std::ostream& co, const MQuat& q)
{
  co << "(" << q[0] << ", " << q[1] << ", " << q[2] << "," << q[3] << ")";
  return co;
}
*/


