// PAKTExp.cpp: Functions for export to PAK's DAT file.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "FEModelData.h"
#include "PAKFExp.h"
#include "BlockIDs.h"
#include "PakExpOption.h"
#include "math.h"
#include "StringAdvanced.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


UINT CModelData::ExportPAK_F(MyFile& file,CPakExpOption *peo)
{

	MyString str;
	MyStringAdvanced strAdvanced;
	UINT uNGELEM=1;
	UINT i;
	long lGeneralDataPos;


	if((m_NodArray.GetSize())<=0)
	{
		//AfxMessageBox(PAKF_NO_NODES);
		printf(PAKF_NO_NODES);
		return(0);	
	};
/*	
	if((uNGELEM=m_PropArray.GetSize())<=0)
	{
		AfxMessageBox(NO_GROUPS);
		return(0);	
	};
*/
	
//	Card /1/
	file.WriteString(PAKF_CardH1);
	file.WriteString(PAKF_CardV1);
	file.WriteString(m_PakGeneral.GetTitle()+"\n");

//PAKF_Card /2/
	file.WriteString(PAKF_CardH2);
	file.WriteString(PAKF_CardV2);
	str.Format("%5u\n",PAKF_INDFOR);
	file.WriteString(str);

//PAKF_Card /3/
 	UINT nNP = m_NodArray.GetSize();
	UINT nNGET = m_PropArray.GetSize();
	UINT nNMATM = m_MaterialsArray.GetSize();
	// BEC 2004 12 16 BUDZENJE ZA BROJ MATERIJALA
	nNMATM = 1;
	UINT nNTP = m_PakGeneral.GetNumOfPeriods();
	UINT nStac = ((m_PakGeneral.m_bDynamic == TRUE) ? 0:1);
	
	file.WriteString(PAKF_CardH3);
	file.WriteString(PAKF_CardV3);

	lGeneralDataPos=file.GetPosition();
	//Vlada 2008-08-08
	//str.Format("%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u\n", nNP, PAKF_NGET, nNMATM, nStac, nNTP, PAKF_NPRINT, m_PakGeneral.m_iFieldType, PAKF_IPENAL, PAKF_IALE, PAKF_IBOUND);
	str.Format("%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u\n", nNP, PAKF_NGET, nNMATM, nStac, nNTP, PAKF_NPRINT, m_PakGeneral.m_iFieldType, m_PakGeneral.m_iAnalysisType, m_PakGeneral.m_bIale, m_PakGeneral.m_bIBound);
	file.WriteString(str);

//PAKF_Card /4/
	file.WriteString(PAKF_CardH4);
	file.WriteString(PAKF_CardV4);
	//Vlada
	//str.Format("%5u%5u%5u%5u%10.4f%10.2e%5u%5u\n", PAKF_INTEB, PAKF_INDSC, PAKF_IFORM, PAKF_MAXIT, PAKF_EPSTA, PAKF_EPSTR, PAKF_METOD, PAKF_MBAND);
	str.Format("%5u%5u%5u%5u%10.4f%10.2e%5u%5u\n", PAKF_INTEB, PAKF_INDSC, PAKF_IFORM, PAKF_MAXIT, PAKF_EPSTA, PAKF_EPSTR, m_PakGeneral.m_IterMethod.m_iIterMethod, PAKF_MBAND);
	file.WriteString(str);

//PAKF_Card /5/
 	file.WriteString(PAKF_CardH5);
	file.WriteString(PAKF_CardV5);
	str.Format("%5u%5u\n",PAKF_IREST, m_PakGeneral.m_bReadInitFile);
	file.WriteString(str);

//PAKF_Card /6/
	file.WriteString(PAKF_CardH6);
	file.WriteString(PAKF_CardV6);
	for(i=1;i<=(UINT)m_PakGeneral.GetNumOfPeriods();i++)
	{
		str.Format("%5u%10.2e\n",m_PakGeneral.GetNumSteps(i-1),m_PakGeneral.GetStep(i-1));
		file.WriteString(str);
	}

//PAKF_Card /7/
// 	file.WriteString(PAKF_CardH7);
//	file.WriteString(PAKF_CardV7);
	ExportPAKF_Nodes(file);

//PAKF_Card /8/
	ExportPAKF_Elements(file,&uNGELEM,peo);
//	ExportPAKF_MatModels(file);

//PAKF_Card /9/
	file.WriteString(PAKF_CardH9);
	file.WriteString(PAKF_CardH9_1);
	file.WriteString(PAKF_CardV9_1);
	//Vlada 2008-08-08
	//str.Format("%10.1f%5d\n", m_MaterialsArray[0].m_dDensity, PAKF_INDAMI);
	UINT nFluidMaterialIndex;
	UINT nMaterialCount = (UINT) m_MaterialsArray.GetSize();
	for(i = 0; i < nMaterialCount; i++) 
	{
		if(m_MaterialsArray[i].m_uSubType == HMaterial::ST_PAK_FLUID)
		{
			nFluidMaterialIndex = i;
			break;
		}
	}

	str.Format("%10.5f%5d\n", m_MaterialsArray[nFluidMaterialIndex].m_dDensity, PAKF_INDAMI);
	file.WriteString(str);
	
	if(m_PakGeneral.m_iFieldType == 2 || m_PakGeneral.m_iFieldType == 0)// Only Heat. Mileta intervention
	{
		file.WriteString(PAKF_CardH9_2);
		file.WriteString(PAKF_CardV9_2);
		strAdvanced.Format("%10.4.2e\n", m_MaterialsArray[nFluidMaterialIndex].m_dK[0]);
		file.WriteString(strAdvanced);
		
		file.WriteString(PAKF_CardH9_3);
		file.WriteString(PAKF_CardV9_3);
		strAdvanced.Format("%10.4.2e\n", m_MaterialsArray[nFluidMaterialIndex].m_dThermal_cap);
		file.WriteString(strAdvanced);
	}

	file.WriteString(PAKF_CardH9_4_1);
	file.WriteString(PAKF_CardH9_4_2);
	file.WriteString(PAKF_CardV9_4);
	str.Format("%10.1f%10.1f%10.1f%10.5f\n", PAKF_GR_ACCELX, PAKF_GR_ACCELY, PAKF_GR_ACCELZ,m_MaterialsArray[0].m_dAlpha[0]);
	file.WriteString(str);

	ExportPAKF_PrescVals(file);

//PAKF_Card /11/
 	file.WriteString(PAKF_CardH11);
	file.WriteString(PAKF_CardV11);
	str.Format("%10.6f%10.6f%10.6f%10.6f%10.6f\n",PAKF_UINIT, PAKF_VINIT, PAKF_WINIT, PAKF_PINIT, PAKF_TINIT);
	file.WriteString(str);

//PAKF_Card /12/
	MyMap<UINT,UINT,UINT,UINT> FunctionMap;
	ExportPAK_TimeFunctions(file,FunctionMap);

	//Vlada 2008-08-08
	ExportPAKF_SurfaceTraction(file);
	
//PAKF_Card /14/	
	file.WriteString(PAKF_CardH13);
	file.WriteString(PAKF_CardH13_1);
	file.WriteString(PAKF_CardH13_2);

	ExportPAKF_SurrTract(file);
//PAKF_Card /14/
 	file.WriteString(PAKF_CardH16);
	file.WriteString(PAKF_CardV16);

//Upisivanje naknadno

	file.Seek(lGeneralDataPos,SEEK_SET);
	//Vlada 2008-08-08
	//str.Format("%5u%5u%5u%5u%5u%5u%5u%5u",m_NodArray.GetSize(), PAKF_NGET,m_MaterialsArray.GetSize(),nStac, nNTP, PAKF_NPRINT, m_PakGeneral.m_iFieldType, PAKF_IPENAL);
	str.Format("%5u%5u%5u%5u%5u%5u%5u%5u",m_NodArray.GetSize(), PAKF_NGET,m_MaterialsArray.GetSize(),nStac, nNTP, PAKF_NPRINT, m_PakGeneral.m_iFieldType, m_PakGeneral.m_iAnalysisType);

	file.WriteString(str);
	file.Seek(0,SEEK_END);

	return(-1);
}

UINT CModelData::ExportPAKF_Elements(MyFile& file, UINT *uNGELEM, CPakExpOption *peo)
{
	MyString str;
	UINT nPropID;
	//UINT uNMODM,uMatIID;
	MyArray <UINT,UINT&> ElNum;
	MyMap<UINT,UINT,UINT,UINT> PropIndex; // relation between Property ID and it's position in ElNum;
	HElement el;

	//FEMAT Topology
	//Value          {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
	  UINT FEM_Top[]={2,0,3,6,4,8,4,6,8,1,10,15,20, 0, 0, 0};

	  
//	for(i=0;i<(UINT)m_PropArray.GetSize();i++)	//Loop by properties (group of elements)
//	{
		nPropID = m_ElArray[0].m_uPropID;
//MyMappedArray		m_nPropIndex.Lookup(nPropID, nPropIndex);

//MyMappedArray		HProperties &Property=m_PropArray[nPropIndex];
		HProperties &Property=m_PropArray.Get(nPropID);
//		mms=MatMap[pr.m_uMatIID];	//Struktura cuva materijalni model i materijal
		switch (Property.m_Type)
		{
//****************************************************************************
//****************************** 2D Elementi *********************************
//****************************************************************************
		case HProperties::PT_SHEAR_LIN:case HProperties::PT_SHEAR_PAR:
		case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:case HProperties::PT_MEMBRANE_PAR_9:
		case HProperties::PT_BENDING_LIN:case HProperties::PT_BENDING_PAR:
		case HProperties::PT_PLATE_LIN:case HProperties::PT_PLATE_PAR:
		case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR:
		case HProperties::PT_LAMINATE_LIN:case HProperties::PT_LAMINATE_PAR:
		case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR:
			{
				ExportPAKF_2DElements(file);
			}break;
//****************************************************************************
//****************************** 3D Elementi *********************************
//****************************************************************************
		case HProperties::PT_3D_LIN:case HProperties::PT_3D_LIN_9:
		case HProperties::PT_3D_PAR:case HProperties::PT_3D_PAR_21:
			{
				ExportPAKF_3DElements(file);
			}break;
		}

	return(-1);
}

UINT CModelData::ExportPAKF_2DElements(MyFile& file)
{
	UINT uNETIP, i;
	MyString str;
//	MyArray<UINT, UINT> ElementIndexes;
	UINT nConductionIndicator;
	UINT nPropID;

	if(m_ElArray[0].m_uTopology == FETO_QUAD4 || m_ElArray[0].m_uTopology == FETO_QUAD8 ||
		m_ElArray[0].m_uTopology == FETO_TRI3 || m_ElArray[0].m_uTopology == FETO_TRI6 ||
		m_ElArray[0].m_uTopology == FETO_QUAD9) uNETIP = 2;
	else uNETIP=3;

	file.WriteString(PAKF_CardH8);
	file.WriteString(PAKF_CardV8);
	//Vlada 2008-08-08
	//str.Format("%5u%5u%5u\n", uNETIP, m_ElArray.GetSize(), PAKF_INDAX);
	HProperties &Prop = m_PropArray.Get(m_ElArray[0].m_uPropID);
	//str.Format("%5u%5u%5u\n", uNETIP, m_ElArray.GetSize(), (Prop.m_Type == HProperties::PT_AXISYM_LIN)?1:0);
	//Raca 2008-09-09
	if(Prop.m_uFlag[1] == 6)
	{
		str.Format("%5u%5u%5u%5u\n", uNETIP, m_ElArray.GetSize(), (Prop.m_Type == HProperties::PT_AXISYM_LIN)?1:0, Prop.m_uFlag[1]);
	}
	else
	{
		str.Format("%5u%5u%5u\n", uNETIP, m_ElArray.GetSize(), (Prop.m_Type == HProperties::PT_AXISYM_LIN)?1:0);
	}
	file.WriteString(str);
	if(Prop.m_uFlag[1] == 6)
	{
		file.WriteString(PAKF_CardV8_1);
		str.Format("%10.3f\n", m_MaterialsArray[0].m_dK[0]);
		file.WriteString(str);
	}


 	file.WriteString(PAKF_CardH8_1);
	file.WriteString(PAKF_CardV8_1_a_1);
	file.WriteString(PAKF_CardV8_1_a_2);
	//Vlada 2008-08-08
	//str.Format("%5u%5u%5u%10.2e\n", PAKF_NMAT2D, PAKF_MAT2D, (m_ElArray[0].m_uTopology == FETO_QUAD9)?9:4 , PAKF_PENALTY);
	double dPenalty = (m_PakGeneral.m_iAnalysisType == 1? 1.0e+9 : 0.0);
	str.Format("%5u%5u%5u%10.2e\n", PAKF_NMAT2D, PAKF_MAT2D, (m_ElArray[0].m_uTopology == FETO_QUAD9)?9:4 , dPenalty);
	file.WriteString(str);

	file.WriteString(PAKF_CardV8_1_b_1);
	file.WriteString(PAKF_CardV8_1_b_2);
	//Vlada 2008-08-08
	//if(PAKF_NP2DMX == 9)
	if(m_ElArray[0].m_uTopology == FETO_QUAD9)
	{
		file.WriteString(PAKF_CardV8_1_c_1);
		file.WriteString(PAKF_CardV8_1_c_2);
	}
	
	for( i = 0; i < (UINT)m_ElArray.GetSize(); i++)
	{
		nPropID = m_ElArray[i].m_uPropID;
		HProperties &ElemProperty = m_PropArray.Get(nPropID);

		if(m_ElArray[0].m_uTopology == FETO_QUAD9)
		{
			str.Format("%5u%5u%5u%5u%5u\n%5u%5u%5u%5u%5u%5u\n",m_ElArray[i].m_nID,
			m_ElArray[i].m_uNode[0],m_ElArray[i].m_uNode[1],m_ElArray[i].m_uNode[2],m_ElArray[i].m_uNode[3],
			m_ElArray[i].m_uNode[4],m_ElArray[i].m_uNode[5],m_ElArray[i].m_uNode[6],m_ElArray[i].m_uNode[7],m_ElArray[i].m_uNode[8],1);
			file.WriteString(str);
		}
		else
		{
			if(ElemProperty.m_uFlag[0] == 0) 
			{
				str.Format("%5u%5u%5u%5u%5u\n",m_ElArray[i].m_nID,
				m_ElArray[i].m_uNode[0],m_ElArray[i].m_uNode[1],m_ElArray[i].m_uNode[2],m_ElArray[i].m_uNode[3]);
				file.WriteString(str);
			}
			else if(ElemProperty.m_uFlag[0] == 1) //Simple Vein Vlada 2007-09-29 Definisanje valvula
			{
				nConductionIndicator = ElemProperty.m_uLayer;
			
				str.Format("%5u%5u%5u%5u%5u%5u\n",m_ElArray[i].m_nID,
					m_ElArray[i].m_uNode[0], m_ElArray[i].m_uNode[1], m_ElArray[i].m_uNode[2], m_ElArray[i].m_uNode[3], nConductionIndicator);
				file.WriteString(str);
			}
		}
	}


	return(-1);
}

UINT CModelData::ExportPAKF_3DElements(MyFile& file)
{
	UINT uNETIP, i;
	MyString str;
//	MyArray<UINT, UINT> ElementIndexes;
	UINT node_order[21]={6,7,4,5,2,3,0,1,18,19,16,17,10,11,8,9,14,15,12,13,20};

	UINT nConductionIndicator;
	UINT nPropID;
	UINT surface_nodes_3d[6][8]={	{0,3,2,1,11,10,9,8},
								{4,5,6,7,16,17,18,19},
								{0,1,5,4,8,13,16,12},
								{1,2,6,5,9,14,17,13},
								{2,3,7,6,10,15,18,14},
								{3,0,4,7,11,12,19,15}};

	if(m_ElArray[0].m_uTopology == FETO_BRICK8 || m_ElArray[0].m_uTopology == FETO_BRICK9 ||
		m_ElArray[0].m_uTopology == FETO_BRICK20 || m_ElArray[0].m_uTopology == FETO_BRICK21)
		uNETIP=3;

	file.WriteString(PAKF_CardH8);
	file.WriteString(PAKF_CardV8);
	str.Format("%5u%5u%5u\n", uNETIP, m_ElArray.GetSize(), PAKF_INDAX);
	file.WriteString(str);

 	file.WriteString(PAKF_CardH8_1);
	file.WriteString(PAKF_CardV8_1_a_1);
	file.WriteString(PAKF_CardV8_1_a_2);
	//Vlada 2008-08-08
	//str.Format("%5u%5u%5u%10.2e\n", PAKF_NMAT2D, PAKF_MAT2D, 21, PAKF_PENALTY);
	double dPenalty = (m_PakGeneral.m_iAnalysisType == 1? 1.0e+9 : 0.0);
	str.Format("%5u%5u%5u%10.2e\n", PAKF_NMAT2D, PAKF_MAT2D, (m_ElArray[0].m_uTopology == FETO_BRICK21)?21:8, dPenalty);


	file.WriteString(str);
	file.WriteString(PAKF_CardV8_1_b_1);
	file.WriteString(PAKF_CardV8_1_b_2);
	if(PAKF_NP2DMX == 9)
	{
		file.WriteString(PAKF_CardV8_1_c_1);
		file.WriteString(PAKF_CardV8_1_c_2);
	}
	
	for( i = 0; i < (UINT)m_ElArray.GetSize(); i++)
	{
		HElement &el = m_ElArray.ElementAt(i);
		nPropID = m_ElArray[i].m_uPropID;

		nConductionIndicator = 1;
//MyMappedArray		nConductionIndicator = m_PropArray[nPropIndex].m_uLayer;
		//nConductionIndicator = m_PropArray.Get(nPropID).m_uLayer;

		if(m_ElArray[0].m_uTopology == FETO_BRICK21)
		{
			str.Format("%5u%5u%5u%5u%5u%5u%5u%5u%5u\n",m_ElArray[i].m_nID,m_ElArray[i].m_uNode[4],m_ElArray[i].m_uNode[5],m_ElArray[i].m_uNode[6],m_ElArray[i].m_uNode[7],
			m_ElArray[i].m_uNode[0],m_ElArray[i].m_uNode[1],m_ElArray[i].m_uNode[2],m_ElArray[i].m_uNode[3]);
			file.WriteString(str);
			str.Format("%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u%5u\n",m_ElArray[i].m_uNode[16],m_ElArray[i].m_uNode[17],m_ElArray[i].m_uNode[18],m_ElArray[i].m_uNode[19],m_ElArray[i].m_uNode[8],
			m_ElArray[i].m_uNode[9],m_ElArray[i].m_uNode[10],m_ElArray[i].m_uNode[11],m_ElArray[i].m_uNode[12],m_ElArray[i].m_uNode[13],m_ElArray[i].m_uNode[14],m_ElArray[i].m_uNode[15],m_ElArray[i].m_uNode[20]);
			file.WriteString(str);
		}
		else
		{
			str.Format("%5u", el.m_nID);
			file.WriteString(str);
			for(UINT k = 0; k < 8; k++) 
			{
				str.Format("%5u",el.m_uNode[node_order[k]]);
				file.WriteString(str);
			}
			str.Format("%5u",1);
			file.WriteString(str);
			file.WriteString("\n");
		}
	}


	return(-1);
}
UINT CModelData::ExportPAKF_Nodes(MyFile& file)
{

	MyString str;
	UINT i,ci;
	HNodes nn;
	int iIU,iIV,iIW,iIP,iIT;
	//BEC 2004 12 15
	UINT PAKF_FICA = 1;

//Card /7/
 	file.WriteString(PAKF_CardH7);
	file.WriteString(PAKF_CardV7);
	for(i=0;i<(UINT)m_NodArray.GetSize();i++)
	{
		nn=m_NodArray[i];
		iIU=nn.m_bPermbc[0];
		iIV=nn.m_bPermbc[1];
		iIW=nn.m_bPermbc[2];
		iIP=nn.m_bPermbc[3];//mileta
		iIT=nn.m_bPermbc[4];//mileta
		if(m_LoadArray.GetSize()>0)
		{
			for(ci=0;ci<(UINT)m_LoadArray[0].m_StructLoads.GetSize();ci++)
			{
				if(m_LoadArray[0].m_StructLoads[ci].m_uLoadID == nn.m_nID && m_LoadArray[0].m_StructLoads[ci].m_uLoadtype==StructLoad::LT_NODAL_VELOCITY
					&& m_LoadArray[0].m_StructLoads[ci].m_uSl_funcID>0)
				{
				 if(fabs(m_LoadArray[0].m_StructLoads[ci].m_dValue[0])>PAKF_VELOCITY_TOL) iIU=1;
				 if(fabs(m_LoadArray[0].m_StructLoads[ci].m_dValue[1])>PAKF_VELOCITY_TOL) iIV=1;
				 if(fabs(m_LoadArray[0].m_StructLoads[ci].m_dValue[2])>PAKF_VELOCITY_TOL) iIW=1;
				}
			}
		}
		//Vlada 2008-08-08 Videti sa Ficom koliko se ogranicenja stampa u dat fajlu
		str.Format("%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
			nn.m_nID, iIU, iIV, iIW, iIP, iIT, nn.m_dX, nn.m_dY, nn.m_dZ);//PAKF_FICA izbachen.Mileta intervention
			
/*		str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
			nn.m_nID, iIU, iIV, iIW, iIP, iIT, PAKF_FICA, nn.m_dX, nn.m_dY, nn.m_dZ);//PAKF_FICA izbachen.Mileta intervention
*/
		file.WriteString(str);
	}


	return(-1);
}



UINT CModelData::ExportPAKF_PrescVals(MyFile& file)
{
	MyString str;
	UINT i,uNUMZAD=0,uINDPR, uNUMST=0, uLOADTYPE=0;
	MyArray<TElemNode,TElemNode&> ElemNodes;
	bool bTip = FALSE;
	UINT nPressCount = 0;
//
//Prebrojavanje zadatih vrednosti	
	if(m_LoadArray.GetSize()>0)
	{
		for(i=0;i<(UINT)m_LoadArray[0].m_StructLoads.GetSize();i++)
		{
			StructLoad &sl = m_LoadArray[0].m_StructLoads[i];
			if(m_LoadArray[0].m_StructLoads[i].m_uLoadtype==StructLoad::LT_NODAL_VELOCITY)
			{
				for(UINT j = 0; j < 6; j++)
				{
					if(m_LoadArray[0].m_StructLoads[i].m_uDof_face[j])	{uNUMZAD++; bTip = TRUE;} 
				}
			}
			//Mileta intervention
			if(m_LoadArray[0].m_StructLoads[i].m_uLoadtype==StructLoad::LT_ELEM_PRESS)
			{
				//Velibor
				uLOADTYPE = m_LoadArray[0].m_StructLoads[i].m_uSubtype;
				uNUMST++;

				PressVectorF(sl,i,ElemNodes, nPressCount);
				if(!bTip)
				{
						
					uNUMZAD = ElemNodes.GetSize();
				}
			}	
			//End Mileta intervention
		}

		for(i = 0; i < (UINT)m_LoadArray[0].m_NodalTemps.GetSize();i++)
		{
			NodalTemp &nt = m_LoadArray[0].m_NodalTemps[i];

			uNUMZAD++;
		}
	}
 	file.WriteString(PAKF_CardH10);
	file.WriteString(PAKF_CardV10);
	str.Format("%5u%5u%5u\n",uNUMZAD,uNUMST,uLOADTYPE);
	file.WriteString(str);

 	file.WriteString(PAKF_CardH10_1);
	file.WriteString(PAKF_CardV10_1);

	UINT nLoadCount = m_LoadArray.GetSize();
	UINT nPressElems = 0;
	if(nLoadCount>0)
	{
		UINT nStructLoadCount = (UINT)m_LoadArray[0].m_StructLoads.GetSize();
		for( i = 0; i < nStructLoadCount; i++ )
		{
			if(m_LoadArray[0].m_StructLoads[i].m_uLoadtype == StructLoad::LT_NODAL_VELOCITY)
			{
				if(m_LoadArray[0].m_StructLoads[i].m_uDof_face[0])
				{
					uINDPR=1;
					str.Format("%5u%5u%5u%10.6f\n",m_LoadArray[0].m_StructLoads[i].m_uLoadID,
						uINDPR,m_LoadArray[0].m_StructLoads[i].m_uSl_funcID,m_LoadArray[0].m_StructLoads[i].m_dValue[0]);
					file.WriteString(str);
				}
				if(m_LoadArray[0].m_StructLoads[i].m_uDof_face[1])
				{
					uINDPR=2;
					str.Format("%5u%5u%5u%10.6f\n",m_LoadArray[0].m_StructLoads[i].m_uLoadID,
						uINDPR,m_LoadArray[0].m_StructLoads[i].m_uSl_funcID,m_LoadArray[0].m_StructLoads[i].m_dValue[1]);
					file.WriteString(str);
				}
				if(m_LoadArray[0].m_StructLoads[i].m_uDof_face[2])
				{
					uINDPR=3;
					str.Format("%5u%5u%5u%10.6f\n",m_LoadArray[0].m_StructLoads[i].m_uLoadID,
						uINDPR,m_LoadArray[0].m_StructLoads[i].m_uSl_funcID,m_LoadArray[0].m_StructLoads[i].m_dValue[2]);
					file.WriteString(str);
				}

			}
			if(m_LoadArray[0].m_StructLoads[i].m_uLoadtype == StructLoad::LT_ELEM_PRESS && m_LoadArray[0].m_StructLoads[i].m_uSubtype == 0)
			{
				uINDPR = 4;
				nPressElems++;
				
				str.Format("%5u%5u%5u%10.3f\n", ElemNodes[i].nNode, uINDPR,
					ElemNodes[i].nSlFuncID,ElemNodes[i].dValue);
				file.WriteString(str);
				if(nPressElems == nPressCount)
				{
					for(UINT j = 1; j <= uNUMZAD-nPressElems; j++)
					{
						str.Format("%5u%5u%5u%10.3f\n", ElemNodes[i+j].nNode, uINDPR,
						ElemNodes[i+j].nSlFuncID,ElemNodes[i+j].dValue);
						file.WriteString(str);

					}
				}
			}
		}

		UINT nNodalTempCount = (UINT)m_LoadArray[0].m_NodalTemps.GetSize();
		for(i = 0; i < nNodalTempCount; i++)
		{
			str.Format("%5u%5u%5u%10.3f\n",m_LoadArray[0].m_NodalTemps[i].m_uNdtempID, 5,m_LoadArray[0].m_NodalTemps[i].m_uNdt_funcID,m_LoadArray[0].m_NodalTemps[i].m_dNdtemp); 
			file.WriteString(str);
		}
	}
	return (-1);
}

//Mileta intervention
//Prebrojavanje cvorova i elemenata za postavljanje pritiska, tj. odredjivanje vrednosti NUMST i NUMZAD parametara za DAT fajlu
UINT CModelData::PressVectorF(StructLoad &sl, UINT i, MyArray<TElemNode,TElemNode&> &ElemNodes, UINT &nPressCount)
{
	HElement &el = m_ElArray[sl.m_uLoadID - 1];
	
	TElemNode elemnode;
	elemnode.nElem = el.m_nID;
	elemnode.nSlFuncID = sl.m_uSl_funcID;
	elemnode.dValue = sl.m_dValue[3];
	bool bPressIndic = FALSE;
	
	UINT surface_nodes_3d[6][8]={   {0,3,2,1,11,10,9,8},
									{4,5,6,7,16,17,18,19},
									{0,1,5,4,8,13,16,12},
									{1,2,6,5,9,14,17,13},
									{2,3,7,6,10,15,18,14},
									{3,0,4,7,11,12,19,15}};
	UINT surface_nodes_2d[4][3]={   {0,1,4},
									{1,2,5},
									{2,3,6},
									{3,0,7}	};

	switch(el.m_uTopology)
	{
	case FETO_QUAD9:
//	if(el.m_uTopology == FETO_QUAD9)
		{
			for(UINT k = 1; k <= 4; k++)
			{
				if(ElemNodes.GetSize() == 0)
				{	
					if(sl.m_uDof_face[0] == k && sl.m_uSubtype == 0)
					{
						bPressIndic = TRUE;
						elemnode.nNode = m_NodArray[el.m_uNode[(k==4)?3:k-1]-1].m_nID;
						ElemNodes.Add(elemnode);
						
						elemnode.nNode = m_NodArray[el.m_uNode[(k==4)?0:k]-1].m_nID;
						ElemNodes.Add(elemnode);
					}
				}
				else
				{
					bool bNonExist = TRUE;
					
					if(sl.m_uDof_face[0] == k && sl.m_uSubtype == 0)
					{
						
						UINT nNodesCount = ElemNodes.GetSize();
						UINT j;
						for(j = 0; j < nNodesCount; j++)
						{
							if(m_NodArray[el.m_uNode[(k==4)?3:k-1]-1].m_nID == ElemNodes[j].nNode)
							{
								bNonExist = FALSE;
								break;
							}
						}
						if(bNonExist)
						{
							elemnode.nNode = m_NodArray[el.m_uNode[(k==4)?3:k-1]-1].m_nID;
							ElemNodes.Add(elemnode);
							bPressIndic = TRUE;
						}

						bNonExist = TRUE;
						for(j = 0; j < nNodesCount; j++)
						{
							if(m_NodArray[el.m_uNode[(k==4)?0:k]-1].m_nID == ElemNodes[j].nNode)
							{
								bNonExist = FALSE;
								break;
							}
						}
						if(bNonExist)
						{
							elemnode.nNode = m_NodArray[el.m_uNode[(k==4)?0:k]-1].m_nID;
							ElemNodes.Add(elemnode);
							bPressIndic = TRUE;
						}
					}
				}	
			}
			break;
		}
	case FETO_BRICK21:
//	else if(el.m_uTopology == FETO_BRICK21)
		{
			for(UINT k = 1; k <= 6; k++)
			{
				for(UINT cu = 0; cu < 4; cu++)
				{
					if(ElemNodes.GetSize() == 0)
					{	
						if(sl.m_uDof_face[k-1] && sl.m_uSubtype == 0)
						{
							bPressIndic = TRUE;
							elemnode.nNode = m_NodArray[el.m_uNode[surface_nodes_3d[k-1][0]]-1].m_nID;
							ElemNodes.Add(elemnode);
							elemnode.nNode = m_NodArray[el.m_uNode[surface_nodes_3d[k-1][1]]-1].m_nID;
							ElemNodes.Add(elemnode);
							elemnode.nNode = m_NodArray[el.m_uNode[surface_nodes_3d[k-1][2]]-1].m_nID;
							ElemNodes.Add(elemnode);
							elemnode.nNode = m_NodArray[el.m_uNode[surface_nodes_3d[k-1][3]]-1].m_nID;
							ElemNodes.Add(elemnode);
						}
					}
					else
					{
						bool bNonExist = TRUE;
						
						if(sl.m_uDof_face[k-1] && sl.m_uSubtype == 0)
						{
							UINT nNodesCount = ElemNodes.GetSize();
							bPressIndic = TRUE;
							
							for(UINT j = 0; j < nNodesCount; j++)
							{
								if(m_NodArray[el.m_uNode[surface_nodes_3d[k-1][cu]]-1].m_nID == ElemNodes[j].nNode)
								{
									bNonExist = FALSE;
									break;
								}
							}
							if(bNonExist)
							{
								elemnode.nNode = m_NodArray[el.m_uNode[surface_nodes_3d[k-1][cu]]-1].m_nID;
								ElemNodes.Add(elemnode);
							}

							bNonExist = TRUE;
						}
					}
				}	
			}
			break;
		}
	case FETO_QUAD4:
		{
			for(UINT k = 1; k <= 6; k++)
			{
				if(ElemNodes.GetSize() == 0)
				{
					if(sl.m_uDof_face[0] == k && sl.m_uSubtype == 0)
					{
						bPressIndic = TRUE;
						elemnode.nNode = m_NodArray.Get(el.m_uNode[ surface_nodes_2d[sl.m_uDof_face[0]-1-2][0] ]).m_nID;
						ElemNodes.Add(elemnode);
						
						elemnode.nNode = m_NodArray.Get(el.m_uNode[ surface_nodes_2d[sl.m_uDof_face[0]-1-2][1] ]).m_nID;
						ElemNodes.Add(elemnode);
					}
				}
				else
				{
					bool bNonExist = TRUE;
					
					if(sl.m_uDof_face[0] == k && sl.m_uSubtype == 0)
					{
						
						UINT nNodesCount = ElemNodes.GetSize();
						UINT j;
						for(j = 0; j < nNodesCount; j++)
						{
							if(m_NodArray.Get(el.m_uNode[ surface_nodes_2d[sl.m_uDof_face[0]-1-2][0] ]).m_nID == ElemNodes[j].nNode)
							{
								bNonExist = FALSE;
								break;
							}
						}
						if(bNonExist)
						{
							elemnode.nNode = m_NodArray.Get(el.m_uNode[ surface_nodes_2d[sl.m_uDof_face[0]-1-2][0] ]).m_nID;
							ElemNodes.Add(elemnode);
							bPressIndic = TRUE;
						}

						bNonExist = TRUE;
						for(j = 0; j < nNodesCount; j++)
						{
							if(m_NodArray.Get(el.m_uNode[ surface_nodes_2d[sl.m_uDof_face[0]-1-2][1] ]).m_nID == ElemNodes[j].nNode)
							{
								bNonExist = FALSE;
								break;
							}
						}
						if(bNonExist)
						{
							elemnode.nNode = m_NodArray.Get(el.m_uNode[ surface_nodes_2d[sl.m_uDof_face[0]-1-2][1] ]).m_nID;
							ElemNodes.Add(elemnode);
							bPressIndic = TRUE;
						}
					}
				}
			}
			break;
		}
	default:
		{
//			ASSERT(FALSE);
		}
	}
	if(bPressIndic)
		nPressCount++;
	return (-1);
}
//End Mileta

UINT CModelData::ExportPAKF_SurrTract(MyFile &file)
{
	UINT nStructLoads =(UINT) m_LoadArray[0].m_StructLoads.GetSize();
	MyString str;
	UINT surface_nodes_3d[6][8]={   {0,3,2,1,11,10,9,8},
									{4,5,6,7,16,17,18,19},
									{0,1,5,4,8,13,16,12},
									{1,2,6,5,9,14,17,13},
									{2,3,7,6,10,15,18,14},
									{3,0,4,7,11,12,19,15}};

	UINT surface_nodes_2d[4][3]={   {0,1,4},
									{1,2,5},
									{2,3,6},
									{3,0,7}	};

	for(UINT i = 0; i < nStructLoads; i++)
	{
		StructLoad& sl = m_LoadArray[0].m_StructLoads[i];
		if(sl.m_uLoadtype == StructLoad::LT_ELEM_PRESS) 
		{
			if(m_ElArray[0].m_uTopology == FETO_QUAD4)
			{
				UINT nfun = (sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
				bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
				ASSERT(bFound);

				for(UINT j = 1; j < 4; j++)
				{
					UINT nElemID = sl.m_uLoadID;
					UINT nElemInd = m_ElArray.GetIndex(nElemID);
				
					if(sl.m_uDof_face[0] == j)
					{
						str.Format("%5u%5u%5u%5u%10.3f\n",sl.m_uLoadID,
							m_ElArray[nElemInd].m_uNode[surface_nodes_2d[sl.m_uDof_face[0]-1-2][0]],m_ElArray[nElemInd].m_uNode[surface_nodes_2d[sl.m_uDof_face[0]-1-2][1]], nfun+1, sl.m_dValue[0]);
					}

					if(sl.m_uSubtype == 1)
					{
						str.Format("%5u%5u%5u%5u%10.3f\n",sl.m_uLoadID,
							m_ElArray[nElemInd].m_uNode[surface_nodes_2d[sl.m_uDof_face[0]-1-2][0]],m_ElArray[nElemInd].m_uNode[surface_nodes_2d[sl.m_uDof_face[0]-1-2][1]], nfun+1, sl.m_dValue[0]);
					}

					if(sl.m_uSubtype == 2)
					{
						str.Format("%5u%5u%5u%5u%10.3f\n",sl.m_uLoadID,
							m_ElArray[nElemInd].m_uNode[surface_nodes_2d[sl.m_uDof_face[0]-1-2][0]],m_ElArray[nElemInd].m_uNode[surface_nodes_2d[sl.m_uDof_face[0]-1-2][1]], nfun+1, sl.m_dValue[0]);
					}
				}
			}
			if(m_ElArray[0].m_uTopology == FETO_QUAD9)
			{
				UINT nfun = (sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
				bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
				ASSERT(bFound);

				for(UINT j = 1; j < 4; j++)
				{
					UINT nElemID = sl.m_uLoadID;
					UINT nElemInd = m_ElArray.GetIndex(nElemID);
				
					if(sl.m_uDof_face[0] == j)
					{
						str.Format("%5u%5u%5u%5u%10.3f\n",sl.m_uLoadID,
							m_ElArray[nElemInd].m_uNode[(j==4)?0:j],m_ElArray[nElemInd].m_uNode[(j==4)?3:j-1], nfun+1, sl.m_dValue[0]);
					}

					if(sl.m_uSubtype == 1)
					{
						str.Format("%5u%5u%5u%5u%10.3f\n",sl.m_uLoadID,
							m_ElArray[nElemInd].m_uNode[(j==4)?3:j-1],m_ElArray[nElemInd].m_uNode[(j==4)?3:j-1], nfun+1, sl.m_dValue[0]);
					}

					if(sl.m_uSubtype == 2)
					{
						str.Format("%5u%5u%5u%5u%10.3f\n",sl.m_uLoadID,
							m_ElArray[nElemInd].m_uNode[(j==4)?0:j],m_ElArray[nElemInd].m_uNode[(j==4)?3:j-1], nfun+1, sl.m_dValue[0]);
					}
				}
			}
			if(m_ElArray[0].m_uTopology == FETO_BRICK21)
			{
				UINT nElemID = m_LoadArray[0].m_StructLoads[i].m_uLoadID;
				UINT nElemInd = m_ElArray.GetIndex(nElemID);

				for(UINT j = 0; j < 6; j++)
				{

					if(m_LoadArray[0].m_StructLoads[i].m_uDof_face[j])
					{
						str.Format("%5u%5u%5u%5u%5u%5u%5u%5u\n",m_LoadArray[0].m_StructLoads[i].m_uLoadID,m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][0]],
							m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][1]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][2]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][3]],m_LoadArray[0].m_StructLoads[i].m_uSl_funcID,m_LoadArray[0].m_StructLoads[i].m_uSl_funcID,m_LoadArray[0].m_StructLoads[i].m_uSl_funcID);
					}
			//Surface traction u slucaju simetrija, postavljanje ogranicenja kretanja fluida u pravcu normalnom na ravansimetrije
					if(m_LoadArray[0].m_StructLoads[i].m_uSubtype == 1 && m_LoadArray[0].m_StructLoads[i].m_uDof_face[j])
					{
						str.Format("%5u%5u%5u%5u%5u%5u%5u%5u\n",m_LoadArray[0].m_StructLoads[i].m_uLoadID,m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][0]],
							m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][1]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][2]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][3]],1,0,0);
					}

					if(m_LoadArray[0].m_StructLoads[i].m_uSubtype == 2 && m_LoadArray[0].m_StructLoads[i].m_uDof_face[j])
					{
						str.Format("%5u%5u%5u%5u%5u%5u%5u%5u\n",m_LoadArray[0].m_StructLoads[i].m_uLoadID,m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][0]],
							m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][1]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][2]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][3]],0,1,0);
					}

					if(m_LoadArray[0].m_StructLoads[i].m_uSubtype == 3 && m_LoadArray[0].m_StructLoads[i].m_uDof_face[j])
					{
						str.Format("%5u%5u%5u%5u%5u%5u%5u%5u\n",m_LoadArray[0].m_StructLoads[i].m_uLoadID,m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][0]],
							m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][1]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][2]],m_ElArray[nElemInd].m_uNode[surface_nodes_3d[j][3]],0,0,1);
					}
				}
			}

			file.WriteString(str);
		}
	}
	return (0);
}

//Exports pressure prescribed on 3D elements VLADA-2007-07-31
UINT CModelData::ExportPAKF_SurfaceTraction(MyFile &file)
{
	UINT i, j, k;
	MyString str;
	MyStringAdvanced p_str;

	UINT surface_nodes_3d[6][8]={   {0,3,2,1,11,10,9,8},
									{4,5,6,7,16,17,18,19},
									{0,1,5,4,8,13,16,12},
									{1,2,6,5,9,14,17,13},
									{2,3,7,6,10,15,18,14},
									{3,0,4,7,11,12,19,15}};

/*
	UINT surface_nodes_prism[5][8]={{0,2,1,1,8,7,1,6},
									{3,4,5,5,12,13,5,14},
									{0,1,4,3,6,10,12,9},
									{1,2,5,4,7,11,13,10},
									{2,0,3,5,8,9,14,11}};

	UINT surface_nodes_tetra[4][8]={{0,2,1,1,6,5,1,4},
									{0,1,3,3,4,8,3,7},
									{1,2,3,3,5,9,3,8},
									{2,0,3,3,6,7,3,9}};
*/
	UINT surface_nodes_shell[2][8]={{0,3,2,1,7,6,5,4},
									{0,1,2,3,4,5,6,7}};

	UINT surface_nodes_tshell[2][8]={{0,2,1,1,5,4,1,3},
									{0,1,2,2,3,4,2,5}};

	UINT surface_nodes_2d[4][3]={   {0,1,4},
									{1,2,5},
									{2,3,6},
									{3,0,7}};

	UINT surface_nodes_t2d[3][3]={  {0,1,3},
									{1,2,4},
									{2,0,5}};


//	VLADA - ZADAVANJE PRITISKA NA FACE ELEMENTA iskopirano is ExportPAK_Loads
	file.WriteString(PAKF_CardH13_3D);
	file.WriteString(PAKF_CardV13_3D);

	for(i=0;i<(UINT)m_LoadArray[0].m_StructLoads.GetSize();i++)
	{
		StructLoad &sl=m_LoadArray[0].m_StructLoads[i];

		if(sl.m_uLoadtype==StructLoad::LT_ELEM_PRESS)
		{
			HElement &el = (HElement&)m_ElArray.Get(sl.m_uLoadID);
			j=sl.m_uDof_face[0]-1;
			 if(fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
			 {
				UINT nfun;
				nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
				bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
				ASSERT(bFound);
				
				switch(el.m_uTopology)
				{
					case FETO_BRICK8: case FETO_BRICK20:
					{
						str.Format("%5u", el.m_nID);
						file.WriteString(str);
//								p_str.Format("%5u%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e%5u\n",nfun+1,PAKS_IPRAV,
//								sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],PAKS_KORC);
//								file.WriteString(p_str);
						for(k = 0; k < (UINT)(el.m_uTopology==FETO_BRICK8 ? 4:8); k++)
						{
							str.Format("%5u",el.m_uNode[surface_nodes_3d[j][k]]);
							file.WriteString(str);
						}
////						p_str.Format("%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n",
////									sl.m_uSl_funcID, sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0]);
						p_str.Format("%5u\n", sl.m_uSl_funcID);
						file.WriteString(p_str);
						
//								file.WriteString("\n");
					}
						break;
					case FETO_QUAD4: case FETO_QUAD8: case FETO_TRI3: case FETO_TRI6:
					if(j<2)
					{
						p_str.Format("%5u%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e%5u\n",nfun+1,PAKS_IPRAV,
							sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],PAKS_KORC);
						file.WriteString(p_str);
						for(k=0;k<(UINT)((el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_TRI3)? 4:8);k++)
						{
			 				if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8)
								str.Format("%5u",el.m_uNode[surface_nodes_shell[j][k]]);
							else
								str.Format("%5u",el.m_uNode[surface_nodes_tshell[j][k]]);
							file.WriteString(str);
						}
						file.WriteString("\n");
					}
					break;
				}
			 }
		}
	}

	return(0);

}