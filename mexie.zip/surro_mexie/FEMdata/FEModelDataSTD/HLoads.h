/*!
 * \file HLoads.h
 * Interface for the HLoads class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HLoads.h: interface for the HLoads class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLOADS_H__ADDF1161_651D_11D2_8266_004F4900B9E0__INCLUDED_)
#define AFX_HLOADS_H__ADDF1161_651D_11D2_8266_004F4900B9E0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "HDataBlock.h"
//#include "..\CSKClasses\ArraySerializable.h"
#include "MyString.h"
#include "MyArray.h"

/** Class representing nodal or elemental structural loads. */
class StructLoad //: public CObject
{
public:
	typedef enum
	{
		LT_NODAL_FORCE =					1,
		LT_NODAL_DISPL =					2,
		LT_NODAL_VELOCITY =					7,
		LT_NODAL_HEAT_GENERATION =			5,
		LT_NODAL_HEAT_FLUX =				6,
		LT_NODAL_STATIC_FLUID_PRESSURE  =	13,
		LT_NODAL_TOTAL_FLUID_PRESSURE  =	14,
		LT_NODAL_ELECTRIC_POTENTIAL  =		51,
		LT_NODAL_ELECTRIC_CURRENT  =		52,

		LT_ELEM_PRESS =						11,
		LT_ELEM_HEAT_GEN =					13,
		LT_ELEM_HEAT_FL  =					14,
		LT_ELEM_CONV =						15,
		LT_ELEM_RADIATION =					16,
		LT_ELEM_CURRENT_DENSITY =			150
	//(4.4+)Type of load (1=Nodal Force, 2=Nodal Displacement, 3=Nodal Accel, 5=Nodal Heat Generation, 6=Nodal Heat Flux, 7=Velocity, 8=Nonlinear Transient, 10=Distributed Line Load, 11=Element Face Pressure, 13=Element Heat Generation, 14=Element Heat Flux, 15=Element Convection, 16=Element Radiation)
	} TLoadType;

public:
	StructLoad();
	~StructLoad();
	StructLoad& operator=(const StructLoad& rc);
	StructLoad(const StructLoad&);
	//void Serialize( CArchive& ar );

	/// ID of the entity where load is applied
	UINT m_uLoadID;
	MyString m_sTitle;
	/// Type of the load
	TLoadType m_uLoadtype;
	/// Color of the structural load
	UINT m_uColor;
	/// Layer of the structural load
	UINT m_uLayer;
	UINT m_uDefine_sys;
	/// ID of the corresponding function
	UINT m_uSl_funcID;
	double m_dPhase;
	double m_dCoefficient;
	/// 6-element array of indicators in which DOF load is applied
	UINT m_uDof_face[6];
	/// 6-element array of values for 6 DOFs.
	double m_dValue[6];
	double m_dAddI_coeff;
	UINT m_uAddI_fnc[3];
	bool m_bCan_shade;
	bool m_bCan_be_shade;
	/// Subtype of the load
	UINT m_uSubtype;
	UINT m_uDir_func[3];
	double m_dDirection[3];
};

/** Class representing nodal temperature. */
class NodalTemp //: public CObject
{
public:
	 NodalTemp();
	NodalTemp& operator =(const NodalTemp& rc);
	NodalTemp(const NodalTemp& rc);
	//void Serialize( CArchive& ar );

	/// ID of the node
	UINT m_uNdtempID;
	/// Color of the nodal temperature
	UINT m_uColor;
	/// Layer of the nodal temperature
	UINT m_uLayer;
	/// Temperature at the node
	double m_dNdtemp;
	/// ID of the corresponding function
	UINT m_uNdt_funcID;
};

/** Class representing temperature at element. */
class ElTemp //: public CObject
{
public:
	ElTemp();
	ElTemp(const ElTemp& rc);
	ElTemp& operator = (const ElTemp& rc);
	//void Serialize( CArchive& ar );

	/// ID of the element
	UINT m_uEltempID;
	/// Color of the temperature
	UINT m_uColor;
	/// Layer of the temperature
	UINT m_uLayer;
	/// Temperature at element
	double m_dEltemp;
	/// ID of the corresponding function
	UINT m_uElf_funcID;
};

/** Class representing load set. */
class HLoads : public HDataBlock  
{
public:	
	HLoads();
	HLoads(const HLoads& rc);
	virtual ~HLoads();
	HLoads& operator = (const HLoads& rp);
	//void Serialize( CArchive& ar );

	/// ID of the load set
	UINT m_nID;
	/// Title of the load set
	MyString m_strTitle;
	UINT m_uCSys;
	/// Default temperature
	double m_dDef_temp;
	/// Indicator whether temperature is considered
	bool m_bTemp_on;
	/// Indicator whether gravitation is considered
	bool m_bGrav_on;
	bool m_bOmega_on;
	/// Gravity
	double m_dGrav[6];
	double m_dOrigin[3];
	double m_dOmega[3];
	double m_dStef_boltz;
	double m_dAbs_temp;
	double m_dFree_cnv_exp;
	double m_dFc_flu_cond;
	double m_dFc_flu_cp;
	double m_dFc_flu_vis;
	double m_dFc_flu_dens;
	double m_dFc_cons_coef;
	double m_dFc_reynolds;
	double m_dFc_pran_in;
	double m_dFc_pran_out;
	UINT m_uTfc_flu_cond;
	UINT m_uTfc_flu_cp;
	UINT m_uTfc_flu_vis;
	bool m_bAlt_free_conv;
	bool m_bFc_flu_flag;
	bool m_bFc_conv_flow;

	double m_dDyn_trans_dt;
	UINT m_uDyn_trans_ts;
	UINT m_uDyn_type;

	/// Collection of structural loads
	MyArray<StructLoad,StructLoad&> m_StructLoads;
	/// Collection of nodal temperatures
	MyArray<NodalTemp,NodalTemp&> m_NodalTemps;
	/// Collection of temperatures at elements
	MyArray<ElTemp,ElTemp&> m_ElTemps;

};

#endif // !defined(AFX_HLOADS_H__ADDF1161_651D_11D2_8266_004F4900B9E0__INCLUDED_)
