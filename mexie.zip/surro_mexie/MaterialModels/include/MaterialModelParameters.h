/*
 * MaterialModelParameters.h
 *
 *  Created on: Sep 12, 2013
 *      Author: anakaplarevic
 */

#ifndef MATERIALMODELPARAMETERS_H_
#define MATERIALMODELPARAMETERS_H_

#include "Globals.h"

class MaterialModelParameters {
public:
	MaterialModelParameters();
	virtual ~MaterialModelParameters()=0;
};

#endif /* MATERIALMODELPARAMETERS_H_ */
