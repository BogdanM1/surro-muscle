/*
 * HuxleyCalculator.h
 *
 *  Created on: Aug 8, 2013
 *      Author: anakaplarevic
 */

#ifndef HUXLEYCALCULATOR_H_
#define HUXLEYCALCULATOR_H_

#include "HuxleyParameters.h"
#include "HuxleyState.h"


class HuxleyCalculator {
private:
	HuxleyParameters* _param;
public:
	HuxleyCalculator(HuxleyParameters* param);
	virtual ~HuxleyCalculator();
private:
	ublas::vector<_TIP> X;
	ublas::vector<_TIP> N;
	ublas::vector<_TIP> V;
	ublas::vector<_TIP> F;

	ublas::vector<_TIP> X_curr;
	ublas::vector<_TIP> N_curr;
	ublas::vector<_TIP> V_curr;
	ublas::vector<_TIP> F_curr;

	ublas::vector<_TIP> X_next;
	ublas::vector<_TIP> N_next;
	ublas::vector<_TIP> V_next;
	ublas::vector<_TIP> F_next;

	ublas::vector<_TIP> X_remash;
	ublas::vector<_TIP> N_remash;

public:

    int brojac;
    int getBrojac();

	void Calculate(ublas::vector<_TIP>& X,ublas::vector<_TIP>& N,_TIP velocity,_TIP time,_TIP* force, _TIP O);
	void Calculate(ublas::vector<_TIP>& X,ublas::vector<_TIP>& N,_TIP& v_t,_TIP velocity_avg,_TIP time,_TIP* force, _TIP O);
	void Simulate(_TIP time, _TIP O);
	void Simulate(_TIP time,_TIP V_start,_TIP V_end, _TIP O);
	void remash(_TIP diff);
	int Iteration(_TIP O);

	_TIP getVelocity();
	_TIP getStiffness();
	_TIP getForce();
	_TIP getSigmaTangent();
	_TIP getSigmaTangent(_TIP e);
    _TIP getSigma();
};

#endif /* HUXLEYCALCULATOR_H_ */
