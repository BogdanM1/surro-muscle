Mister Musculo - SOLEUS
Start UP verzija








Verzija 3
	Verzija Materijalnog modela sa definisanjem tipa podataka sa kojima radi HuxleModel.
	U HuxleyParameters.h se nalazi makro kojim je definisan _TIP.
	Od _TIP-a zavise HuxleyState, HuxleyFunctions i HuxleyCalculator.
	_TIP promenjen samo u HuxleyModel, ali ne i u HuxleModel2D.
	
Verzija 4
	HuxleyCalculator izmenjen.  
	HUxle_functons - napravljena verzija bez if-a.

Verzija 5
	Ukljucen libconfig.
	
Verzija 6 
 	PAKOVANJE OD POCETKA. Postoje samo 3 apstraktne klase - MaterialModel, MaterialModelParameters, MaterialModelState.
 	