/*
 * MPIManager.cpp
 *
 *  Created on: May 14, 2014
 *      Author: anakaplarevic
 */

#include "MPIManager.h"
#include "FEM2D.h"
#include <string>
#include <stdlib.h>
#include "MMChunkCUDA.h"
#include "vector"

FILE* logfajl;

MPIManager::MPIManager(FEM2D* macroModel,MMChunkCalculator* microModelChunk) {
	this->macroModel = macroModel;
	this->microModelChunk = microModelChunk;
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::MPIManager ... namestam isti loga za chunk\n");
    fflush(velikiLog);
    this->microModelChunk->setFileVelikiLog(&velikiLog);
#endif
    totalCalculateTime = 0;
    totalCalculateTimeWithComm = 0;
}

MPIManager::~MPIManager() {
}

void MPIManager::createFileForChunk(){
    FILE* pom;
    pom=fopen(createFileName(),"w");
    //fprintf(pom,"-- a di je ime -- %s\n",createFileName());
    microModelChunk->setFile(pom);
    microModelChunk->setMPI(mpi_ID);
}

void MPIManager::run(){
	if (mpi_ID!=0) {
    	printf("ZSSNC Proces koji treba da bude QPoint manager nema ID=0\n");
    	return;
    }
        char imeloga[40];
        sprintf(imeloga,"vremena%d.log",mpi_ID);
//        FILE* log;
        logfajl=fopen(imeloga,"w");

    if (mpi_SIZE==0) printf("______________ MPICalcualtorManager je jedini pokrenut proces\n");
    timestamp();
    			cout << "\n HELLO_MPI - Master process:\n";
    			double  wtime = MPI::Wtime ( );

    macroModel->run(this);

	wtime = MPI::Wtime ( ) - wtime;
    cout << "  Calculate Time without Scatter & Gather "<< totalCalculateTime<< " seconds.\n";
    cout << "  TOTAL Calculate Time "<< totalCalculateTimeWithComm<< " seconds.\n";
    cout << "  Elapsed wall clock time = " << wtime << " seconds.\n";
    fclose(logfajl);
    fclose(f);
}

void MPIManager::init(int number_of_q_points, MMType* mmtypes, std::vector<double> &m_E, std::vector<double> &m_ni, std::vector<double> &m_fi, std::vector<_TIPF1> &m_f1) {
#ifdef LOGON
    fprintf(velikiLog,"PROCESS %d\n",mpi_ID);
    fprintf(velikiLog,"MPIManager::init ... start\n");
    fflush(velikiLog);
#endif
    n_q_points_all = number_of_q_points;
    scheduler = new Scheduler(n_q_points_all,mpi_SIZE);
//	DEBUG printf("--------------- QPoint MANAGER init - slanje broja qpoint-a, velicina porcija, tipova q_pointa\n");
// MPI_Bcast(&n_q_points_all,1,MPI_INT, 0,MPI_COMM_WORLD);

//    DEFINISANJE CHUNK-ova

 /*   char* sc;
    sc = (char*) malloc(sizeof(char));
    config_t cfg; //   const char *str;
    config_init(&cfg);

    if(!config_read_file(&cfg, CFGFAJL)) { printf("Neuspesno otvaranje FEM_MM.cfg fajla\n"); config_destroy(&cfg); exit(-1);}
    if(!config_lookup_string(&cfg, "RUN.scenario", (const char**)&sc)) fprintf(stderr, "Nema 'scenario' u konfiguracionom fajlu\n");
    printf("Procitao iz CFG-a %s \n",sc);
    char *cit;
    cit = (char*)malloc(sizeof(char)*(strlen(sc)-1));
    sscanf(sc,"%s",cit);
    config_destroy(&cfg);
*/
  //  if (strcmp(cit,"MPImixCUDA")!=0)
    if (Globals::scenario!=MPImixCUDA)
      {
        printf("Cist MPI runner\n");
        defineChunks();
      }
    else
      {
        printf("Mixed MPI CUDA runner\n");
 /*     config_t cfg; const config_setting_t *setting1,*setting2;//   const char *str;
      config_init(&cfg);

      if(!config_read_file(&cfg, CFGFAJL)) { printf("Neuspesno otvaranje FEM_MM.cfg fajla\n"); config_destroy(&cfg); exit(-1);}

      setting1 = config_lookup(&cfg, "RUN.gdeSuCude");
      int i,count = config_setting_length(setting1);
      setting2 = config_lookup(&cfg, "RUN.maxCude");
      count = config_setting_length(setting2);
      int *cudaMPIID,*cudaMAX;
      cudaMPIID = (int*)malloc(sizeof(int)*count);
      cudaMAX = (int*)malloc(sizeof(int)*count);
      for (i = 0; i < count; i++) {
             cudaMPIID[i]=(int)config_setting_get_int_elem(setting1, i);
             cudaMAX[i]=(int)config_setting_get_int_elem(setting2, i);
             printf("CUDA MPI_IP = %d   max = %d\n",cudaMPIID[i],cudaMAX[i]);
         }
      config_destroy(&cfg);
      defineChunks(count,cudaMPIID,cudaMAX);
*/
      defineChunks(Globals::numOfCUDA,Globals::cudaMPIID,Globals::cudaMAX,Globals::cudaV,Globals::mpiV);
 //     defineChunks(Globals::numOfCUDA,Globals::cudaMPIID,Globals::cudaMAX);
      }

//    SLANJE PODELE POSLA WORKERIMA
	  MPI_Bcast(podela,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(dispodela,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(podela3,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(dispodela3,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(podela33,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);
	  MPI_Bcast(dispodela33,mpi_SIZE,MPI_INT, 0,MPI_COMM_WORLD);

	  int* tipovi;
	  tipovi = (int *) mmtypes;
	  tipovi_part = (int*) malloc(sizeof(int)*podela[mpi_ID]);
      Globals* g=Globals::getInstance();

      m_E_part.resize(podela[mpi_ID]);
      m_ni_part.resize(podela[mpi_ID]);
      m_fi_part.resize(podela[mpi_ID]);
      m_f1_part.resize(podela[mpi_ID]);

	  e_part=(double *)malloc(podela3[mpi_ID]*sizeof(double));
	  sigma_part=(double *)malloc(podela3[mpi_ID]*sizeof(double));
	  deltasigma_part=(double *)malloc(podela33[mpi_ID]*sizeof(double));

 //   scheduler->orderForExecution(tipovi);
	MPI_Scatterv(tipovi, podela,dispodela, MPI_INT, tipovi_part,podela[mpi_ID], MPI_INT,0, MPI_COMM_WORLD);
 //   scheduler->orderAsOriginal(tipovi);

    printf("Poceo sa scatter!\n");
 //   scheduler->orderForExecution(&g->m_E[0]);
 //   scheduler->orderForExecution(&g->m_ni[0]);
//    scheduler->orderForExecution(&g->m_fi[0]);
 //   scheduler->orderForExecution(&g->m_f1[0]);
    MPI_Scatterv((void *)&g->m_E[0], podela,dispodela, MPI_DOUBLE, (void *)&m_E_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
    MPI_Scatterv((void *)&g->m_ni[0], podela,dispodela, MPI_DOUBLE, (void *)&m_ni_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
    MPI_Scatterv((void *)&g->m_fi[0], podela,dispodela, MPI_DOUBLE, (void *)&m_fi_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);

  // ANAF1TIP
#if num_TIPF1 == 1
    MPI_Scatterv(&g->m_f1[0], podela,dispodela, MPI_DOUBLE, &m_f1_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
    printf("----------------------------- DOUBLE sclatter ----------------------------\n");
#else
    MPI_Scatterv(&g->m_f1[0], podela,dispodela, MPI_FLOAT, &m_f1_part[0],podela[mpi_ID], MPI_FLOAT,0, MPI_COMM_WORLD);
    printf("----------------------------- FLOAT sclatter ----------------------------\n");
#endif

 //   scheduler->orderAsOriginal(&g->m_E[0]);
 //   scheduler->orderAsOriginal(&g->m_ni[0]);
 //   scheduler->orderAsOriginal(&g->m_fi[0]);
 //   scheduler->orderAsOriginal(&g->m_f1[0]);

    printf("Zavrsio sa scatter!\n");

  //  printf("proces %d : E=%f\n", mpi_ID, m_f1_part[1000]);


    microModelChunk->init(podela[mpi_ID],(MMType*)tipovi_part,m_E_part,m_ni_part,m_fi_part,m_f1_part);
	// DEBUG
		  printf("Manager - zavrsen INIT chunk-a\n");
	// --- DEBUG
    char* nazivHvajla;
    nazivHvajla=(char*)malloc(sizeof(char)*20);
  //  if(strcmp(cit,"MPImixCUDA")==0){
    if(Globals::scenario==MPImixCUDA){
        switch(mpi_ID){
        case 0: strcpy(nazivHvajla,"ITER0.txt");
                break;
        case 1: strcpy(nazivHvajla,"ITER1.txt");
                break;
        case 2: strcpy(nazivHvajla,"ITER2.txt");
                break;
        case 3: strcpy(nazivHvajla,"ITER3.txt");
                break;
        default: strcpy(nazivHvajla,"empty.txt");
            break;
        }
    }
    else strcpy(nazivHvajla,"empty.txt");
    f=fopen(nazivHvajla,"w");
// DEBUG 	printf("--------------- QPoint MANAGER init - slanje broja qpoint-a, velicina porcija, tipova q_pointa\n");
	microModelChunk->setStartID(dispodela[mpi_ID]);
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::init ... END\n");
    fflush(velikiLog);
#endif
}

void MPIManager::calculate(double* e_original,double* sigma,double* dsigmade){//,const double& t ) {
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::calculate ... start\n");
    fflush(velikiLog);
#endif
    //double t = Globals::getInstance()->dt;
	//  MPI_Bcast(&t,1,MPI_DOUBLE, 0,MPI_COMM_WORLD);
    //  static int rbr=0;
      double* e;
	  int dim = Globals::getInstance()->dimOfSigmaVector;
	  e = (double*)malloc(sizeof(double)*dim*n_q_points_all);

		 for (int ii=0;ii<dim;ii++)
			 for (int jj=0;jj<n_q_points_all;jj++)
				 	 *(e + jj*dim + ii)=*(e_original+ii*n_q_points_all+jj);

      double  wtime1,wtime2,wtime3,wtime4;
      wtime1 = MPI::Wtime();
      scatterAndUpdateParameters();
 //     scheduler->orderForExecution(e);
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::calculate ... scatter(e) ... \n");
    fflush(velikiLog);
#endif
      MPI_Scatterv(e, podela3,dispodela3, MPI_DOUBLE, e_part,podela3[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
// DEBUG
	  printf("-------------------- MANAGER pre podele posla\n");
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::calculate ... calculateChunk ... \n");
    fflush(velikiLog);
#endif
      wtime2 = MPI::Wtime();
	  if (podela[mpi_ID]>0)
		  microModelChunk->calculateChunk((double*)e_part,(double*)sigma_part,(double*)deltasigma_part);
      wtime3 = MPI::Wtime();
#ifdef LOGON
    fprintf(velikiLog,"MPIManager:: ... primio od chunk calculatora ... \n");
    fprintf(velikiLog,"ID\te\tsigma\tdetasigma\n");
    fflush(velikiLog);
    for(int i=0;i<10;i++) fprintf(velikiLog,"%d\t%e\t%e\t%e\n",dispodela[mpi_ID]+i,*(e_part+i*dim),*(sigma_part+i*dim),*(deltasigma_part+i*dim*dim));
    fprintf(velikiLog,"MPIManager::calculate ... gather(s,ds) ... \n");
    fflush(velikiLog);
#endif
      MPI_Gatherv(sigma_part, podela3[mpi_ID], MPI_DOUBLE,sigma,podela3,dispodela3, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	 	  	 	 	 printf("Sakupio sigma_part-s\n");
	  MPI_Gatherv(deltasigma_part, podela33[mpi_ID], MPI_DOUBLE, dsigmade,podela33,dispodela33, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	 	  	 	 printf("Sakupio deltasigma_part-s\n");
  //    scheduler->orderAsOriginal(sigma);
  //    scheduler->orderAsOriginal(dsigmade);
// DEBUG
  //  fprintf(logfajl,"%d %d %e %e\n",mpi_ID,rbr,wtime2,wtime3);
      wtime4 = MPI::Wtime();
      totalCalculateTime+=(wtime3-wtime2);
      totalCalculateTimeWithComm+=wtime4-wtime1;
      printf("\nVREMENA za CALCULATE _____________ Ukupno(scatter+calc_part+gatherx2): %f \t Samo calculate_part: %f\n\n",wtime4-wtime1,wtime3-wtime2);
   //   fprintf(f,"rbr %d\n",rbr);
//      if(((MMChunkCUDA*)microModelChunk)->_cudaTip==CUDARunCustom){
      if(Globals::cudaRunTip==CUDARunCustom){
   //       for(int i=0;i<podela[mpi_ID];i++) fprintf(f,"%f %f %f %d\n",sigma_part[i*dim],deltasigma_part[i*dim*dim],e_part[i*dim],((MMChunkCUDA*)microModelChunk)->iterCount[i]);
   //       fprintf(f,"\n");
      }
   //   rbr++;
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::calculate ... END\n");
    fflush(velikiLog);
#endif
}

void MPIManager::scatterAndUpdateParameters() {
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::scatterAndUpdateParameters ... start\n");
    fflush(velikiLog);
#endif
    Globals* g=Globals::getInstance();
 //   scheduler->orderForExecution(&g->m_f1[0]);
#if num_TIPF1 == 1
    MPI_Scatterv(&g->m_f1[0], podela,dispodela, MPI_DOUBLE, &m_f1_part[0],podela[mpi_ID], MPI_DOUBLE,0, MPI_COMM_WORLD);
#else
    MPI_Scatterv(&g->m_f1[0], podela,dispodela, MPI_FLOAT, &m_f1_part[0],podela[mpi_ID], MPI_FLOAT,0, MPI_COMM_WORLD);
#endif
//   scheduler->orderAsOriginal(&g->m_f1[0]);
    microModelChunk->updateParameters(podela[mpi_ID],m_f1_part);
#ifdef LOGON
    fprintf(velikiLog,"MPIManager::scatterAndUpdateParameters ... END\n");
    fflush(velikiLog);
#endif
}

void MPIManager::createMaps(int* original,int* neworder,int size) {
	for(int i=0;i<size;i++){
		toBrigadier[original[i]]=neworder[i];
		toFEM[neworder[i]]=toBrigadier[i];
    	}
}

void MPIManager::imageByMap(double* in, double* out, int size,map<int,int>& mapa) {
	for(int i=0;i<size;i++)
		out[mapa[i]]=in[i];
}

void MPIManager::saveAndcontinue(int* flags) {
	// provera nastavka i pamcenja stanja

	MPI_Bcast(flags,2,MPI_INT, 0,MPI_COMM_WORLD);
			microModelChunk->setToNew(flags[1]);
//	printf("ID %d zavrsio krug \n",mpi_ID);

}

/*void MPIManager::defineChunks(){
      int p=mpi_SIZE;
      double *V;
      int *max,i;
      V = (double*)malloc(sizeof(double)*p);
      max = (int*)malloc(sizeof(int)*p);
      for(i=0;i<p;i++) {
          V[i] = 1;
          max[i] = INT_MAX;
          podela[i] = 0;
      }
      scheduler->createBasicSchedule(V,max);
      scheduler->getSizeOfPartitions(podela);

      int vecSIZE = Globals::getInstance()->dimOfSigmaVector;
      for(int i=0;i<p;i++)
		  {
              if (i==0) dispodela[i]=0;
		  	  else dispodela[i]=dispodela[i-1]+podela[i-1];
			  podela3[i]=vecSIZE*podela[i];
			  dispodela3[i]=vecSIZE*dispodela[i];
			  podela33[i]=vecSIZE*vecSIZE*podela[i];
			  dispodela33[i]=vecSIZE*vecSIZE*dispodela[i];
			  printf("PODELA %d %d \n",podela[i],dispodela[i]);
		  }
}*/

void MPIManager::defineChunks(int cudaNum, int *cudaMPI_ID, int *cudaMaxPoints){
      printf("Number od CUDA proceses : %d\n",cudaNum);
      int NUM = n_q_points_all,p=mpi_SIZE;
      int vecSIZE = Globals::getInstance()->dimOfSigmaVector;

// Racunam podele za CUDA procese
      int i = 0;
      int *podelaCuda;
      podelaCuda = (int*) malloc(sizeof(int)*cudaNum);
      while (i<cudaNum) {
          podelaCuda[i] = ((NUM - cudaMaxPoints[i])>=0)?cudaMaxPoints[i]:NUM;
          NUM = NUM - podelaCuda[i];
          if (NUM < 0) { printf("_________________ greska u podeli porcija _________________ \n"); return;}
          i++;
      }

// Popunjavanje podataka o chunkovima - podela,dispodela,...
      int p_mpi = p - cudaNum;
      int num_elements=(p_mpi>0)?(NUM/p_mpi):0;
      int k = (p_mpi>0)?NUM % p_mpi:0, upisanoCuda=0;
      for(int j=0;j<p;j++)
          {
              i=0;
              while (i<cudaNum) { if (cudaMPI_ID[i]==j) break; i++;}
              if (i < cudaNum ){ // kada je u pitanju CUDA proces
                  podela[j] = podelaCuda[i];
                  upisanoCuda++;
              }
              else { // Kada je u pitanju obican MPI
                  podela[j]=((j-upisanoCuda)<k)?(num_elements+1):(num_elements);
              }
              if (j==0) dispodela[j]=0;
                    else dispodela[j]=dispodela[j-1]+podela[j-1];
              podela3[j]=vecSIZE*podela[j];
              dispodela3[j]=vecSIZE*dispodela[j];
              podela33[j]=vecSIZE*vecSIZE*podela[j];
              dispodela33[j]=vecSIZE*vecSIZE*dispodela[j];
              printf("PODELA %d %d \n",podela[j],dispodela[j]);
          }
      free(podelaCuda);
}

/*void MPIManager::defineChunks(int cudaNum, int *cudaMPI_ID, int *cudaMaxPoints, double *cudaV, double mpiV){
    printf("Number od CUDA proceses : %d\n",cudaNum);

    int p=mpi_SIZE;
    double *V;
    int *max,i;
    V = (double*)malloc(sizeof(double)*p);
    max = (int*)malloc(sizeof(int)*p);
    for(i=0;i<p;i++) {
        V[i] = mpiV;
        max[i] = INT_MAX;
        podela[i] = 0;
    }
    for(i=0;i<cudaNum;i++) {
        printf("cudaV[%d]=%f\n",i,cudaV[i]);
        V[cudaMPI_ID[i]] = cudaV[i];
        max[cudaMPI_ID[i]] = cudaMaxPoints[i];
    }

    for(i=0;i<p;i++) printf("------------ V[%d]=%f\n",i,V[i]);
    scheduler->createBasicSchedule(V,max);
    scheduler->getSizeOfPartitions(podela);

    for(i=0;i<p;i++) printf("podela[%d] = %d   V = %f\n",i,podela[i],V[i]);
    int vecSIZE = Globals::getInstance()->dimOfSigmaVector;
    for(int j=0;j<p;j++)
        {
            if (j==0) dispodela[j]=0;
                  else dispodela[j]=dispodela[j-1]+podela[j-1];
            podela3[j]=vecSIZE*podela[j];
            dispodela3[j]=vecSIZE*dispodela[j];
            podela33[j]=vecSIZE*vecSIZE*podela[j];
            dispodela33[j]=vecSIZE*vecSIZE*dispodela[j];
            printf("PODELA %d %d \n",podela[j],dispodela[j]);
        }
}*/

/* STARE VERZIJE defineChunks, bez poziva Scheduler klase
 *
 *
 */
    void MPIManager::defineChunks(){
      int NUM = n_q_points_all,p=mpi_SIZE;
      int num_elements=n_q_points_all/p;
      int vecSIZE = Globals::getInstance()->dimOfSigmaVector;
      int k = NUM % p;
      for(int i=0;i<p;i++)
          {
              podela[i]=(i<k)?(num_elements+1):(num_elements);
              if (i==0) dispodela[i]=0;
              else dispodela[i]=dispodela[i-1]+podela[i-1];
              podela3[i]=vecSIZE*podela[i];
              dispodela3[i]=vecSIZE*dispodela[i];
              podela33[i]=vecSIZE*vecSIZE*podela[i];
              dispodela33[i]=vecSIZE*vecSIZE*dispodela[i];
              printf("PODELA %d %d \n",podela[i],dispodela[i]);
          }
    }
  void MPIManager::defineChunks(int cudaNum, int *cudaMPI_ID, int *cudaMaxPoints, double *cudaV, double mpiV){
    printf("Number od CUDA proceses : %d\n",cudaNum);
    int B = n_q_points_all,p=mpi_SIZE,pom;
    double *V,Vsum,Ti;
    int *max,i;
    V = (double*)malloc(sizeof(double)*p);
    max = (int*)malloc(sizeof(int)*p);
    for(i=0;i<p;i++) {
        V[i] = mpiV;
        max[i] = INT_MAX;
        podela[i] = 0;
    }
    for(i=0;i<cudaNum;i++) {
        printf("cudaV[%d]=%f\n",i,cudaV[i]);
        V[cudaMPI_ID[i]] = cudaV[i];
        max[cudaMPI_ID[i]] = cudaMaxPoints[i];
    }

    for(i=0;i<p;i++) printf("------------ V[%d]=%f\n",i,V[i]);
//  ODREDI Tidealno
    bool nasao=false;
    while (!nasao){
        for(Vsum=0,i=0;i<p;Vsum+=V[i],i++);
        Ti=B/Vsum;
        for(i=0;i<p;i++) podela[i]=trunc(V[i]*Ti);
        nasao=true;
        for(i=0;i<p;i++) {
            nasao=nasao?(podela[i]<=max[i]):nasao;
            if (podela[i]>max[i]) {
                V[i]=max[i]*1.0/Ti;
                podela[i]=max[i];
            }
        }
    }
    for(i=0;i<p;i++) printf("podela[%d] = %d   V = %f\n",i,podela[i],V[i]);
    for(Vsum=0,i=0;i<p;Vsum+=V[i],i++);
    Ti=B/Vsum;

//  RASPOREDI nerasporedjene B-Sum(Ni)
    for(i=0;i<p;i++) B=B-podela[i];
    for(i=0;(i<p)&&(B>0);i++)
    {
        if (podela[i]>=max[i]) continue;
       // pom = round((Ti-podela[i]/V[i])*V[i]);
        pom = ceil(Ti*V[i])-podela[i];//V[i])*V[i]);
        pom = ((max[i]-podela[i])>=pom)?pom:(max[i]-podela[i]);
        printf("i = %d\t pom = %d\n",i,pom);
        podela[i]=podela[i]+(((B-pom)>=0)?pom:(B-pom));
        B=B-(((B-pom)>=0)?pom:(B-pom));
        printf("i = %d\t B = %d\n",i,B);
    }
    if (B>0) printf("Ima nerasporedenjenih. Ukupno %d, Nerasporedjeno %d \n",n_q_points_all,B);
    for(i=0;i<p;i++) printf("podela[%d] = %d   V = %f\n",i,podela[i],V[i]);
    int vecSIZE = Globals::getInstance()->dimOfSigmaVector;
    for(int j=0;j<p;j++)
        {
            if (j==0) dispodela[j]=0;
                  else dispodela[j]=dispodela[j-1]+podela[j-1];
            podela3[j]=vecSIZE*podela[j];
            dispodela3[j]=vecSIZE*dispodela[j];
            podela33[j]=vecSIZE*vecSIZE*podela[j];
            dispodela33[j]=vecSIZE*vecSIZE*dispodela[j];
            printf("PODELA %d %d \n",podela[j],dispodela[j]);
        }
}
