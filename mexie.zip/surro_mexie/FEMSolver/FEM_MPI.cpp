//============================================================================
// Name        : FEM_MPI.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <iostream>
#include <cstdio>
#include <libconfig.h++>

#include "FEM2D.h"
#include "MPIManager.h"
#include "MPIWorker.h"
#include "MMChunkCPU.h"
#include "Sequential.h"
#include "Globals.h"


#include "HuxleyModel.h"
#include "HuxleyState.h"
#include "HuxleyState2D.h"
#include "HuxleyModel2D.h"
#include "HuxleyParameters.h"
#include "MaterialModel.h"
#include "MaterialModelParameters.h"
#include "MaterialModelState.h"


#include <sys/unistd.h>

#ifdef imaCUDA
    #include "MMChunkCUDA.h"
#endif

using namespace std;

int main(int argc, char *argv[]) {
    Globals* g = Globals::getInstance();
        
	FEM2D f;
	MMChunkCPU chunkCalc;

    /*//BEGIN TEST
          std::vector<Point<2> > vertices;
          std::vector<CellData<2> > cells;
          CModelData ModelData;
          ImportModel m_pImportModel;

          FILE *fin=fopen("Pak.dat","r");
          FILE *fin1=fopen("FiberDirections.csv","r");
          if (fin == NULL)
                       {
                            printf ("Error opening file");
                       }

          m_pImportModel.setModel(fin,fin1,ModelData,vertices,cells);


          for(int i=0; i< ModelData.m_NodArray.GetSize(); i++)
           {
              printf("ID: %d	",ModelData.m_NodArray[i].m_nID);
              for(int j=0;j<6;j++)
                  printf("%d	",ModelData.m_NodArray[i].m_bPermbc[j]);
               printf("(%lf,%lf)\n",ModelData.m_NodArray[i].m_dX,ModelData.m_NodArray[i].m_dY);
           }
           getchar();
          printf("%d\n",ModelData.m_ElArray.GetSize());

          for(int i=0; i< ModelData.m_ElArray.GetSize(); i++)
               {

                   printf("ID: %d ",ModelData.m_ElArray[i].m_nID);
                    printf("ID MAT: %d\n ",ModelData.m_PropArray.GetByIndex(ModelData.m_ElArray[i].m_uPropID).m_uMatIID);
                    printf("ID fun: %d\n ",ModelData.m_MaterialsArray.GetByIndex(ModelData.m_PropArray.GetByIndex(ModelData.m_ElArray[i].m_uPropID).m_uMatIID).m_dGMatrix_3D[7]);
                   printf("Property: %d ",ModelData.m_ElArray[i].m_uPropID);
                    for(int j=0;j<4;j++)
                       printf("%6d	 ",ModelData.m_ElArray[i].m_uNode[j]);

                    printf("%6.3lf   %6.3lf",ModelData.m_MaterialsArray.GetByIndex(ModelData.m_PropArray.GetByIndex(ModelData.m_ElArray[i].m_uPropID).m_uMatIID).m_dE[0], ModelData.m_MaterialsArray.GetByIndex(ModelData.m_PropArray.GetByIndex(ModelData.m_ElArray[i].m_uPropID).m_uMatIID).m_dNu[0]);
                    printf("\nOrijentacija:");

                    for(int j=0;j<2;j++)
                       printf("%6.3lf	 ",ModelData.m_ElArray[i].m_dOrient[j]);
                    printf("\n");
                          //getchar();

               }

          for(int i=0; i< ModelData.m_MaterialsArray.GetSize(); i++)
                       {
                           printf("ID: %d	",ModelData.m_MaterialsArray[i].m_nID);
                           printf("Subtype: %d	",ModelData.m_MaterialsArray[i].m_uSubType);
                           printf("Density: %lf	",ModelData.m_MaterialsArray[i].m_dDensity);
                           printf("E: %lf	",ModelData.m_MaterialsArray[i].m_dE[0]);
                           printf("P: %lf	",ModelData.m_MaterialsArray[i].m_dNu[0]);
                           printf("fi: %lf	",ModelData.m_MaterialsArray[i].m_dG[0]);
                           printf("fun: %d	",ModelData.m_MaterialsArray[i].m_uFGMatrix3D[7]);


                           printf("\n");
                       }
          getchar();
          for(int i=0; i< ModelData.m_PropArray.GetSize(); i++)
                           {
                               printf("ID: %d	",ModelData.m_PropArray[i].m_nID);
                               printf("Tip analize: %d	",ModelData.m_PropArray[i].m_AnalysisType);
                               printf("IDMAT: %d	",ModelData.m_PropArray[i].m_uMatIID);

                               for(int j=0; j< ModelData.m_MaterialsArray.GetSize(); j++)
                                            {
                                   if (ModelData.m_MaterialsArray[j].m_nID == ModelData.m_PropArray[i].m_uMatIID)
                                        printf("fun: %d	",ModelData.m_MaterialsArray[j].m_uFGMatrix3D[7]);
                               }
                               printf("IDfun: %d	",ModelData.m_MaterialsArray.GetById(ModelData.m_PropArray[i].m_uMatIID).m_dGMatrix_3D[7]);

                               printf("\n");
                           }

          getchar();

          for(int i=0; i< ModelData.m_FunctionsArray.GetSize(); i++)
                           {
                               printf("ID: %d	",ModelData.m_FunctionsArray[i].m_nID);
                               printf("Tip analize: %d	\n",ModelData.m_FunctionsArray[i].m_uFunc_type);
                               for (int j=0;j<ModelData.m_FunctionsArray[i].m_FunctionEntry.GetSize(); j++)
                               {
                                   printf("%lf %lf\n",ModelData.m_FunctionsArray[i].m_FunctionEntry[j].m_dX,ModelData.m_FunctionsArray[i].m_FunctionEntry[j].m_dY);
                               }

                               printf("\n");
                           }
          getchar();

          MMType tipovi[4*ModelData.m_ElArray.GetSize()];
          m_pImportModel.setMaterials(ModelData,4*ModelData.m_ElArray.GetSize(),tipovi);

          fclose(fin);
          fclose(fin1);

          double ev[3];
          ev[0]=0; ev[1]=0; ev[2]=0;
          double e=0.0,*sigma,*dsigmade;
          sigma =(double*)malloc(3*sizeof(double));
          dsigmade = (double *)malloc(9*sizeof(double));

          HuxleyState2D s2D;
          s2D.init(m_pImportModel.parametar[2]);
          m_pImportModel.model[0]->Calculate(&s2D,ev,sigma,dsigmade);
          getchar();

       *///END TEST

    printf("Starting ... scenario=%d\n",Globals::scenario);
    char hostname[128];
    gethostname(hostname, sizeof(hostname));

#if num_TIPF1 == 1
    printf("_TIPF1 double\n");
#else
    printf("_TIPF1 float\n");
#endif

#ifdef imaCUDA
    printf("vidi haveCUDA %d\n",imaCUDA==1);
#else
	printf("ne vidi haveCUDA\n");
#endif
    switch(Globals::scenario){
	case Sekvencijalno:
	{
                            printf("Zapoceo sekvencijalno\n");
                            Sequential manager(&f,&chunkCalc);
							f.run(&manager);
                            printf("sequential \t IterationCount = %ld\n",chunkCalc.allIterationCount);
	}
                            break;
	case MPIparalelno:
	{						MPI::Init();
							int mpi_SIZE = MPI::COMM_WORLD.Get_size ( );  printf("broj procesa %d \n",mpi_SIZE);
							int mpi_ID = MPI::COMM_WORLD.Get_rank ( );  printf("proces ID = %d \n",mpi_ID);
							if (mpi_ID==0)
	    						{
	    					 	MPIManager manager(&f,&chunkCalc);
							manager.createFileForChunk();
                                			printf("Napravio managera\n");
	    					 	manager.run();
	    						}
							else
							{
								MPIWorker worker(&chunkCalc);
								worker.createFileForChunk();
                                				printf("Napravio workera\n");
								worker.run();
							}
							MPI::Finalize ( );
	}
							break;
#ifdef imaCUDA
    case CUDAjedna:
    {						MPI::Init();
                            CUDARunType cudaRunTip = Globals::cudaRunTip;
							int mpi_SIZE = MPI::COMM_WORLD.Get_size ( );  printf("broj procesa %d \n",mpi_SIZE);
							int mpi_ID = MPI::COMM_WORLD.Get_rank ( );  printf("proces ID = %d \n",mpi_ID);
                            MMChunkCUDA chunkCUDA(&cudaRunTip);
                            printf("_____ tip CUDA calc. %s\n",(cudaRunTip==CUDARunCustom)?"Custom":"Thrust");

							if (mpi_ID==0  && mpi_SIZE==1)
	    					{
                                		MPIManager manager(&f,&chunkCUDA);
                                		manager.run();
	    					}
							else {
								printf("Broj MPI procesa mora biti 1\n");
							}
                            if (cudaRunTip==CUDARunCustom) printf("mpi_ID = %d \t IterationCount = %ld\n",mpi_ID,chunkCUDA.allIterationCount);
							MPI::Finalize ( );
	}
							break;
    case MPImixCUDA:
    {
                            MPI::Init();
                            int mpi_ID = MPI::COMM_WORLD.Get_rank ( );  //printf("proces ID = %d \n",mpi_ID);

                            CUDARunType cudaRunTip = Globals::cudaRunTip;
                            int jesamCuda = 0;
                            for (int i = 0; i < Globals::numOfCUDA; i++)
                                if (Globals::cudaMPIID[i]==mpi_ID) jesamCuda=1;

                            MMChunkCalculator *q;
                            MMChunkCUDA chunkCUDA(&cudaRunTip);
                            q = (jesamCuda)?(MMChunkCalculator *)&chunkCUDA:(MMChunkCalculator *)&chunkCalc;
                            if (mpi_ID==0)
                            {
                                MPIManager manager(&f,q);
                                manager.createFileForChunk();
                                printf("Running on %s - MANAGER rank:%d Cuda:%s\n",hostname,mpi_ID,(jesamCuda)?"da":"ne");
                                try {
                                    manager.run();
                                }
                                catch( const std::exception & ex ) {
                                    cerr << "Proces ";
                                    cerr << mpi_ID;
                                    cerr << ex.what() << endl;
                                }
                            }
                            else
                            {
                                MPIWorker worker(q);
                                worker.createFileForChunk();
                                printf("Running on %s - WORKER rank:%d Cuda:%s\n",hostname,mpi_ID,(jesamCuda)?"da":"ne");
                                try {
                                    worker.run();
                                }
                                catch( const std::exception & ex ) {
                                    cerr << "Proces ";
                                    cerr << mpi_ID;
                                    cerr << ex.what() << endl;
                                }
                            }
                            if (jesamCuda)
                                printf("\n mpi_ID = %d \t IterationCount = %ld\n",mpi_ID,chunkCUDA.allIterationCount);
                            else
                                printf("\n mpi_ID = %d \t IterationCount = %ld\n",mpi_ID,chunkCalc.allIterationCount);
                            MPI::Finalize ( );
    }
                            break;
#endif
    default:
                            printf("Navadeni scenario nije moguce izvrsiti\n");
                            break;
	}
    return 0;
}


