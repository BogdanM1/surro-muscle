#!/bin/sh

pbsnodes > freenodes.txt
freenodes=`python find_cn_ppn.py`

echo $freenodes