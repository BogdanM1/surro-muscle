/*
 * Math3d - The 3D Computer Graphics Math Library
 * Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
 * All rights reserved.
 *
 * This program is  free  software;  you can redistribute it and/or modify it
 * under the terms of the  GNU Lesser General Public License  as published by 
 * the  Free Software Foundation;  either version 2.1 of the License,  or (at 
 * your option) any later version.
 *
 * This  program  is  distributed in  the  hope that it will  be useful,  but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
 * License for more details.
 *
 * You should  have received  a copy of the GNU Lesser General Public License
 * along with  this program;  if not, write to the  Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: mplane.cpp,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
 */
#include "Stdafx.h"
#define _MATH3D_EXPORT
#include "mplane.h"
#include <math.h>


/*!
 *
 */
Math3d::MPlane::MPlane(const M3d& n, double d)
  : norm(n), dist(d) 
{
}


/*!
 *
 */
Math3d::MPlane::MPlane(const MPlane& p)
  : norm(p.norm), dist(p.dist) 
{
}


/*!
 *
 */
const Math3d::MPlane& 
Math3d::MPlane::operator=(const MPlane& p)
{
  norm=p.norm;
  dist=p.dist;
  return(*this);
}


/*!
 *
 */
void 
Math3d::MPlane::copy(const MPlane& p)
{
  norm=p.norm;
  dist=p.dist;
}


/*!
 *
 */
bool 
Math3d::MPlane::operator==(const MPlane& p) const
{
  return(cmp(p));
}


/*!
 *
 */
bool 
Math3d::MPlane::operator!=(const MPlane& p) const
{
  return(!cmp(p));
}


/*!
 *
 */
bool 
Math3d::MPlane::cmp(const MPlane& p, double epsilon) const
{
  return(
    norm.cmp(p.norm) &&
    (fabs(dist-p.dist)<epsilon)
  );
}
