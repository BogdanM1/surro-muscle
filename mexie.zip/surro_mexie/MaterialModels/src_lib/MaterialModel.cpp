/*
 * MaterialModel.cpp
 *
 *  Created on: Aug 7, 2013
 *      Author: anakaplarevic
 */

#include "MaterialModel.h"

MaterialModel::MaterialModel() {
	// TODO Auto-generated constructor stub

}

MaterialModel::~MaterialModel() {
	// TODO Auto-generated destructor stub
}

void MaterialModel::getCountOfIterations(int& countV,int& countVPert){
    countV = -1;
    countVPert = -1;
}

_TIP MaterialModel::getCurrForce(MaterialModelState *s)
{
     return -111111;	
}

void MaterialModel::getV(_TIP* V, _TIP* VP)
{
	*V=-1111111;
	*VP=-1111111;	
}
