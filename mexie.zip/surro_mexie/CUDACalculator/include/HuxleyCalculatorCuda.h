
#ifndef CUDACALCULATOR_H_
#define CUDACALCULATOR_H_



#include <cuda.h>
#include <cuda_runtime.h>
#include <device_launch_parameters.h>
#include <sys/time.h>
#include <stdio.h>
#include <vector>

#include "HuxleyParameters.h"
#include "kernels.h"


#define _TIP float
#define NDIM 8192
#define MAX_ITER 1000


class HuxleyCalculatorCuda
{

public:
	HuxleyCalculatorCuda();
	HuxleyCalculatorCuda(int k);
	HuxleyCalculatorCuda(int k, HuxleyParameters* param);
	virtual ~HuxleyCalculatorCuda();

	virtual void Initialize()=0;
	virtual void Initialize(int)=0;
	virtual void Initialize(int k, HuxleyParameters* param)=0;
	virtual void Remash(int)=0;
	// virtual int Iteration(int, float, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2)=0;
	virtual int Iteration(int, float)=0;
	// virtual void Simulate(int i, float v, float time, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2)=0;
	virtual void Simulate(int i, float v, float time)=0;
	// virtual void Calculate(std::vector<float> es, float time, std::vector<float> m_f1, std::vector<float> m_g1, std::vector<float> m_g2)=0;
	virtual void Calculate(std::vector<float> es, float time)=0;
	virtual void SetToNew(int)=0;
	virtual void SetToNew()=0;
	virtual float getForce(int)=0;
	virtual void getForce(std::vector<float>&)=0;
	virtual void check()=0;

	virtual std::vector<_TIP> Get_X(int)=0;
	virtual std::vector<_TIP> Get_N(int)=0;
	virtual void Get_X(int i,std::vector<_TIP>& r)=0;
	virtual void Get_N(int i,std::vector<_TIP>& r)=0;

    void getCountOfIterations(long& count);

    long count;
};

#endif /* CUDACALCULATOR_H_ */
