// -*- c++ -*-
#ifndef INCLUDED_MATH3D_MPLANE_H
#define INCLUDED_MATH3D_MPLANE_H
/*
* Math3d - The 3D Computer Graphics Math Library
* Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
* All rights reserved.
*
* This program is  free  software;  you can redistribute it and/or modify it
* under the terms of the  GNU Lesser General Public License  as published by 
* the  Free Software Foundation;  either version 2.1 of the License,  or (at 
* your option) any later version.
*
* This  program  is  distributed in  the  hope that it will  be useful,  but
* WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
* or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
* License for more details.
*
* You should  have received  a copy of the GNU Lesser General Public License
* along with  this program;  if not, write to the  Free Software Foundation,
* Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* $Id: mplane.h,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
*/

#ifndef INCLUDED_MATH3D_M3D_H
#include "m3d.h"
#endif

namespace Math3d {
	
/**
* 3-dimensional plane.
	*/
	class _CCMATH3D MPlane {
    public:
		M3d norm;
		double dist;
		MPlane() {}
		MPlane(const M3d & n, double d);
		MPlane(const MPlane & p);
		
		/** Initialization from normal vector and point that lies on plane */
		void Init(const M3d & normal, const M3d & point)
		{
			norm = normal;
			norm.Normalize();
			dist = -norm.dot(point);
		}
		
		/** Initialization from normal vector and negative distance of a plane from (0,0,0) */
		void Init(const M3d & normal, double distance)
		{
			norm = normal;
			norm.Normalize();
			dist = distance;
		}

		/** Initialization from triangle - three points */
		void Init(const M3d & p0, const M3d & p1, const M3d & p2)
		{
			Init((p1 - p0).Cross(p2 - p0), p0);
		}
		
		double Distance(const M3d & p) const
		{
			return (p.dot(norm) + dist);
		}

		void ProjectPoint(M3d & p)
		{
			p -= norm * Distance(p);
		}
		
		/** Finds intersection of plane and a line defined by two points.
		*	returns:
		*	-1	-	no intersection
		*	0	-	point 0 lies on the plane - res is p0
		*	1	-	point 1 lies on the plane - res is p1
		*	2	-	complete line is on the plane
		*	3	-	intersection is exactly one point returned in res
		*/
		int IntersectLine(const M3d & p0, const M3d & p1, M3d & res) const
		{
			double d0 = Distance(p0);
			double d1 = Distance(p1);
			
			if (d1*d0 > 0) return -1;//no intersect
			
			double ad0 = d0*d0;
			double ad1 = d1*d1;
			
			if (ad0 < 1e-25)
			{//p0 lying
				if (ad1 < 1e-25)
				{//p1 lying also
					return 2; // p0 and p1 lying, no res
				}
				else
				{
					res = p0;
					return 0; // p0 lying, res is p0
				}
			}
			else
			{
				if (ad1 < 1e-25)
				{//p1 lying
					res = p1;
					return 1; // p1 lying, res is p1
				}
				//calculations for regular intersect!!!
				double d = d0 - d1;
				double k0 = (d0 / d);
				//res = p1*k0 + p0*(1-k0);
				res = (p1-p0)*k0 + p0;
				return 3; //line intersects, intersection point is in res
			}
		}
		
		const MPlane& operator=(const MPlane& p);
		void copy(const MPlane& p);
		
		bool operator==(const MPlane& p) const;
		bool operator!=(const MPlane& p) const;
		bool cmp(const MPlane& p, double epsilon=EPSILON) const;
	};
	
}
#endif // INCLUDED_MATH3D_MPLANE_H
