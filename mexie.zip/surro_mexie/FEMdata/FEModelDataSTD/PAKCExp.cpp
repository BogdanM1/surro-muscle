// PAKExp.cpp: Functions for export to PAK's DAT file.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "FEModelData.h"
#include "PAKExp.h"
#include "PAKCExp.h"
#include "BlockIDs.h"
#include "PakExpOption.h"
#include "math.h"
#include "StringAdvanced.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


///////////////////////////////////////////////////////////////////////////////////////////////////
//Vlada 2006-10-17  Export PAK-C za potrebe Veliborovog diplomskog rada (iskopirani ExportPAKS)
//
UINT CModelData::ExportPAK_C(MyFile& file,CPakExpOption *peo)
{
	MyString str;
	UINT uNGELEM;
	UINT i;
	long lGeneralDataPos;


	if((m_NodArray.GetSize())<=0)
	{
		//AfxMessageBox(PAKC_NO_NODES);
		printf(PAKC_NO_NODES);
		return(0);	
	};
	
	if((uNGELEM=m_PropArray.GetSize())<=0)
	{
		//AfxMessageBox(PAKC_NO_GROUPS);
		printf(PAKC_NO_GROUPS);
		return(0);	
	};

	//	Card /1/
	file.WriteString(PAKC_CardH1);
	file.WriteString(PAKC_CardV1);
	file.WriteString(m_PakGeneral.GetTitle()+"\n");

	//	Card /2/
	file.WriteString(PAKC_CardH2);
	file.WriteString(PAKC_CardV2);
	str.Format("%5u\n",PAKC_INDFOR);
	file.WriteString(str);

	//	Card /3/
 	file.WriteString(PAKC_CardH3);
	file.WriteString(PAKC_CardV3);
	lGeneralDataPos=file.GetPosition();
	str.Format("                              \n");
	file.WriteString(str);

	//	Card /4/
 	file.WriteString(PAKC_CardH4);
	file.WriteString(PAKC_CardV4);
	str.Format("%5u%5u%5u%5u%10.6f%10.6f%5u\n",	PAKC_INTEB, PAKC_INDSC, PAKC_IFORM, PAKC_MAXIT,
												PAKC_EPSTA, PAKC_EPSTR, PAKC_NJRAP);
	file.WriteString(str);

	//	Card /5/
 	file.WriteString(PAKC_CardH5);
	file.WriteString(PAKC_CardV5);
	str.Format("%5u\n",PAKC_IREST);
	file.WriteString(str);

	//	Card /6/
 	file.WriteString(PAKC_CardH6);
//	file.WriteString(PAKC_CardV6);
	for(i = 1; i <= (UINT)m_PakGeneral.GetNumOfPeriods(); i++)
	{
		str.Format("%5u%10.6f\n", m_PakGeneral.GetNumSteps(i-1),m_PakGeneral.GetStep(i-1));
		file.WriteString(str);
	}

	//	Card /7/
	ExportPAKC_Nodes(file);

	//	Card /8/
	MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> FEMAP2PAK_MaterialMap;
	ExportPAKC_Elements(file,&uNGELEM,FEMAP2PAK_MaterialMap,peo);

	//	Card /9/
 	file.WriteString(PAKC_CardH9);
	ExportPAKC_PrescribedValues(file);

	//	Card /10/ - Inicijalne vrednosti.
	double dQx = 0.0;
	double dQy = 0.0;
	double dQz = 0.0;
	double dP  = 0.0;
 	file.WriteString(PAKC_CardH10);
	file.WriteString(PAKC_CardV10);
	str.Format("%10.3lf%10.3lf%10.3lf%10.3lf\n",dQx, dQy, dQz, dP);
	file.WriteString(str);

	//	Card /11/
	ExportPAKC_BoundaryConditions( file );

	//	Card /12/
	UINT nModelCount;
	ExportPAKC_Materials(file,nModelCount,FEMAP2PAK_MaterialMap);

	//	Card /13/
	ExportPAKC_TimeFunctions(file);

	//	Card /14/
	file.WriteString(PAKC_CardH14);
	file.WriteString(PAKC_CardV14);

	//	Card /15/
	ExportPAKC_Forces(file);

	//	Card /16/
	file.WriteString(PAKC_CardH16);
	file.WriteString(PAKC_CardV16);

	//	Upisivanje naknadno
	//	P R I V R E M E N O

	file.Seek(lGeneralDataPos,SEEK_SET);

	str.Format("%5u%5u%5u%5u%5u%5u",m_NodArray.GetSize(),PAKC_NGET, PAKC_NMATM,
		(int)m_PakGeneral.GetDynamicAnIsSet(), m_PakGeneral.GetNumOfPeriods(),
		PAKC_NPRINT, PAKC_NKRT);

	file.WriteString(str);
	file.Seek(0,SEEK_END);

	return(-1);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

UINT CModelData::ExportPAKC_Elements(MyFile& file,UINT *uNGELEM,MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap,CPakExpOption *peo)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT i,j,k;
	//UINT uNMODM,uMatIID;
	MyArray <UINT,UINT&> ElNum;
	MyMap<UINT,UINT,UINT,UINT> PropIndex; // relation between Property ID and it's position in ElNum;
	HElement el;
	PAK_MaterialKey mms;

	UINT nCounter = 0;
	HProperties pr;
	for(i = 0; i < (UINT) m_PropArray.GetSize(); i++)	//Loop by properties (group of elements)
	{
		pr = m_PropArray[i];

//		FEMAP2PAK_MaterialMap.Lookup(pr.m_uMatIID, mms);	//Struktura cuva materijalni model i materijal

		switch (pr.m_Type)
		{
		//****************************************************************************
		//****************************** 2D Elementi *********************************
		//****************************************************************************
/*
		case FET_SHEAR_LIN:case FET_SHEAR_PAR:
		case FET_MEMBRANE_LIN:case FET_MEMBRANE_PAR:
		case FET_BENDING_LIN:case FET_BENDING_PAR:
		case FET_PLATE_LIN:case FET_PLATE_PAR:
		case FET_PLANESTRAIN_LIN:case FET_PLANESTRAIN_PAR:
		case FET_LAMINATE_LIN:case FET_LAMINATE_PAR:
		case FET_AXISYM_LIN:case FET_AXISYM_PAR:
			{
				UINT uNE4=0,uNE3=0;

				switch (pr.m_uType)
				{
					case FET_SHEAR_LIN:case FET_SHEAR_PAR: uIETYP=4;
						break;
					case FET_MEMBRANE_LIN:case FET_MEMBRANE_PAR: uIETYP=0;
						break;
					case FET_PLANESTRAIN_LIN:case FET_PLANESTRAIN_PAR: uIETYP=2;
						break;
					case FET_AXISYM_LIN:case FET_AXISYM_PAR: uIETYP=1;
						break;
				}

				for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						if(m_ElArray[j].m_uTopology==FETO_QUAD4 || m_ElArray[j].m_uTopology==FETO_QUAD8) uNE4++;
						else uNE3++;
					}

				if(uNE4>0)	//Cetvorougaoni 2D Element
				{
				 //Card /8-1/
				 if(pr.m_uType==FET_BENDING_LIN || pr.m_uType==FET_BENDING_PAR ||
					pr.m_uType==FET_PLATE_LIN || pr.m_uType==FET_PLATE_PAR ||
					pr.m_uType==FET_LAMINATE_LIN || pr.m_uType==FET_LAMINATE_PAR) uNETIP=(peo->m_b4N2BD ? PAK_SHELL_BD : PAK_ISO_SHELL); 
				 else uNETIP=PAK_ISO_2D;

				 file.WriteString(PAKC_CardH13);
				 file.WriteString(PAKSC_CardV13);

//					 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE4,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);
				 int iIALFA=0;		//Bez inkompatibilnih pomeranja: int iIALFA=-1;	

				 // Beta - angle of first material axis
				 double dBeta = 0.0;
				 if( pr.m_dValue.GetSize() >= 2 ) dBeta = pr.m_dValue[1];

				 if(uNETIP==PAK_ISO_2D)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,dBeta,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,iIALFA);
				 }
				 else
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5d%5u%10.6f%5u%10.6f%10.6f%10.6f%5d\n",
					  PAKS_NGAUSX2,PAKS_NGAUSY2,(peo->m_bDrillShell ? -2 : PAKS_NGAUSZ2),
					  PAKS_MSET,dBeta,PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,iIALFA);
				 }
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_QUAD4 || el.m_uTopology==FETO_QUAD8)
						{
							UINT uIPGS=1;
							str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,uIPGS,pr.m_dValue[0],
								PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<FEM_Top[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[k]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}

				if(uNE3>0)	// Trougaoni 2D Element
				{
				 if(uNE4>0) (*uNGELEM)++;
				 //Card /13/
				 if(pr.m_uType==FET_BENDING_LIN || pr.m_uType==FET_BENDING_PAR ||
					pr.m_uType==FET_PLATE_LIN || pr.m_uType==FET_PLATE_PAR ||
					pr.m_uType==FET_LAMINATE_LIN || pr.m_uType==FET_LAMINATE_PAR) uNETIP=PAK_ISO_TRI_SHELL; 
				 else uNETIP=PAK_ISO_TRI;

				 file.WriteString(PAKS_CardH13);
				 file.WriteString(PAKS_CardV13);

//				 uNMODM=m_PakGeneral.GetMaterialModel(uNETIP);

				 str.Format("%5u%5u%5u%5u%5u%5u%5u%10.6f%10.6f%10.6f\n",
				 uNETIP,uNE3,pr.m_AnalysisType,mms.m_nModel,PAKS_INDBTH,PAKS_INDDTH,
				 PAKS_INDKOV,PAKS_COEF1,PAKS_COEF2,PAKS_COEF3);
				 file.WriteString(str);

				 file.WriteString(PAKS_CardH13_2);
				 file.WriteString(PAKS_CardV13_2_a_1);

				 if(uNETIP==PAK_ISO_TRI)
				 {
				  file.WriteString(PAKS_CardV13_2_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					uIETYP,PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_MSET,PAKS_BETA,
					PAKS_MSLOJ,PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,PAKS_IALFA);
				 }
				 {
				  file.WriteString(PAKS_CardV13_8_a_2);
				  str.Format("%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f%10.6f%5u\n",
					PAKS_NGAUSX2,PAKS_NGAUSY2,PAKS_NGAUSZ2,PAKS_MSET,PAKS_BETA,PAKS_MSLOJ,
					PAKS_CPP1,PAKS_CPP2,PAKS_CPP3,PAKS_IALFA);
				 }
				 file.WriteString(str);

				 file.WriteString(PAKS_CardV13_2_b_1);
				 file.WriteString(PAKS_CardV13_2_b_2);
				 file.WriteString(PAKS_CardV13_2_c_1);
				 file.WriteString(PAKS_CardV13_2_c_2);

				 for(j=0;j<(UINT)m_ElArray.GetSize();j++)
				 if(m_ElArray[j].m_uPropID==pr.m_nID)
					{
						el=m_ElArray[j];
//						pr = m_PropArray[m_nPropIndex[el.m_uPropID]];

						if(el.m_uTopology==FETO_TRI3 || el.m_uTopology==FETO_TRI6)
						{
							str.Format("%5u%5u%5u%5u%5u%10.6f%5u%10.6f%10.6f\n",
								el.m_nID,mms.m_nMaterial,PAKS_IPRCO,PAKS_ISNA,PAKS_IPGS,pr.m_dValue[0],
								PAKS_KORC,PAKS_BTH,PAKS_DTH);
							file.WriteString(str);
							for(k=0;k<FEM_Top[el.m_uTopology];k++) 
							{
								str.Format("%5u",el.m_uNode[k]);
								file.WriteString(str);
							}
							file.WriteString("\n");
						}
					}
				}				

			}
			break;


*/
//****************************************************************************
//******************************* 2D Elementi ********************************
//****************************************************************************
		case HProperties::PT_SHEAR_LIN:case HProperties::PT_SHEAR_PAR:
		case HProperties::PT_MEMBRANE_LIN:case HProperties::PT_MEMBRANE_PAR:
		case HProperties::PT_BENDING_LIN:case HProperties::PT_BENDING_PAR:
		case HProperties::PT_PLATE_LIN:case HProperties::PT_PLATE_PAR:
		case HProperties::PT_PLANESTRAIN_LIN:case HProperties::PT_PLANESTRAIN_PAR:
		case HProperties::PT_LAMINATE_LIN:case HProperties::PT_LAMINATE_PAR:
		case HProperties::PT_AXISYM_LIN:case HProperties::PT_AXISYM_PAR: 
		case HProperties::PT_MEMBRANE_PAR_9: case HProperties::PT_MEMBRANE_LIN_5:
			{
				//Card /8/
				if(nCounter == 0)
				{
					UINT nElCount = m_ElArray.GetSize();
					file.WriteString(PAKC_CardH8);
					file.WriteString(PAKC_CardV8);

					UINT nINDAX  = 0;	//
					UINT nIATYP  = 0;	//
					UINT nNMODM  = 0;	//
					UINT nIPN	 = 0;	//
					UINT nIPOROS = 0;	//	Indicator for variable porosity
					UINT nISWELL = 0;	//	Indicator for swelling pressure

					UINT nMaterialModelCount = 1;		//
					UINT nMaterialCount = *uNGELEM;		//
					UINT nNodeCount = 0;				//

					nIPOROS = pr.m_uFlag[0];
					nISWELL = pr.m_uFlag[1];
					nINDAX = pr.m_uFlag[2];

					switch (pr.m_AnalysisType)
					{
						case HProperties::AT_LINEAR:				nIATYP = 1;	break;
						case HProperties::AT_TOTAL_LAGRANGIAN:		nIATYP = 2;	break;
						case HProperties::AT_UPDATED_LAGRANGIAN:	nIATYP = 3;	break;
						case HProperties::AT_LARGE_STRAIN_UL:		nIATYP = 4;	break;
						case HProperties::AT_LARGE_STRAIN_TL:		nIATYP = 4;	break;
					}

					switch (pr.m_Type)
					{
						case HProperties::PT_MEMBRANE_LIN:		nNodeCount = 4;		nIPN = 4;	break;
						case HProperties::PT_MEMBRANE_LIN_5:	nNodeCount = 4;		nIPN = 1;	break;
						case HProperties::PT_MEMBRANE_PAR_9:	nNodeCount = 9;		nIPN = 4;	break;
					}

					str.Format("%5u%5u%5u%5u%5u%5u%5u\n", PAK_ISO_2D, nElCount, nINDAX, nIATYP, nNMODM, nIPN, nIPOROS);
					file.WriteString(str);

					file.WriteString(PAKC_CardH8_1);
					file.WriteString(PAKC_CardV8_1);
					str.Format("%5u%5u%5u%5u\n", nMaterialModelCount, nMaterialCount, nNodeCount, nISWELL);
					file.WriteString(str);



					if(nISWELL == 1)
					{
						// Constants for water-content approach (This card used if nISWELL == 1)
						double dSWELLA, dSWELLB, dSWELLC;
						// Initial swelling pressure
						double dPC0;

						dSWELLA = pr.m_dValue[1];
						dSWELLB = pr.m_dValue[2];
						dSWELLC = pr.m_dValue[3];
						dPC0  = pr.m_dValue[4];

						str.Format(PAKC_CardH8_3);
						file.WriteString(str);
						p_str.Format("%10.4.1e%10.4.1e%10.4.1e%10.4.1e\n", dSWELLA, dSWELLB, dSWELLC, dPC0);
						file.WriteString(p_str);
					}

					if(nISWELL == 2)
					{
						// Coefficient of chemical contraction
						double dALFAC = 0.0;
						str.Format("%10.5lf", dALFAC);
						file.WriteString(str);
					}

					file.WriteString(PAKC_CardH8_2);
					file.WriteString(PAKC_CardV8_2);
				}

				nCounter++;

				for(j = 0; j < (UINT)m_ElArray.GetSize(); j++)
				{
					if(m_ElArray[j].m_uPropID == pr.m_nID)
					{
						el = m_ElArray[j];

						str.Format("%5u", el.m_nID);
						file.WriteString(str);
						for(k=0;k<4;k++) 
						{
							str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[k]]);
							file.WriteString(str);
						}
						if(el.m_uTopology==FETO_QUAD9)
						{
							for(k=4;k<9;k++) 
							{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[k]]);
								file.WriteString(str);
							}
				//			str.Format("%5u",el.m_uNode[5]);
				//			file.WriteString(str);
						}

						if(el.m_uTopology==FETO_QUAD5)
						{
								str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder2D[8]]);
								file.WriteString(str);
						}

						str.Format("%5u%10.5lf\n", pr.m_uMatIID, pr.m_dValue[0]);
						file.WriteString(str);
					}
				}

				break;
			}

	//****************************************************************************
	//******************************* 3D Elementi ********************************
	//****************************************************************************
		case HProperties::PT_3D_LIN_9: case HProperties::PT_3D_LIN:
			{
				//Card /8/
				if(nCounter == 0)
				{
					UINT nElCount = m_ElArray.GetSize();
					file.WriteString(PAKC_CardH8);
					file.WriteString(PAKC_CardV8);

					UINT nINDAX  = 0;	//
					UINT nIATYP  = 0;	//
					UINT nNMODM  = 0;	//
					UINT nIPN	 = 0;	//
					UINT nIPOROS = 0;	//	Indicator for variable porosity
					UINT nISWELL = 0;	//	Indicator for swelling pressure

					UINT nMaterialModelCount = 1;		//
					UINT nMaterialCount = *uNGELEM;		//
					UINT nNodeCount = 0;				//

					nIPOROS = pr.m_uFlag[0];
					nISWELL = pr.m_uFlag[1];

					switch (pr.m_AnalysisType)
					{
						case HProperties::AT_LINEAR:				nIATYP = 1;	break;
						case HProperties::AT_TOTAL_LAGRANGIAN:		nIATYP = 2;	break;
						case HProperties::AT_UPDATED_LAGRANGIAN:	nIATYP = 3;	break;
						case HProperties::AT_LARGE_STRAIN_UL:		nIATYP = 4;	break;
						case HProperties::AT_LARGE_STRAIN_TL:		nIATYP = 4;	break;
					}

					switch (pr.m_Type)
					{
						case HProperties::PT_3D_LIN_9:	nNodeCount = 8;		nIPN = 1;	break;
						case HProperties::PT_3D_LIN:	nNodeCount = 8;		nIPN = 8;	break;
					}


					str.Format("%5u%5u%5u%5u%5u%5u%5u\n", PAK_ISO_3D, nElCount, nINDAX, nIATYP, nNMODM, nIPN, nIPOROS);
					file.WriteString(str);
			
					file.WriteString(PAKC_CardH8_1);
					file.WriteString(PAKC_CardV8_1);
					str.Format("%5u%5u%5u%5u\n", nMaterialModelCount, nMaterialCount, nNodeCount, nISWELL);
					file.WriteString(str);



					if(nISWELL == 1)
					{
						// Constants for water-content approach (This card used if nISWELL == 1)
						double dSWELLA, dSWELLB, dSWELLC;
						// Initial swelling pressure
						double dPC0;

						dSWELLA = pr.m_dValue[1];
						dSWELLB = pr.m_dValue[2];
						dSWELLC = pr.m_dValue[3];
						dPC0  = pr.m_dValue[4];
						str.Format("%10.3lf%10.3lf%10.3lf%10.3lf\n", dSWELLA, dSWELLB, dSWELLC, dPC0);
						file.WriteString(str);
					}

					if(nISWELL == 2)
					{
						// Coefficient of chemical contraction
						double dALFAC = 0.0;
						str.Format("%10.3lf", dALFAC);
						file.WriteString(str);
					}

					file.WriteString(PAKC_CardH8_2);
					file.WriteString(PAKC_CardV8_2);
				}

				nCounter++;

				for(j = 0; j < (UINT)m_ElArray.GetSize(); j++)
				{
					if(m_ElArray[j].m_uPropID == pr.m_nID)
					{
						el = m_ElArray[j];

						str.Format("%5u", el.m_nID);
						file.WriteString(str);
						for(k=0;k<8;k++) 
						{
							str.Format("%5u",el.m_uNode[PAK2FEMAP_NodeOrder3D[k]]);
							file.WriteString(str);
						}
						if(el.m_uTopology==FETO_BRICK9)
						{
							str.Format("%5u",el.m_uNode[8]);
							file.WriteString(str);
						}

						str.Format("%5u\n", pr.m_uMatIID);
						file.WriteString(str);
					}
				}

				break;
			}
		}	// End of swich ( pr.m_uType )
	}		// End of loop over elements

	return(-1);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////
//Vlada
UINT CModelData::ExportPAKC_Nodes(MyFile& file)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT i;
	HNodes nn;

	//	Card /10/
 	file.WriteString(PAKC_CardH7);
	file.WriteString(PAKC_CardV7);

	UINT nNodeCount = m_NodArray.GetSize();

	if (0)/*	fabs(m_NodArray[0].m_dX - m_NodArray[nNodeCount - 1].m_dX) > 0.0001	||
			fabs(m_NodArray[0].m_dY - m_NodArray[nNodeCount - 1].m_dY) > 0.0001	||
			fabs(m_NodArray[0].m_dZ - m_NodArray[nNodeCount - 1].m_dZ) > 0.0001		)*/
	{
		for(i = 0; i < nNodeCount; i++)
		{
			nn = m_NodArray[i];
		
			str.Format("%5u %2u%2u%2u%2u%2u%2u%2u%2u  %10.6lf%10.6lf%10.6lf%2u%2u%2u\n",
						nn.m_nID, nn.m_bPermbc[0],nn.m_bPermbc[1],nn.m_bPermbc[2],
						nn.m_bPermbc[3], nn.m_bPermbc[4], nn.m_bPermbc[5],
						nn.m_bPermbc[6], nn.m_bPermbc[7],
						nn.m_dX, nn.m_dY, nn.m_dZ,
						nn.m_bPermbc[8], nn.m_bPermbc[9], nn.m_bPermbc[10]);
			file.WriteString(str);
		}
	}
	else
	{
		for(i = 0; i < nNodeCount; i++)
		{
			nn = m_NodArray[i];

			p_str.Format("%5u %2u%2u%2u%2u%2u%2u%2u%2u  %10.3.2e%10.3.2e%10.3.2e%2u%2u%2u\n",
						nn.m_nID, nn.m_bPermbc[0],nn.m_bPermbc[1],nn.m_bPermbc[2],
						nn.m_bPermbc[3], nn.m_bPermbc[4], nn.m_bPermbc[5],
						nn.m_bPermbc[6], nn.m_bPermbc[7],
						nn.m_dX, nn.m_dY, nn.m_dZ,
						nn.m_bPermbc[8], nn.m_bPermbc[9], nn.m_bPermbc[10]);
			file.WriteString(p_str);
		}
	}

	return(-1);
}

UINT CModelData::ExportPAKC_Materials(MyFile& file, UINT &nModelCount, MyMap<UINT,UINT,PAK_MaterialKey,PAK_MaterialKey> &FEMAP2PAK_MaterialMap)
{
	// PakC - /12-1/a: m_uFK[0] = INDJOT
	// PakC - /12-1/c:	m_dK[0] = Ro_f,  m_dK[1] = n,  m_dK[2] = k,
	//				m_dK[3] = Ks,    m_dK[4] = Kf, m_dK[5] = ;	Material constants
	// PAKC - /12-1/d:	m_dAlpha[0] = B11, m_dAlpha[1] = B12, 
	//				m_dAlpha[2] = B21, m_dAlpha[3] = B22;	Constants about electrokinetic coupling
	
	MyString str;
	MyStringAdvanced p_str;

	//	Card /12/
	file.WriteString(PAKC_CardH12);
	file.WriteString(PAKC_CardV12);

	UINT nMaterialCount = m_MaterialsArray.GetSize();
	
	str.Format("%5u\n", nMaterialCount);
	file.WriteString(str);
	
	for(UINT i = 0; i < nMaterialCount; i++)
	{
//		str.Format("C /12-1/ MATERIAL CONSTANTS FOR MATERIAL %d", i + 1);
//		file.WriteString(str);

		HMaterial &Material = m_MaterialsArray[i];
		
		switch (Material.m_uType)
		{
		case HMaterial::MT_FEMAP_OTHER:
			{
				switch (Material.m_uSubType)
				{
				case HMaterial::ST_PAK_POROUS_DEFORMABLE:
					{
						//	Card /12-1/
 						file.WriteString(PAKC_CardH12_1);
						str.Format(" %d\n", i + 1);
						file.WriteString(str);
						file.WriteString(PAKC_CardV12_1);

						UINT nINDJOT = Material.m_uFK[0];
						str.Format("%5u%5u%5u\n", 1, i + 1, nINDJOT);
						file.WriteString(str);

						file.WriteString(PAKC_CardV12_1_1_a);
						p_str.Format("%10.3.2e%10.3.2e%10.3.2e%10.3.2e\n",Material.m_dE[0], Material.m_dNu[0], Material.m_dDensity, Material.m_dK[0]);
						file.WriteString(p_str);

						file.WriteString(PAKC_CardV12_1_1_b);
						p_str.Format("%10.3.2e%10.3.2e%10.3.2e%10.3.2e\n",Material.m_dK[1], Material.m_dK[2], Material.m_dK[3], Material.m_dK[4]);
						file.WriteString(p_str);

						if ( nINDJOT == 1 )
						{
							file.WriteString(PAKC_CardV12_1_1_d);
							p_str.Format("%10.3.2e%10.3.2e%10.3.2e%10.3.2e\n",Material.m_dAlpha[0], Material.m_dAlpha[1], Material.m_dAlpha[2], Material.m_dAlpha[3]);
							file.WriteString(p_str);
						}
					}
					break;

				default:
					ASSERT(FALSE);
				}
			}
			break;

		default:
			ASSERT(FALSE);
		}
	}

	return(-1);
}

UINT CModelData::ExportPAKC_TimeFunctions(MyFile& file)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT i,j,uMAXTFT=0;

	//Check the total number of time functions
	UINT nTimeFunctionCount = 0;
	for(i=0;i<(UINT)m_FunctionsArray.GetSize();i++)
	{
		if(m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_VS_TIME || m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME)
			nTimeFunctionCount++;
	}


	if(nTimeFunctionCount==0)
	{
		HFunctions new_function;
		FunctionEntry fun_entry;

		fun_entry.m_dX=0.;
		fun_entry.m_dY=1.;
		new_function.m_FunctionEntry.Add(fun_entry);
		fun_entry.m_dX=10000.;
		fun_entry.m_dY=1.;
		new_function.m_FunctionEntry.Add(fun_entry);

		new_function.m_nID = 1;
		new_function.m_uFunc_type = HFunctions::FT_VS_TIME;

		m_FunctionsArray.Add(new_function);
		nTimeFunctionCount++;
	}

	//Determine maximum number of points
	for(i=0;i<(UINT)m_FunctionsArray.GetSize();i++)
	{
		if((m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_VS_TIME) || (m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME))
		{
			if((UINT)m_FunctionsArray[i].m_FunctionEntry.GetSize()>uMAXTFT)
				uMAXTFT=m_FunctionsArray[i].m_FunctionEntry.GetSize();
		}
	}

	file.WriteString(PAKC_CardH13);
	file.WriteString(PAKC_CardV13);
	str.Format("%5u%5u\n", nTimeFunctionCount, uMAXTFT);
	file.WriteString(str);
	file.WriteString(PAKC_CardH13_1);
	UINT nPAKFuncID = 0;
	for(i = 0; i < (UINT)m_FunctionsArray.GetSize(); i++)
	{
		if((m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_VS_TIME) || (m_FunctionsArray[i].m_uFunc_type == HFunctions::FT_DISPLACEMENT_VS_TIME))
		{
			nPAKFuncID++;
			file.WriteString(PAKC_CardV13_1_a_1);
			file.WriteString(PAKC_CardV13_1_a_2);
//			str.Format("%5u%5u\n",m_FunctionsArray[i].m_nID,m_FunctionsArray[i].m_FunctionEntry.GetSize());
			str.Format("%5u%5u\n",nPAKFuncID,m_FunctionsArray[i].m_FunctionEntry.GetSize());
			file.WriteString(str);
			file.WriteString(PAKC_CardV13_1_b_1);
			file.WriteString(PAKC_CardV13_1_b_2);
			for(j=0;j<(UINT)m_FunctionsArray[i].m_FunctionEntry.GetSize();j++)
			{
				p_str.Format("%10.3.2e%10.3.2e\n",m_FunctionsArray[i].m_FunctionEntry[j].m_dX,
											m_FunctionsArray[i].m_FunctionEntry[j].m_dY);
				file.WriteString(p_str);
			}
		}
	}
	return (-1);
}

UINT CModelData::ExportPAKC_BoundaryConditions( MyFile& file )
{
	MyString str;
	MyStringAdvanced p_str;

	UINT nPresureCount2D=0, nPresureCount3D=0, nCurrentDensityCount2D=0, nCurrentDensityCount3D=0, i, j, k;
	
	HLoads lo;
	StructLoad sl;
	HElement el;

	UINT surface_nodes_3d[6][8]={   {0,3,2,1,11,10,9,8},
									{4,5,6,7,16,17,18,19},
									{0,1,5,4,8,13,16,12},
									{1,2,6,5,9,14,17,13},
									{2,3,7,6,10,15,18,14},
									{3,0,4,7,11,12,19,15}	};


	UINT surface_nodes_2d[4][3]={   {0,1,4},
									{1,2,5},
									{2,3,6},
									{3,0,7}	};

	if(m_LoadArray.GetSize()==0) 
	{
		//AfxMessageBox(PAKS_NO_LOADS);
		printf(PAKS_NO_LOADS);
		str.Format("\n");
		file.WriteString (str);

		return(0);
	}
	lo = m_LoadArray[0];	//Za sada samo prvi set

	for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
	{
		sl = lo.m_StructLoads[i];
		switch(sl.m_uLoadtype)
		{
		case StructLoad::LT_ELEM_PRESS:
			{
				j = sl.m_uDof_face[0] - 1;
				if(fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					if(j < 2) nPresureCount3D++;
					else
					{
						el=m_ElArray.Get(sl.m_uLoadID);
						if(el.m_uTopology==FETO_BRICK8 || el.m_uTopology==FETO_BRICK20 || el.m_uTopology==FETO_BRICK9) nPresureCount3D++;
						else nPresureCount2D++;
					}
				}
			}
		break;
		case StructLoad::LT_ELEM_CURRENT_DENSITY:
			{
				j = sl.m_uDof_face[0] - 1;
				if(fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					if(j < 2) nCurrentDensityCount3D++;
					else
					{
						el=m_ElArray.Get(sl.m_uLoadID);
						if(el.m_uTopology==FETO_BRICK8 || el.m_uTopology==FETO_BRICK20 || el.m_uTopology==FETO_BRICK9) nCurrentDensityCount3D++;
						else nCurrentDensityCount2D++;
					}
				}
			}
		break;
		}
	}

	//	Card /11/
	file.WriteString(PAKC_CardH11);
	file.WriteString(PAKC_CardV11);

	// Line pressure
	if(nPresureCount2D > 0)
	{
		UINT nPresureOnSurface = 0;
		str.Format("%5u%5u\n", nPresureCount2D, nPresureOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_PRESS)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0] - 1;
				if(j>1 && fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_QUAD4: case FETO_QUAD5: case FETO_QUAD8: case FETO_QUAD9:
						{
							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k = 0; k < 2; k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_2d[j-2][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	// Surface pressure
	else if(nPresureCount3D > 0)
	{
		UINT nPresureOnSurface = 0;
		str.Format("%5u%5u\n", nPresureCount3D, nPresureOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_PRESS)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0]-1;
				if(fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_BRICK8: case FETO_BRICK9: case FETO_BRICK20:
						{
							//VLADA 2006-10-23 Eksportovanje pritiska u PAKC

							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k=0;k<(UINT)(el.m_uTopology==FETO_BRICK9 ? 4:8);k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_3d[j][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	// Line current density
	else if(nCurrentDensityCount2D > 0)
	{
		UINT nCurrentDensityOnSurface = 1;
		str.Format("%5u%5u\n", nCurrentDensityCount2D, nCurrentDensityOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_CURRENT_DENSITY)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0] - 1;
				if(fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_QUAD4: case FETO_QUAD5: case FETO_QUAD8: case FETO_QUAD9:
						{
							//VLADA 2006-10-23 Eksportovanje pritiska u PAKC

							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k = 0; k < 2; k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_2d[j-2][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	// Surface current density
	else if (nCurrentDensityCount3D > 0)
	{
		UINT nCurrentDensityOnSurface = 1;
		str.Format("%5u%5u\n", nCurrentDensityCount3D, nCurrentDensityOnSurface);
		file.WriteString(str);

		file.WriteString(PAKC_CardH11_1);

		for(i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_ELEM_CURRENT_DENSITY)
			{
				el = m_ElArray.Get(sl.m_uLoadID);
				j = sl.m_uDof_face[0]-1;
				if(fabs(sl.m_dValue[0])>=PAKS_LOAD_PRESS_TOL)
				{
					UINT nfun;
					nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
					bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
					ASSERT(bFound);
					
					switch(el.m_uTopology)
					{
					case FETO_BRICK8: case FETO_BRICK9: case FETO_BRICK20:
						{
							p_str.Format("%5u",el.m_nID);
							file.WriteString(p_str);
							for(k=0;k<(UINT)(el.m_uTopology==FETO_BRICK9 ? 4:8);k++)
							{
								p_str.Format("%5u",el.m_uNode[surface_nodes_3d[j][k]]);
								file.WriteString(p_str);
							}

							p_str.Format("%5u%10.4.1e%10.4.1e%10.4.1e%10.4.1e",nfun+1,
						 		sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0],sl.m_dValue[0]);

							file.WriteString(p_str);
							file.WriteString("\n");
						}
						break;
					}
				}
			}
		}
	}
	else
	{
		str.Format("    0    0\n");
		file.WriteString (str);
	}
	return (-1);
}

UINT CModelData::ExportPAKC_Forces(MyFile& file)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT uNCF=0, uNPP2=0, uNPP3=0, uNZADP=0, nElectricCurrent=0, i, j;
	HLoads lo;
	StructLoad sl;
	HElement el;

	
	if(m_LoadArray.GetSize()==0) 
	{
		//AfxMessageBox(PAKS_NO_LOADS);
		printf(PAKS_NO_LOADS);
		str.Format("\n");
		file.WriteString (str);

		return(0);
	}
	lo = m_LoadArray[0];	//Za sada samo prvi set

	for( i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
	{
		sl = lo.m_StructLoads[i];

		switch(sl.m_uLoadtype)
		{
		case StructLoad::LT_NODAL_FORCE:
			{
				for(j = 0; j < 6; j++)
				{
					if( sl.m_uDof_face[j] && (fabs(sl.m_dValue[j]) >= PAKS_LOAD_FORCE_TOL) )
						uNCF++;
				}
				break;
			}
		case StructLoad::LT_NODAL_ELECTRIC_CURRENT:
			{
				for(j = 0; j < 6; j++)
				{
					if( sl.m_uDof_face[j] && (fabs(sl.m_dValue[j]) >= PAKS_LOAD_FORCE_TOL) )
						nElectricCurrent++;
				}
				break;
			}
		}
	}

	if(uNCF > 0)
	{
		str.Format("%5u\n", uNCF);
		file.WriteString(str);
		file.WriteString(PAKC_CardH14_1);
		file.WriteString(PAKC_CardV14_1);
		for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
		{
			sl=lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_NODAL_FORCE)
			{
				for(j = 0; j < 6; j++)
				{
					if(sl.m_uDof_face[j] && fabs(sl.m_dValue[j])>=PAKS_LOAD_FORCE_TOL)
					{
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = m_FunctionsArray.FindIndex(nc,nc);
						ASSERT(bFound);
						p_str.Format( "%5u%5u%5u%10.4.1e\n", sl.m_uLoadID, j+1, nc+1, sl.m_dValue[j] );
						file.WriteString(p_str);
					}
				}
			}
		}
	}
	else if(nElectricCurrent > 0)
	{
		str.Format("%5u\n", nElectricCurrent);
		file.WriteString(str);
		file.WriteString(PAKC_CardH14_1);
		file.WriteString(PAKC_CardV14_1);
		for(i=0;i<(UINT)lo.m_StructLoads.GetSize();i++)
		{
			sl=lo.m_StructLoads[i];
			if(sl.m_uLoadtype == StructLoad::LT_NODAL_ELECTRIC_CURRENT)
			{
				for(j = 0; j < 6; j++)
				{
					if(sl.m_uDof_face[j] && fabs(sl.m_dValue[j]) >= PAKS_LOAD_FORCE_TOL)
					{
						UINT nc;
						nc=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
						bool bFound = m_FunctionsArray.FindIndex(nc,nc);
						ASSERT(bFound);
						p_str.Format( "%5u%5u%5u%10.4.1e\n", sl.m_uLoadID, j+11, nc+1, sl.m_dValue[j] );
						file.WriteString(p_str);
					}
				}
			}
		}
	}
	else
	{
		str.Format("    0\n");
		file.WriteString (str);
	}

	return(-1);
}

UINT CModelData::ExportPAKC_PrescribedValues(MyFile& file)
{
	MyString str;
	MyStringAdvanced p_str;
	UINT nDisplacementCount=0, nVelocityCount=0, nPressureCount=0, nPotentialCount=0,i,j;
	HLoads lo;
	StructLoad sl;
	HElement el;

	
	if(m_LoadArray.GetSize()==0) 
	{
		//AfxMessageBox(PAKS_NO_LOADS);
		printf(PAKS_NO_LOADS);
		str.Format("\n");
		file.WriteString (str);

		return(0);
	}
	lo = m_LoadArray[0];	//Za sada samo prvi set

	// Prebrojavanje
	for( i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
	{
		sl = lo.m_StructLoads[i];

		switch(sl.m_uLoadtype)
		{
		case StructLoad::LT_NODAL_DISPL:
			{
				for(j = 0; j < 3; j++)
				{
					if( fabs(sl.m_dValue[j]) && sl.m_uDof_face[j])
						nDisplacementCount++;
				}
				break;
			}
		case StructLoad::LT_NODAL_VELOCITY:
			{
				for(j = 0; j < 3; j++)
				{
					if( fabs(sl.m_dValue[j]) )
						nVelocityCount++;
				}
				break;
			}
		case StructLoad::LT_NODAL_STATIC_FLUID_PRESSURE:
			{
				if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL )
					nPressureCount++;
				break;
			}
		case StructLoad::LT_NODAL_ELECTRIC_POTENTIAL:
			{
				if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_NDISP_TOL )
					nPotentialCount++;
				break;
			}
		}
	}

	// Export prescribed values
	UINT nPrescribedValuesCount = nDisplacementCount + nVelocityCount + nPressureCount + nPotentialCount;
	if( nPrescribedValuesCount > 0 )
	{
		file.WriteString(PAKC_CardH9);
		str.Format("%5u\n", nPrescribedValuesCount);
		file.WriteString(str);
		file.WriteString(PAKC_CardH9_1);

		UINT nCounter = 1;
		for( i = 0; i < (UINT)lo.m_StructLoads.GetSize(); i++)
		{
			sl = lo.m_StructLoads[i];

			UINT nfun;
			nfun=(sl.m_uSl_funcID ? sl.m_uSl_funcID : 1);
			bool bFound = m_FunctionsArray.FindIndex(nfun,nfun);
			ASSERT(bFound);
		
			switch(sl.m_uLoadtype)
			{
			case StructLoad::LT_NODAL_DISPL:
				{
					for(j = 0; j < 3; j++)
					{
						if( fabs(sl.m_dValue[j]) >= PAKS_LOAD_NDISP_TOL && sl.m_uDof_face[j])
						{

							str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, j + 1, nfun+1, sl.m_dValue[j]);
							file.WriteString(str);
						}
					}
					break;
				}
			case StructLoad::LT_NODAL_VELOCITY:
				{
					for(j = 0; j < 3; j++)
					{
						if( fabs(sl.m_dValue[j]) >= PAKS_LOAD_NDISP_TOL )
						{
							str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, j + 5, nfun+1, sl.m_dValue[j]);
							file.WriteString(str);
						}
					}
					break;
				}
			case StructLoad::LT_NODAL_STATIC_FLUID_PRESSURE:
				{
					if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL )
					{
						UINT nINDPR = 4;
						str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, nINDPR, nfun+1, sl.m_dValue[0]);
						file.WriteString(str);
					}
					break;
				}
			case StructLoad::LT_NODAL_ELECTRIC_POTENTIAL:
				{
					if( fabs(sl.m_dValue[0]) >= PAKS_LOAD_PRESS_TOL )
					{
						UINT nINDPR = 8;
						str.Format("%5u%5u%5u%10.5lf\n", sl.m_uLoadID, nINDPR, nfun+1, sl.m_dValue[0]);
						file.WriteString(str);
					}
					break;
				}
			}
		}
	}
	else
	{
		str.Format("    0\n");
		file.WriteString (str);
	}

	return(-1);
}
/*
UINT CModelData::ExportPAK_Loads_FindType(HMaterial* mat, int uMODEL1)
{
	if (m_PakGeneral.GetAnalysisType()!=0) uMODEL1=5;

			switch (uMODEL1)
			{
			case  PAKM_ELASTIC_ISO:
				{
_label_elastic_iso:
					if (mat->m_dAlpha[0]!=0) goto _label_thermo_elastic_iso;
					uMODEL1=1;
				}
				break;
			case  PAKM_THERMO_ELASTIC_ISO:
				{
_label_thermo_elastic_iso:
					uMODEL1=3;
				}
				break;
			case PAKM_ELASTIC_ORTHO:
				{
					uMODEL1=2;
				}
			case  PAKM_MISES_PLASTIC:
				{
			 		if (mat->m_uNonlin_type==0) goto _label_elastic_iso;
				}
			}

	return uMODEL1;
}

UINT CModelData::ExportPAK_Function(MyFile &File, const HFunctions& Function, double dScaleFactor, const MyString& sTitle, const MyString& sXTitle, const MyString& sYTitle)
{
	MyStringAdvanced p_str;

	File.WriteString( MyString("C ") + sTitle + "\n");
	File.WriteString("C Point count\n");

	UINT nPointCount = Function.m_FunctionEntry.GetSize();
	p_str.Format("%5u\n", nPointCount);
	File.WriteString(p_str);


	File.WriteString(MyString("C ") + sXTitle + ", " + sYTitle + "\n");
	for(UINT i = 0; i < nPointCount; i++)
	{
		p_str.Format("%10.4.1e",Function.m_FunctionEntry[i].m_dX);
		File.WriteString(p_str);
		p_str.Format("%10.4.1e\n",Function.m_FunctionEntry[i].m_dY * dScaleFactor);
		File.WriteString(p_str);
	}

	return(0);
}
*/