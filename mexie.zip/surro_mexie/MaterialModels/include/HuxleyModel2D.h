/*
 * HuxleyModel2D.h
 *
 *  Created on: Nov 14, 2013
 *      Author: anakaplarevic
 */

#ifndef LIBCONFIG_H
#define LIBCONFIG_H

#include <libconfig.h>

#endif /* LIBCONFIG_H */


#ifndef HUXLEYMODEL2D_H_
#define HUXLEYMODEL2D_H_

#include "MaterialModel.h"
#include "HuxleyState2D.h"
#include "HuxleyParameters.h"
#include "HuxleyCalculator.h"
#include <math.h>
#include <curl/curl.h>

//CurlWrite_CallbackFunc_StdString(void *contents, size_t size, size_t nmemb, std::string *s);

class HuxleyModel2D: public MaterialModel {
private:
	HuxleyParameters* _param;
	HuxleyCalculator* _calculator;
	HuxleyState2D* stateP;
	
    int lastPointIterCount_V; // broj iteracija u poslednjem pozivu Caluclate() modela za V
    int lastPointIterCount_VPert; // broj iteracija u poslednjem pozivu Caluclate() modela za Vpert

public:
	HuxleyModel2D(HuxleyParameters* param);
	virtual ~HuxleyModel2D();

	void Calculate(MaterialModelState *state,double* e,double* sigma,double* dsigmade);
	void CalculateStress(_TIP *force,_TIP *forceP,double* e,double* sigma,double* dsigmade);
	MaterialModelParameters* getParameters();

//  pomocne funkcije
    void getCountOfIterations(int& countV,int& countVPert);
    _TIP getCurrForce(MaterialModelState *state);
    void getV(_TIP* V,_TIP* VP);
	void calculate_surogat(ublas::vector<double>&  distrib, double v, double activation);
};

#endif /* HUXLEYMODEL2D_H_ */
