/*!
 * \file PakExpOption.cpp
 * Implementation of the CPakExpOption class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PakExpOption.cpp: implementation of the CPakExpOption class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "CAD.h"
#include "PakExpOption.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*!
 * Default constructor.
 */
CPakExpOption::CPakExpOption()
{

}

/*!
 * Destructor.
 */
CPakExpOption::~CPakExpOption()
{

}

void CPakExpOption::Init()
{
	/// Indicator whether shella are exported as Bathe-Dvorkin shell
	m_bShellAsBatheDvorkin = FALSE;
	/// Indicator whether shells are 6-DOF shells
	m_bDrillShell = FALSE;
}
