// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#include <assert.h>

#define UINT int
#define BOOL bool
#define DWORD long int
#define TRUE 1
#define FALSE 0
#define NULL 0l

#ifndef ASSERT
#define ASSERT(x) assert(x)
//#define ASSERT(x) if(!(x)) int ppp=1;
#endif
