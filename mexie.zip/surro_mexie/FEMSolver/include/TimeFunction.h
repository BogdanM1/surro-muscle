/*
 * ImportModel.h
 *
 *  Created on: Jul 1, 2014
 *      Author: marina
 */
#ifndef TIMEFUNCTION_H_
#define TIMEFUNCTION_H_

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>


using namespace std;

class TimeFunction
{
private:
	vector< pair<double,double> > m_function;	

public:
	TimeFunction();
	~TimeFunction();

	void LoadValues(string fileName);
	double GetValue (const double t);
    void SetValue(double* x, double *y, int n);
};

#endif /* TIMEFUNCTION_H_ */
