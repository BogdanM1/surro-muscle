#define PAKC_CardH1 "C /1/ HEADING CARD (80A1)\n"
#define PAKC_CardV1 "C NASLOV\n"

#define PAKC_CardH2 "C /2/ FORMAT FOR INPUT DATA (free format)\n"
#define PAKC_CardV2 "C INDFOR\n"

#define PAKC_CardH3 "C /3/ BASIC DATA (7I5)\n"
#define PAKC_CardV3 "C NP,NGET,NMATM,NDIN,NPER,PRINT,NKRT,IPAKS,KONTAKT\n"

#define PAKC_CardH4 "C /4/ BASIC DATA FOR THE PROBLEM\n"
#define PAKC_CardV4 "C INTEB,INDSC,IFORM,MAXIT,EPSTA,  EPSTR,NJRAP\n"

#define PAKC_CardH5 "C /5/ DATA FOR RESTART (I5)\n"
#define PAKC_CardV5 "C IREST\n"

#define PAKC_CardH6 "C /6/ GROUP OF CARDS WITH DATA FOR TIME STEPS (I5,F10.0)\n"
#define PAKC_CardV6 "C \n"

#define PAKC_CardH7 "C /7/ GROUP OF CARDS FOR NODAL POINT DATA (I5,1X,8I2,2X,3F10.6,3I2)\n"
#define PAKC_CardV7 "C   N, (ID(N,I),I=1,8)  KORD(N,1),KORD(N,2),KORD(N,3),(ID(N,I),I=9,11)\n"

#define PAKC_CardH8 "C /8/ ELEMENT GROUP DATA (7I5)\n"
#define PAKC_CardV8 "C NETIP,NET,INDAX,IATYP,NMODM,IPN,IPOROS (5I5)\n"
#define PAKC_CardH8_1 "C /8-1/ DATA COMMON FOR ALL ELEMENTS\n"
#define PAKC_CardV8_1 "C NMODEL, NMATER, NP2DMX, ISWELL (4I5)\n"
#define PAKC_CardH8_2 "C /8-2/ card with nodal point data of the current element (5I5,num. material I5)\n"
#define PAKC_CardV8_2 "C NN,   (NEL(NN,I),I=1,4)\n"
#define PAKC_CardH8_3 "C   SWELLA,   SWELLB,   SWELLC,      PC0\n"

#define PAKC_CardH9 "C /9/ NUMBER PRESCRIBED VALUES - NUMZAD (I5)\n"
#define PAKC_CardH9_1 "C /9-1/NODE,IND.,TIME FUNC.,VALUES(3I5,F10.3)\n"

#define PAKC_CardH10 "C /10/ INITIAL VALUES (4F10.3)\n"
#define PAKC_CardV10 "C      Qx0       Qy0       Qz0        p0\n"

#define PAKC_CardH11 "C /11/ DATA ABOUT SURFACE BOUNDARY CONDITIONS (4I5)\n"
#define PAKC_CardV11 "C  MAXSIL, INDPJ (2I5)\n"
#define PAKC_CardH11_1 "C ELEMENT NODE1 NODE2 TIME FUNCT. VALUE1 VALUE2 \n"

//Card /12/
#define PAKC_CardH12 "C /12/ DATA ABOUT MATERIALS\n"
#define PAKC_CardV12 "C /12-1/ NUMBER OF MATERIALS  (I5)\n"

//VLADA
#define PAKC_CardH12_1 "C /12-1/ MATERIAL CONSTANTS FOR MATERIAL"
#define PAKC_CardV12_1 "C /12-1/a MODEL,MATERIAL NUMBER, INDJOT  (3I5)\n"

#define PAKC_CardV12_1_1 "C CORTICAL BONE\n"
#define PAKC_CardV12_1_1_a "C YOUNG'S MODUL.E, POISS. RATIO v,DENS. MIXT. Ro, DENS. FLUID Rf (4E10.3)\n"
#define PAKC_CardV12_1_1_b "C POROSITY n,PERMEAB. k,BULK MOD. OF SOLID Ks,BULK MOD. OF FLUID Kf(4D10.3)\n"
#define PAKC_CardV12_1_1_d "C GRODZINSKY:\nC B(1,1), B(1,2), B(2,1), B(2,2)\n"

#define PAKC_CardV12_1_2 "C CANCELLOUS BONE\n"
#define PAKC_CardV12_1_3 "C END PLATE\n"
#define PAKC_CardV12_1_4 "C NUCLEUS\n"
#define PAKC_CardV12_1_5 "C ANNULUS\n"


//Card /13/
#define PAKC_CardH13       "C /13/ DATA ABOUT TIME FUNCTIONS (2I5)\n"
#define PAKC_CardV13       "C NTABFT,MAXTFT\n"

#define PAKC_CardH13_1 "C /13-1/ GROUP OF CARDS WITH TABLES FOR TIME FUNCTIONS\n"
#define PAKC_CardV13_1_a_1 "C a) data about function in a table form (2I5)\n"
#define PAKC_CardV13_1_a_2 "C IBR,IMAX    (IMAX.LE.MAXTFT)\n"
#define PAKC_CardV13_1_b_1 "C b) values for argument - function (2F10.0)\n"
#define PAKC_CardV13_1_b_2 "C ((FN(I,IBR,J),I=1,2),J=1,IMAX)\n"

#define PAKC_CardH14 "C /14/ FORCES\n"
#define PAKC_CardV14 "C /14/NUMBER OF FORCES\n"

#define PAKC_CardH14_1 "C /14-1/ Forces and current prescribed at nodal points (3I5, F10.0)\n"
#define PAKC_CardV14_1 "C NODE, IND, VALUE\n"

#define PAKC_CardH16 "C /16/ FINAL CARD (A4)\n"
#define PAKC_CardV16 "STOP"

#define PAKCS_CardH1 "C ========================= PakS =========================\n"
#define PAKCS_CardV1 "C NMATM,NGELEM,NULAZ\n"

//Default values

//Card /2/
#define PAKC_INDFOR		2
//Card /3/
#define PAKC_NPER		1
#define PAKC_NPRINT		0
#define PAKC_NKRT		0
#define PAKC_NGET		1
#define PAKC_NMATM		1
#define PAKCS_IPAKS		1
#define PAKCS_KONTAKT	0
//Card /4/
#define PAKC_INTEB		1
#define PAKC_INDSC		0
#define PAKC_IFORM		0
#define PAKC_MAXIT		30
#define PAKC_EPSTA		0.
#define PAKC_EPSTR		0.01
#define PAKC_NJRAP		2
//Card /5/
#define PAKC_IREST		1
//Card /6/
#define PAKC_NPRGR1		1
#define PAKC_NPRGR2		1
#define PAKC_NPRGR3		9000
#define PAKC_NPRGR4	    0
//Card /7/
#define PAKC_NMODS		0
#define PAKC_ICCGG		0
#define PAKC_TOLG		0.
#define PAKC_ALFAG		0.
//Card /8/
//#define PAKC_ISWELL		0
#define PAKC_DTDT		1.
//Card /9/
#define PAKC_METOD		1
#define	PAKC_KONVE		1
#define	PAKC_KONVS		0
#define	PAKC_KONVM		0
#define	PAKC_TOLE		0.000001
#define	PAKC_TOLS		0.
#define	PAKC_TOLM		0.
#define	PAKC_NBRCR		2
//Card /10/
#define PAKC_CH			' '
#define PAKC_KORC		0
#define PAKC_LJ			0
//Card /11/
#define PAKC_MODEL2		1
#define PAKC_MODEL3		20
//Card /12/
#define PAKC_MOD		1
#define PAKC_MAT		1
#define PAKC_GUST		0.
//Card /12-1/
#define PAKC_FUNMAT1_1	1.e+5
#define PAKC_FUNMAT2_1	0
//Card /12-92/
#define PAKC_HILLS_FIBER_AXIS	3
//Card /13/
#define PAKC_IATYP		0
//#define NMODM		1
#define PAKC_INDBTH		0
#define PAKC_INDDTH		0
#define	PAKC_INDKOV		0
#define PAKC_COEF1		0.
#define PAKC_COEF2		0.
#define PAKC_COEF3		0.
//Card /13-2/a
#define PAKC_NGAUSX2	2
#define PAKC_NGAUSY2	2
#define PAKC_NGAUSZ2	2
#define PAKC_MSET		0
#define PAKC_BETA		0.
#define PAKC_MSLOJ		0
#define PAKC_CPP1		0.
#define PAKC_CPP2		0.
#define PAKC_CPP3		0.
#define PAKC_IALFA		0
//Card /13-2/b, /13-3/b
#define PAKC_IPRCO		0
#define PAKC_ISNA		0
#define PAKC_IPGS		0
#define PAKC_THI		1.
#define PAKC_KORC		0
#define PAKC_BTH		0.
#define PAKC_DTH		0.
//Card /13-3/a
#define PAKC_NGAUSX3	2
#define	PAKC_NGAUSY3	2
#define PAKC_NGAUSZ3	2
#define PAKC_BETA		0.
#define PAKC_IALFA		0
//Card /13-6
#define PAKC_NT			0
#define PAKC_NELM       0
#define PAKC_NTIP		0
#define PAKC_NKAR		0
#define PAKC_OY			0.
#define PAKC_OZ			0.
#define PAKC_YM			0.
#define PAKC_ZM			0.
#define PAKC_ALFAU		0.
#define PAKC_INDOF		0
#define PAKC_ALFA		0.
#define PAKC_CAPAY		0.
#define PAKC_CAPAZ		0.
#define PAKC_ILU 		0
#define PAKC_ICP 		0
#define PAKC_NTIP_13_6  0
#define PAKC_NAP_13_6   0



//Card /14/
#define PAKC_MAXTFT		100
//Card /15/
#define	PAKC_NPP2		0
#define PAKC_NPP3		0
#define PAKC_NPGR		0
#define PAKC_NPLJ		0
#define PAKC_NTEMP		0
#define PAKC_NZADP		0
#define PAKC_INDZS		0
#define PAKC_ICERNE		0
//Card /15-1/
#define PAKC_NC			0
#define PAKC_KORC		0
#define PAKC_FPOM		0
//Card /15-3/
#define PAKC_NFUN		1
#define PAKC_IPRAV		0

//Errors

#define PAKC_NO_NODES		"There are no nodes."
#define PAKC_NO_GROUPS		"There are no groups of elements."
#define PAKC_NO_LOADS		"There are no loads."


//Tolerancije
#define PAKC_LOAD_FORCE_TOL		1.e-8
#define PAKC_LOAD_PRESS_TOL		1.e-8
#define PAKC_LOAD_NDISP_TOL		1.e-12

#define PAKC_MAT_ALPHA_TOL		1.e-12

//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////
