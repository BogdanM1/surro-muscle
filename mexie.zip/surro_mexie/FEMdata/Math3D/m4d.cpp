/*
 * Math3d - The 3D Computer Graphics Math Library
 * Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
 * All rights reserved.
 *
 * This program is  free  software;  you can redistribute it and/or modify it
 * under the terms of the  GNU Lesser General Public License  as published by 
 * the  Free Software Foundation;  either version 2.1 of the License,  or (at 
 * your option) any later version.
 *
 * This  program  is  distributed in  the  hope that it will  be useful,  but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
 * License for more details.
 *
 * You should  have received  a copy of the GNU Lesser General Public License
 * along with  this program;  if not, write to the  Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: m4d.cpp,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
 */
#include "Stdafx.h"
#define _MATH3D_EXPORT
#include "m4d.h"
#include "m3d.h"
#include <math.h>
//#include <iostream>


/*!
 * Construction from cartesian coordinates
 * ([X, Y, Z] -> [X, Y, Z, 1]).
 *
 * \param A 3-dimensional vector. 
 */
Math3d::M4d::M4d(const M3d& A)
{
  x=A.x;
  y=A.y;
  z=A.z;
  w=1.0;
}


/*!
 * Standard copy constuctor.
 */
Math3d::M4d::M4d(const M4d& A)
{
  x=A.x;
  y=A.y;
  z=A.z;
  w=A.w;
}


/*!
 * Standard assignment operator.
 */
const Math3d::M4d&
Math3d::M4d::operator=(const M4d& A)
{
  x=A.x;
  y=A.y;
  z=A.z;
  w=A.w;
  return(*this);
}


/*!
 *
 */
void
Math3d::M4d::zero()
{
  x=y=z=w=0.0;
}


/*!
 *
 */
void
Math3d::M4d::copy(const M4d& A)
{
  x=A.x;
  y=A.y;
  z=A.z;
  w=A.w;
}


/*!
 *
 */
double&
Math3d::M4d::get(int i)
{
  ASSERT(i>=0 && i<4);
  return((&x)[i]);
}


/*!
 *
 */
Math3d::M4d
Math3d::M4d::operator+(const M4d& A)
{
  return(M4d(
    x+A.x,
    y+A.y,
    z+A.z,
    w+A.w
  ));
}


/*!
 *
 */
Math3d::M4d
Math3d::M4d::operator+()
{
  return(*this);
}


/*!
 *
 */
const Math3d::M4d&
Math3d::M4d::operator+=(const M4d& A)
{
  x+=A.x;
  y+=A.y;
  z+=A.z;
  w+=A.w;
  return(*this);
}


/*!
 *
 */
Math3d::M4d
Math3d::M4d::operator-(const M4d& A)
{
  return(M4d(
    x-A.x,
    y-A.y,
    z-A.z,
    w-A.w
  ));
}


/*!
 *
 */
Math3d::M4d
Math3d::M4d::operator-()
{
  return(M4d(-x,-y,-z,-w));
}


/*!
 *
 */
const Math3d::M4d&
Math3d::M4d::operator-=(const M4d& A)
{
  x-=A.x;
  y-=A.y;
  z-=A.z;
  w-=A.w;
  return(*this);
}


/*!
 *
 */
Math3d::M4d
Math3d::M4d::operator*(double k)
{
  return(M4d(
    x*k,
    y*k,
    z*k,
    w*k
  ));
}


/*!
 *
 */
const Math3d::M4d&
Math3d::M4d::operator*=(double k)
{
  x*=k;
  y*=k;
  z*=k;
  w*=k;
  return(*this);
}


/*!
 *
 */
void
Math3d::M4d::neg()
{
  x=-x;
  y=-y;
  z=-z;
  w=-w;
}


/*!
 *
 */
void
Math3d::M4d::abs()
{
  x=fabs(x);
  y=fabs(y);
  z=fabs(z);
  w=fabs(w);
}


/*!
 *
 */
void
Math3d::M4d::add(const M4d& A, const M4d& B)
{
  x=A.x + B.x; 
  y=A.y + B.y; 
  z=A.z + B.z; 
  w=A.w + B.w; 
}


/*!
 *
 */
void
Math3d::M4d::sub(const M4d& A, const M4d& B)
{
  x=A.x - B.x; 
  y=A.y - B.y; 
  z=A.z - B.z; 
  w=A.w - B.w; 
}


/*!
 *
 */
void
Math3d::M4d::scalar(double k)
{
  x*=k;
  y*=k;
  z*=k;
  w*=k;
}


/*!
 *
 */
void
Math3d::M4d::normalize()
{
  double l,c;

  l=length();
  if (fabs(l)<EPSILON) {
    x=y=z=z=0.0;
  }
  else {
    c=1.0/l;
    x*=c;
    y*=c;
    z*=c;
    w*=c;
  }
}


/*!
 * If this point instance is of the form [W*X, W*Y, W*Z, W], for some 
 * scale factor W != 0, then it is reset to be [X, Y, Z, 1]. This will 
 * only work correctly if the point is in homogenous form or cartesian 
 * form. If the point is in rational form, the results are not defined.
 */
void 
Math3d::M4d::cartesianize()
{
  if (fabs(w)<EPSILON) {
    ASSERT(false);
    x=y=z=w=0.0;
  }
  else {
    double c=1/w;
    x*=c;
    y*=c;
    z*=c;
    w=1.0;
  }
}
      

/*!
 * If this point instance is of the form [W*X, W*Y, W*Z, W], for some 
 * scale factor W != 0, then [X, Y, Z] is returned. 
 *
 * \return The cartesianized coordinates.
 */
Math3d::M3d 
Math3d::M4d::cartesianized()
{
  if (fabs(w)<EPSILON) {
    ASSERT(false);
    return(M3d(0,0,0));
  }

  double c=1/w;
  M3d A;
  A[0]=x*c;
  A[1]=y*c;
  A[2]=z*c;
  return(A);
}
      

/*!
 * If this point instance is of the form [W*X, W*Y, W*Z, W] (ie. is in 
 * homogenous or (for W==1) cartesian form), for some scale factor W != 0,
 * then it is reset to be [X, Y, Z, W]. This will only work correctly if 
 * the point is in homogenous or cartesian form. If the point is already
 * in rational form, the resultsare not defined.
 */
void 
Math3d::M4d::rationalize()
{
  if (fabs(w)<EPSILON) {
    ASSERT(false);
    x=y=z=w=0.0;
  }
  else {
    double c=1/w;
    x*=c;
    y*=c;
    z*=c;
    w=1.0;
  }
}
     
/*!
 * If this point instance is of the form [X, Y, Z, W] (ie. is in rational
 * or (for W==1) cartesian form), for some scale factor W != 0, then it is
 * reset to be [W*X, W*Y, W*Z, W].
 */
void 
Math3d::M4d::homogenize()
{
  x*=w;
  y*=w;
  z*=w;
}


/*!
 *
 */
void
Math3d::M4d::lerp(const M4d& A, const M4d& B, double t)
{
  x=A.x+t*(B.x-A.x);
  y=A.y+t*(B.y-A.y);
  z=A.z+t*(B.z-A.z);
  w=A.w+t*(B.w-A.w);
}


/*!
 *
 */
void
Math3d::M4d::Min(const M4d& m)
{
  if (m.x<x) x=m.x;
  if (m.y<y) y=m.y;
  if (m.z<z) z=m.z;
  if (m.w<w) w=m.w;
}


/*!
 *
 */
void
Math3d::M4d::Max(const M4d& m)
{
  if (m.x>x) x=m.x;
  if (m.y>y) y=m.y;
  if (m.z>z) z=m.z;
  if (m.w>w) w=m.w;
}


/*!
 *
 */
void
Math3d::M4d::cubic(const M4d& A, const M4d& TA, const M4d& TB, const M4d& B, double t)
{
  double a,b,c,d;   

  a=2*t*t*t - 3*t*t + 1;
  b=-2*t*t*t + 3*t*t;
  c=t*t*t - 2*t*t + t;
  d=t*t*t - t*t;
  x=a*A.x + b*B.x + c*TA.x + d*TB.x;
  y=a*A.y + b*B.y + c*TA.y + d*TB.y;
  z=a*A.z + b*B.z + c*TA.z + d*TB.z;
  w=a*A.w + b*B.w + c*TA.w + d*TB.w;
}


/*!
 *
 */
double
Math3d::M4d::get(int i) const
{
  ASSERT(i>=0 && i<4);
  return((&x)[i]);
}


/*!
 *
 */
double
Math3d::M4d::operator*(const M4d& A) const
{
  return(x*A.x + y*A.y + z*A.z + w*A.w);
}


/*!
 *
 */
bool
Math3d::M4d::operator==(const M4d& A) const
{
  return(cmp(A));
}


/*!
 *
 */
bool
Math3d::M4d::operator!=(const M4d& A) const
{
  return(!cmp(A));
}


/*!
 *
 */
double
Math3d::M4d::dot(const M4d& A) const
{
  return(x*A.x + y*A.y + z*A.z + w*A.w);
}


/*!
 *
 */
bool
Math3d::M4d::cmp(const M4d& A, double epsilon) const
{
  return(
    (fabs(x-A.x)<epsilon) &&
    (fabs(y-A.y)<epsilon) &&
    (fabs(z-A.z)<epsilon) &&
    (fabs(w-A.w)<epsilon)
  );
}


/*!
 *
 */
double
Math3d::M4d::squared() const
{
  return(x*x + y*y + z*z + w*w);
}


/*!
 *
 */
double
Math3d::M4d::length() const
{
  return(sqrt(x*x + y*y + z*z + w*w));
}


/*!
 *
 */
/*std::ostream& 
Math3d::operator << (std::ostream& co, const M4d& v)
{
  co << "(" << v[0] << ", " << v[1] << ", " << v[2] << "," << v[3] << ")";
  return co;
}
*/
