#include "histogram.h"

ublas::vector<double> createHistogram(ublas::vector<double> x, ublas::vector<double> y, int division)
{
	double min = -20.0;
	double max = 20.0;
    unsigned int nsize = x.size();
	double chunk_size = (max-min)/division; 
	ublas::vector<double >rez(division, 0); 
		
	for(int idiv = 0; idiv < division; idiv++)
	{
		double lower_bound = min + idiv*chunk_size;
		double upper_bound = lower_bound + chunk_size; 
		if(idiv == division - 1 ) upper_bound+= 1.e-10; 
		for(unsigned int i =0 ; i < nsize; i++ )
		{
			if(lower_bound <= x[i] && x[i] < upper_bound )
			rez[idiv] += y[i];
		}
	}
	return rez; 
}