#include "HuxleyState.h"

HuxleyState::HuxleyState() {

}

HuxleyState::~HuxleyState(){

}

void HuxleyState::init(MaterialModelParameters* param)
{
// HuxleyParameters* p;
	HuxleyParameters* p;
	p=dynamic_cast<HuxleyParameters*>(param);
//	p=((HuxleyParameters*) &param);
	long DIM = ceil((p->xmax-p->xmin)/p->step);
	DIM = DIM + p->m_leftng + p->m_rightng;
	ublas::zero_vector<_TIP> _0(DIM+1);

	N.resize(DIM+1,false);
	X.resize(DIM+1,false);

	N = _0;
	_TIP poc = p->xmin - p->m_leftng*p->step;
	for(unsigned int i = 0; i <= DIM; i++) {
		X(i) = poc + p->step * i;
	}

	e_t = 0.0;
}

void HuxleyState::init(MaterialModelState* state)
{
	HuxleyState* s;
	s = dynamic_cast<HuxleyState*>(state);

	printf("s->N.size() = %lu\n",s->N.size());
	N.resize(s->N.size(),false);
	X.resize(s->N.size(),false);

	X = s->X;
	N = s->N;
	e_t=s->e_t;
}

bool HuxleyState::equal(MaterialModelState* state)
{
	HuxleyState* s;
	s = (HuxleyState*) state;
	unsigned int no = (unsigned int)s->N.size();
	for(unsigned int i=0;i<no;i++) if (N(i) != s->N(i)) return false;
	for(unsigned int i=0;i<no;i++) if (X(i) != s->X(i)) return false;
	return true;
}
