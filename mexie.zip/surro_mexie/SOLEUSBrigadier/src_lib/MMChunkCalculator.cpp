/*
 * MMChunkCalculator.cpp
 *
 *  Created on: May 10, 2014
 *      Author: anakaplarevic
 */

#include "MMChunkCalculator.h"
//#include <cstdio>
#include <map>


MMChunkCalculator::MMChunkCalculator() {
	// TODO Auto-generated constructor stub
    allIterationCount = 0;
    fLog = NULL;
    moj_MPI=-1;
    moj_start=-1;
}

MMChunkCalculator::~MMChunkCalculator() {
	// TODO Auto-generated destructor stub
	if (fLog) fclose(fLog);
}

void MMChunkCalculator::setFile(FILE *f){
	fLog = f;
}

void MMChunkCalculator::setFileVelikiLog(FILE* *f){
    velikiLogChunk = *f;
}

void MMChunkCalculator::fillArrays(int num_points,MMType *types,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1){
//	sizeOfChunk = num_points;
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCalculator::fillArrays ... start\n");
    fflush(velikiLogChunk);
#endif
	model = (MaterialModel**) malloc(num_points*sizeof(MaterialModel*));
	state_t = (MaterialModelState**) malloc(num_points*sizeof(MaterialModelState*));
	state_curr = (MaterialModelState**) malloc(num_points*sizeof(MaterialModelState*));
    hp.resize(num_points);
    printf("MMChunkCalculator:: proces %d je poceo fillArray()\n",moj_MPI);
    for(int i=0;i<num_points;i++)
        {
            //if ((types[i]!=Huxley1D) && (types[i]!=Huxley2D)) return;

            hp[i] = new HuxleyParameters();

            hp[i]->InputData();
              //printf("Model m_E[i] = %lf\n",m_f1[i]);
            hp[i]->_E=m_E[i];
            hp[i]->_ni=m_ni[i];
            hp[i]->_fi=m_fi[i];
            hp[i]->m_f1=m_f1[i];

            model[i]=new HuxleyModel2D(hp[i]);

            switch (types[i])
            {
            case Huxley1D: 	state_t[i]=new HuxleyState();
                                            state_t[i]->init((MaterialModelParameters*)hp[i]);
                                            state_curr[i]=new HuxleyState();
                                            state_curr[i]->init((MaterialModelParameters*)hp[i]);
                                            break;
            case Huxley2D: 	state_t[i]=new HuxleyState2D();
                                            state_t[i]->init((MaterialModelParameters*)hp[i]);
                                            state_curr[i]=new HuxleyState2D();
                                            state_curr[i]->init((MaterialModelParameters*)hp[i]);
          //                                  printf("Napravio HuxleyState2D i koristi  HuxleyModel2D\n");
                                            break;
            case Huxley3D: /*	state_t[i]=new HuxleyState2D();*/
                                            printf("____________Huxley3D\n");
                                            break;
            case Linear1D: /*	state_t[i]=new HuxleyState2D();*/
                                            printf("____________Linear1D\n");
                                            break;
            case Linear2D: /*	state_t[i]=new HuxleyState2D();*/
                                            printf("____________Linear2D\n");
                                            break;
            case Linear3D: /*	state_t[i]=new HuxleyState2D();*/
                                            printf("____________Linear3D\n");
                                            break;
            case Murphy1D: /*	state_t[i]=new HuxleyState2D();*/
                                            printf("____________Murphy1D\n");
                                            break;
            case Murphy2D: /*	state_t[i]=new HuxleyState2D();*/
                                            printf("____________Murphy2D\n");
                                            break;
            case Murphy3D: /*	state_t[i]=new HuxleyState2D();*/
                                            printf("____________Murphy3D\n");
                                            break;
            }
        }
    printf("MMChunkCalculator:: proces %d je izvrsio fillArray()\n",moj_MPI);


//    if (g->modeli==NULL){
//	map<MMType,MaterialModel* > mapaModela;

//	HuxleyParameters* hp = new HuxleyParameters();
//	hp->InputData();

//	mapaModela[Huxley1D] = new HuxleyModel(hp);
//	mapaModela[Huxley2D] = new HuxleyModel2D(hp);

//	for(int i=0;i<num_points;i++)
//		{
//			if ((types[i]!=Huxley1D) && (types[i]!=Huxley2D)) return;
//			model[i]=mapaModela[types[i]];
//			switch (types[i])
//			{
//			case Huxley1D: 	state_t[i]=new HuxleyState();
//											state_t[i]->init((MaterialModelParameters*)hp);
//											state_curr[i]=new HuxleyState();
//											state_curr[i]->init((MaterialModelParameters*)hp);
//											break;
//			case Huxley2D: 	state_t[i]=new HuxleyState2D();
//											state_t[i]->init((MaterialModelParameters*)hp);
//											state_curr[i]=new HuxleyState2D();
//											state_curr[i]->init((MaterialModelParameters*)hp);
//                                            //printf("Napravio HuxleyState2D i koristi  HuxleyModel2D\n");
//											break;
//            case Huxley3D: /*	state_t[i]=new HuxleyState2D();*/
//                                            printf("____________Huxley3D\n");
//                                            break;
//            case Linear1D: /*	state_t[i]=new HuxleyState2D();*/
//                                            printf("____________Linear1D\n");
//                                            break;
//            case Linear2D: /*	state_t[i]=new HuxleyState2D();*/
//                                            printf("____________Linear2D\n");
//                                            break;
//            case Linear3D: /*	state_t[i]=new HuxleyState2D();*/
//                                            printf("____________Linear3D\n");
//                                            break;
//            case Murphy1D: /*	state_t[i]=new HuxleyState2D();*/
//                                            printf("____________Murphy1D\n");
//                                            break;
//            case Murphy2D: /*	state_t[i]=new HuxleyState2D();*/
//                                            printf("____________Murphy2D\n");
//                                            break;
//            case Murphy3D: /*	state_t[i]=new HuxleyState2D();*/
//                                            printf("____________Murphy3D\n");
//                                            break;
//            }
//		}
//}
//else
//        {
//          for(int i=0;i<num_points;i++) {
//              model[i]=g->modeli[i];
//              switch (types[i])
//              {
//              case Huxley1D: 	state_t[i]=new HuxleyState();
//                                              state_t[i]->init((MaterialModelParameters*)g->parametri[i]);
//                                              state_curr[i]=new HuxleyState();
//                                              state_curr[i]->init((MaterialModelParameters*)g->parametri[i]);
//                                              break;
//              case Huxley2D: 	state_t[i]=new HuxleyState2D();
//                                              state_t[i]->init((MaterialModelParameters*)g->parametri[i]);
//                                              state_curr[i]=new HuxleyState2D();
//                                              state_curr[i]->init((MaterialModelParameters*)g->parametri[i]);
//                                              //printf("Napravio HuxleyState2D i koristi  HuxleyModel2D\n");
//                                              break;
//              case Huxley3D: /*	state_t[i]=new HuxleyState2D();*/
//                                              printf("____________Huxley3D\n");
//                                              break;
//              case Linear1D: /*	state_t[i]=new HuxleyState2D();*/
//                                              printf("____________Linear1D\n");
//                                              break;
//              case Linear2D: /*	state_t[i]=new HuxleyState2D();*/
//                                              printf("____________Linear2D\n");
//                                              break;
//              case Linear3D: /*	state_t[i]=new HuxleyState2D();*/
//                                              printf("____________Linear3D\n");
//                                              break;
//              case Murphy1D: /*	state_t[i]=new HuxleyState2D();*/
//                                              printf("____________Murphy1D\n");
//                                              break;
//              case Murphy2D: /*	state_t[i]=new HuxleyState2D();*/
//                                              printf("____________Murphy2D\n");
//                                              break;
//              case Murphy3D: /*	state_t[i]=new HuxleyState2D();*/
//                                              printf("____________Murphy3D\n");
//                                              break;
//              }
//            }
//        }
//}
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCalculator::fillArrays ... end\n");
    fflush(velikiLogChunk);
#endif
}

void MMChunkCalculator::updateParameters(int num_points, std::vector<_TIPF1> &m_f1) {
    for(int i=0;i<num_points;i++)
         hp[i]->m_f1=(_TIPF1)m_f1[i];
}

/*void MMChunkCalculator::updateParameters(int num_points, std::vector<float> &m_f1) {
    for(int i=0;i<num_points;i++)
         hp[i]->m_f1=m_f1[i];
}*/

void MMChunkCalculator::setMPI(int i) {
	moj_MPI=i;
}

void MMChunkCalculator::setStartID(int s) {
	moj_start=s;
}
