/*
 * FEM.h
 *
 *  Created on: May 2, 2014
 *      Author: anakaplarevic
 */

#ifndef FEM2D_H_
#define FEM2D_H_

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/compressed_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/grid/grid_out.h>
#include <deal.II/grid/grid_reordering.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <libconfig.h++>
#include <libconfig.h>
#include <cstdlib>
#include <vector>  // !!!!!!!!!!!!!!!!!  proveriti duplikate

//za surogat
#include <string>
#include <curl/curl.h>
#include <boost/algorithm/string.hpp>
#include <iostream>

#include <deal.II/lac/sparse_direct.h>

//#include "FEM.cpp"
#include "Globals.h"
#include "ImportModel.h"
#include "MappingDeal.h"
#include "TimeFunction.h"
 class QPointCalculator;

using namespace libconfig;
using namespace dealii;

class FEM2D{
public:
	FEM2D();
	virtual ~FEM2D();
	void run(QPointCalculator* qpoint_calculator);
//		void run ( Config& cfg);
	std::map<int, double> U_prescribed;
	std::map<int,double> F_prescribed;
	double T; 			// total simulation time
	QPointCalculator* qpoint_calculator;

private:
	void make_grid ();
	void setup_system ();
	void solve ();
	void simulate();
	void init ();
	void update_fe_value();

	FullMatrix<double> e_element(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,std::vector<unsigned int> dofIndex );
	FullMatrix<double> e_element_nulti(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape);
	FullMatrix<double> set_eNL(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape);
    FullMatrix<double> t_e_qpoint(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,std::vector<unsigned int> dofIndex, Vector<double> &x_local );
	void transform_local_to_global(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
                                      std::vector<unsigned int> dofIndex, const unsigned int q_point_Index, double* sigma_matrix_global,double* sigma_matrix, double* deltasigma_matrix, FullMatrix<double> & C_matrix,FullMatrix<double> &  C_matrix_global, double* tEglobal);
	void transform_local_to_global_CE(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
                                      std::vector<unsigned int> dofIndex, const unsigned int q_point_Index, double* sigma_matrix_global,double* sigma_matrix, double* deltasigma_matrix, FullMatrix<double> & C_matrix,FullMatrix<double> &  C_matrix_global, double* tEglobal);

	void calculate_surogat_all_qpoints(double* aktivacija, double* akt_prev, double* stretch, double* stretch_prev, double* sigma_prev, double* delta_sigma_prev, double* sigma_matrix, double* deltasigma_matrix);
	void surogat_set_start();
	void surogat_set_end(); 
	friend size_t CurlWrite_CallbackFunc_StdString(void *contents, size_t size, size_t nmemb, std::string *s);
	
	FullMatrix<double> set_K_matrix(FullMatrix<double>   C_matrix_global,FullMatrix<double>   B_matrix, const unsigned int dofs_per_cell);								 
    FullMatrix<double> set_B_matrix_L0(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape);
	FullMatrix<double> set_B_matrix_L1(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape);
	FullMatrix<double> set_B_matrix_NL(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape);
	void set_sPK(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell, double* init_inverse_jacobian, double* sigma_global, double* sPK_matrix_vector, FullMatrix<double> & sPK_matrix);
	FullMatrix<double> t_sigma_qpoint(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,std::vector<unsigned int> dofIndex );
    Vector<double>  set_local_orient(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell, double* init_inverse_jacobian, Point<2> init_orient);
	Vector<double> set_local_orient(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell, double* init_inverse_jacobian, Point<2> init_orient, Vector<double> &stretch);
    Vector<double>  set_eGL(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell, double* init_inverse_jacobian);
	
	void stampa(const Vector<double> vektor, const char* naziv, const int POM);

      Point<2> VoxelData_GetVector(int VoxelFileNum, double qPointX, double qPointY);
      void VoxelData_Load(int VoxelFileNum);

	  Triangulation<2>     triangulation;
	  FESystem<2>              fe;				// FE_Q<2>              fe;
      DoFHandler<2>        dof_handler;


	  ConstraintMatrix constraints;

	  SparsityPattern      sparsity_pattern;
	  SparseMatrix<double> system_matrix;
	  Vector<double>       solution;
	  Vector<double>       system_rhs;
	  std::map<unsigned int,double> boundary_values;
	  std::map<unsigned int, Point<2> > boundary_point;
	  std::map<unsigned int, Vector<double> > boundary_vector;
      std::map<unsigned int, Vector<double> > elastic_support1D;
      std::vector<unsigned int>  IDelastic_support1D;
      std::map< int,  int > mapNodePakModelData;
      CModelData ModelData;
      ImportModel m_pImportModel;
      std::vector<Point<2> > m_element_orient;

      std::vector<Point<2> > m_qpoint_voxel_orient;

      std::vector<double > m_element_thickness;
      MappingDeal mapDeal;
	  TimeFunction m_ForceFunction;
	  TimeFunction m_PressureFunction;
	  TimeFunction m_DisplacementFunction;



      typedef struct TVoxelData{

          int nVoxelCountX, nVoxelCountY, nVoxelCountZ;
          double dVoxelSizeX, dVoxelSizeY, dVoxelSizeZ;
          Point<2> Origin;
          std::vector<std::vector<Point<2> > > Vectors;
          bool bLoaded;

      }TVoxelData;

      TVoxelData VoxelDataArray[20];

	  unsigned int   dofs_per_cell; // const
	  unsigned int   n_q_points; 	// const
	  unsigned int   n_dofs_all;	// const
	  unsigned int   n_q_points_all;	// const

	  unsigned int num_cells_x,num_cells_y;
      unsigned int indeks;
	  Vector<double> R;
	  Vector<double> F;
	  Vector<double> U;
	  Vector<double> U_prev;

	  FullMatrix<double> R_matrix;
	  FullMatrix<double> F_matrix;
	  FullMatrix<double> U_matrix;


	  QGauss<2>  quadrature_formula;
      //FEValues<2> fe_values_init;
      FEValues<2> fe_values;

	  Globals* g;
	  CURL *curl;

	  std::ifstream _fInFPrescibed;
	  std::ifstream _fInUPrescribed;
	  std::ofstream fOut;
	  FILE* fUnv;

	 std::vector<Point<2> > cvorovi;
};

#endif /* FEM2D_H_ */
