/*
 * Globals.h
 *
 *  Created on: Jul 22, 2013
 *      Author: anakaplarevic
 */

#ifndef GLOBALS_H_
#define GLOBALS_H_
#include <cstdio>
#include <map>
#include <string>
#include <vector>
#include <fstream>
#ifndef LIBCONFIG_H
#define LIBCONFIG_H

#include <libconfig.h>


#endif /* LIBCONFIG_H */

class MaterialModel;
class HuxleyParameters;

#define CFGFAJL "../../shared/FEM_MM.cfg"
#define _TIP double
#define num_TIPF1 1 // 0 za float, 1 za double
#if num_TIPF1 == 0
    #define _TIPF1 float
#else
    #define _TIPF1 double
#endif
#ifndef LOGON
#define LOGON 1
#endif
enum MMType{
		Linear1D,Linear2D,Linear3D,
		Huxley1D,Huxley2D,Huxley3D,
		Murphy1D,Murphy2D,Murphy3D
};

enum CUDARunType{
        CUDARunThrust, CUDARunCustom, CUDARunCublas
};

enum Scenario{
    Sekvencijalno,MPIparalelno,CUDAjedna,MPImixCUDA
};

#ifndef _ENUM_SCHEDULESSCENARIO
#define _ENUM_SCHEDULESSCENARIO
enum ScheduleScenario{
    BasicSchedule,Zorki0
};
#endif /* _ENUM_SCHEDULESSCENARIO */

class Globals {
private:
	static Globals* privateInstance;
	Globals();

public:
    std::map <std::string, Scenario> enumMap;
    std::map <std::string, CUDARunType> enumCudaRunTip;
    std::map <std::string, ScheduleScenario> enumScheduleScenario;

// FEM
    int step;
    static double dt;  // duzina simulacionog koraka FEM-a
    static int dimOfSigmaVector;
	int use_surro; 
	int use_time_series; 

    MaterialModel** modeli;
    HuxleyParameters** parametri;
    std::vector<double> m_E;
    std::vector<double> m_ni;
    std::vector<double> m_fi;
    std::vector<_TIPF1> m_f1;

// RUN
    static CUDARunType cudaRunTip;
    static Scenario scenario;
    static ScheduleScenario scheduler;
    static int *cudaMPIID;
    static int *cudaMAX;
    static double *cudaV;
    static int numOfCUDA;
	static int iter;
    static double mpiV;

    static _TIPF1 f1;

//	static HuxleyParameters* huxleyParameters;

	virtual ~Globals();
	static Globals* getInstance();
    void namestiMapu();


	static int nbins; 
	std::ifstream fnet;
	std::string network; 
	std::string netname;
	std::string simulation_id;
};

#endif /* GLOBALS_H_ */
