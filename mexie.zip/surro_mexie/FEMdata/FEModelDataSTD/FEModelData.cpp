/*!
 * \file FEModelData.cpp
 * Implementation of the CModelData class.
 * 
 * \author Boban Stojanovic, Nikola Milivojevic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// FEModelData.cpp: implementation of the CModelData class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "FEModelData.h"
#include "BlockIDs.h"
#include "ImporterUNV.h"
#include "../Math3D/m3d.h"
#include "EffectiveValueCalculator.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
UINT CModelData::PAK2FEMAP_NodeOrder2D[9]={2,3,0,1,6,7,4,5,8};
UINT CModelData::PAK2FEMAP_NodeOrder3D[21]={6,7,4,5,2,3,0,1,18,19,16,17,10,11,8,9,14,15,12,13,20};

/*!
 * Default constructor.
 */
CModelData::CModelData()
{
	m_NodArray.SetSize(NODE_ARRAY_NEW_SIZE, NODE_ARRAY_GROW_BY);
	m_ElArray.SetSize(ELEMENT_ARRAY_NEW_SIZE, ELEMENT_ARRAY_GROW_BY);
	m_PropArray.SetSize(PROPERTIES_ARRAY_NEW_SIZE, PROPERTIES_ARRAY_GROW_BY);
	m_ConsArray.SetSize(LOADS_ARRAY_NEW_SIZE, LOADS_ARRAY_GROW_BY);
	m_LoadArray.SetSize(CONSTRAINTS_ARRAY_NEW_SIZE, CONSTRAINTS_ARRAY_GROW_BY);
	m_OutSetArray.SetSize(OUTSETS_ARRAY_NEW_SIZE, OUTSETS_ARRAY_GROW_BY);
	
	FEMAP_Topology_NodeCount[0] = 2;
	FEMAP_Topology_NodeCount[1] = 0;
	FEMAP_Topology_NodeCount[2] = 3;
	FEMAP_Topology_NodeCount[3] = 6;
	FEMAP_Topology_NodeCount[4] = 4;
	FEMAP_Topology_NodeCount[41] = 5;
	FEMAP_Topology_NodeCount[5] = 8;
	FEMAP_Topology_NodeCount[51] = 9;
	FEMAP_Topology_NodeCount[6] = 4;
	FEMAP_Topology_NodeCount[7] = 6;
	FEMAP_Topology_NodeCount[8] = 8;
	FEMAP_Topology_NodeCount[81] = 9;
	FEMAP_Topology_NodeCount[9] = 1;
	FEMAP_Topology_NodeCount[10] = 10;
	FEMAP_Topology_NodeCount[11] = 15;
	FEMAP_Topology_NodeCount[12] = 20;
	FEMAP_Topology_NodeCount[121] = 21;
	FEMAP_Topology_NodeCount[13] = 0;
	FEMAP_Topology_NodeCount[14] = 0;
	FEMAP_Topology_NodeCount[15] = 0;
}

/*!
 * Destructor.
 */
CModelData::~CModelData()
{

}

/*!
 * Exports finite element model to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap(MyFile& file)
{
	MyString str;
	
	//Stampanje verzije NEU fajla
	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("   %s\n","100");
	file.WriteString(str);

	str.Format("%s\n","<NULL>");
	file.WriteString(str);

	str.Format("%s,\n",FEMAP_FILE_CURRENT_VERSION);
	file.WriteString(str);

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);
    ///////////////////////////////

	ExportFemap_Materials(file);
	ExportFemap_Properties(file);
	ExportFemap_Nodes(file);
	ExportFemap_Elements(file);
	ExportFemap_Constraints(file);
	ExportFemap_Loads(file);
	ExportFemap_Output(file);

	return(-1);
}

/*!
 * Exports constraints to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_Constraints(MyFile& file)
{

	MyString str;

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("%d\n",FBID_CONSTRAINTS);
	file.WriteString(str);

	int i,j;
	for (i=0;i<m_ConsArray.GetSize();i++)
	{
		HConstraints& con=m_ConsArray[i];

		str.Format("%u,\n",con.m_nID);
		file.WriteString(str);
		
		str=con.m_strTitle+"\n";
		file.WriteString(str);
		
		for (j=0;j<con.m_ConsNodes.GetSize();j++)
		{
			const ConsNode* cn=&con.m_ConsNodes[j];
			str.Format("%u,%u,%u,%d,%d,%d,%d,%d,%d,\n",
						cn->m_uNodeID,cn->m_uColor,cn->m_uLayer,
						cn->m_bDOF[0],cn->m_bDOF[1],cn->m_bDOF[2],
						cn->m_bDOF[3],cn->m_bDOF[4],cn->m_bDOF[5]);
			file.WriteString(str);
		}
		
		str="-1,-1,-1,0,0,0,0,0,0,\n";
		file.WriteString(str);
		
		for (j=0;j<con.m_ConsEqs.GetSize();j++)
		{
			const ConsEq* ce=&con.m_ConsEqs[j];
			str.Format("%u,%u,%u,%u,\n",
					ce->m_uEqnID,ce->m_uColor,ce->m_uLayer);
			file.WriteString(str);
			str.Format("%d,\n",ce->m_EqCoefs.GetSize());

			for (int k=0;k<ce->m_EqCoefs.GetSize();k++)
			{
				const EqCoeff* ec=&ce->m_EqCoefs[k];
				str.Format("%u,%u,%lf,\n",
						ec->m_uEqn_nodeID,ec->m_uEqn_dof,
						ec->m_dCoeff);
				file.WriteString(str);
			}
		}
		
		str="-1,-1,-1,\n";
		file.WriteString(str);					
	}

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	return(-1);
}

/*!
 * Exports elements to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_Elements(MyFile& file)
{
	
	MyString str;

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("%d\n",FBID_ELEMENTS);
	file.WriteString(str);
	
	for (int i=0;i<m_ElArray.GetSize();i++)
	{
		HElement& element=m_ElArray[i];

		str.Format("%u,%u,%u,%u,%u,%u,%u,%d,\n",
				element.m_nID,element.m_uColor,element.m_uPropID,element.m_uType,
				element.m_uTopology,element.m_uLayer,element.m_uOrientID,element.m_bMatl_orflag);
		file.WriteString(str);

		str.Format("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,\n",
				element.m_uNode[0],element.m_uNode[1],element.m_uNode[2],element.m_uNode[3],
				element.m_uNode[4],element.m_uNode[5],element.m_uNode[6],element.m_uNode[7],
				element.m_uNode[8],element.m_uNode[9]);
		file.WriteString(str);

		str.Format("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,\n",
			element.m_uNode[10],element.m_uNode[11],element.m_uNode[12],element.m_uNode[13],
			element.m_uNode[14],element.m_uNode[15],element.m_uNode[16],element.m_uNode[17],
			element.m_uNode[18],element.m_uNode[19]);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,\n",element.m_dOrient[0],
				element.m_dOrient[1],element.m_dOrient[2]);
		file.WriteString(str);

		str.Format("%lf,%lf,%lf,\n",element.m_dOffset1[0],
			element.m_dOffset1[1],element.m_dOffset1[2]);
		file.WriteString(str);

		str.Format("%lf,%lf,%lf,\n",element.m_dOffset2[0],
			element.m_dOffset2[1],element.m_dOffset2[2]);
		file.WriteString(str);

		str.Format("0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,\n");
		file.WriteString(str);
		}

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	return(-1);
}

/*!
 * Exports loads to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_Loads(MyFile& file)
{
	MyString str;
	
	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("%d\n",FBID_LOADS);
	file.WriteString(str);

	int i,j,k;

	for (i=0;i<m_LoadArray.GetSize();i++)
	{
		HLoads& ld=m_LoadArray[i];

		str.Format("%u,\n",ld.m_nID);
		file.WriteString(str);
		
		str=ld.m_strTitle + "\n";
		file.WriteString(str);
		
		str.Format("%u,%lf,%d,%d,%d,\n",
				ld.m_uCSys,ld.m_dDef_temp,
				ld.m_bTemp_on,ld.m_bGrav_on,
				ld.m_bOmega_on);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,\n",
				ld.m_dGrav[0],ld.m_dGrav[1],ld.m_dGrav[2]);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,\n",
				ld.m_dGrav[3],ld.m_dGrav[4],ld.m_dGrav[5]);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,\n",
				ld.m_dOrigin[0],ld.m_dOrigin[1],ld.m_dOrigin[2]);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,\n",
				ld.m_dOmega[0],ld.m_dOmega[1],ld.m_dOmega[2]);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,\n",
				ld.m_dStef_boltz,ld.m_dAbs_temp,ld.m_dFree_cnv_exp);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,%lf,\n",
				ld.m_dFc_flu_cond,ld.m_dFc_flu_cp,
				ld.m_dFc_flu_vis,ld.m_dFc_flu_dens);
		file.WriteString(str);
		
		str.Format("%lf,%lf,%lf,%lf,\n",
				ld.m_dFc_cons_coef,ld.m_dFc_reynolds,
				ld.m_dFc_pran_in,ld.m_dFc_pran_out);
		file.WriteString(str);
		
		str.Format("%u,%u,%u,\n",
				ld.m_uTfc_flu_cond,ld.m_uTfc_flu_cp,ld.m_uTfc_flu_vis);
		file.WriteString(str);
		
		str="0,0,0,\n"; // To je onaj red sto pravi zbrku kod ucitavanja 
		file.WriteString(str);
			// Devet nepoznatih redova
			str="0.,0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,0.,0.,0.,\n";
			file.WriteString(str);

			str.Format("%lf,%lf,%lf,%lf,%lf,%lf,\n", 0.0, 0.0, 0.0, 0.0, 0.0, ld.m_dDyn_trans_dt);
			file.WriteString(str);

			str="0,0,0,0,0,0,0,0,0,\n";
			file.WriteString(str);
			str="0,0,0,0,0,0,0,0,\n";
			file.WriteString(str);

			str.Format("%u,%u,%u,%u,%u,\n", 0, 0, 0, ld.m_uDyn_trans_ts, 0);
			file.WriteString(str);

			str="0,0,0,0,0,0,0,\n";
			file.WriteString(str);

			str.Format("%u,%u,%u,%u,%u,\n", 0, ld.m_uDyn_type, 0, 0, 0);
			file.WriteString(str);
		
		for (j=0;j<ld.m_StructLoads.GetSize();j++)
		{
			StructLoad& sl=ld.m_StructLoads[j];
		
			str.Format("%u,%u,%u,%u,%u,%u,\n",
					sl.m_uLoadID,sl.m_uLoadtype,
					sl.m_uColor,sl.m_uLayer,
					sl.m_uDefine_sys,sl.m_uSl_funcID);
			file.WriteString(str);
			
			str.Format("%lf,%lf,\n",
					sl.m_dPhase,sl.m_dCoefficient);
			file.WriteString(str);
			
			for (k=0;k<6;k++)
			{
				str.Format("%u,%lf,\n",
						sl.m_uDof_face[k],sl.m_dValue[k]);
				file.WriteString(str);
			}
			
			str.Format("%lf,%u,%u,%u,\n",
					sl.m_dAddI_coeff,sl.m_uAddI_fnc[0],
					sl.m_uAddI_fnc[1],sl.m_uAddI_fnc[2]);
			file.WriteString(str);
			
			str="0,0,0,0,0,0,0,\n";
			file.WriteString(str);
			
			str.Format("%u,%u,%u\n",
					sl.m_uDir_func[0],sl.m_uDir_func[1],
					sl.m_uDir_func[2]);
			file.WriteString(str);
			
			str.Format("%lf,%lf,%lf,\n",
					sl.m_dDirection[0],sl.m_dDirection[1],
					sl.m_dDirection[2]);
			file.WriteString(str);
		}

		str="-1,-1,-1,-1,-1,\n";
		file.WriteString(str);
		
		for (j=0;j<ld.m_NodalTemps.GetSize();j++)
		{
			NodalTemp& nt=ld.m_NodalTemps[j];
		
			str.Format("%u,%u,%u,%lf,%lf,%u,\n",
					nt.m_uNdtempID,nt.m_uColor,
					nt.m_uLayer,nt.m_dNdtemp,
					-1.0,
					nt.m_uNdt_funcID);
			file.WriteString(str);
		}
		
		str="-1,-1,-1,0.,0.,\n";

		file.WriteString(str);
		
		for (j=0;j<ld.m_ElTemps.GetSize();j++)
		{
			ElTemp& nt=ld.m_ElTemps[j];
		
			str.Format("%u,%u,%u,%lf,%u,\n",
					nt.m_uEltempID,nt.m_uColor,
					nt.m_uLayer,nt.m_dEltemp,
					nt.m_uElf_funcID);
			file.WriteString(str);
		}

		str="-1,-1,-1,0.,0.,\n";
		file.WriteString(str);
	}

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	return(-1);
}

/*!
 * Exports nodes to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_Nodes(MyFile& file)
{

	MyString str;
	
	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("%d\n",FBID_NODES);
	file.WriteString(str);
	
	for (int i=0;i<m_NodArray.GetSize();i++)
	{
		HNodes& node=m_NodArray[i];

		str.Format("%u,%u,%u,%u,%u,%d,%d,%d,%d,%d,%d,%lf,%lf,%lf,0,\n",
					node.m_nID,node.m_uDefine_sys,node.m_uOutput_sys,
					node.m_uLayer,node.m_uColor,node.m_bPermbc[0],node.m_bPermbc[1],
					node.m_bPermbc[2],node.m_bPermbc[3],node.m_bPermbc[4],node.m_bPermbc[5],
					node.m_dX,node.m_dY,node.m_dZ);
		file.WriteString(str);
	}

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	return(-1);
}

/*!
 * Exports properties to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_Properties(MyFile &file)
{

	MyString str;

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("%d\n",FBID_PROPERTIES);
	file.WriteString(str);
	
	int i,j,k;
	for (i=0;i<m_PropArray.GetSize();i++)
	{
		HProperties& prop=m_PropArray[i];

		str.Format("%u,%u,%u,%u,%u,%u,\n",
				prop.m_nID,prop.m_uColor,prop.m_uMatIID,
				prop.m_Type,prop.m_uLayer,prop.m_uRefCS);
		file.WriteString(str);
		
		str=prop.m_strTitle+"\n";
		file.WriteString(str);
		
		str.Format("%u,%u,%u,%u\n",
				prop.m_uFlag[0],prop.m_uFlag[1],
				prop.m_uFlag[2],prop.m_uFlag[3]);
		file.WriteString(str);
		
		str.Format("%u\n",prop.m_uLam_MID.GetSize());
		file.WriteString(str);
		
		for (j=0;j<prop.m_uLam_MID.GetSize()/8;j++)
		{
			str.Format("%u,%u,%u,%u,%u,%u,%u,%u,\n",
				prop.m_uLam_MID[j*8],prop.m_uLam_MID[j*8+1],
				prop.m_uLam_MID[j*8+2],prop.m_uLam_MID[j*8+3],
				prop.m_uLam_MID[j*8+4],prop.m_uLam_MID[j*8+5],
				prop.m_uLam_MID[j*8+6],prop.m_uLam_MID[j*8+7]);
			file.WriteString(str);
		}
		
		for (k=j*8;k<prop.m_uLam_MID.GetSize();k++)
			fprintf(file,"%u,",prop.m_uLam_MID[k]);
		
		if(j*5<prop.m_uLam_MID.GetSize()) fprintf(file,"\n");
		
		str.Format("%u\n",prop.m_dValue.GetSize());
		file.WriteString(str);
		
		for (j=0;j<prop.m_dValue.GetSize()/5;j++)
		{
			str.Format("%lf,%lf,%lf,%lf,%lf,\n",
				prop.m_dValue[j*5],prop.m_dValue[j*5+1],
				prop.m_dValue[j*5+2],prop.m_dValue[j*5+3],
				prop.m_dValue[j*5+4]);
			file.WriteString(str);
		}
		
		for (k=j*5;k<prop.m_dValue.GetSize();k++)
			fprintf(file,"%lf,",prop.m_dValue[k]);
		
		if(j*5<prop.m_dValue.GetSize()) fprintf(file,"\n");

	}

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	return(-1);
}

/*!
 * Exports materials to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_Materials(MyFile& file)
{

	MyString str;

	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("   %d\n",FBID_MATERIALS);
	file.WriteString(str);

	int i,j;
	for (i=0;i<m_MaterialsArray.GetSize();i++)
		{
			HMaterial& mat=m_MaterialsArray[i];
			str.Format("%u,%u,%u,%u,%u\n",
				mat.m_nID,mat.m_uColor,mat.m_uType,
				mat.m_uLayer,mat.m_bHas_functions);
			file.WriteString(str);
			str=mat.m_strTitle+"\n";
			file.WriteString(str);
			str.Format("%lf,%lf,%lf\n",
				mat.m_dE[0],mat.m_dE[1],mat.m_dE[2]);
			file.WriteString(str);
			str.Format("%lf,%lf,%lf\n",
				mat.m_dG[0],mat.m_dG[1],mat.m_dG[2]);
			file.WriteString(str);
			str.Format("%lf,%lf,%lf\n",
				mat.m_dNu[0],mat.m_dNu[1],mat.m_dNu[2]);
			file.WriteString(str);
			for (j=0;j<4;j++)
			{
				str.Format("%lf,%lf,%lf,%lf,%lf\n",
					mat.m_dGMatrix_3D[j*5],mat.m_dGMatrix_3D[j*5+1],
					mat.m_dGMatrix_3D[j*5+2],mat.m_dGMatrix_3D[j*5+3],
					mat.m_dGMatrix_3D[j*5+4]);
				file.WriteString(str);
			}
			str.Format("%lf\n",mat.m_dGMatrix_3D[20]);
			file.WriteString(str);
			str.Format("%lf,%lf,%lf,%lf,%lf\n",
				mat.m_dGMatrix_2D[0],mat.m_dGMatrix_2D[1],
				mat.m_dGMatrix_2D[2],mat.m_dGMatrix_2D[3],
				mat.m_dGMatrix_2D[4]);
			file.WriteString(str);
			str.Format("%lf\n",mat.m_dGMatrix_2D[5]);
			file.WriteString(str);
			str.Format("%lf,%lf,%lf,%lf,%lf\n",
				mat.m_dAlpha[0],mat.m_dAlpha[1],
				mat.m_dAlpha[2],mat.m_dAlpha[3],
				mat.m_dAlpha[4]);
			file.WriteString(str);
			str.Format("%lf\n",mat.m_dAlpha[5]);
			file.WriteString(str);
			str.Format("%lf,%lf,%lf,%lf,%lf\n",
				mat.m_dK[0],mat.m_dK[1],
				mat.m_dK[2],mat.m_dK[3],
				mat.m_dK[4]);
			file.WriteString(str);
			str.Format("%lf\n",mat.m_dK[5]);
			file.WriteString(str);
			str.Format("%lf,%lf,%lf,%lf\n",
				mat.m_dThermal_cap,mat.m_dDensity,
				mat.m_dDamping,mat.m_dTemperature);
			file.WriteString(str);
			str.Format("%lf,%lf,%lf,%lf,%lf\n",
				mat.m_dTensionLimit[0],mat.m_dTensionLimit[1],
				mat.m_dCompLimit[0],mat.m_dCompLimit[1],
				mat.m_dShearLimit);
			file.WriteString(str);
			if (mat.m_bHas_functions)
			{
				str.Format("%u,%u,%u\n",
					mat.m_uFE[0],mat.m_uFE[1],mat.m_uFE[2]);
				file.WriteString(str);
				str.Format("%u,%u,%u\n",
					mat.m_uFG[0],mat.m_uFG[1],mat.m_uFG[2]);
				file.WriteString(str);
				str.Format("%u,%u,%u\n",
					mat.m_uNu[0],mat.m_uNu[1],mat.m_uNu[2]);
				file.WriteString(str);
				for (j=0;j<4;j++)
				{
					str.Format("%u,%u,%u,%u,%u\n",
						mat.m_uFGMatrix3D[j*5],mat.m_uFGMatrix3D[j*5+1],
						mat.m_uFGMatrix3D[j*5+2],mat.m_uFGMatrix3D[j*5+3],
						mat.m_uFGMatrix3D[j*5+4]);
					file.WriteString(str);
				}
				str.Format("%u\n",mat.m_uFGMatrix3D[20]);
				file.WriteString(str);
				str.Format("%u,%u,%u,%u,%u\n",
					mat.m_uFGMatrix2D[0],mat.m_uFGMatrix2D[1],
					mat.m_uFGMatrix2D[2],mat.m_uFGMatrix2D[3],
					mat.m_uFGMatrix2D[4]);
				file.WriteString(str);				
				str.Format("%u\n",mat.m_uFGMatrix2D[5]);
				file.WriteString(str);
				sscanf(str,"%u,%u,%u,%u,%u\n",
					mat.m_uFAlpha[0],mat.m_uFAlpha[1],
					mat.m_uFAlpha[2],mat.m_uFAlpha[3],
					mat.m_uFAlpha[4]);
				file.WriteString(str);
				str.Format("%u\n",mat.m_uFAlpha[5]);
				file.WriteString(str);
				str.Format("%u,%u,%u,%u,%u\n",
					mat.m_uFK[0],mat.m_uFK[1],
					mat.m_uFK[2],mat.m_uFK[3],
					mat.m_uFK[4]);
				file.WriteString(str);
				str.Format("%u\n",mat.m_uFK[5]);
				file.WriteString(str);
				str.Format("%u,%u,%u,%u\n",
					mat.m_uFThermal_cap,mat.m_uFDensity,
					mat.m_uFDamping,mat.m_uFTemperature);
				file.WriteString(str);
				str.Format("%u,%u,%u,%u,%u\n",
					mat.m_uFTensionLimit[0],mat.m_uFTensionLimit[1],
					mat.m_uCompLimit[0],mat.m_uCompLimit[1],
					mat.m_uShearLimit);
				file.WriteString(str);
			}
			// Nepoznati redovi:
			str="0.,0.,0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,\n";
			file.WriteString(str);
			str="0,0,0,0,0,\n";
			file.WriteString(str);
			str="0,0,1,0,0,0,\n";
			file.WriteString(str);
			str="0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,0.,0.,0.,\n";
			file.WriteString(str);
			str="0.,0.,\n";
			file.WriteString(str);
			str="0,0,0,0,\n";
			file.WriteString(str);
			str="0,0,0,0,\n";
			file.WriteString(str);
	}
		
	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	return(-1);
}

/*!
 * Exports OutputSets to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_OutputSets(MyFile& file)
{
	MyString str;
	
	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

	str.Format("   %d\n",FBID_OUTSETS);
	file.WriteString(str);

	for (int i=0;i<m_OutSetArray.GetSize();i++)
	{
		COutSet& outset=m_OutSetArray[i];

		str.Format("%u,\n",outset.m_nID);
		file.WriteString(str);

		str.Format("%s,\n",outset.m_sTitle.c_str());
		file.WriteString(str);

		str.Format("%u,%u,\n",outset.m_nFrom_prog,outset.m_nAnal_type);
		file.WriteString(str);

		str.Format("%lf,\n",outset.m_dValue);
		file.WriteString(str);

		str.Format("%u,\n",outset.m_nNLines);
		file.WriteString(str);

		
		str.Format("%s\n",outset.m_sNotes.c_str());
		file.WriteString(str);

	}
	
	str.Format("%s\n",FB_SEPARATOR);
	file.WriteString(str);

return 0;
}
/*!
 * Exports OutputVectors to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_OutputVectors(MyFile& file)
{
	MyString str;
	
	
	str.Format("%s\n",FB_SEPARATOR);
    file.WriteString(str);

    str.Format("   %d\n",FBID_OUTVECTORS);
    file.WriteString(str);

	for(int i=0;i<m_OutSetArray.GetSize();i++)
    {
	  
		COutSet& outset=m_OutSetArray[i];

		for(int j=0;j<outset.m_OutVectors.GetSize();j++)
     	{
			COutVector& outvector=outset.m_OutVectors[j]; 

			str.Format("%u,%u,1\n",outvector.m_nSetID, outvector.m_nID);
			file.WriteString(str);

			str.Format("%s,\n",outvector.m_sTitle.c_str());
			file.WriteString(str);

			str.Format("%lf,%lf,%lf,\n",outvector.m_dMin_val, outvector.m_dMax_val, outvector.m_dAbs_max);
			file.WriteString(str);

			str.Format("%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,\n", outvector.m_Comp[0],
			 outvector.m_Comp[1], outvector.m_Comp[2], outvector.m_Comp[3], outvector.m_Comp[4],
			 outvector.m_Comp[5], outvector.m_Comp[6], outvector.m_Comp[7], outvector.m_Comp[8],
			 outvector.m_Comp[9]);
			file.WriteString(str);

			str.Format("%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,%ld,\n", outvector.m_Comp[10],
			 outvector.m_Comp[11], outvector.m_Comp[12], outvector.m_Comp[13], outvector.m_Comp[14],
			 outvector.m_Comp[15], outvector.m_Comp[16], outvector.m_Comp[17], outvector.m_Comp[18],
			 outvector.m_Comp[19]);
			file.WriteString(str);

			str.Format("%u,%u,%u,%u,\n",outvector.m_nID_min, outvector.m_nID_max, outvector.m_nOut_type, outvector.m_nEnt_type);
			file.WriteString(str);

			str.Format("%u,%u,%u\n",outvector.m_bCalc_warn ? 1 : 0, outvector.m_nComp_dir, outvector.m_bCent_total ? 1 : 0);
			file.WriteString(str);

			map<UINT,double>::const_iterator pos=outvector.m_Values.GetStartPosition();
			UINT ID;
			double value;
			while (pos != outvector.m_Values.end())
			{
				outvector.m_Values.GetNextAssoc( pos, ID, value );
				str.Format("%u,%lf\n", ID, value);
				file.WriteString(str);
			}
			file.WriteString("-1\n");
		}

	}

		str.Format("%s\n",FB_SEPARATOR);
	    file.WriteString(str);

		return 0;
}

UINT CModelData::ExportFemap_Output(MyFile& file)
{
	ExportFemap_OutputSets(file); 
	ExportFemap_OutputVectors(file);
    
	return 0;
}
/*!
 * Reads string from the ASCII file. All commas are replaced with spaces, while exponent character 'D' is replaced with 'E'.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \param[in] str
 * Reference to the destination string.
 */
void FReadString(MyFile& file,MyString &str)
{
	file.ReadString(str);
	str.Replace(',',' ');
	str.Replace('D','E');
}

/*!
 * Imports finite element model from FEMAP neutral file.
 * 
 * \param[in] file
 * Reference to the source file.
 * 
 * \param[in] ExpectedNodeCount
 * Expected number of nodes to import. Used to optimize loading speed. Optional.
 * 
 * \param[in] ExpectedElemCount
 * Expected number of elements to import. Used to optimize loading speed. Optional.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap(MyFile& file,UINT ExpectedNodeCount,UINT ExpectedElemCount)
{
	MyString str;

	while (!feof(file))
	{
		file.ReadString(str);

		if (atoi(str)==-1)
		{
			file.ReadString(str);
	
			int nDataBlockType=atoi(str);

			if ((nDataBlockType==FBID_NODES)||(nDataBlockType==FBID_ELEMENTS)||(nDataBlockType==FBID_PROPERTIES)||(nDataBlockType==FBID_LOADS)||
				(nDataBlockType==FBID_CONSTRAINTS) || (nDataBlockType==FBID_MATERIALS) || (nDataBlockType==FBID_FUNCTIONS) ||
				(nDataBlockType==FBID_OUTSETS) || (nDataBlockType==FBID_OUTVECTORS))
			{
				ImportFemap_DataBlock(file, nDataBlockType,ExpectedNodeCount,ExpectedElemCount);
			}
			else
			{
				file.ReadString(str);
	
				while((atoi(str)!=-1)&&(!feof(file)))
					file.ReadString(str);
			}
		}
		else
		{
			file.ReadString(str);

			while((atoi(str)!=-1)&&(!feof(file)))
				file.ReadString(str);
		}
	}
	return(-1);
}

/*!
 * Imports data block from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \param[in] nDataBlockType
 * Type of the data block.
 * 
 * \param[in,out] ExpectedNodeCount
 * Reference to the expected number of nodes to import. After execution of the function, parameter contains exact number of nodes.
 * 
 * \param[in] ExpectedElemCount
 * Reference to the expected number of elements to import. After execution of the function, parameter contains exact number of element.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_DataBlock(MyFile& file, int nDataBlockType,UINT &ExpectedNodeCount,UINT &ExpectedElemCount)
{
	
	MyString str="0";

	switch (nDataBlockType)
	{
	case FBID_NODES:
		{
			ImportFemap_Nodes(file);
			
			if(ExpectedNodeCount==0) ExpectedNodeCount=m_NodArray.GetSize();
		}
	break;

	case FBID_ELEMENTS:
		{
			ImportFemap_Elements(file);
			
			if(ExpectedElemCount==0) ExpectedElemCount=m_ElArray.GetSize();
		}
	break;

	case FBID_PROPERTIES:
		{
			ImportFemap_Properties(file);

//			FillPropIndex();
		}
	break;

	case FBID_LOADS:
		{
			ImportFemap_Loads(file);
		}
	break;

	case FBID_CONSTRAINTS:
		{
			ImportFemap_Constraints(file);
		}
	break;

	case FBID_MATERIALS:
		{
			ImportFemap_Materials(file);
		}
	break;

	case FBID_FUNCTIONS:
		{
			ImportFemap_Functions(file);
//			FillFuncIndex();
		}
	break;

	case FBID_OUTSETS:
		{
			ImportFemap_OutSets(file);
		}
	break;

	case FBID_OUTVECTORS:
		{
			ImportFemap_OutVectors(file,ExpectedNodeCount,ExpectedElemCount);
		}
	break;


	default:
		while((atoi(str)!=-1)||(feof(file)))
		{file.ReadString(str);}
	break;
	}	//switch (nDataBlockType)


	return(-1);
}

/*!
 * Imports constraints from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_Constraints(MyFile& file)
{

	MyString str;

	FReadString(file,str);
	
	while (atoi(str)!=-1)
	{
		HConstraints constraints;

		constraints.m_uDataBlockID=406;
		constraints.m_nID=atoi(str);

		file.ReadString(str);
		
		constraints.m_strTitle=str;
		
		FReadString(file,str);
		
		while (atoi(str)!=-1)
		{
			ConsNode cn;
		
			sscanf(str,"%u%u%u%d%d%d%d%d%d",
					&cn.m_uNodeID,&cn.m_uColor,&cn.m_uLayer,
					&cn.m_bDOF[0],&cn.m_bDOF[1],&cn.m_bDOF[2],
					&cn.m_bDOF[3],&cn.m_bDOF[4],&cn.m_bDOF[5]);
			
			constraints.m_ConsNodes.Add(cn);
			
			FReadString(file,str);
			
		}//while (str.Left(3)!="-1,")
		
		FReadString(file,str);

		while (atoi(str)!=-1)
		{
			ConsEq conseq;
			sscanf(str,"%u%u%u%u",
					&conseq.m_uEqnID,&conseq.m_uColor,&conseq.m_uLayer);
		
			FReadString(file,str);
			
			int nSize=atoi(str);
			
			conseq.m_EqCoefs.SetSize(nSize);
			
			for (int i=0;i<nSize;i++)
			{
				//EqCoeff e;
			
				//conseq.m_EqCoefs.Add(e);
				
				EqCoeff& eqcoeff=conseq.m_EqCoefs[i];

				FReadString(file,str);
				
				sscanf(str,"%u%u%lf",
						&eqcoeff.m_uEqn_nodeID,&eqcoeff.m_uEqn_dof,
						&eqcoeff.m_dCoeff);
				
			}
			
			constraints.m_ConsEqs.Add(conseq);
			
			FReadString(file,str);
			
		}//while (str.Left(3)!="-1,")

		m_ConsArray.Add(constraints);

		FReadString(file,str);
		
	}//	while (str.Left(5)!="   -1")
	
	return(-1);
}

/*!
 * Imports elements from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_Elements(MyFile& file)
{
	MyString str;

	FReadString(file,str);

	while (atoi(str)!=-1)
	{

		HElement element;

		element.m_uDataBlockID=404;
		
		sscanf(str,"%u%u%u%u%u%u%u%d",
				&element.m_nID,&element.m_uColor,&element.m_uPropID,&element.m_uType,
				&element.m_uTopology,&element.m_uLayer,&element.m_uOrientID,&element.m_bMatl_orflag);

		FReadString(file,str);
		
		sscanf(str,"%d%d%d%d%d%d%d%d%d%d",
				&element.m_uNode[0],&element.m_uNode[1],&element.m_uNode[2],&element.m_uNode[3],
				&element.m_uNode[4],&element.m_uNode[5],&element.m_uNode[6],&element.m_uNode[7],
				&element.m_uNode[8],&element.m_uNode[9]);
		
		FReadString(file,str);
		
		sscanf(str,"%d%d%d%d%d%d%d%d%d%d",
				&element.m_uNode[10],&element.m_uNode[11],&element.m_uNode[12],&element.m_uNode[13],
				&element.m_uNode[14],&element.m_uNode[15],&element.m_uNode[16],&element.m_uNode[17],
				&element.m_uNode[18],&element.m_uNode[19]);
		
		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf",&element.m_dOrient[0],
				&element.m_dOrient[1],&element.m_dOrient[2]);
		
		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf",&element.m_dOffset1[0],
				&element.m_dOffset1[1],&element.m_dOffset1[2]);
		
		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf",&element.m_dOffset2[0],
				&element.m_dOffset2[1],&element.m_dOffset2[2]);
		
		FReadString(file,str);

		//Nejasno ssta se ccita (previsse brojki)
		
		FReadString(file,str);
		
		m_ElArray.Add(element);

	}//while (str.Left(5)!="   -1")

	return(-1);
}

/*!
 * Imports loads from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_Loads(MyFile& file)
{

	MyString str;

	FReadString(file,str);

	while (atoi(str)!=-1)
	{
	
		HLoads load;
	
		load.m_uDataBlockID=407;
		load.m_nID=atoi(str);
		
		file.ReadString(str);
		
		load.m_strTitle=str;
		
		FReadString(file,str);
		
		sscanf(str,"%u%lf%d%d%d",&load.m_uCSys,&load.m_dDef_temp,
				&load.m_bTemp_on,&load.m_bGrav_on,&load.m_bOmega_on);

		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf",&load.m_dGrav[0],&load.m_dGrav[1],&load.m_dGrav[2]);

		FReadString(file,str);

		sscanf(str,"%lf%lf%lf",&load.m_dGrav[3],&load.m_dGrav[4],&load.m_dGrav[5]);

		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf",&load.m_dOrigin[0],&load.m_dOrigin[1],&load.m_dOrigin[2]);

		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf",&load.m_dOmega[0],&load.m_dOmega[1],&load.m_dOmega[2]);

		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf",&load.m_dStef_boltz,&load.m_dAbs_temp,&load.m_dFree_cnv_exp);

		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf%lf",&load.m_dFc_flu_cond,&load.m_dFc_flu_cp,
				&load.m_dFc_flu_vis,&load.m_dFc_flu_dens);

		FReadString(file,str);
		
		sscanf(str,"%lf%lf%lf%lf",&load.m_dFc_cons_coef,&load.m_dFc_reynolds,
				&load.m_dFc_pran_in,&load.m_dFc_pran_out);

		FReadString(file,str);
		
		sscanf(str,"%u%u%u",&load.m_uTfc_flu_cond,&load.m_uTfc_flu_cp,&load.m_uTfc_flu_vis);

		FReadString(file,str);
		
		int a,ff,cf;
		
		sscanf(str,"%d%d%d",&a,&ff,&cf);

		load.m_bAlt_free_conv=a;
		load.m_bFc_flu_flag=ff;
		load.m_bFc_conv_flow=cf;

		int i;
		for (i=0;i<3;i++) file.ReadString(str);
					
		double dtmp;
		UINT utmp;
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf%lf%lf%lf",&dtmp,&dtmp,&dtmp,&dtmp,&dtmp,&load.m_dDyn_trans_dt);

		for (i=0;i<2;i++) file.ReadString(str);

		FReadString(file,str);
		sscanf(str,"%u%u%u%u%u",&utmp,&utmp,&utmp,&load.m_uDyn_trans_ts,&utmp);

		file.ReadString(str);

		FReadString(file,str);
		sscanf(str,"%u%u%u%u%u",&utmp,&load.m_uDyn_type,&utmp,&utmp,&utmp);

		// Struct loads
		FReadString(file,str);

		while (atoi(str)!=-1)
		{

			StructLoad structload;
			
			sscanf(str,"%u%u%u%u%u%u",&structload.m_uLoadID,&structload.m_uLoadtype,
					&structload.m_uColor,&structload.m_uLayer,&structload.m_uDefine_sys,&structload.m_uSl_funcID);

			FReadString(file,str);
			
			sscanf(str,"%lf%lf",&structload.m_dPhase,&structload.m_dCoefficient);

			for (i=0;i<6;i++)
			{
				FReadString(file,str);
				
				sscanf(str,"%u%lf",&structload.m_uDof_face[i],&structload.m_dValue[i]);
			}
			
			FReadString(file,str);
			
			sscanf(str,"%lf%u%u%u", &structload.m_dAddI_coeff,&structload.m_uAddI_fnc[0],
					&structload.m_uAddI_fnc[1],&structload.m_uAddI_fnc[2]);

			FReadString(file,str); // Nejasno
			
			FReadString(file,str);
			
			sscanf(str,"%u%u%u",&structload.m_uDir_func[0],&structload.m_uDir_func[1],
					&structload.m_uDir_func[2]);
					
			FReadString(file,str);
			
			sscanf(str,"%lf%lf%lf",&structload.m_dDirection[0],&structload.m_dDirection[1],
					&structload.m_dDirection[2]);
					
			load.m_StructLoads.Add(structload);

			FReadString(file,str);

		}//while (str.Left(3)!="-1,")

		FReadString(file,str);
		
		while (atoi(str)!=-1)
		{
			NodalTemp nodaltemp;
			double tmp;

			sscanf(str,"%u%u%u%lf%lf%u",&nodaltemp.m_uNdtempID,&nodaltemp.m_uColor,
					&nodaltemp.m_uLayer,&nodaltemp.m_dNdtemp,&tmp,&nodaltemp.m_uNdt_funcID);
					
			load.m_NodalTemps.Add(nodaltemp);
			
			FReadString(file,str);	

		}//while (str.Left(3)!="-1,")


		FReadString(file,str);
		
		while (atoi(str)!=-1)
		{
			ElTemp eltemp;

			sscanf(str,"%u%u%u%lf%u",&eltemp.m_uEltempID,&eltemp.m_uColor,
					&eltemp.m_uLayer,&eltemp.m_dEltemp,&eltemp.m_uElf_funcID);

			load.m_ElTemps.Add(eltemp);

			FReadString(file,str);

		}//while (str.Left(3)!="-1,")
			
		m_LoadArray.Add(load);					

		FReadString(file,str);

	}//	while (str.Left(5)!="   -1")

	return(-1);
}

/*!
 * Imports nodes from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_Nodes(MyFile& file)
{

	MyString str;
	
	FReadString(file,str);
	
//	while (str.Left(5)!="   -1")
	while (atoi(str)!=-1)
	{
		HNodes node;
		
		node.m_uDataBlockID=FBID_NODES;
		
		sscanf(str,"%u%u%u%u%u%d%d%d%d%d%d%lf%lf%lf",
				&node.m_nID,&node.m_uDefine_sys,&node.m_uOutput_sys,
				&node.m_uLayer,&node.m_uColor,&node.m_bPermbc[0],&node.m_bPermbc[1],
				&node.m_bPermbc[2],&node.m_bPermbc[3],&node.m_bPermbc[4],&node.m_bPermbc[5],
				&node.m_dX,&node.m_dY,&node.m_dZ);
		
		m_NodArray.Add(node);
		
		FReadString(file,str);

	}//while (str.Left(5)!="   -1")
	
	return(-1);
}

/*!
 * Imports properties from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_Properties(MyFile& file)
{
	MyString str;

	FReadString(file,str);

	while (atoi(str)!=-1)
	{
		HProperties prop;

		prop.m_uDataBlockID=402;
		
		UINT nType;
		sscanf(str,"%u%u%u%u%u%u",&prop.m_nID,&prop.m_uColor,&prop.m_uMatIID,
				&nType,&prop.m_uLayer,&prop.m_uRefCS);
		prop.m_Type = (HProperties::TPropertyType)nType;
				
		file.ReadString(str);
		
		prop.m_strTitle=str;
		
		FReadString(file,str);
		
		sscanf(str,"%u%u%u%u",&prop.m_uFlag[0],&prop.m_uFlag[1],
				&prop.m_uFlag[2],&prop.m_uFlag[3]);
				
		FReadString(file,str);
		
		int uNum_lam=(UINT)atoi(str);
		prop.m_uLam_MID.SetSize(uNum_lam);

		int i,j;
		for (i=0;i<uNum_lam/8;i++)
		{
			FReadString(file,str);
		
			sscanf(str,"%u%u%u%u%u%u%u%u",
					&prop.m_uLam_MID[i*8],&prop.m_uLam_MID[i*8+1],
					&prop.m_uLam_MID[i*8+2],&prop.m_uLam_MID[i*8+3],
					&prop.m_uLam_MID[i*8+4],&prop.m_uLam_MID[i*8+5],
					&prop.m_uLam_MID[i*8+6],&prop.m_uLam_MID[i*8]+7);
		}
		
		for (j=i*8;j<uNum_lam;j++)
			fscanf(file,"%u",&prop.m_uLam_MID[j]);
		
		if(i*8<uNum_lam) FReadString(file,str); //Iscitava kraj reda jer je citao pojedinacno polja

		FReadString(file,str);
					
		int uNum_val=(UINT)atoi(str);
		prop.m_dValue.SetSize(uNum_val);

		for (i=0;i<uNum_val/5;i++)
		{
			FReadString(file,str);
			
			sscanf(str,"%lf%lf%lf%lf%lf",
					&prop.m_dValue[i*5],&prop.m_dValue[i*5+1],
					&prop.m_dValue[i*5+2],&prop.m_dValue[i*5+3],
					&prop.m_dValue[i*5+4]);	
		}

		for (j=i*5;j<uNum_val;j++)
			fscanf(file,"%lf,",&prop.m_dValue[j]);
		
		if(i*5<uNum_val) FReadString(file,str);	//Iscitava kraj reda jer je citao pojedinacno polja
		
		m_PropArray.Add(prop);
		
		FReadString(file,str);

	}//while (str.Left(5)!="   -1")

	return(-1);
}

/*!
 * Imports materials from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_Materials(MyFile& file)
{

	MyString str;

	FReadString(file,str);

	while (atoi(str)!=-1)
	{
		HMaterial mat;
		mat.m_uDataBlockID=401;
		sscanf(str,"%u%u%u%u%u",
			&mat.m_nID,&mat.m_uColor,&mat.m_uType,
			&mat.m_uLayer,&mat.m_bHas_functions);
		file.ReadString(str);
		mat.m_strTitle=str;
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf",
			&mat.m_dE[0],&mat.m_dE[1],&mat.m_dE[2]);
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf",
			&mat.m_dG[0],&mat.m_dG[1],&mat.m_dG[2]);
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf",
			&mat.m_dNu[0],&mat.m_dNu[1],&mat.m_dNu[2]);
		int i;
		for (i=0;i<4;i++)
		{
			FReadString(file,str);
			sscanf(str,"%lf%lf%lf%lf%lf",
				&mat.m_dGMatrix_3D[i*5],&mat.m_dGMatrix_3D[i*5+1],
				&mat.m_dGMatrix_3D[i*5+2],&mat.m_dGMatrix_3D[i*5+3],
				&mat.m_dGMatrix_3D[i*5+4]);
		}
		FReadString(file,str);
		mat.m_dGMatrix_3D[20]=atof(str);
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf%lf%lf",
			&mat.m_dGMatrix_2D[0],&mat.m_dGMatrix_2D[1],
			&mat.m_dGMatrix_2D[2],&mat.m_dGMatrix_2D[3],
			&mat.m_dGMatrix_2D[4]);
		FReadString(file,str);
		mat.m_dGMatrix_2D[5]=atof(str);
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf%lf%lf",
			&mat.m_dAlpha[0],&mat.m_dAlpha[1],
			&mat.m_dAlpha[2],&mat.m_dAlpha[3],
			&mat.m_dAlpha[4]);
		FReadString(file,str);
		mat.m_dAlpha[5]=atof(str);
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf%lf%lf",
			&mat.m_dK[0],&mat.m_dK[1],
			&mat.m_dK[2],&mat.m_dK[3],
			&mat.m_dK[4]);
		FReadString(file,str);
		mat.m_dK[5]=atof(str);
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf%lf",
			&mat.m_dThermal_cap,&mat.m_dDensity,
			&mat.m_dDamping,&mat.m_dTemperature);
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf%lf%lf",
			&mat.m_dTensionLimit[0],&mat.m_dTensionLimit[1],
			&mat.m_dCompLimit[0],&mat.m_dCompLimit[1],
			&mat.m_dShearLimit);
		
		if (mat.m_bHas_functions)
		{
			FReadString(file,str);
			sscanf(str,"%u%u%u",
				&mat.m_uFE[0],&mat.m_uFE[1],&mat.m_uFE[2]);
			FReadString(file,str);
			sscanf(str,"%u%u%u",
				&mat.m_uFG[0],&mat.m_uFG[1],&mat.m_uFG[2]);
			FReadString(file,str);
			sscanf(str,"%u%u%u",
				&mat.m_uNu[0],&mat.m_uNu[1],&mat.m_uNu[2]);
			for (i=0;i<4;i++)
			{
				FReadString(file,str);
				sscanf(str,"%u%u%u%u%u",
					&mat.m_uFGMatrix3D[i*5],&mat.m_uFGMatrix3D[i*5+1],
					&mat.m_uFGMatrix3D[i*5+2],&mat.m_uFGMatrix3D[i*5+3],
					&mat.m_uFGMatrix3D[i*5+4]);
			}
			FReadString(file,str);
			mat.m_uFGMatrix3D[20]=atoi(str);
			FReadString(file,str);
			sscanf(str,"%u%u%u%u%u",
				&mat.m_uFGMatrix2D[0],&mat.m_uFGMatrix2D[1],
				&mat.m_uFGMatrix2D[2],&mat.m_uFGMatrix2D[3],
				&mat.m_uFGMatrix2D[4]);
			FReadString(file,str);
			mat.m_uFGMatrix2D[5]=atoi(str);
			FReadString(file,str);
			sscanf(str,"%u%u%u%u%u",
				&mat.m_uFAlpha[0],&mat.m_uFAlpha[1],
				&mat.m_uFAlpha[2],&mat.m_uFAlpha[3],
				&mat.m_uFAlpha[4]);
			FReadString(file,str);
			mat.m_uFAlpha[5]=atoi(str);
			FReadString(file,str);
			sscanf(str,"%u%u%u%u%u",
				&mat.m_uFK[0],&mat.m_uFK[1],
				&mat.m_uFK[2],&mat.m_uFK[3],
				&mat.m_uFK[4]);
			FReadString(file,str);
			mat.m_uFK[5]=atoi(str);
			FReadString(file,str);
			sscanf(str,"%u%u%u%u",
				&mat.m_uFThermal_cap,&mat.m_uFDensity,
				&mat.m_uFDamping,&mat.m_uFTemperature);
			FReadString(file,str);
			sscanf(str,"%u%u%u%u%u",
				&mat.m_uFTensionLimit[0],&mat.m_uFTensionLimit[1],
				&mat.m_uCompLimit[0],&mat.m_uCompLimit[1],
				&mat.m_uShearLimit);
		}

	for (i=0;i<7;i++)
		FReadString(file,str);
		sscanf(str,"%lf%lf%lf",
				&mat.m_dPlastHardSlope,&mat.m_dPlastYieldLim[0],&mat.m_dPlastYieldLim[1]);

	for (i=0;i<2;i++)
		FReadString(file,str);
		sscanf(str,"%lf%lf%d%u%d%d",
				&mat.m_dHypPolyord[0], &mat.m_dHypPolyord[1], &mat.m_uNonlin_type, &mat.m_uNonlin_func,
				&mat.m_iHard_type, &mat.m_iYield_type);

	for (i=0;i<5;i++)
		FReadString(file,str);

	m_MaterialsArray.Add(mat);
	FReadString(file,str);
	}

	return(-1);
}

/*!
 * Imports functions from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_Functions(MyFile& file)
{
	MyString str;

	FReadString(file,str);

	while (atoi(str)!=-1)
	{
		HFunctions fn;

		fn.m_uDataBlockID=420;
		
		sscanf(str,"%u%u",
					&fn.m_nID,&fn.m_uFunc_type);
	
		file.ReadString(str);
		fn.m_strTitle = str;
		
		FReadString(file,str);
		while (str.Left(2)!="-1")
		{
			FunctionEntry fe;
			sscanf(str,"%u%lf%lf",
						&fe.m_uEntryID,&fe.m_dX,&fe.m_dY);
			
			fn.m_FunctionEntry.Add(fe);
			FReadString(file,str);
		}
		
		FReadString(file,str);
		
		m_FunctionsArray.Add(fn);
	}

	return(-1);
}

/*!
 * Imports output sets from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_OutSets(MyFile& file)
{
	MyString str;
	COutSet os;
	
	//	os.m_uDataBlockID=450;

	FReadString(file,str);

	while (atoi(str)!=-1)
	{

		sscanf(str,"%u",&os.m_nID);

		file.ReadString(str);
		os.m_sTitle = str;

		FReadString(file,str);
		sscanf(str,"%u%u",&os.m_nFrom_prog,&os.m_nAnal_type);
		
		FReadString(file,str);
		sscanf(str,"%lf",&os.m_dValue);

		FReadString(file,str);
		sscanf(str,"%u",&os.m_nNLines);

		for(UINT i=0;i<os.m_nNLines;i++) file.ReadString(str);
		
		m_OutSetArray.Add(os);

		FReadString(file,str);
	}

	return(-1);
}

/*!
 * Imports output vectors from FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the source file.
 * 
 * \param[in] ExpectedNodeCount
 * Expected number of nodes to import. Used to optimize loading speed.
 * 
 * \param[in] ExpectedElemCount
 * Expected number of elements to import. Used to optimize loading speed.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ImportFemap_OutVectors(MyFile& file,UINT ExpectedNodeCount,UINT ExpectedElemCount)
{
	MyString str;
	COutVector ov;
	UINT tmp;
//	os.m_uDataBlockID=450;

	FReadString(file,str);

	while (atoi(str)!=-1)
	{
	
		sscanf(str,"%u%u%u",&ov.m_nSetID,&ov.m_nID,&tmp);

		file.ReadString(str);
		ov.m_sTitle = str;

		FReadString(file,str);
		sscanf(str,"%lf%lf%lf",&ov.m_dMin_val,&ov.m_dMax_val,&ov.m_dAbs_max);
		
		FReadString(file,str);
		sscanf(str,"%u%u%u%u%u%u%u%u%u%u",&(ov.m_Comp[0]),&(ov.m_Comp[1]),&(ov.m_Comp[2]),&(ov.m_Comp[3])
			,&(ov.m_Comp[4]),&(ov.m_Comp[5]),&(ov.m_Comp[6]),&(ov.m_Comp[7]),&(ov.m_Comp[8]),&(ov.m_Comp[9]));
		FReadString(file,str);
		sscanf(str,"%u%u%u%u%u%u%u%u%u%u",&(ov.m_Comp[10]),&(ov.m_Comp[11]),&(ov.m_Comp[12]),&(ov.m_Comp[13])
			,&(ov.m_Comp[14]),&(ov.m_Comp[15]),&(ov.m_Comp[16]),&(ov.m_Comp[17]),&(ov.m_Comp[18]),&(ov.m_Comp[19]));

		FReadString(file,str);
		sscanf(str,"%u%u%u%u",&ov.m_nID_min,&ov.m_nID_max,&ov.m_nOut_type,&ov.m_nEnt_type);

		FReadString(file,str);
		sscanf(str,"%u%u%u",&ov.m_bCalc_warn,&ov.m_nComp_dir,&ov.m_bCalc_warn);

		ov.m_Values.RemoveAll();
		//if(ov.m_nEnt_type==NEU_NODE) ov.m_Values.InitHashTable((UINT)(1.2*ExpectedNodeCount));
		//else ov.m_Values.InitHashTable((UINT)(1.2*ExpectedElemCount));


		UINT entID;
		double value;

		FReadString(file,str);

		bool prvi=TRUE;

		while (atoi(str)!=-1)
		{
			sscanf(str,"%u%lf",&entID,&value);

			ov.SetValue(entID,value);
			
			FReadString(file,str);
		}
		
		COutSet &os = m_OutSetArray.Get(ov.m_nSetID);
		os.m_OutVectors.Add(ov);

		FReadString(file,str);
	}

	return(-1);
}


/*!
 * Exports functions to FEMAP neutral file.
 * 
 * \param[in] file
 * Pointer to the destination file.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::ExportFemap_Functions(MyFile& file)
{
	return(-1);
}

/*!
 * Removes all data from the finite element model.
 * 
 * \returns
 * Nonzero if successful.
 */
UINT CModelData::DeleteContents()
{

	m_NodArray.RemoveAll();
	m_ElArray.RemoveAll();
	m_PropArray.RemoveAll();
	m_ConsArray.RemoveAll();
	m_LoadArray.RemoveAll();
	m_FunctionsArray.RemoveAll();

	m_OutSetArray.RemoveAll();

	return(-1);
}

/*!
 * Initializes finite element model.
 * 
 * \returns
 * Nonzero if successful.
 */





UINT CModelData::OnNewDocument()
{

	return(-1);
}

/*!
 * Adds node to the finite element model.
 * 
 * \param[in] Node
 * Reference to the node to be added.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::AddNode(HNodes &Node)
{
	m_NodArray.Add(Node);

	return(0);
}

/*!
 * Adds element to the finite element model.
 * 
 * \param[in] Elem
 * Reference to the element to be added.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::AddElem(HElement &Elem)
{
	m_ElArray.Add(Elem);

	return(0);
}

/*!
 * Adds property to the finite element model.
 * 
 * \param[in] Prop
 * Reference to the property to be added.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::AddProperty(HProperties &Prop)
{
	m_PropArray.Add(Prop);

	return(0);
}

/*!
 * Adds material to the finite element model.
 * 
 * \param[in] Mat
 * Reference to the material to be added.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::AddMaterial(HMaterial &Mat)
{
	m_MaterialsArray.Add(Mat);

	return(0);
}

/*!
 * Adds function to the finite element model.
 * 
 * \param[in] Func
 * Reference to the function to be added.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::AddFunction(HFunctions &Func)
{
	m_FunctionsArray.Add(Func);

	return(0);
}

/*!
 * Adds load to the finite element model.
 * 
 * \param[in] Load
 * Reference to the load to be added.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::AddLoad(HLoads &Load)
{
	m_LoadArray.Add(Load);

	return(0);
}

/*!
 * Adds constraint to the finite element model.
 * 
 * \param[in] Const
 * Reference to the constraint to be added.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::AddConst(HConstraints &Const)
{
	m_ConsArray.Add(Const);

	return(0);
}

/*!
 * Equalizes two objects of the CModelData class.
 * 
 * \param[in] other
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
CModelData& CModelData::operator =(const CModelData &other)
{
	m_NodArray = other.m_NodArray;
	m_ElArray = other.m_ElArray;
	m_PropArray = other.m_PropArray;;
	m_ConsArray = other.m_ConsArray;
	m_LoadArray = other.m_LoadArray;
	m_MaterialsArray = other.m_MaterialsArray;
	m_FunctionsArray = other.m_FunctionsArray;
	m_OutSetArray = other.m_OutSetArray;

	m_PakGeneral = other.m_PakGeneral;

	return(*this);

}

/*!
 * Imports finite element model from PAK universal file.
 * 
 * \param[in] File
 * Reference to the source file.
 * 
 * \param[in] bImportGeometry
 * Indicator whether geometry data are loaded.
 * 
 * \param[in] bImportOutput
 * Indicator whether results are loaded.
 * 
 * \param[in] nExpectedNodeCount
 * Expected number of nodes to import. Used to optimize loading speed. Optional.
 * 
 * \param[in] nExpectedElemCount
 * Expected number of elements to import. Used to optimize loading speed. Optional.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::ImportUNV(MyFile &File,bool bImportGeometry, bool bImportOutput,UINT nExpectedNodeCount,UINT nExpectedElemCount)
{
	if(bImportGeometry)
	{
		m_NodArray.RemoveAll();
		m_ElArray.RemoveAll();
		m_PropArray.RemoveAll();
		m_ConsArray.RemoveAll();
		m_LoadArray.RemoveAll();
		m_FunctionsArray.RemoveAll();
	}
	if(bImportOutput)
	{
		m_OutSetArray.RemoveAll();
	}

	CImporterUNV ImporterUNV;

	ImporterUNV.m_bImportGeometry = bImportGeometry;
	ImporterUNV.m_bImportOutput = bImportOutput;
	if( nExpectedNodeCount > 0 )	ImporterUNV.SetExpectedNodeCount(nExpectedNodeCount);
	if( nExpectedElemCount > 0 )	ImporterUNV.SetExpectedElemCount(nExpectedElemCount);

	return( ImporterUNV.Import(File, *this) );
}

/*!
 * Renumerates nodes in order to minimize band of skyline matrix.
 * 
 * \param[in] AxisOrder
 * 3-element array representing order of axes for sorting nodes. Nodes are sorted by their position on first axis. If position of two nodes are same, nodes are sorted by second axis. Finally, if both coordinates are the same, nodes are sorted by third axis.
 * 
 * \returns
 * Zero if successful.
 */
UINT CModelData::RenumNodes(UINT AxisOrder[3])
{
	MyMap<UINT,UINT,UINT,UINT> NodeMap;

	UINT i, j;
//	double TOL = GetBoundingBox().getSize().length() * 1.e-6;
	double TOL = 1.e-3;

	//Nodes sorting
	Math3d::M3d Node1Point, Node2Point;
	UINT nNodeCount = m_NodArray.GetSize();
	for(i = 1; i < nNodeCount; i++)
	{
		HNodes no1 = m_NodArray[i];
		Node1Point.set(no1.m_dX, no1.m_dY, no1.m_dZ);
		for(j = 0; j < i; j++)
		{
			HNodes no2 = m_NodArray[j];
			Node2Point.set(no2.m_dX, no2.m_dY, no2.m_dZ);

			if(
			   Node1Point[AxisOrder[0]] + TOL < Node2Point[AxisOrder[0]] ||
			   (
			    fabs( Node1Point[AxisOrder[0]] - Node2Point[AxisOrder[0]]) < TOL && 
			    (
				 Node1Point[AxisOrder[1]] + TOL < Node2Point[AxisOrder[1]] ||
				 (
				  fabs( Node1Point[AxisOrder[1]] - Node2Point[AxisOrder[1]]) < TOL &&
				  Node1Point[AxisOrder[2]] < Node2Point[AxisOrder[2]]
				 )
			    )
			   )
			  )
			{
				m_NodArray[i]=no2;
				m_NodArray[j]=no1;

				no1=no2;
				Node1Point.set(no1.m_dX, no1.m_dY, no1.m_dZ);
			}

		}
	}


//Nodes renumeration
	nNodeCount = (UINT)m_NodArray.GetSize();
	for(i = 0; i < nNodeCount; i++)
	{
		HNodes &no1 = (HNodes &)m_NodArray[i];

		NodeMap[no1.m_nID] = i + 1;
		no1.m_nID = i + 1;
		m_NodArray.SetIDAt(i, no1.m_nID);
	}

//Remap nodes ID in elements

	bool bFound;
	UINT nElemCount = (UINT)m_ElArray.GetSize();
	for(i = 0; i < nElemCount; i++)
	{
		HElement &el=(HElement &)m_ElArray[i];
		if(el.m_uTopology == FETO_LINE)
		{
			for(j = 0; j < 2; j++)
			{
				bFound = NodeMap.Lookup(el.m_uNode[j], el.m_uNode[j]);
				ASSERT(bFound);
			}
		}
		else if(el.m_uTopology == FETO_BRICK8)
		{
			for(j = 0; j < 8; j++)
			{
				bFound = NodeMap.Lookup(el.m_uNode[j], el.m_uNode[j]);
				ASSERT(bFound);
			}

		}
	}

//Remap Loads
	UINT nNewID=0;
	
	for(i = 0; i < (UINT)m_LoadArray.GetSize(); i++)
	{
		HLoads &lo = m_LoadArray.ElementAt(i);

		for(j = 0; j < (UINT)lo.m_NodalTemps.GetSize(); j++)
		{
			NodalTemp &nt = lo.m_NodalTemps.ElementAt(j);

			bool bFound = NodeMap.Lookup(nt.m_uNdtempID, nNewID);

			ASSERT( bFound );

			nt.m_uNdtempID = nNewID;
		}
	}

	return(0);
}

UINT CModelData::InterelementAveraging(UNV_VARIABLES ElemVariable, UNV_VARIABLES NodeVariable, UINT nNodeVectorID, const CEffectiveValueCalculator &EVC)
{
	UINT nElemVectorID, nTmp;
	UINT i, j, k;
	bool bFound;

	UINT ios;
	for(ios = 0; ios < (UINT)m_OutSetArray.GetSize(); ios++)
	{
		COutSet &OS = m_OutSetArray.ElementAt(ios);
		if( !OS.FindOutVectorByOutType(ElemVariable,nElemVectorID) ) return(-1);
		if( OS.FindOutVectorByOutType(NodeVariable,nTmp) ) return(-1);
		
		UINT nComponentCount;

		//Create nodal vectors
		{
			COutVector &ElemOV = OS.GetOutVector(nElemVectorID);		
			COutVector &Node0OV = OS.GetOutVector(ElemOV.m_Comp[0]);	
			nComponentCount = Node0OV.GetComponentCount();

			MyString sCompExt[6] = {"X","Y","Z","RX","RY","RZ"};
			UINT nHashTableSize= m_NodArray.GetSize() * 6/5;
			OS.ProvideNComponentOutVector(nNodeVectorID,OS.GetOutVector(nElemVectorID).m_sTitle,sCompExt,NodeVariable,NEU_NODE,nHashTableSize,nComponentCount);
		}

		//Out vector of element variable
		COutVector &ElemOV = OS.GetOutVector(nElemVectorID);	

		//Out vectors of element nodes
		COutVector *pElemVectors[21][20];
		UINT nNodeCount = ElemOV.GetComponentCount();
		for(i = 0; i < nNodeCount; i++)
		{
			COutVector &NodeOV = OS.GetOutVector(ElemOV.m_Comp[i]);	

			//Componental out vectors of element nodes
			nComponentCount = NodeOV.GetComponentCount();
			for(k = 0; k < nComponentCount; k++)	pElemVectors[i][k] = &OS.GetOutVector(NodeOV.m_Comp[k]);
		}

		//Out vector of averaged nodal variable
		COutVector &NodeOV = OS.GetOutVector(nNodeVectorID);		

		//Componental out vectors of averaged nodal variable
		COutVector *pNodeVectors[20];
		for(k = 0; k < nComponentCount; k++)
		{
			pNodeVectors[k] = &OS.GetOutVector(NodeOV.m_Comp[k]);

			//Initialize component out vector
			for(i = 0; i < (UINT)m_NodArray.GetSize(); i++)
			{
				HNodes &Node = m_NodArray.ElementAt(i);
				pNodeVectors[k]->m_Values.SetAt(Node.m_nID, 0.0);
			}
		}

		//Initialize elements per node
		MyMap<UINT,UINT,UINT,UINT> ElementsPerNode;
		for(i = 0; i < (UINT)m_NodArray.GetSize(); i++)
		{
			HNodes &Node = m_NodArray.ElementAt(i);
			ElementsPerNode.SetAt(Node.m_nID, 0);
		}

		//Loop through elements
		for(i = 0; i < (UINT)m_ElArray.GetSize(); i++)
		{
			HElement &Elem = m_ElArray.ElementAt(i);

			switch(Elem.m_uTopology)
			{
			case FETO_LINE: continue;//nNodeCount = 2;
				break;
			case FETO_QUAD4: nNodeCount = 4;
				break;
			case FETO_BRICK8: nNodeCount = 8;
				break;
			}

			for(j = 0; j < nNodeCount; j++)
			{
				UINT nNodeID = Elem.m_uNode[j];

				UINT nElementsPerNode;
				bFound = ElementsPerNode.Lookup(nNodeID, nElementsPerNode);
				ASSERT(bFound);

				ElementsPerNode.SetAt(nNodeID,nElementsPerNode+1);

				for(k = 0; k < nComponentCount; k++)
				{
					double dElemValue, dNodeValue;
					bFound = pElemVectors[j][k]->m_Values.Lookup(Elem.m_nID, dElemValue);
					ASSERT(bFound);
					bFound = pNodeVectors[k]->m_Values.Lookup(nNodeID, dNodeValue);
					ASSERT(bFound);

					pNodeVectors[k]->m_Values.SetAt(nNodeID, dNodeValue+dElemValue);
				}
			}
		}

		//Average nodal variable
		double dCompValues[20];
		for(i = 0; i < (UINT)m_NodArray.GetSize(); i++)
		{
			HNodes &Node = m_NodArray.ElementAt(i);

			UINT nElementsPerNode;
			bFound = ElementsPerNode.Lookup(Node.m_nID, nElementsPerNode);
			ASSERT(bFound);

			for(k = 0; k < nComponentCount; k++)
			{
				bFound = pNodeVectors[k]->m_Values.Lookup(Node.m_nID, dCompValues[k]);
				ASSERT(bFound);

				pNodeVectors[k]->m_Values.SetAt(Node.m_nID, dCompValues[k]/nElementsPerNode);
			}
			NodeOV.SetValue(Node.m_nID, EVC.Calculate(dCompValues));
		}

		for(k = 0; k < nComponentCount; k++)
		{
			pNodeVectors[k]->RecalculateMinMax();
		}

	}

	return(0);
}