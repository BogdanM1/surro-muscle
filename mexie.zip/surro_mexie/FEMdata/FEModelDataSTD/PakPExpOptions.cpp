/*!
 * \file PakPExpOptions.cpp
 * Implementation of the CPakPExportOptions class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PakPExportOptions.cpp: implementation of the CPakPExportOptions class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "cad.h"
#include "PakPExpOptions.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*!
 * Default constructor.
 */
CPakPExpOptions::CPakPExpOptions()
{

}

/*!
 * Destructor.
 */
CPakPExpOptions::~CPakPExpOptions()
{

}
