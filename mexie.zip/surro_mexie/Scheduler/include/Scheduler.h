/*
* Scheduler.h
* 13.07.2015. Ana
*  
*/
#ifndef SCHEDULER_H_
#define SCHEDULER_H_

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <stdlib.h>
#include <vector>
#include <cmath>

using namespace std;

class Scheduler {
private:
    int* pomInt;
    double* pomDouble;

protected:
	int num_jobs; 	// broj poslova (n_qpoints_all) 
    int num_proc; 		// broj procesa
  //  std::map<int,int> mapToProcess;
	
  //  std::map<int,int> rbrInChunk;
	
    int* to;
	double* W; 	// tezine poslova 
			// (izrazene brojem huxley iteracija )
	double* V;	// brzine resursa na kojima se procesi izvrsavaju
			// 1 za najsporije (CPU)
			// K za one koji su K puta brzi od najsporijih
	int* M;		// memorijski kapaciteti resursa (broj Qpoint-a koje moze da zabelezi)
    vector<std::pair<int, int> > mapToProcess;
	
public:
    Scheduler(int n, int k);
    ~Scheduler();
    void createTestSchedule();
    void createBasicSchedule(double* v, int* m);
    void createBasicSchedule(double* w,double* v, int* m);
    void orderForExecution(double* niz);
    void orderForExecution(int* niz);
    void orderAsOriginal(double* niz);
    void orderAsOriginal(int* niz);
    void getSizeOfPartitions(int* niz);
};

struct sort_predS {
    bool operator()(const std::pair<int,int> &left, const std::pair<int,int> &right) {
        return ((left.second < right.second)||((left.second == right.second) && (left.first<right.first)));
    }
};

#endif /* Scheduler.h */

