/*
 * QPointCalculator.h
 *
 *  Created on: May 2, 2014
 *      Author: anakaplarevic
 */

#ifndef QPOINTCALCULATOR_H_
#define QPOINTCALCULATOR_H_

//#include "FEM.h"
#include <Scheduler.h>
#include "MMChunkCalculator.h"
#include "vector"

class FEM2D;
//#include "Globals.h"

class QPointCalculator {
public:

	 MMChunkCalculator* microModelChunk;
	 FEM2D* macroModel;
	 int n_q_points_all;
     Scheduler* scheduler;

	QPointCalculator();
	virtual ~QPointCalculator();

    virtual void init(int number_of_q_points, MMType* mmtypes,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1) = 0;
    virtual void calculate(double* e,double* sigma,double* dsigmade ) = 0;
    virtual void saveAndcontinue(int* flags) = 0;
};

#endif /* QPOINTCALCULATOR_H_ */
