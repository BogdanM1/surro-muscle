// StringAdvanced.h: interface for the MyStringAdvanced class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_StringAdvanced_H__249CAF80_E73C_11D5_93CB_5254AB509BD5__INCLUDED_)
#define AFX_StringAdvanced_H__249CAF80_E73C_11D5_93CB_5254AB509BD5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//#include "..\stdafx.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include "MyString.h"

class MyStringAdvanced : public MyString  
{
public:
	MyStringAdvanced();
	virtual ~MyStringAdvanced();

	//void FormatV(const char * lpszFormat, va_list argList);
	//void Format(const char * lpszFormat, ...);
 //   void RemoveExponents(const char * lpszFormat, va_list argList);
};

#endif // !defined(AFX_StringAdvanced_H__249CAF80_E73C_11D5_93CB_5254AB509BD5__INCLUDED_)
