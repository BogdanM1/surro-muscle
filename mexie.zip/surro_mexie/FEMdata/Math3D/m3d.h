// -*- c++ -*-
#ifndef INCLUDED_MATH3D_M3D_H
#define INCLUDED_MATH3D_M3D_H
/*
* Math3d - The 3D Computer Graphics Math Library
* Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
* All rights reserved.
*
* This program is  free  software;  you can redistribute it and/or modify it
* under the terms of the  GNU Lesser General Public License  as published by 
* the  Free Software Foundation;  either version 2.1 of the License,  or (at 
* your option) any later version.
*
* This  program  is  distributed in  the  hope that it will  be useful,  but
* WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
* or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
* License for more details.
*
* You should  have received  a copy of the GNU Lesser General Public License
* along with  this program;  if not, write to the  Free Software Foundation,
* Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* $Id: m3d.h,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
*/

#ifndef INCLUDED_MATH3D_MATH3DDEF_H
#include "math3ddef.h"
#endif

namespace Math3d {
	
	class M2d;
	class M4d;
	class MQuat;
	class M4x4;
	
	/** 
	* 3-dimensional vector class.
	*/
	class _CCMATH3D M3d {
    public:
		double x,y,z;
		const static M3d AxisX;
		const static M3d AxisY;
		const static M3d AxisZ;
    public:
	    void RotateArroundVector(double dAngle, const M3d & vec);
		M3d() {};
		M3d(double tx, double ty, double tz) {set(tx,ty,tz);};
		M3d(const M2d& A);
		M3d(const M3d& A);
		M3d(const M4d& A);
		const M3d& operator=(const M3d& A);
		
		void zero();
		void Init(double sx, double sy, double sz) {set(sx,sy,sz);};
		void set(double sx, double sy, double sz) {x=sx; y=sy; z=sz;};
		void copy(const M3d& A);
		
		inline double& operator[](int i);
		//operator double*() {return(&x);}
		double& X() {return(x);}
		double& Y() {return(y);}
		double& Z() {return(z);}
		double& get(int i);
		
		void Translate(double tx, double ty, double tz)
		{
			x+=tx;
			y+=ty;
			z+=tz;
		}
		double DistSqr(const M3d& A) const
		{
			return Math3dSqr(x-A.x) + Math3dSqr(y-A.y) + Math3dSqr(z-A.z);
		}
		double Dist(const M3d& A) const
		{
			return sqrt(DistSqr(A));
		}
		double DistSqrXY(const M3d& A) const
		{
			return Math3dSqr(x-A.x) + Math3dSqr(y-A.y);
		}
		double Norm() const {return sqrt(NormSqr());}
		double NormSqr() const {return x*x + y*y + z*z;}
		void Normalize();
		const M3d Cross(const M3d &v) const {
			return M3d(
				y*v.z - z*v.y,
				z*v.x - x*v.z,
				x*v.y - y*v.x);
		}	
		M3d operator+(const M3d& A) const;
		M3d operator+() const;
		const M3d& operator+=(const M3d& A);
		M3d operator-(const M3d& A) const;
		M3d operator-() const;
		const M3d& operator-=(const M3d& A);
		M3d operator*(double k) const;
		const M3d& operator*=(double k);
		void neg();
		void abs();
		void add(const M3d& A, const M3d& B);
		void sub(const M3d& A, const M3d& B);
		void scalar(double k);
		void cartesianize();
		M2d cartesianized();
		void rationalize();
		void homogenize();
		void cross(const M3d& A, const M3d& B);
		void lerp(const M3d& A, const M3d& B, double t);
		void normal(const M3d& A, const M3d& B, const M3d& C);
		void Min(const M3d& m);
		void Max(const M3d& m);
		void MaxXY(const M3d& m)
		{
			if (x < m.x) x = m.x;
			if (y < m.y) y = m.y;
		}
		void MinXY(const M3d& m)
		{
			if (x > m.x) x = m.x;
			if (y > m.y) y = m.y;
		}
		void operator /= (double koef)
		{
			ASSERT(koef != 0);
			x /= koef;
			y /= koef;
			z /= koef;
		}
		/** Rotate given angle */
		void RotateXY(double dAngle)
		{
			double s, c;
			s = sin(dAngle);
			c = cos(dAngle);
			double t = x;
			x = (t*c - y*s);
			y = (t*s + y*c);
		}

		/** Rotate given sin and cos of angle */
		void RotateXYSinCos(double dSin, double dCos)
		{
			double t = x;
			x = (t*dCos - y*dSin);
			y = (t*dSin + y*dCos);
		}

		/** Rotate for 90 degrees in xy plane*/
		void RotateXY90()
		{
			double t = x;
			x = -y;
			y = t;
		}

		void cubic(const M3d& A, const M3d& TA, const M3d& TB, 
			const M3d& B, double t);
		
		inline double operator[](int i) const;
		double X() const {return(x);}
		double Y() const {return(y);}
		double Z() const {return(z);}
		double get(int i) const;
		
		double operator*(const M3d& A)  const;  //dot product!
		bool operator==(const M3d& A) const;
		bool operator!=(const M3d& A) const;
		double dot(const M3d& A) const;
		bool cmp(const M3d& A, double epsilon=EPSILON) const;
		double squared() const;
		double length() const;

		//void Serialize(CArchive &ar);

		friend class M2d;
		friend class M4d;
		friend class MQuat;
		friend class M4x4;
	};
	
	inline double&
		M3d::operator[](int i)
	{
		ASSERT(i>=0 && i<3);
		return((&x)[i]);
	}
	inline double
		M3d::operator[](int i) const
	{
		ASSERT(i>=0 && i<3);
		return((&x)[i]);
	}

	//  extern _CCMATH3D std::ostream& operator << (std::ostream& co, const M3d& v);
	
}
#endif // INCLUDED_MATH3D_M3D_H







