#pragma once

#include "Stdafx.h"
#include <vector>
#include <map>

using namespace std;

	template<class KEY_TYPE, class VALUE_TYPE>
	class MappedArray
	{
	public:
		MappedArray(){ }

		MappedArray( int capacity ) { Reserve(capacity); }

		inline int Count() { return _Vector.size(); }
		inline int GetSize() { return Count(); }
		inline int GetUpperBound() { return Count()-1; }

		inline void Reserve( int capacity ) { _Vector.reserve(capacity); }

		inline void Add( KEY_TYPE key, VALUE_TYPE value ) { _Map[key] = _Vector.size(); _Vector.push_back(value); }
		int Add( VALUE_TYPE value )
		{
			_Map[value.m_nID] = _Vector.size();
			_Vector.push_back(value);
			return _Vector.size()-1;
		}

		inline VALUE_TYPE& GetById( KEY_TYPE key ) { return GetByIndex( _Map[key] ); }
		inline VALUE_TYPE& Get( KEY_TYPE key ) { return ElementAt( _Map[key] ); }

		inline VALUE_TYPE& GetByIndex( int index ) { return _Vector[index]; }
		inline VALUE_TYPE& ElementAt( int index ) { return _Vector[index]; }

		inline UINT GetIndex(KEY_TYPE key)	{ return _Map[key];}
		inline bool FindIndex(KEY_TYPE key, UINT &index)
		{
			typename map<KEY_TYPE,int>::iterator it;

			if( (it = _Map.find(key)) != _Map.end())
			{
				index = it->second;
				return TRUE;
			}

			return FALSE;
		}

		inline void Clear() {_Vector.clear(); _Map.clear(); }
		inline void RemoveAll() { Clear(); }

		inline VALUE_TYPE& operator[](int index) { return _Vector[index]; }

		inline void SetIDAt(UINT nIndex, UINT nID)
		{
			VALUE_TYPE &Element = _Vector[nIndex];
			_Map.erase(_Map.find(Element.m_nID));
			Element.m_nID = nID;
			_Map[nID] = nIndex;
		}

		inline bool IsExist(KEY_TYPE key)	{ return (_Map.find(key) != _Map.end()); }

		void Remove(KEY_TYPE key)
		{
			_Vector.erase( _Vector.begin()+ _Map[key] );

			Remap();
		}

		void Remap()
		{
			_Map.clear();

			for(int i = 0; i < _Vector.size(); i++)	_Map[_Vector[i].m_nID] = i;
		}

		inline void SetSize(int size, int grow_by)
		{
			_Vector.reserve(size);
		}

	private:
		vector<VALUE_TYPE> _Vector;
		map<KEY_TYPE, int> _Map;
	};
