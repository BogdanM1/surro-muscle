/*!
 * \file HElement.h
 * Interface for the HElement class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HElement.h: interface for the HElement class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HELEMENT_H__ABFFBE40_6355_11D2_B069_444553540000__INCLUDED_)
#define AFX_HELEMENT_H__ABFFBE40_6355_11D2_B069_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "HDataBlock.h"
#include "MyArray.h"

/** Class representing finite element. */
class HElement : public HDataBlock  
{
public:
	HElement();
	HElement(const HElement& rc);
	virtual ~HElement();

	HElement& operator = (const HElement& rp);

	//DECLARE_SERIAL(HElement)
	//void Serialize( CArchive& ar );

	/// ID of the element
	UINT m_nID;
	/// Color of the element
	UINT m_uColor;
	/// ID of the element property
	UINT m_uPropID;
	/// Type of the element
	UINT m_uType;
	/// Topology of the element
	UINT m_uTopology;
	/// Layer of the element
	UINT m_uLayer;
	UINT m_uOrientID;
	/// Flag of the material orientation
	bool m_bMatl_orflag;
	/// Array of node IDs
	UINT m_uNode[21];
	double m_dOrient[3];
	double m_dOffset1[3];
	double m_dOffset2[3];
	bool m_bRelease1[6];
	bool m_bRelease2[6];

	MyArray<UINT,UINT> m_NodeList;

};

#endif // !defined(AFX_HELEMENT_H__ABFFBE40_6355_11D2_B069_444553540000__INCLUDED_)
