/*
 * MaterialModelState.h
 *
 *  Created on: Jul 18, 2013
 *      Author: anakaplarevic
 */
#ifndef MATERIALMODELSTATE_H_
#define MATERIALMODELSTATE_H_

#include "MaterialModelParameters.h"

class MaterialModelState
{
public:
	MaterialModelState();
	virtual ~MaterialModelState() = 0;
	virtual void init(MaterialModelParameters* p)=0;
	virtual void init(MaterialModelState* s)=0;
	virtual bool equal(MaterialModelState* s)=0;
};

#endif /* MATERIALMODELSTATE_H_ */
