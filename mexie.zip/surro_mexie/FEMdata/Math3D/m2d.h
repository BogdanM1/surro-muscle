// -*- c++ -*-
#ifndef INCLUDED_MATH3D_M2D_H
#define INCLUDED_MATH3D_M2D_H
/*
* Math3d - The 3D Computer Graphics Math Library
* Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
* All rights reserved.
*
* This program is  free  software;  you can redistribute it and/or modify it
* under the terms of the  GNU Lesser General Public License  as published by 
* the  Free Software Foundation;  either version 2.1 of the License,  or (at 
* your option) any later version.
*
* This  program  is  distributed in  the  hope that it will  be useful,  but
* WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
* or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
* License for more details.
*
* You should  have received  a copy of the GNU Lesser General Public License
* along with  this program;  if not, write to the  Free Software Foundation,
* Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*
* $Id: m2d.h,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
*/

#ifndef INCLUDED_MATH3D_MATHDEF_H
#include "math3ddef.h"
//#include <afx.h>
#endif

namespace Math3d
{
	
	class M3d;
	
	/**
	* 2-dimensional vector class.
	*/
	class _CCMATH3D M2d {
    public:
		double x,y;
		const static M2d AxisX;
		const static M2d AxisY;

		M2d() {}
		M2d(double tx, double ty) {set(tx,ty);};
		M2d(const M2d& A);
		M2d(const M3d& A);
		const M2d& operator=(const M2d& A);
		
		double NormSqr()
		{
			return x*x + y*y;
		}
		double Cross(const M2d &v) const
		{
			return (x*v.y - y*v.x);
		}
		double Dot(const M2d &v) const
		{
			return (x*v.x + y*v.y);
		}
		void Translate(double dx, double dy)
		{
			x+=dx;
			y+=dy;
		}

		void RotateMinus90()
		{
			double t = x;
			x = y;
			y = -t;
		}
		
		void Rotate90()
		{
			double t = x;
			x = -y;
			y = t;
		}
		
		void operator /= (double koef)
		{
			x /= koef;
			y /= koef;
		}
		
		double DistSqr(const M2d& A) const
		{
			return ((x-A.x)*(x-A.x) + (y-A.y)*(y-A.y));
		}

		double Dist(const M2d& A) const
		{
			return ( sqrt(DistSqr(A)) );
		}

		void zero();
		void Init(double sx, double sy) {set(sx, sy);}
		void set(double sx, double sy) {x=sx; y=sy;};
		void copy(const M2d& A);
		
		inline double& operator[](int i);
		//operator double*() {return(d_v);}
		double& X() {return(x);}
		double& Y() {return(y);}
		double& get(int i);
		
		M2d operator+(const M2d& A);
		M2d operator+();
		const M2d& operator+=(const M2d& A);
		M2d operator-(const M2d& A) const;
		M2d operator-();
		const M2d& operator-=(const M2d& A);
		M2d operator*(double k);
		const M2d& operator*=(double k);
		void neg();
		void abs();
		void add(const M2d& A, const M2d& B);
		void sub(const M2d& A, const M2d& B);
		void scalar(double k);
		void normalize();
		void Normalize() {normalize();}
		void lerp(const M2d& A, const M2d& B, double t);
		void Min(const M2d& min);
		void Max(const M2d& max);
		void cubic(const M2d& A, const M2d& TA, const M2d& TB, 
			const M2d& B, double t);
		
		inline double operator[](int i) const;
		//operator const double*() const {return(d_v);}
		double X() const {return(x);}
		double Y() const {return(y);}
		double get(int i) const;
		
		double operator*(const M2d& A)  const;  //dot product!
		bool operator==(const M2d& A) const;
		bool operator!=(const M2d& A) const;
		double dot(const M2d& A) const;
		bool cmp(const M2d& A, double epsilon=EPSILON) const;
		double squared() const;
		double length() const;

		//void Serialize(CArchive& ar);

		
		friend class M3d;
	};
	
	inline double&
		M2d::operator[](int i)
	{
		ASSERT(i>=0 && i<2);
		return((&x)[i]);
	}
	inline double
		M2d::operator[](int i) const
	{
		ASSERT(i>=0 && i<2);
		return((&x)[i]);
	}
	
	//  extern _CCMATH3D std::ostream& operator << (std::ostream& co, const M2d& v);
	
}
#endif // INCLUDED_MATH3D_M2D_H
