/*
 * MMChunkCUDA.cpp
 *
 *  Created on: May 22, 2014
 *      Author: anakaplarevic
 */

#include "MMChunkCUDA.h"
#ifdef imaCUDA
    #include "HuxleyCalculatorCudaThrust.h"
    #include "HuxleyCalculatorCudaCustom.h"
    #include "HuxleyCalculatorCudaParam.h"
#endif

MMChunkCUDA::MMChunkCUDA() {
    _cudaTip = NULL;
    printf("MMChunkCUDA::MMChunkCUDA()\n");
#ifdef imaCUDA
    printf("MMChunCUDA vidi imaCUDA\n");
    cudaHuxley = new HuxleyCalculatorCudaThrust();
#else
    printf("MMChunCUDA ne vidi imaCUDA\n");
    cudaHuxley = NULL;
#endif
}

MMChunkCUDA::MMChunkCUDA(CUDARunType *cudaTip) {
#ifdef imaCUDA
    printf("MMChunkCUDA::MMChunkCUDA(CUDARunType *cudaTip)\n");
    _cudaTip = cudaTip;
    switch(*cudaTip)
    {
    case CUDARunThrust:
    {
            cudaHuxley = new HuxleyCalculatorCudaThrust();
            printf("cudaHuxley = new HuxleyCalculatorCudaThrust();\n");
    }
            break;
    case CUDARunCustom:
    {
          //  cudaHuxley = new HuxleyCalculatorCudaCustom();
            cudaHuxley = new HuxleyCalculatorCudaParam();
            printf("cudaHuxley = new HuxleyCalculatorCudaCustom();\n");
    }
            break;
    default:
    {
            printf("Nepostojeci nacin izrsavanja CUDACalcualtor klase\n");
    }
            break;
    }
#else
    printf("MMChunCUDA ne vidi imaCUDA\n");
    cudaHuxley = NULL;
#endif
}

MMChunkCUDA::~MMChunkCUDA() {
}

/*void MMChunkCUDA::init(int num_points,MMType *types){
#ifdef imaCUDA
    sizeOfChunk = num_points;

	this->types = types;
	for(int i=0;i<sizeOfChunk;i++){
		if (types[i]!=Huxley1D && types[i]!=Huxley2D && types[i]!=Huxley3D)
		{
			printf("tipovi materijalnih modela poslatih na CUDA-u nisu hakslijevski\n");
			return;
		}
	}
	fillArrays(1,types);
    printf("CUDA:  sizeOfChunk = %d\n",sizeOfChunk);
    iterCount.resize(sizeOfChunk);
	cudaHuxley->Initialize(sizeOfChunk,(HuxleyParameters*)model[0]->getParameters());
#endif
}
*/

void MMChunkCUDA::init(int num_points,MMType *types, std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1){
#ifdef imaCUDA
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::init ... start\n");
    fflush(velikiLogChunk);
#endif
    sizeOfChunk = num_points;

        this->types = types;
        for(int i=0;i<sizeOfChunk;i++){
                if (types[i]!=Huxley1D && types[i]!=Huxley2D && types[i]!=Huxley3D)
                {
                        printf("tipovi materijalnih modela poslatih na CUDA-u nisu hakslijevski\n");
                        return;
                }
        }
//        fillArrays(1,types);
    fillArrays(num_points,types,m_E,m_ni,m_fi,m_f1);
    printf("CUDA:  sizeOfChunk = %d\n",sizeOfChunk);
    iterCount.resize(sizeOfChunk);
        cudaHuxley->Initialize(sizeOfChunk,(HuxleyParameters*)model[0]->getParameters());
    
    std::vector<float> m_g1;
    std::vector<float> m_g2;
    m_g1.resize(num_points);
    m_g2.resize(num_points);
    for(int i=0;i<num_points;i++)
     {
           hp[i]->m_f1=m_f1[i];
           m_g1[i]=hp[i]->m_g1;
           m_g2[i]=hp[i]->m_g2;
     }
     std::vector<float> local_f1;
     local_f1.resize(num_points);
     for(int i=0;i<num_points;i++) local_f1[i]=m_f1[i];
         ((HuxleyCalculatorCudaParam*)cudaHuxley)->Set_m_f1(local_f1);
         ((HuxleyCalculatorCudaParam*)cudaHuxley)->Set_m_g1(m_g1); // ne sluzi nicemu, nece se update-ovati
         ((HuxleyCalculatorCudaParam*)cudaHuxley)->Set_m_g2(m_g2); // ne sluzi nicemu, nece se update-ovati
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::init ... end\n");
    fflush(velikiLogChunk);
#endif
#endif
}


void MMChunkCUDA::calculateChunk(double *e_original,double* sigma,double* dsigmade){
#ifdef imaCUDA
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::calculateChunk ... start\n");
    fflush(velikiLogChunk);
#endif
    int dim = Globals::getInstance()->dimOfSigmaVector;
	int coord =  ((HuxleyParameters*)model[0]->getParameters())->direction;
	std::vector<float> f,fp;
	std::vector<float> e,ep;
    std::vector<int> iter1,iter2;
    e.resize(sizeOfChunk);
	ep.resize(sizeOfChunk);
	f.resize(sizeOfChunk);
	fp.resize(sizeOfChunk);
    iter1.resize(sizeOfChunk);
    iter2.resize(sizeOfChunk);
    long tmpCount=0,tmpV=0,tmpVP = 0;
	for (int i=0; i<sizeOfChunk; i++) {
        printf("%f \t %f \t %f\n",*(e_original+i*dim),*(e_original+i*dim+1),*(e_original+i*dim+2));
		//ep[i]=((float)*(e_original+i*dim+coord))+pertubacija;
	}

#ifdef LOGON
    std::vector<float> pomF;
    pomF.resize(sizeOfChunk);
    cudaHuxley->getForce(pomF);
#endif

    float pertubacija = ((HuxleyParameters*)model[0]->getParameters())->pertubacija;

	printf("cudaWrapper2D 2 \n");
	for (int i=0; i<sizeOfChunk; i++) {
		e[i]=(float)*(e_original+i*dim+coord);
		ep[i]=((float)*(e_original+i*dim+coord))+pertubacija;
	}
	cudaHuxley->Calculate(ep,Globals::getInstance()->dt);
	cudaHuxley->getForce(fp);
    if (*_cudaTip==CUDARunCustom) {
        cudaHuxley->getCountOfIterations(tmpV);
        ((HuxleyCalculatorCudaCustom*)cudaHuxley)->getIter_count(iter1);
    }
    cudaHuxley->Calculate(e,Globals::getInstance()->dt);
	cudaHuxley->getForce(f);
    if (*_cudaTip==CUDARunCustom) {
        cudaHuxley->getCountOfIterations(tmpVP);
        ((HuxleyCalculatorCudaCustom*)cudaHuxley)->getIter_count(iter2);
        tmpCount = tmpV+tmpVP;
    }
#ifdef LOGON
    fprintf(velikiLogChunk,"... racun \n");
    fprintf(velikiLogChunk,"tacka\tf\te\tsigma\tdeltasigma\n");
    fflush(velikiLogChunk);
#endif
	for(int i=0;i<sizeOfChunk;i++) {
		printf("--- Stampam za %d -ti model u chunku\n",i);    
	        if (*_cudaTip==CUDARunCustom) iterCount[i]=iter1[i]+iter2[i];
 			model[i]->CalculateStress((float*)&f[i],(float*)&fp[i],(e_original+i*dim),(sigma+i*dim),(dsigmade+i*dim*dim));
                printf("--- ------- za %d -ti model u chunku\n",i); 
		printf("f =%f \t fp = %f e[0] = %f \t e[1] = %f \t e[2] = %f\n",f[i],fp[i],*(e_original+i*dim),*(e_original+i*dim+1),*(e_original+i*dim+2));
    #ifdef LOGON
        if (i<10)  {
            fprintf(velikiLogChunk,"%d\t%f\t%f\t%f\t%f\n",moj_start+i,pomF[i],*(e_original+i*dim),*(sigma+i*dim),*(dsigmade+i*dim*dim));
            fflush(velikiLogChunk);
        }
    #endif
    }
//    printf("MMChunkCUDA::calculateChunk - countV:%ld \t countVP:%ld \t total:%ld\n",tmpCount);
    if (*_cudaTip==CUDARunCustom) {
        printf("\nMMChunkCUDA::calculateChunk - countV:%ld \t countVP:%ld \t total:%ld\n\n",tmpV,tmpVP,tmpCount);
        allIterationCount+=tmpCount;
    }
    e.clear();
    ep.clear();
    f.clear();
    fp.clear();
    iter1.clear();
    iter2.clear();
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::calculateChunk ... end\n");
    fflush(velikiLogChunk);
#endif
#endif
}

void MMChunkCUDA::setToNew(int flag){
#ifdef imaCUDA
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::setToNew ... start\n");
    fflush(velikiLogChunk);
#endif
    if (flag ==1)  cudaHuxley->SetToNew(); // Pogledati Worker2DCuda u projektu FEM_MPI_CUDA, setToNew je radjen i kada je flag[1] 0
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::setToNew ... end\n");
    fflush(velikiLogChunk);
#endif
#endif
}

/*void MMChunkCUDA::updateParameters(int num_points, std::vector<_TIP> &m_f1) {
#ifdef imaCUDA
	std::vector<float> local_f1;
	local_f1.resize(num_points);
	for(int i=0;i<num_points;i++) local_f1[i]=m_f1[i];
      
     ((HuxleyCalculatorCudaParam*)cudaHuxley)->Set_m_f1(local_f1); // prepisan metod za update
#endif
}*/

void MMChunkCUDA::fillArrays(int num_points,MMType *types,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1) {
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::fillArrays ... start\n");
    fflush(velikiLogChunk);
#endif
    model = (MaterialModel**) malloc(num_points*sizeof(MaterialModel*));
        //state_t = (MaterialModelState**) malloc(num_points*sizeof(MaterialModelState*));
        //state_curr = (MaterialModelState**) malloc(num_points*sizeof(MaterialModelState*));
	hp.resize(num_points);
	    printf("poceo filArray\n");
    std::vector<float> m_g1;
    std::vector<float> m_g2;
    m_g1.resize(num_points);
    m_g2.resize(num_points);
    for(int i=0;i<num_points;i++)
        {
            //if ((types[i]!=Huxley1D) && (types[i]!=Huxley2D)) return;
            hp[i] = new HuxleyParameters();
            hp[i]->InputData();
           //printf("Model m_E[i] = %lf\n",m_f1[i]);
            hp[i]->_E=m_E[i];
            hp[i]->_ni=m_ni[i];
            hp[i]->_fi=m_fi[i];
            hp[i]->m_f1=m_f1[i];
	    m_g1[i]=hp[i]->m_g1;
	    m_g2[i]=hp[i]->m_g2;
            model[i]=new HuxleyModel2D(hp[i]);
	// U originalnoj verziji fillArrays (u MMChunkCalculatoru) ide kreiranje State objekata
	}
 /*       std::vector<float> local_f1;
        local_f1.resize(num_points);
        for(int i=0;i<num_points;i++) local_f1[i]=m_f1[i];
	 ((HuxleyCalculatorCudaParam*)cudaHuxley)->Set_m_f1(local_f1); 
	 ((HuxleyCalculatorCudaParam*)cudaHuxley)->Set_m_g1(m_g1); // ne sluzi nicemu, nece se update-ovati
	 ((HuxleyCalculatorCudaParam*)cudaHuxley)->Set_m_g2(m_g2); // ne sluzi nicemu, nece se update-ovati
*/
#ifdef LOGON
    fprintf(velikiLogChunk,"MMChunkCUDA::fillArrays ... end\n");
    fflush(velikiLogChunk);
#endif
}



