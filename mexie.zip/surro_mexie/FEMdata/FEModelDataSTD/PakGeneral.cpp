// PakGeneral.cpp: implementation of the CPakGeneral class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "CAD.h"
#include "PakGeneral.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPakGeneral::CPakGeneral()
{
	m_iProgramStart=0;
	m_IterMethod.m_bConvEnergy=TRUE; //Konvergiranje energije
	m_IterMethod.m_bConvForce=FALSE; //Konvergiranje sile
	m_IterMethod.m_bConvMoment=FALSE; //Konvergiranje momenta
	m_IterMethod.m_iIterMethod=1; //Iterativni metod
	m_IterMethod.m_dTOLE=1.e-8; //Tolerancija energije
	m_IterMethod.m_dTOLS=1.e-8; //Tolerancija sile
	m_IterMethod.m_dTOLM=1.e-8; //Tolerancija momenta
	m_IterMethod.m_dTOLA=0.0; //Apsolutna tolerancija
	m_iAnalysisType=0; //Tip analize
	m_iFieldType=0; //
	m_bDynamic=FALSE; //Iskljucena dinamika
	m_bEigenValue=FALSE; //Iskljucena Eigenvalue
	m_bFreeNumeration = TRUE; //Ukljucena slobodna numeracija
	m_bReadInitFile = FALSE; //Iskljuceno pocetno citanje iz fajla
	m_bIale = FALSE; //Iskljucena ALE formulacija
	m_bIBound = FALSE; //Iskljucen IBOUND
}

CPakGeneral::~CPakGeneral()
{

}

CPakGeneral& CPakGeneral::operator=(const CPakGeneral &other)
{
	m_strTitle = other.m_strTitle;
	m_bDynamic = other.m_bDynamic;	
	m_bEigenValue = other.m_bEigenValue;
	m_bFreeNumeration = other.m_bFreeNumeration;
	m_bReadInitFile = other.m_bReadInitFile;
	m_bIale = other.m_bIale;
	m_bIBound = other.m_bIBound;
	m_iNSOPV = other.m_iNSOPV;
	m_iProgramStart = other.m_iProgramStart;
	m_iAnalysisType = other.m_iAnalysisType;
	m_iFieldType = other.m_iFieldType;


//Time periods
	m_TimeSteps = other.m_TimeSteps;
	m_IterMethod = other.m_IterMethod;

	return( *this );
}

MyString CPakGeneral::GetTitle()
{
	return(m_strTitle);
}

bool CPakGeneral::GetDynamicAnIsSet()
{
	return(m_bDynamic);	
}

bool CPakGeneral::GetEigenvalueIsSet()
{
	return(m_bEigenValue);
}

int CPakGeneral::GetNSOPV()
{
	return(m_iNSOPV);
}

int		CPakGeneral::GetProgramStart()
{
	return(m_iProgramStart);
}

int		CPakGeneral::GetAnalysisType()
{
	return(m_iAnalysisType);
}

//TimePeriods

int		CPakGeneral::GetNumOfPeriods()
{
	return(m_TimeSteps.GetTimePeriodsCount());
}

int		CPakGeneral::GetNumSteps(int i)
{
	return(m_TimeSteps.GetTimePeriod(i).nSteps);
}

double	CPakGeneral::GetStep(int i)
{
	return(m_TimeSteps.GetTimePeriod(i).dStepDuration);
}

int CPakGeneral::GetMaterialModel(int ElementType)
{
	if (GetAnalysisType()!=0)
	{
		if (ElementType!=1)
		{
//			return(6);
//			return(3);
			return(1);
		}
		else
		{
			return(5);
		}
	}
	else
	{
		return(1);
	}
}

//Ither method

int	CPakGeneral::GetIterMethod()
{
	return(m_IterMethod.m_iIterMethod);
}

UINT CPakGeneral::GetNodeNumber()
{
	return(m_IterMethod.m_uNodeNumber);
}

int CPakGeneral::GetDirection()
{
	return(m_IterMethod.m_iDirection);
}

double CPakGeneral::GetValue()
{
	return(m_IterMethod.m_dValue);
}

double CPakGeneral::GetAG()
{
	return(m_IterMethod.m_dAG);
}

double CPakGeneral::GetDS()
{
	return(m_IterMethod.m_dDS);
}
