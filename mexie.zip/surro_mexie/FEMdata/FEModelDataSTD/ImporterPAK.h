/*
 * ImporterPAK.h
 *
 *  Created on: Jun 30, 2014
 *      Author: Marina Svicevic
 */

// ImporterPAK.h: interface for the CImporterPAK class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMPORTERPAK_H__82CB7E64_0518_49B5_A230_DE27A9592326__INCLUDED_)
#define AFX_IMPORTERPAK_H__82CB7E64_0518_49B5_A230_DE27A9592326__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class COutSet;
class CEffectiveValueCalculator;
class CModelData;
#include <fstream>
#include <iostream>
#include <math.h>
#include <cstdlib>
#include <map>

//PAK Block markers
#define PAKC_CardH3 "C /3/ BASIC DATA FOR THE PROBLEM (5I5)"
#define PAKC_CardV3 "C NP,NGELEM,NMATM,NPER,NKRT"

#define PAKC_CardH10 "C /10/ INPUT NODAL DATA (I5,A1,6I2,2X,3F10.0,2I5)   (K=1,NP)"
#define PAKC_CardV10 "C  N,CH,(ID(N,I),I=1,6),   (CORD(N,J),J=1,3),      KORC,INDS"

#define PAKC_CardH13 "C /13/ INPUT DATA FOR ELEMENT GROUP (8I5,3F10.0)    (I=1,NGELEM)"
#define PAKC_CardV13 "C NETIP,NE,IATYP,NMODM,INDBTH,INDDTH,INDKOV,ICOEF,COEF1,COEF2,   COEF3"

#define PAKC_CardH11 "C /11/ DATA FOR MATERIAL MODELS (3I5)"
#define PAKC_CardV11 "C (MODEL(I,K),I=1,3)    (K=1,NMATM)"

#define PAKC_CardH12 "C /12/ DATA FOR MATERIAL (2I5,F10.0)"
#define PAKC_CardV12 "C MOD  MAT     GUST"

#define PAKC_CardActivation "C Activation function"


/** Class containing functions for importing data from PAK PAK file. */
class CImporterPAK  
{
public:
	 CImporterPAK();
	 virtual ~CImporterPAK();

     void import(FILE *f, FILE *g,  CModelData &ModelData);
     void setSizeOfArray(FILE *f);
     void import_node(FILE *f);
     void import_elements(FILE *f);
     void importFiberDirections(FILE *f);
     
     void setNumberOfMaterial(FILE *f);
     void import_material(FILE *f);
     void import_ActivationFunction(FILE *f);
	 bool skip_comment(FILE *f, char s[]);
     
     static unsigned int PAK2FEMAP_NodeOrder2D_4[4];

//private:
	 
	 unsigned int n_Point;
	 unsigned int n_Material;
	 unsigned int n_Group;
	 std::map <int,int> mapaNodova;
	 std::map <int,int> mapaElemenata;
	 std::map <int,int> mapaMaterijala;
	 int vrste_materijala[11];

	 CModelData *m_pModelData;
};

#endif // !defined(AFX_IMPORTERPAK_H__82CB7E64_0518_49B5_A230_DE27A9592326__INCLUDED_)

