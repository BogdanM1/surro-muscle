/*
 * ImporterPAK.cpp
 *
 *  Created on: Jun 30, 2014
 *      Author: Marina Svicevic
 */

// ImporterPAK.cpp: implementation of the CImporterPAK class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "ImporterPAK.h"

#include "FEModelData.h"
#include "EffectiveTranslation.h"
#include "EquivalentVonMisesStress.h"
#include "EquivalentStrain.h"
#include "EffectiveScalar.h"
#include "FileIO.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

unsigned int CImporterPAK::PAK2FEMAP_NodeOrder2D_4[4]={2,3,0,1};

/*!
 * Default constructor.
 */
CImporterPAK::CImporterPAK()
{
}

/*!
 * Destructor.
 */
CImporterPAK::~CImporterPAK()
{

}

void CImporterPAK::import(FILE *f, FILE *g, CModelData &ModelData)
{
		char s[100];
	    m_pModelData = &ModelData;
	    while (fgets (s, 100 , f) != NULL)
		{
						int i=0;
	    				while(s[i])
	    				{
	    					if(s[i]==10) s[i]='\0';
	    					if(s[i]==13) s[i]='\0';
	    					i++;
	    				}
	    				if (strcmp(s, PAKC_CardV3)==0)
	    								{
	    												setSizeOfArray(f);
	    								}
	    				if (strcmp(s, PAKC_CardV10)==0)
	    								{
	    					                            import_node(f);
	    								}
	    				if (strcmp(s, PAKC_CardV13)==0)
	    								{
	    												import_elements(f);
	    								}
	    			    if (strcmp(s, PAKC_CardV11)==0)
										{
											            setNumberOfMaterial(f);
											            fgets (s, 100 , f);
										}
						if (strcmp(s, PAKC_CardV12)==0)
										{
											            import_material(f);
										}

         }
         //importFiberDirections(g);
}

void CImporterPAK::setSizeOfArray(FILE *f)
{
								fscanf(f,"%d",&n_Point);
								fscanf(f,"%d",&n_Group);
								fscanf(f,"%d",&n_Material);
								
                                //n_Point = n_Point -11; //-11 zbog poslenjih 11 cvorova koji nisu potrebni
								m_pModelData->m_NodArray.SetSize(n_Point,-1);
}

void CImporterPAK::setNumberOfMaterial(FILE *f)
{
								int br1, br2;
								char s[100];
								for(int i=0; i<n_Material; i++)
								{
									fscanf(f,"%d%d",&br1,&br2);
									int br_trenutno = m_pModelData->m_MaterialsArray.GetSize();
									m_pModelData->m_ElArray.SetSize(br2 + br_trenutno,-1);
									mapaMaterijala[br1]=br2;
									vrste_materijala[i] = br1;
									fgets (s, 100 , f);
								}						
}

void CImporterPAK::import_node(FILE *f)
{
	int br;
	char s[100];
	for(int i=0; i< n_Point; i++)
						{
							fscanf(f,"%d",&br);
							mapaNodova[br] = i;

                            //printf("PAK: %d  ModelData: %d \n",br,i);
                            //getchar();

							HNodes node;
							node.m_nID = i;
							//za boundary
							for (int j=0; j<6; j++)
												fscanf(f,"%d",&node.m_bPermbc[j]);

							fscanf(f,"%lf%lf%lf",&node.m_dX,&node.m_dY,&node.m_dZ);
							m_pModelData->m_NodArray.Add( node);

							fgets (s, 100 , f);
						}

}

void CImporterPAK::import_material(FILE *f)
{
	HMaterial material;
	char s[100];
	int tip;
	double pom1,pom2,pom3;
	fgets (s, 100 , f);
	sscanf(s,"%d%lf",&tip,&material.m_dDensity);
	if (tip==HMaterial::ST_PAK_ELASTIC_ISO)
	{
		if(skip_comment(f,s))
		sscanf(s,"%lf",&material.m_dE[0]);
		if(skip_comment(f,s))
		sscanf(s,"%lf",&material.m_dNu[0]);
		material.m_dG[0] = 0.0;
		
		material.m_uSubType = HMaterial::ST_PAK_ELASTIC_ISO;
	    material.m_strTitle = ST_PAK_ELASTIC_ISO_NAME;
        material.m_uType = HMaterial::MT_FEMAP_2D_ORTHO;
		
		material.m_nID = m_pModelData->m_MaterialsArray.GetSize();
		m_pModelData->m_MaterialsArray.Add( material);

        material.m_dAlpha[2] = 1.0;
	}
	if (tip==HMaterial::ST_HUXLEY)
	{
        //if(skip_comment(f,s)) fgets (s, 100 , f);
        fgets (s, 100 , f);

        if(skip_comment(f,s))
        {
            sscanf(s,"%lf%lf%lf",&material.m_dAlpha[0],&material.m_dAlpha[1],&material.m_dAlpha[2]);
        }

        //printf("%lf%lf%lf\n",material.m_dAlpha[0],material.m_dAlpha[1],material.m_dAlpha[2]);
        //getchar();

		if(skip_comment(f,s)) 
		{
			sscanf(s,"%lf%lf",&material.m_dE[0],&material.m_dNu[0]);
		}
		if(skip_comment(f,s)) 
		{
			//fi privremeno cuvam u m_dG[0]
			sscanf(s,"%lf%lf%lf%lf",&pom1,&pom2,&pom3,&material.m_dG[0]);
		}
        //potrebno je dodati jos ucitavanja vezana za ovaj model
        material.m_uSubType = HMaterial::ST_HUXLEY;
        material.m_strTitle = ST_HUXLEY_NAME;
        material.m_uType = HMaterial::MT_FEMAP_2D_ORTHO;
        
        material.m_nID = m_pModelData->m_MaterialsArray.GetSize();

        material.m_uFGMatrix3D[7] = m_pModelData->m_FunctionsArray.GetSize();

		m_pModelData->m_MaterialsArray.Add(material);
        import_ActivationFunction(f);

	}
	
	
}

void CImporterPAK::import_ActivationFunction(FILE *f)
{

    char s[100];
    HFunctions function;
    int Point_count;
    double time, value;

    while (fgets (s, 100 , f) != NULL)
    {
                    int i=0;
                    while(s[i])
                    {
                        if(s[i]==10) s[i]='\0';
                        if(s[i]==13) s[i]='\0';
                        i++;
                    }
                    if (strcmp(s, PAKC_CardActivation)==0)
                                    {
                                             function.m_nID = m_pModelData->m_FunctionsArray.GetSize();
                                             function.m_uFunc_type = HFunctions::FT_VS_TIME;
                                             if(skip_comment(f,s))
                                             sscanf(s,"%d",&Point_count);

                                             for(int i=0; i < Point_count; i++)
                                             {
                                                 skip_comment(f,s);
                                                 sscanf(s,"%lf%lf",&time,&value);
                                                 FunctionEntry t(i,time,value);
                                                 function.m_FunctionEntry.Add(t);
                                             }
                                             m_pModelData->m_FunctionsArray.Add(function);
                                             break;

                                    }

     }

}

bool CImporterPAK::skip_comment(FILE *f, char s[])
{
	fgets (s, 100 , f);
	while(s[0]=='C'&&!feof(f))
	{
		fgets (s, 100 , f);
	}
	if(!feof(f)) return true;
		else return false;

}

void CImporterPAK::import_elements(FILE *f)
{
    int br, br_elemenata, tip_materijala, IDmat,pom;
    double thickness, m_E, m_Erotation;
	unsigned int nNodeID;
	char s[100];
	fscanf(f,"%d",&br);
						if (br==2)
						{
							HProperties properties;
							
							//povecavam niz elemenata za broj elemenata trenutne grupe
							fscanf(f,"%d",&br_elemenata);
							int br_trenutno = m_pModelData->m_ElArray.GetSize();
							m_pModelData->m_ElArray.SetSize(br_elemenata + br_trenutno,-1);
							
							//novi property-a ima ID rednog broja grupe
							properties.m_nID = m_pModelData->m_PropArray.GetSize();
							
							//tip analize
							fscanf(f,"%d",&properties.m_AnalysisType);
							//tip materijala date grupe, potreban zbog odredjivanja ID-a materijala trenutnog property-a
							fscanf(f,"%d",&tip_materijala);
							
							std::map<int,int> ::iterator it;

                            for (int j=0; j<9; j++)
									fgets (s, 100 , f);
							//printf("%d %d %d %d\n", properties.m_nID, br_trenutno, br_elemenata, tip_materijala);
							//getchar();

							for(int i=br_trenutno; i< br_elemenata + br_trenutno; i++)
							{
                                HElement element;
								fscanf(f,"%d",&br);
								mapaElemenata[br] = i;
								element.m_nID =br-1; //umesto br-1 stajalo je bas i, nov id

								fscanf(f,"%d",&br);
								//elementi ima property njegove grupe
								element.m_uPropID=properties.m_nID;

                                //deo za debljinu
                                fscanf(f,"%d",&pom);
                                fscanf(f,"%d",&pom);
                                fscanf(f,"%d",&pom);

                                fscanf(f,"%lf",&thickness);

                                //tip elementa 0=1D, 4=2D, 8=3D
                                element.m_uType = 4;
								
                                fgets (s, 100 , f);

										for(int k=0;k<4;k++)
										{
											fscanf(f,"%10u",&nNodeID);
											it = mapaNodova.find(nNodeID);
											element.m_uNode[PAK2FEMAP_NodeOrder2D_4[k]] =  (*it).second;
											//printf("%d  %d\n", nNodeID, (*it).second);
										}
                                element.m_dOrient[0] = 0.0;
                                element.m_dOrient[1] = 1.0;
                                element.m_dOrient[2] = 0.0;

										m_pModelData->m_ElArray.Add(element);

							}
							//getchar();
							
							//odredjivanje ID-a elementa, tako sto se u nizu tipova materijala pronadje tekuci tip
							//da bi se odredio trenutni ID potrebno je na sumu broja pojavljivanja svake prethodne vrste materijala u nizu dodati trenutan br
							IDmat = 0;
							for(int i=0; i<n_Material; i++)
								{				
									if( vrste_materijala[i]==tip_materijala){ IDmat += (br-1); break;}
									it = mapaMaterijala.find(vrste_materijala[i]);
									IDmat += (*it).second;
								}
								
							//tip property-a
                            properties.m_dValue.Add(thickness);
							properties.m_Type = HProperties::PT_PLATE_LIN;
							properties.m_uMatIID=IDmat;
							m_pModelData->m_PropArray.Add(properties);
							
						}
						else
                        if(br==11)
                        {
                            HProperties properties;

                            //povecavam niz elemenata za broj elemenata trenutne grupe
                            fscanf(f,"%d",&br_elemenata);
                            int br_trenutno = m_pModelData->m_ElArray.GetSize();
                            m_pModelData->m_ElArray.SetSize(br_elemenata + br_trenutno,-1);

                            //novi property-a ima ID rednog broja grupe
                            properties.m_nID = m_pModelData->m_PropArray.GetSize();

                            std::map<int,int> ::iterator it;

                            for (int j=0; j<6; j++)
                                    fgets (s, 100 , f);

                            for(int i=br_trenutno; i< br_elemenata + br_trenutno; i++)
                            {
                                HElement element;
                                fscanf(f,"%d",&br);

                                mapaElemenata[br] = i;
                                element.m_nID =br-1; //umesto br-1 stajalo je bas i, nov id

                                //elementi ima property njegove grupe
                                element.m_uPropID=properties.m_nID;

                                //deo za debljinu
                                fscanf(f,"%lf",&m_E);
                                fscanf(f,"%lf",&m_Erotation);

                                fscanf(f,"%lf",&element.m_dOrient[0]);
                                fscanf(f,"%lf",&element.m_dOrient[1]);
                                fscanf(f,"%lf",&element.m_dOrient[2]);

                                //printf("%lf %lf %lf %lf %lf\n",m_E, m_Erotation,element.m_dOrient[0],element.m_dOrient[1],element.m_dOrient[2]);
                                //getchar();



                                //tip elementa 0=1D, 4=2D, 8=3D
                                element.m_uType = 0;

                                fgets (s, 100 , f);

                                fscanf(f,"%10u",&nNodeID);
                                it = mapaNodova.find(nNodeID);
                                element.m_uNode[0] =  (*it).second; // to je ID node-a bas iz ModelData, ne iz Pak-a

                                //printf("%d\n",nNodeID);
                                //getchar();

                                fgets (s, 100 , f);

                                m_pModelData->m_ElArray.Add(element);

                            }

                            //tip property-a
                            properties.m_dValue.Add(m_E);
                            properties.m_dValue.Add(m_Erotation);

                            m_pModelData->m_PropArray.Add(properties);

                        }

}

void CImporterPAK::importFiberDirections(FILE *f)
{
                        std::map<int,int> ::iterator it;
                        int id;
                        double x,y,z;
                        char s[100];
                        while (fgets (s, 100 , f) != NULL)
                        {
                            sscanf(s,"%d%lf%lf%lf",&id,&x,&y,&z);

                            it = mapaElemenata.find(id);
                            m_pModelData->m_ElArray[(*it).second].m_dOrient[0] = x;
                            m_pModelData->m_ElArray[(*it).second].m_dOrient[1] = y;
                            m_pModelData->m_ElArray[(*it).second].m_dOrient[2] = z;
                            // printf("Deal:%d Pak:%d %lf  %lf  %lf\n",(*it).second,id,x,y,z);

                            //getchar();

                        }


}
