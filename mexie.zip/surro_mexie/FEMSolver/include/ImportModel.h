/*
 * ImportModel.h
 *
 *  Created on: Jul 1, 2014
 *      Author: marina
 */
#ifndef IMPORTMODEL_H_
#define IMPORTMODEL_H_

#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/compressed_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/grid/grid_out.h>

//Materijalni model
#include "MaterialModelState.h"
#include "MaterialModelParameters.h"
#include "MaterialModel.h"
#include "HuxleyModel.h"
#include "HuxleyModel2D.h"
#include "HuxleyState.h"
#include "HuxleyState2D.h"
#include "HuxleyParameters.h"
#include "TimeFunction.h"

#include <fstream>
#include <iostream>
#include <math.h>
#include <cstdlib>
#include <vector>
#include <map>


#include<FEModelData.h>
using namespace dealii;

class ImportModel{
public:
	ImportModel();
	virtual ~ImportModel();


     void setModel(FILE *f, FILE *g, CModelData &ModelData, std::vector<Point<2> > &vertices, std::vector<CellData<2> > &cells);
     void setModel(FILE *f, FILE *g, CModelData &ModelData, std::vector<Point<2> > &vertices, std::vector<CellData<2> > &cells,  std::map<unsigned int, Point<2> > &boundary_point, std::map<unsigned int, Vector<double> > &boundary_vector,std::vector<Point<2> > &element_orient,std::vector<double> &m_element_thickness,std::map< int,  int > &mapNodePakModelData, std::map<unsigned int, Vector<double> > &elastic_support1D, std::vector<unsigned int>  &IDelastic_support1D);
     void setMaterials(CModelData &ModelData, int num_points,MMType *types, double *voxelData);
     void setActivation(CModelData &ModelData, double time);
	 void setActivation(CModelData &ModelData, double time, double* stretch_matrix);

     HuxleyParameters** parametar;
     MaterialModel** model;
     map<int,MaterialModel* > mapaModela;
     map<int,HuxleyParameters* > mapaParametara;
     map<int,TimeFunction* > mapaFunkcija;
	 TimeFunction m_GordonFunction;
	 double m_g1;
	 double m_num_points;

private:


	CModelData *m_pModelData;
};



#endif /* IMPORTMODEL_H_ */
