/*
 * QPointCalculator.cpp
 *
 *  Created on: May 2, 2014
 *      Author: anakaplarevic
 */

#include "QPointCalculator.h"

#define CPLUSPLUS_STD_VER       STD_C94

QPointCalculator::QPointCalculator() {

}

QPointCalculator::~QPointCalculator() {

}
