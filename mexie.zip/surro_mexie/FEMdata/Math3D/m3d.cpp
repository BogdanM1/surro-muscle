/*
 * Math3d - The 3D Computer Graphics Math Library
 * Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
 * All rights reserved.
 *
 * This program is  free  software;  you can redistribute it and/or modify it
 * under the terms of the  GNU Lesser General Public License  as published by 
 * the  Free Software Foundation;  either version 2.1 of the License,  or (at 
 * your option) any later version.
 *
 * This  program  is  distributed in  the  hope that it will  be useful,  but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
 * License for more details.
 *
 * You should  have received  a copy of the GNU Lesser General Public License
 * along with  this program;  if not, write to the  Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: m3d.cpp,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
 */
#include "Stdafx.h"
#define _MATH3D_EXPORT
#include "m2d.h"
#include "m3d.h"
#include "m4d.h"
#include <math.h>
//#include <iostream>


const Math3d::M3d Math3d::M3d::AxisX(1,0,0);
const Math3d::M3d Math3d::M3d::AxisY(0,1,0);
const Math3d::M3d Math3d::M3d::AxisZ(0,0,1);


/*!
 * Construction from cartesian coordinates
 * ([X, Y] -> [X, Y, 1]).
 *
 * \param A 2-dimensional vector. 
 */
Math3d::M3d::M3d(const M2d& A)
{
  x=A.x;
  y=A.y;
  z=1.0;
}


/*!
 *
 */
Math3d::M3d::M3d(const M3d& A)
{
  x=A.x;
  y=A.y;
  z=A.z;
}


/*!
 * Construction from homogenous coordinates
 * ([W*X, W*Y, W*Z, W] with scale factor W !=0 -> [X, Y, Z]).
 *
 * \param A 4-dimensional vector. 
 */
Math3d::M3d::M3d(const M4d& A)
{
  if (fabs(A.w)<EPSILON) {
    ASSERT(false);
    x=y=z=0.0;
  }

  double c=1/A.w;
  x=A.x*c;
  y=A.y*c;
  z=A.z*c;
}


/*!
 *
 */
const Math3d::M3d&
Math3d::M3d::operator=(const M3d& A)
{
  x=A.x;
  y=A.y;
  z=A.z;
  return(*this);
}


/*!
 *
 */
void
Math3d::M3d::zero()
{
  x=0.0;
  y=0.0;
  z=0.0;
}


/*!
 *
 */
void
Math3d::M3d::copy(const M3d& A)
{
  x=A.x;
  y=A.y;
  z=A.z;
}


/*!
 *
 */
double&
Math3d::M3d::get(int i)
{
  ASSERT(i>=0 && i<3);
  return((&x)[i]);
}


/*!
 *
 */
Math3d::M3d
Math3d::M3d::operator+(const M3d& A) const
{
  return(M3d(
    x+A.x,
    y+A.y,
    z+A.z
  ));
}


/*!
 *
 */
Math3d::M3d
Math3d::M3d::operator+() const
{
  return(*this);
}


/*!
 *
 */
const Math3d::M3d& 
Math3d::M3d::operator+=(const M3d& A)
{
  x+=A.x;
  y+=A.y;
  z+=A.z;
  return(*this);
}


/*!
 *
 */
Math3d::M3d
Math3d::M3d::operator-(const M3d& A) const
{
  return(M3d(
    x-A.x,
    y-A.y,
    z-A.z
  ));
}


/*!
 *
 */
Math3d::M3d
Math3d::M3d::operator-() const
{
  return(M3d(-x,-y,-z));
}


/*!
 *
 */
const Math3d::M3d&
Math3d::M3d::operator-=(const M3d& A)
{
  x-=A.x;
  y-=A.y;
  z-=A.z;
  return(*this);
}


/*!
 *
 */
Math3d::M3d
Math3d::M3d::operator*(double k) const
{
  return(M3d(
    x*k,
    y*k,
    z*k
  ));
}


/*!
 *
 */
const Math3d::M3d&
Math3d::M3d::operator*=(double k)
{
  x*=k;
  y*=k;
  z*=k;
  return(*this);
}


/*!
 *
 */
void
Math3d::M3d::neg()
{
  x=-x;
  y=-y;
  z=-z;
}


/*!
 *
 */
void
Math3d::M3d::abs()
{
  x=fabs(x);
  y=fabs(y);
  z=fabs(z);
}


/*!
 *
 */
void
Math3d::M3d::add(const M3d& A, const M3d& B)
{
  x=A.x + B.x; 
  y=A.y + B.y; 
  z=A.z + B.z; 
}


/*!
 *
 */
void
Math3d::M3d::sub(const M3d& A, const M3d& B)
{
  x=A.x - B.x; 
  y=A.y - B.y; 
  z=A.z - B.z; 
}


/*!
 *
 */
void
Math3d::M3d::scalar(double k)
{
  x*=k;
  y*=k;
  z*=k;
}


/*!
 *
 */
void Math3d::M3d::Normalize() {
	double de = NormSqr();
	if (de <= EPSILON) {
		zero();
	} else {
		de = sqrt(de);
		x /= de;
		y /= de;
		z /= de;
	}
}



/*!
 * If this point instance is of the form [W*X, W*Y, W], for some 
 * scale factor W != 0, then it is reset to be [X, Y, 1]. This will 
 * only work correctly if the point is in homogenous form or cartesian 
 * form. If the point is in rational form, the results are not defined.
 */
void 
Math3d::M3d::cartesianize()
{
  if (fabs(z)<EPSILON) {
    ASSERT(false);
    x=y=z=0.0;
  }
  else {
    double c=1/z;
    x*=c;
    y*=c;
    z=1.0;
  }
}
      

/*!
 * If this point instance is of the form [W*X, W*Y, W], for some 
 * scale factor W != 0, then [X, Y] is returned. 
 *
 * \return The cartesianized coordinates.
 */
Math3d::M2d 
Math3d::M3d::cartesianized()
{
  if (fabs(z)<EPSILON) {
    ASSERT(false);
    return(M2d(0,0));
  }

  double c=1/z;
  M3d A;
  A[0]=x*c;
  A[1]=y*c;
  return(A);
}
      

/*!
 * If this point instance is of the form [W*X, W*Y, W] (ie. is in 
 * homogenous or (for W==1) cartesian form), for some scale factor W != 0,
 * then it is reset to be [X, Y, W]. This will only work correctly if 
 * the point is in homogenous or cartesian form. If the point is already
 * in rational form, the resultsare not defined.
 */
void 
Math3d::M3d::rationalize()
{
  if (fabs(z)<EPSILON) {
    ASSERT(false);
    x=y=z=0.0;
  }
  else {
    double c=1/z;
    x*=c;
    y*=c;
    z=1.0;
  }
}
     
/*!
 * If this point instance is of the form [X, Y, W] (ie. is in rational
 * or (for W==1) cartesian form), for some scale factor W != 0, then it is
 * reset to be [W*X, W*Y, W].
 */
void 
Math3d::M3d::homogenize()
{
  x*=z;
  y*=z;
}


/*!
 *
 */
void
Math3d::M3d::cross(const M3d& A, const M3d& B)
{
  x=A.y*B.z - A.z*B.y;
  y=A.z*B.x - A.x*B.z;
  z=A.x*B.y - A.y*B.x;
}


/*!
 *
 */
void
Math3d::M3d::lerp(const M3d& A, const M3d& B, double t)
{
  x=A.x+t*(B.x-A.x);
  y=A.y+t*(B.y-A.y);
  z=A.z+t*(B.z-A.z);
}


/*!
 *
 */
void
Math3d::M3d::normal(const M3d& A, const M3d& B, const M3d& C)
{
  M3d P,Q;

  P.sub(C,B);
  Q.sub(A,B);
  cross(P,Q);
  Normalize();
}


/*!
 *
 */
void
Math3d::M3d::Min(const M3d& m)
{
  if (m.x<x) x=m.x;
  if (m.y<y) y=m.y;
  if (m.z<z) z=m.z;
}


/*!
 *
 */
void
Math3d::M3d::Max(const M3d& m)
{
  if (m.x>x) x=m.x;
  if (m.y>y) y=m.y;
  if (m.z>z) z=m.z;
}


/*!
 *
 */
void
Math3d::M3d::cubic(const M3d& A, const M3d& TA, const M3d& TB, 
  const M3d& B, double t)
{
  double a,b,c,d;   

  a=2*t*t*t - 3*t*t + 1;
  b=-2*t*t*t + 3*t*t;
  c=t*t*t - 2*t*t + t;
  d=t*t*t - t*t;
  x=a*A.x + b*B.x + c*TA.x + d*TB.x;
  y=a*A.y + b*B.y + c*TA.y + d*TB.y;
  z=a*A.z + b*B.z + c*TA.z + d*TB.z;
}


/*!
 *
 */
double
Math3d::M3d::get(int i) const
{
  ASSERT(i>=0 && i<3);
  return((&x)[i]);
}


/*!
 *
 */
double
Math3d::M3d::operator*(const M3d& A) const
{
  return(x*A.x + y*A.y + z*A.z);
}

/*!
 *
 */
bool
Math3d::M3d::operator==(const M3d& A) const
{
  return(cmp(A));
}


/*!
 *
 */
bool
Math3d::M3d::operator!=(const M3d& A) const
{
  return(!cmp(A));
}


/*!
 *
 */
double
Math3d::M3d::dot(const M3d& A) const
{
  return(x*A.x + y*A.y + z*A.z);
}


/*!
 *
 */
bool
Math3d::M3d::cmp(const M3d& A, double epsilon) const
{
  return(
    (fabs(x-A.x)<epsilon) &&
    (fabs(y-A.y)<epsilon) &&
    (fabs(z-A.z)<epsilon)
  );
}



/*!
 *
 */
double
Math3d::M3d::squared() const
{
  return(x*x + y*y + z*z);
}


/*!
 *
 */
double
Math3d::M3d::length() const
{
  return(sqrt(x*x + y*y + z*z));
}

//void Math3d::M3d::Serialize(CArchive& ar)
//{
//	if( ar.IsStoring() )
//	{
//		ar << x;
//		ar << y;
//		ar << z;
//	}
//	else
//	{
//		ar >> x;
//		ar >> y;
//		ar >> z;
//	}
//}


/*!
 *
 */
/*std::ostream& 
Math3d::operator << (std::ostream& co, const M3d& v)
{
  co << "(" << v[0] << ", " << v[1] << ", " << v[2] << ")";
  return co;
}
*/

void Math3d::M3d::RotateArroundVector(double dAngle, const M3d &vec)
{
	double s = sin(dAngle);
	double sx = s * vec.x;
	double sy = s * vec.y;
	double sz = s * vec.z;
	double c = cos(dAngle);
	double t = 1.0 - c;
	double xy = t * vec.x * vec.y;
	double xz = t * vec.x * vec.z;
	double yz = t * vec.y * vec.z;
	double xSqr = vec.x * vec.x;
	double ySqr = vec.y * vec.y;
	double zSqr = vec.z * vec.z;
	Init( 
		(t * xSqr + c)*x + (xy - sz)*y + (xz + sy)*z,
		(xy + sz)*x + (t * ySqr + c)*y + (yz - sx)*z,
		(xz - sy)*x + (yz + sx)*y + (t * zSqr + c)*z);
}
