/*#include <iostream>
#include <cstdio>
#include <algorithm>
#include <map>
#include <stdlib.h>
#include <vector>
*/
#include "Scheduler.h"

using namespace std;
struct sort_pred {
    bool operator()(const std::pair<int,int> &left, const std::pair<int,int> &right) {
        return ((left.second < right.second)||((left.second == right.second) && (left.first<right.first)));
    }
} sorter;

main(){
//	map<int,int> t;
	vector<std::pair<int, int> > t;
	int k=3;
	int* original;
    int** noviRaspored;
	int* kNiz;
	kNiz=(int*)calloc(k,sizeof(k));
//	t.resize(10);
	noviRaspored=(int**)malloc(10*sizeof(int*));
	original = (int*)malloc(10*sizeof(int));
	for(int i=0;i<10;i++) noviRaspored[i]=&original[i];
	for(int i=0;i<10;i++) {
	//	t[i]=i%3;
		//t.add(new pair<i,i%3>);
		std::pair<int,int> *p;
		p = new std::pair<int,int>(i,i%k);
		t.push_back(*p);
		kNiz[i%3]++;
	}
	sort(t.begin(), t.end(), sorter);
	for(int i=0;i<10;i++)
		printf("Element na %d. mestu (%d,%d)\n",i,t.at(i).first,t.at(i).second);
//	printf("count[0]=%d count[1]=%d\n",t.count(0),t.count(1));
    int *ulaz,*izlaz,*ulazB;
    ulaz=(int*)malloc(10*sizeof(int));
    izlaz=(int*)malloc(10*sizeof(int));
    ulazB=(int*)malloc(10*sizeof(int));
    printf("Unesi ORIGINAL \n");
    for(int i=0;i<10;i++) scanf("%d",&ulaz[i]);

    printf("forward\n");
    for(int i=0;i<10;i++) izlaz[i]=ulaz[t.at(i).first];
    for(int i=0;i<10;i++) printf("%d ",izlaz[i]);

    printf("\n backward\n");
    for(int i=0;i<10;i++) ulazB[t.at(i).first]=izlaz[i];
    for(int i=0;i<10;i++) printf("%d ",ulazB[i]);
    putchar('\n');

    printf("\n PONOVO\n");
    Scheduler* sch =  new Scheduler(10,3);
    sch->createTestSchedule();
    sch->orderForExecution(ulaz);
    printf("\n orderForExecution \n");
    for(int i=0;i<10;i++) printf("%d ",ulaz[i]);
    sch->orderAsOriginal(ulaz);
    printf("\n orderAsOriginal \n");
    for(int i=0;i<10;i++) printf("%d ",ulaz[i]);
    printf("..... \n");

    int tniz[3];
    sch->getSizeOfPartitions(tniz);
    for(int i=0;i<3;i++) printf("Podela: proces %d dobio %d jobs\n",i,tniz[i]);

    printf("Nova podela\n");
    double V[]={2,1,1};
    int max[]={100,100,100};
    sch->createBasicSchedule(V,max);
    sch->getSizeOfPartitions(tniz);
    for(int i=0;i<3;i++) printf("Podela: proces %d dobio %d jobs\n",i,tniz[i]);
    sch->orderForExecution(ulaz);
    printf("\n orderForExecution \n");
    for(int i=0;i<10;i++) printf("%d ",ulaz[i]);
    sch->orderAsOriginal(ulaz);
    printf("\n orderAsOriginal \n");
    for(int i=0;i<10;i++) printf("%d ",ulaz[i]);
    printf("..... \n");

}

