#include <boost/numeric/ublas/vector.hpp>
#include "HuxleyParameters.h"

using namespace boost::numeric;

void fun_F(ublas::vector<_TIP> &N, ublas::vector<_TIP> &X, const HuxleyParameters &data, ublas::vector<_TIP> &FX, _TIP O);

// Calculating stiffness
_TIP fun_Stiffness(ublas::vector<_TIP> &X, ublas::vector<_TIP> &N, _TIP Kxb);
// Calculating force
_TIP fun_Force(ublas::vector<_TIP> &X, ublas::vector<_TIP> &N, _TIP Kxb);
