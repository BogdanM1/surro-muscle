/*
 * MPIProcess.cpp
 *
 *  Created on: May 14, 2014
 *      Author: anakaplarevic
 */

#include "MPIProcess.h"
#include "MMChunkCalculator.h"
#include <cstdlib>

MPIProcess::MPIProcess() {
	mpi_SIZE = MPI::COMM_WORLD.Get_size ( );  printf("broj procesa %d \n",mpi_SIZE);
    mpi_ID = MPI::COMM_WORLD.Get_rank ( );  printf("proces ID = %d \n",mpi_ID);
	printf("mpi_ID = %d\t PID = %d\n",mpi_ID,getpid());

	podela = (int*)malloc(sizeof(int)*(mpi_SIZE));
	dispodela = (int*)malloc(sizeof(int)*(mpi_SIZE));
	podela3 = (int*)malloc(sizeof(int)*(mpi_SIZE));
	dispodela3 = (int*)malloc(sizeof(int)*(mpi_SIZE));
	podela33 = (int*)malloc(sizeof(int)*(mpi_SIZE));
	dispodela33 = (int*)malloc(sizeof(int)*(mpi_SIZE));
#ifdef LOGON
    printf("LOGON definisan\n");
    velikiLog = fopen(createFileName((char*)"bigLog"),"w");
#else
    printf("LOGON nije definisan\n");
    velikiLog = NULL;
#endif
}

MPIProcess::~MPIProcess() {
#ifdef LOGON
    fclose(velikiLog);
#endif

}

char* MPIProcess::createFileName(){
	char* name;
	name=(char*)malloc(30*sizeof(char));
	sprintf(name,"stat%d.log",mpi_ID);
	return name;
}

char* MPIProcess::createFileName(char* base){
    char* name;
    name=(char*)malloc(30*sizeof(char));
    sprintf(name,"%s%03d.log",base,mpi_ID);
    return name;
}

void MPIProcess::timestamp ( )
{
# define TIME_SIZE 40

  static char time_buffer[TIME_SIZE];
  const struct tm *tm_ptr;
//  size_t len1;
  time_t now;

  now = time ( NULL );
  tm_ptr = localtime ( &now );

//  len1 = strftime ( time_buffer, TIME_SIZE, "%d %B %Y %I:%M:%S %p", tm_ptr );
  strftime ( time_buffer, TIME_SIZE, "%d %B %Y %I:%M:%S %p", tm_ptr );
  std::cout << time_buffer << "\n";

  return;
# undef TIME_SIZE
}
