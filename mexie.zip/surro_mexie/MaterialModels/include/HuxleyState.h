/*
 * HuxleyState.h
 *
 *  Created on: Jul 18, 2013
 *      Author: anakaplarevic
 */

#ifndef HUXLEYSTATE_H_
#define HUXLEYSTATE_H_

#include <boost/numeric/ublas/vector.hpp>
#include "MaterialModelState.h"
#include "HuxleyParameters.h"
using namespace boost::numeric;

class HuxleyState:public MaterialModelState
{
public:
	ublas::vector<_TIP> X;
	ublas::vector<_TIP> N;

	_TIP e_t;

public:
	HuxleyState();
	~HuxleyState();
	void init(MaterialModelParameters* p);
	void init(MaterialModelState* s);
	bool equal(MaterialModelState* s);
};


#endif /* HUXLEYSTATE_H_ */

