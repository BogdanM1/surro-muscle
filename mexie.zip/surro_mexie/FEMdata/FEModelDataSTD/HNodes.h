/*!
 * \file HNodes.h
 * Interface for the HNodes class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HNodes.h: interface for the HNodes class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HNODES_H__A0ABEC00_6290_11D2_B069_444553540000__INCLUDED_)
#define AFX_HNODES_H__A0ABEC00_6290_11D2_B069_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "HDataBlock.h"

#define HNODES_MAX_DOF_COUNT 11

/** Class representing node. */
class HNodes : public HDataBlock  
{
public:
	HNodes();
	HNodes (const HNodes& rc);
	virtual ~HNodes();

	HNodes& operator =(const HNodes& rp);
	//DECLARE_SERIAL(HNodes)
	//void Serialize( CArchive& ar );

	/// ID of the node
	UINT m_nID;
	/// ID of definition coordinate system
	UINT m_uDefine_sys;
	/// ID of output coordinate system
	UINT m_uOutput_sys;
	/// Layer of the nodes
	UINT m_uLayer;
	/// Color of the node
	UINT m_uColor;
	// Element array of permanent constaints
	bool m_bPermbc[HNODES_MAX_DOF_COUNT];

	/// X coordinate of the node
	double m_dX;
	/// Y coordinate of the node
	double m_dY;
	/// Z coordinate of the node
	double m_dZ;

	/// Initial temperature at node
	double m_dInitTemp;

};

#endif // !defined(AFX_HNODES_H__A0ABEC00_6290_11D2_B069_444553540000__INCLUDED_)
