/*!
 * \file OutVector.h
 * Interface for the COutVector class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// OutVector.h: interface for the COutVector class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OUTVECTOR_H__DC0B2564_B82F_11D6_8623_5254AB509DC9__INCLUDED_)
#define AFX_OUTVECTOR_H__DC0B2564_B82F_11D6_8623_5254AB509DC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <math.h>
#include "MyString.h"
#include "MyMap.h"

/** Class representing output vector. */
class COutVector //: public CObject  
{
public:
	UINT GetComponentCount();
	void RecalculateMinMax();
	UINT SetValue(UINT ID,double val);
	COutVector();
	virtual ~COutVector();
	COutVector& operator = (const COutVector& other);
	//void Serialize( CArchive& ar );
	
	/// ID of the output set
	UINT m_nSetID;
	/// ID of the output vector
	UINT m_nID;

	/// Title of the output vector
	MyString m_sTitle;
	/// Minimal value in the output vector
	double m_dMin_val;
	/// Maximal value in the output vector
	double m_dMax_val;
	/// Maximal absolute value in the output vector
	double m_dAbs_max;

	/// Array of component output vector IDs
	long m_Comp[20];

	/// ID of entity where minimal value appears
	UINT m_nID_min;
	/// ID of entity where maximal value appears
	UINT m_nID_max;
	/// Type of variable in the output vector
	UINT m_nOut_type;
	/// Type of the entity which results are related to (node or element).
	UINT m_nEnt_type;
	bool m_bCalc_warn;

	UINT m_nComp_dir;
	/// Indicator whether element results are given at centroid
	bool m_bCent_total;

	/// Collection of the values
	MyMap<UINT,UINT,double,double> m_Values;

protected:
	//DECLARE_SERIAL(COutVector)

};

#endif // !defined(AFX_OUTVECTOR_H__DC0B2564_B82F_11D6_8623_5254AB509DC9__INCLUDED_)
