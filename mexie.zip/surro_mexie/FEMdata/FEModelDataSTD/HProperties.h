/*!
 * \file HProperties.h
 * Interface for the HProperties class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HProperties.h: interface for the HProperties class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HPROPERTIES_H__E4BF19A3_6284_11D2_B069_444553540000__INCLUDED_)
#define AFX_HPROPERTIES_H__E4BF19A3_6284_11D2_B069_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "HDataBlock.h"
#include "MyString.h"
#include "MyArray.h"

/** Class representing element property. */
class HProperties : public HDataBlock  
{
public:
	//FEMAP Types
	typedef enum
	{
		PT_ROD =				 1,
		PT_BAR =			     2,
		PT_BEAM =			     5,
		PT_PLOT_ONLY =			10,
		PT_SHEAR_LIN =			11,
		PT_SHEAR_PAR =			12,
		PT_MEMBRANE_LIN =		13,
		PT_MEMBRANE_LIN_5 =		131,
		PT_MEMBRANE_PAR =		14,
		PT_MEMBRANE_PAR_9 =		141,
		PT_BENDING_LIN =		15,
		PT_BENDING_PAR =		16,
		PT_PLATE_LIN =			17,
		PT_PLATE_PAR =			18,
		PT_PLANESTRAIN_LIN =	19,
		PT_PLANESTRAIN_PAR =	20,
		PT_LAMINATE_LIN =		21,
		PT_LAMINATE_PAR =		22,
		PT_AXISYM_LIN =			23,
		PT_AXISYM_PAR =			24,
		PT_3D_LIN =				25,
		PT_3D_LIN_9 =			251,
		PT_3D_PAR =				26,
		PT_3D_PAR_21 =		    261,
		PT_RIGID_BODY =		    29,
		PT_EFG_2D
	} TPropertyType;

	typedef enum
	{
		AT_LINEAR,
		AT_MATERIAL_NONLINEAR_ONLY,
		AT_TOTAL_LAGRANGIAN,
		AT_UPDATED_LAGRANGIAN,
		AT_LARGE_STRAIN_TL,
		AT_LARGE_STRAIN_UL
	} TAnalysisType;

	typedef enum
	{
		IM_NOT_USED = -1,
		IM_DEFAULT = 0,
		IM_2D_4_PARAMETERS_TAYLOR = 1,
		IM_2D_5_PARAMETERS_SIMO = 2,
		IM_3D_9_PARAMETERS_TAYLOR = 1,
		IM_3D_18_PARAMETERS = 2,
		IM_3D_12_PARAMETERS = 3
	} TIncompatibleModes;

	typedef enum
	{
		PSS_PRINTED_IN_LOCAL_SYSTEM = 0,
		PSS_NOT_PRINTED = 1,
		PSS_PRINTED_IN_GLOBAL_SYSTEM = 2
	} TPrintStressShell;


public:
	HProperties();
	HProperties(const HProperties& rc);
	virtual ~HProperties();

	HProperties& operator =(const HProperties& rp);
	//DECLARE_SERIAL(HProperties)
	//void Serialize( CArchive& ar );

	/// ID of the property
	UINT m_nID;
	/// Color of the property
	UINT m_uColor;
	/// Material of the property
	UINT m_uMatIID;
	/// Type of the property
	TPropertyType m_Type;
	/// Layer of the property
	UINT m_uLayer;
	/// Reference coordinate system
	UINT m_uRefCS;
	/// Title of the property
	MyString m_strTitle;
	UINT m_uFlag[4];
	//UINT m_uNum_lam;
	MyArray<UINT,UINT> m_uLam_MID;
	//UINT m_uNum_val;
	/// Collection of values defining the property
	MyArray <double,double> m_dValue;

	///Type of analysis
	TAnalysisType m_AnalysisType;

	//Incompatibile modes
	TIncompatibleModes m_IncompatibleModes;

	TPrintStressShell m_PrintStressShell;

private:
	void Init();
};

#endif // !defined(AFX_HPROPERTIES_H__E4BF19A3_6284_11D2_B069_444553540000__INCLUDED_)
