/*
 * ImportModel.cpp
 *
 *  Created on: Jul 1, 2014
 *      Author: marina
 */
#include "ImporterPAK.h"
#include "ImportModel.h"
#include "FEModelData.h"
#include "TimeFunction.h"
#include "Globals.h"
using namespace dealii;
//#define ElasticSupport1D
//#define MDX
//#define MDX_utrn

ImportModel::ImportModel()

{

}

ImportModel::~ImportModel() {

}

//Prva verzija bez boundary
void ImportModel::setModel(FILE *f,FILE *g,CModelData &ModelData, std::vector<Point<2> > &vertices, std::vector<CellData<2> > &cells)
{
	CImporterPAK m_pImportPAK;
    m_pImportPAK.import(f,g,ModelData);


	m_pModelData = &ModelData;

	int br_Nod = m_pModelData->m_NodArray.GetSize();
	int br_El = m_pModelData->m_ElArray.GetSize();
	vertices.resize(br_Nod);
	cells.resize(br_El);

	for(int i=0; i< br_Nod; i++)
	{
		vertices[i][0] = m_pModelData->m_NodArray[i].m_dX ;
		vertices[i][1] = m_pModelData->m_NodArray[i].m_dY ;
	}
	for(int i=0; i< br_El; i++)
		{
            if(m_pModelData->m_ElArray[i].m_uType==4)
            {
		    for(int j=0; j< 4; j++)
		    	cells[i].vertices[j] = m_pModelData->m_ElArray[i].m_uNode[j];
            }
		}

}

void ImportModel::setModel(FILE *f, FILE *g, CModelData &ModelData, std::vector<Point<2> > &vertices, std::vector<CellData<2> > &cells, std::map<unsigned int, Point<2> > &boundary_point, std::map<unsigned int, Vector<double> > &boundary_vector, std::vector<Point<2> > &element_orient,std::vector<double> &m_element_thickness, std::map< int,  int > &mapNodePakModelData, std::map<unsigned int, Vector<double> > &elastic_support1D, std::vector<unsigned int>  &IDelastic_support1D)
{
	CImporterPAK m_pImportPAK;
    m_pImportPAK.import(f,g,ModelData);

	m_pModelData = &ModelData;
    mapNodePakModelData = m_pImportPAK.mapaNodova;

	int br_Nod = m_pModelData->m_NodArray.GetSize();
    int br_El = m_pModelData->m_ElArray.GetSize();  //oduzeto 9 zbog 9 1D elastic support elemenata
 #ifdef ElasticSupport1D
    br_El = br_El - 9;
 #endif
	vertices.resize(br_Nod);
	cells.resize(br_El);
    element_orient.resize(br_El);
    m_element_thickness.resize(br_El);
    IDelastic_support1D.resize(9);
    Vector<double> boundary(6), e_support(3);

    int k=0;
    //printf("%d  %d\n", br_Nod, br_El);
	for(int i=0; i< br_Nod; i++)
	{
		vertices[i][0] = m_pModelData->m_NodArray[i].m_dX ;
		vertices[i][1] = m_pModelData->m_NodArray[i].m_dY ;
		int ind = 0;
		for(int j=0; j<6; j++)
		{
			if(m_pModelData->m_NodArray[i].m_bPermbc[j]>0) ind = 1;
			boundary[j] = m_pModelData->m_NodArray[i].m_bPermbc[j];
		}
		if(ind)
		{
			boundary_point.insert(pair<unsigned int,Point<2> >(k,vertices[i]));
			boundary_vector.insert(pair<unsigned int, Vector<double> >(k,boundary));
			k++;
		}

        /*std::map< int, int> ::iterator it;
        it=m_pImportPAK.mapaNodova.find(i);
        mapNodePakModelData[(*it).second]=i;

        printf("ModelData: %d Pak: %d \n",i,(*it).second);
              getchar();*/

	}
    printf("Ucitani cvorovi\n");
    int brEsupport = 0;
    for(int i=0; i< m_pModelData->m_ElArray.GetSize(); i++)
		{
            if(m_pModelData->m_ElArray[i].m_uType==4)
            {

                for(int j=0; j< 4; j++)
                    cells[i].vertices[j] = m_pModelData->m_ElArray[i].m_uNode[j];

				//printf("i: %d :	%d %d %d %d\n", i, cells[i].vertices[0], cells[i].vertices[1], cells[i].vertices[2], cells[i].vertices[3]);

					
                for(int j=0; j< 2; j++)
                    element_orient[i][j] = m_pModelData->m_ElArray[i].m_dOrient[j];


                m_element_thickness[i] = m_pModelData->m_PropArray.GetById(m_pModelData->m_ElArray[i].m_uPropID).m_dValue[0];
            }
            else
            {
                e_support[0] = m_pModelData->m_PropArray.GetById(m_pModelData->m_ElArray[i].m_uPropID).m_dValue[0];
                e_support[1] = m_pModelData->m_ElArray[i].m_dOrient[0];
                e_support[2] = m_pModelData->m_ElArray[i].m_dOrient[1];

                elastic_support1D.insert(pair<unsigned int, Vector<double> >(m_pModelData->m_ElArray[i].m_uNode[0],e_support));

                IDelastic_support1D[brEsupport] = m_pModelData->m_ElArray[i].m_uNode[0];
                brEsupport++;

                //printf("%d  %lf %lf %lf\n",m_pModelData->m_ElArray[i].m_uNode[0],elastic_support1D[m_pModelData->m_ElArray[i].m_uNode[0]][0],elastic_support1D[m_pModelData->m_ElArray[i].m_uNode[0]][1],elastic_support1D[m_pModelData->m_ElArray[i].m_uNode[0]][2]);
                //getchar();

            }

		}
	//getchar();
  //printf("Zavrsio\n");
    //nizMM i nizPAR



}

void ImportModel::setMaterials(CModelData &ModelData, int num_points, MMType *types, double *voxelData)
{
    m_pModelData = &ModelData;
    m_num_points = num_points;
    model = (MaterialModel**) malloc(num_points*sizeof(MaterialModel*));
    parametar = (HuxleyParameters**) malloc(num_points*sizeof(HuxleyParameters*));
	double fi_0 = 0.7;
	double p_mdx = 0.2;
	double multE = 2.0;
	double p_mdx_utrn = 0.13;


    for(int i=0; i< ModelData.m_FunctionsArray.GetSize(); i++)
    {
        mapaFunkcija[i] = new TimeFunction();
        int n = ModelData.m_FunctionsArray[i].m_FunctionEntry.GetSize();
        double *x=(double *)malloc(n*sizeof(double));
        double *y=(double *)malloc(n*sizeof(double));
        for(int j=0; j< n; j++)
        {
            x[j]=ModelData.m_FunctionsArray[i].m_FunctionEntry[j].m_dX; // vreme 10 puta manje / 10.0;
            y[j]=ModelData.m_FunctionsArray[i].m_FunctionEntry[j].m_dY;
        }

        mapaFunkcija[i]->SetValue(x,y,n);
        free(x);
        free(y);

        //printf("%lf %lf\n",0.25,mapaFunkcija[i]->GetValue(0.25));
        //getchar();
    }


    for(int i=0; i< ModelData.m_MaterialsArray.GetSize(); i++)
                 {
                    mapaParametara[i] = new HuxleyParameters();
                    mapaParametara[i]->InputData();

                    //ovo moze ovako jer trenutno svi materijali imaju iste parametre za f, inace mi morao static niz
                    Globals::f1 = mapaParametara[i]->m_f1;
					m_g1 = mapaParametara[i]->m_g1;
#ifdef	MDX_utrn
					Globals::f1 = ((1 - p_mdx_utrn) * mapaParametara[i]->m_g1 * mapaParametara[i]->m_f1) / (mapaParametara[i]->m_g1 + p_mdx_utrn * mapaParametara[i]->m_f1);
#endif
                    mapaParametara[i]->_E = ModelData.m_MaterialsArray[i].m_dE[0];
                    mapaParametara[i]->_ni = ModelData.m_MaterialsArray[i].m_dNu[0];
                    mapaParametara[i]->_fi = ModelData.m_MaterialsArray[i].m_dG[0];

                    //za slucaj vise tipova ovde cemo da granamo

                    if(ModelData.m_MaterialsArray[i].m_uType == 1)
                    {
                        mapaModela[i] = new HuxleyModel2D(mapaParametara[i]);

                    }
 #ifdef MDX
                    if(ModelData.m_MaterialsArray[i].m_uSubType == HMaterial::ST_HUXLEY)
                    {
                        //mapaParametara[i]->m_f1 = mapaFunkcija[ModelData.m_MaterialsArray[i].m_uFGMatrix3D[7]]->GetValue(0.0) * Globals::f1;
						mapaParametara[i]->_E *=(((1 - p_mdx) * (1 - fi_0) + p_mdx * multE * (1 - fi_0)) / ((1 - p_mdx) * (1 - fi_0) + p_mdx));
						mapaParametara[i]->_fi *=(1 - p_mdx);
						printf("%lf\n",mapaParametara[i]->m_f1);
						printf("%lf\n",mapaParametara[i]->_E);
						printf("%lf\n",Globals::f1);

						getchar();
                    }
#endif

                 }
    //int provera=0;
    for (int i=0; i<ModelData.m_ElArray.GetSize(); i++)
    {
        if(ModelData.m_ElArray[i].m_uType==4)
        {

            for(int j=0; j<4; j++) //zbog broja qpoint-a
            {
                model[i*4+j] = mapaModela[ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID];
                parametar[i*4+j] = mapaParametara[ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID];
                //ovde ce biti case u zavisnosti od elementa
                types[i*4+j] = Huxley2D;
                voxelData[i*4+j] = ModelData.m_MaterialsArray.GetById(ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID).m_dAlpha[2];
                //if (!(voxelData[i*4+j] < 0)) provera++;
                //printf("%lf\n",ModelData.m_MaterialsArray.GetById(ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID).m_dAlpha[2]);

            }
        }

    }
    //printf("%d\n",provera);
    //getchar();
    Globals* g=Globals::getInstance();
    g->modeli = (MaterialModel**)malloc(sizeof(MaterialModel*)*num_points);
    g->parametri = (HuxleyParameters**)malloc(sizeof(HuxleyParameters*)*num_points);

    g->m_E.resize(num_points);
    g->m_ni.resize(num_points);
    g->m_fi.resize(num_points);
    g->m_f1.resize(num_points);
    //g->m_f1_tip.resize(num_points); // ANAF1IP

    for (int i=0; i<num_points; i++)
    {
        g->modeli[i]=model[i];
        g->parametri[i]=parametar[i];

        g->m_E[i] = parametar[i]->_E;
        g->m_ni[i] = parametar[i]->_ni;
        g->m_fi[i] = parametar[i]->_fi;
        g->m_f1[i] = parametar[i]->m_f1;
		//printf("%lf\n",g->m_fi[i]);
		
    }
	//getchar();
}

void ImportModel::setActivation(CModelData &ModelData,double time)
{
    m_pModelData = &ModelData;
    Globals* g=Globals::getInstance();
    for(int i=0; i< ModelData.m_MaterialsArray.GetSize(); i++)
    {
       if(ModelData.m_MaterialsArray[i].m_uSubType == HMaterial::ST_HUXLEY)
        {
           //printf("i=  %d  IDmat %d  IDfun  %d\n",i,ModelData.m_MaterialsArray[i].m_nID, ModelData.m_MaterialsArray[i].m_uFGMatrix3D[7]);
           mapaParametara[i]->m_f1 = mapaFunkcija[ModelData.m_MaterialsArray[i].m_uFGMatrix3D[7]]->GetValue(time) * Globals::f1;
		}
    }
	printf("alo\n");
    int br=0;
    for (int i=0; i<ModelData.m_ElArray.GetSize(); i++)
    {
        if(ModelData.m_ElArray[i].m_uType==4)
        {

            for(int j=0; j<4; j++) //zbog broja qpoint-a
            {
             if(ModelData.m_MaterialsArray[ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID].m_uSubType == HMaterial::ST_HUXLEY)
                {
                    g->m_f1[i*4+j] = mapaFunkcija[ModelData.m_MaterialsArray[ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID].m_uFGMatrix3D[7]]->GetValue(time) * Globals::f1;
				}
                //g->m_f1[i*4+j] = 0.1;
                 /*printf("ModelData.m_ElArray[i].m_uPropID = %d\n", ModelData.m_ElArray[i].m_uPropID);
                 printf("ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID = %d\n", ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID);*/
                 //printf("f1=%lf\n",g->m_f1[i*4+j] / Globals::f1);
                 //if(abs(g->m_f1[i*4+j] - 0.0)>1.0e-2) br++;//{printf("%d = %lf\n",i*4+j,g->m_f1[i*4+j]); getchar();}

            }
         //getchar();
        }
    }
    //printf("%d\n",br);
    //getchar();

    /*FILE *f=fopen("Element1.dat","a");
    fprintf(f,"time %lf   q1=%lf  q2=%lf  q3=%lf  q4=%lf\n",time, (g->parametri[0])->m_f1,(g->parametri[1])->m_f1,(g->parametri[2])->m_f1,(g->parametri[3])->m_f1);
    fclose(f);

    FILE *f1=fopen("Element555.dat","a");
    fprintf(f1,"time %lf   q1=%lf  q2=%lf  q3=%lf  q4=%lf\n",time, (g->parametri[554*4])->m_f1,(g->parametri[554*4+1])->m_f1,(g->parametri[554*4+2])->m_f1,(g->parametri[554*4+3])->m_f1);
    fclose(f1);*/
    //getchar();

}

void ImportModel::setActivation(CModelData &ModelData,double time, double* stretch_matrix)
{
    m_pModelData = &ModelData;
    Globals* g=Globals::getInstance();
	int indGordon;
    for(int i=0; i< ModelData.m_MaterialsArray.GetSize(); i++)
    {
       if(ModelData.m_MaterialsArray[i].m_uSubType == HMaterial::ST_HUXLEY)
        {
           //printf("i=  %d  IDmat %d  IDfun  %d\n",i,ModelData.m_MaterialsArray[i].m_nID, ModelData.m_MaterialsArray[i].m_uFGMatrix3D[7]);
		   double tmp = mapaFunkcija[ModelData.m_MaterialsArray[i].m_uFGMatrix3D[7]]->GetValue(time);
		   mapaParametara[i]->m_f1 = tmp * Globals::f1;
		   indGordon = i;
        }
    }
	
	//for (int i=0; i<m_num_points; i++)
	//printf("%lf\n",(mapaParametara[0]->stressStretchFunction).GetValue(*(stretch_matrix+i)));
	//getchar();
    int br=0;
	double L_m=788.0;
	double O_m=88.0;
    for (int i=0; i<ModelData.m_ElArray.GetSize(); i++)
    {
        if(ModelData.m_ElArray[i].m_uType==4)
        {

            for(int j=0; j<4; j++) //zbog broja qpoint-a
            {
             if(ModelData.m_MaterialsArray[ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID].m_uSubType == HMaterial::ST_HUXLEY)
                {
					double d = ((*(stretch_matrix+i*4+j))-1) * 1188.0;
					double O = (L_m- (O_m + d))/(L_m-O_m);
					double k = m_g1 * O / (Globals::f1 + m_g1 - Globals::f1 * O);
					
					double tmp = mapaFunkcija[ModelData.m_MaterialsArray[ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID].m_uFGMatrix3D[7]]->GetValue(time);
                    if(g->use_ca_conc) tmp = CaToAct::getAct(tmp, *(stretch_matrix+i*4+j));
					g->m_f1[i*4+j] = tmp * Globals::f1;			
					//printf("Korekcija %lf\n",O);
                }
				
                //g->m_f1[i*4+j] = 0.1;
                 /*printf("ModelData.m_ElArray[i].m_uPropID = %d\n", ModelData.m_ElArray[i].m_uPropID);
                 printf("ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID = %d\n", ModelData.m_PropArray.GetById(ModelData.m_ElArray[i].m_uPropID).m_uMatIID);*/
                 //printf("f1=%lf\n",g->m_f1[i*4+j] / Globals::f1);
                 //if(abs(g->m_f1[i*4+j] - 0.0)>1.0e-2) br++;//{printf("%d = %lf\n",i*4+j,g->m_f1[i*4+j]); getchar();}

            }
         //getchar();
        }
    }
    //printf("%d\n",br);
    //getchar();

    /*FILE *f=fopen("Element1.dat","a");
    fprintf(f,"time %lf   q1=%lf  q2=%lf  q3=%lf  q4=%lf\n",time, (g->parametri[0])->m_f1,(g->parametri[1])->m_f1,(g->parametri[2])->m_f1,(g->parametri[3])->m_f1);
    fclose(f);

    FILE *f1=fopen("Element555.dat","a");
    fprintf(f1,"time %lf   q1=%lf  q2=%lf  q3=%lf  q4=%lf\n",time, (g->parametri[554*4])->m_f1,(g->parametri[554*4+1])->m_f1,(g->parametri[554*4+2])->m_f1,(g->parametri[554*4+3])->m_f1);
    fclose(f1);*/
    //getchar();

}




