/*
 * MMChunkCalculator.h
 *
 *  Created on: May 10, 2014
 *      Author: anakaplarevic
 */

#ifndef MMCHUNKCALCULATOR_H_
#define MMCHUNKCALCULATOR_H_

#include <fstream>
#include <iostream>
#include <math.h>
//#include <libconfig.h++>
//#include <libconfig.h>
#include <cstdlib>
#include <vector>

#include "MaterialModelState.h"
#include "MaterialModelParameters.h"
#include "MaterialModel.h"
#include "HuxleyModel.h"
#include "HuxleyModel2D.h"
#include "HuxleyState.h"
#include "HuxleyState2D.h"

class MMChunkCalculator {
public:
	MaterialModel** model;   // CUDA ne koristi
	MaterialModelState** state_t;   // CUDA ne koristi
	MaterialModelState** state_curr;   // CUDA ne koristi
	MMType* types;
	int sizeOfChunk;
	int sigmaVectorDIM;
    	long allIterationCount;
    	std::vector<HuxleyParameters*> hp;
        FILE* fLog;        //fajl za log koji otvara MPIProces i prosledjuje ga ChunkCalculatoru, ako je potrebno
        FILE* velikiLogChunk; //fajl za log koji otvara MPIProces i prosledjuje ga ChunkCalculatoru, ako je potrebno
	int moj_MPI;	   //pomocni podatak, pravljenje statistike
	int moj_start;	   //pomocni podatak, pamti koji je prvi q_point ya koji je zaduzen kalkulator
public:
	MMChunkCalculator();
	virtual ~MMChunkCalculator();

    virtual void init(int num_points,MMType *types,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1)=0;
    virtual void calculateChunk(double* e,double* sigma,double* dsigmade)=0;
    virtual void setToNew(int flag)=0;

    virtual void fillArrays(int num_points,MMType *types,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1);
    virtual void updateParameters(int num_points,std::vector<_TIPF1> &m_f1);
// pomocne funkcije
    void setFile(FILE* f);	// fja kojom MPIProcess   kaze Chucku gde treba da pise svoj log
    void setFileVelikiLog(FILE* *f);	// fja kojom MPIProcess   kaze Chucku gde treba da pise svoj log
    void setMPI(int m);
    void setStartID(int s);
};

#endif /* MMCHUNKCALCULATOR_H_ */
