/*!
 * \file EquivalentVonMisesStress.h
 * Interface for the CEquivalentVonMisesStress class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// EquivalentVonMisesStress.h: interface for the CEquivalentVonMisesStress class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EQUIVALENTVONMISESSTRESS_H__FB135C99_8850_4FB8_BC1D_B326B632D443__INCLUDED_)
#define AFX_EQUIVALENTVONMISESSTRESS_H__FB135C99_8850_4FB8_BC1D_B326B632D443__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Stdafx.h"

#include "EffectiveValueCalculator.h"

class CEquivalentVonMisesStress : public CEffectiveValueCalculator  
{
public:
	CEquivalentVonMisesStress() {};
	virtual ~CEquivalentVonMisesStress() {};

	/*!
	 * Calculates Von Mises equivalent stress.
	 * 
	 * \param[in] dCompValues
	 * 6-element array of stress components.
	 * 
	 * \returns
	 * Von Mises Translation effective value.
	 */
	inline double Calculate(double dCompValues[]) const
	{
		double s[6];
		double dSigma, dEq;

		dSigma = (dCompValues[0]+dCompValues[1]+dCompValues[3])/3.;
		s[0]=dCompValues[0]-dSigma;
		s[1]=dCompValues[1]-dSigma;
		s[2]=dCompValues[2]-dSigma;
		s[3]=dCompValues[3];
		s[4]=dCompValues[4];
		s[5]=dCompValues[5];

		dEq=sqrt(1.5*(s[0]*s[0] +s[1]*s[1] +s[2]*s[2] + 2*(s[3]*s[3] +s[4]*s[4] +s[5]*s[5])));
		return(dEq);
	}

};

#endif // !defined(AFX_EQUIVALENTVONMISESSTRESS_H__FB135C99_8850_4FB8_BC1D_B326B632D443__INCLUDED_)
