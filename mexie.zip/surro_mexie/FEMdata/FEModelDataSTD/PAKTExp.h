/*!
 * \file PAKTExp.h
 * Constants for PAKT.
 * 
 * \author Boban Stojanovic, Nikola Milivojevic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */


#define PAKT_CardH1 "C /1/ HEADING CARD (80A1)\n"
#define PAKT_CardV1 "C NASLOV\n"
#define PAKT_CardH2 "C /2/ FORMAT FOR INPUT DATA (free format)\n"
#define PAKT_CardV2 "C INDFOR\n"
#define PAKT_CardH3 "C /3/ BASIC DATA FOR THE PROBLEM (10I5)\n"
#define PAKT_CardV3 "C NP,NGET,NMATT,NSTAC,NPER,NPRINT,IANIZ,NULAZ,ITOR,IGRAF\n"
#define PAKT_CardH4 "C /4/ BASIC DATA FOR THE PROBLEM (4I5,2F10.0,I5)\n"
#define PAKT_CardV4 "C INTEB,INDSC,IFORM,MAXIT,EPSTA,EPSTR,NJRAP\n"
#define PAKT_CardH5 "C /5/ DATA FOR RESTART (3I5,D15.8)\n"
#define PAKT_CardV5 "C IREST,NCZK,NCZR,VREMO\n"
#define PAKT_CardH6 "C /6/ DATA FOR TIME STEPS\n"
#define PAKT_CardV6_a_1 "C a) Number of time steps card (16I5)\n"
#define PAKT_CardV6_a_2 "C (NKDT(I),I=1,NPER)\n"
#define PAKT_CardV6_b_1 "C b) Card of time increment per step in solution period (8F10.0)\n"
#define PAKT_CardV6_b_2 "C (DDT(I),I=1,NPER)\n"
#define PAKT_CardH7 "C /7/ DATA FOR NODAL POINT DATA (I5,3X,I2,3F10.2,10X,I5)\n"
#define PAKT_CardV7 "C N,IDT(N),CORD(N,1),CORD(N,2),CORD(N,3),KORC\n"

//Card /8/
#define PAKT_CardH8 "C /8/ ELEMENT GROUP DATA (4I5)\n"
#define PAKT_CardV8 "C NETIP,NET,INDAX,IZIP\n"
#define PAKT_CardH8_2 "C /8-2/ DATA FOR 2D ELEMENT GROUP (8I5,F10.0)\n"
#define PAKT_CardV8_2_a_1 "C a) Card with data about 2D element\n"
#define PAKT_CardV8_2_a_2 "C NMAT2D,MAT2D,NP2DMX,IPR2DC,IPTG2,NGAU2X,NGAU2Y,NTHIC,THIC\n"
#define PAKT_CardV8_2_b_1 "C b) Data for each element in group (11I5,F10.0)\n"
#define PAKT_CardV8_2_b_2 "C NN,(NEL(NN,I),I=1,4),NMAT,NQQ,KORE,NBEG,IPRCO,IPGS,THI\n"
#define PAKT_CardV8_2_c_1 "C Midnodes for 2D element (5I5)\n"
#define PAKT_CardV8_2_c_2 "C (NEL(NN,I),I=5,9)\n"

#define PAKT_CardH8_3 "C /8-3/ DATA FOR 3D ELEMENT GROUP (8I5)\n"
#define PAKT_CardV8_3_a_1 "C a) Card with data about 3D element\n"
#define PAKT_CardV8_3_a_2 "C NMAT3d,MAT3D,NP3DMX,IPR3DC,IPRTG3,NGAUSX,NGAUSY,NGAUSZ\n"
#define PAKT_CardV8_3_b_1 "C b) Data for each element in group (15I5)\n"
#define PAKT_CardV8_3_b_2 "C NN,(NEL(NN,I),I=1,8),NMAT,NQQ,KORE,NBEG,IPRCO,IPGS\n"
#define PAKT_CardV8_3_c_1 "C Midnodes for 3D element (13I5)\n"
#define PAKT_CardV8_3_c_2 "C (NEL(NN,I),I=9,21)\n"

//Card /9/
#define PAKT_CardH9 "C /9/ DATA ABOUT DEPENDENCE OF MATERIAL CONSTANTS ON TEMPERATURE (6I5)\n"
#define PAKT_CardV9 "C NANLK,NTABK,MAXTK,NANLC,NTABC,MAXTC\n"
#define PAKT_CardH9_1 "C /9-1/ DATA ABOUT MATERIALS (3I5,6F10.0)\n"
#define PAKT_CardV9_1 "C IBFK(I,1),IBFK(I,2),IBFK(I,3),FAKP(I,1),FAKP(I,2),FAKP(I,3),GUSM(I),TOPM(I),TMNM(I)\n"

#define PAKT_CardH9_2 "C /9-2/ TABLES OF DEPENDENCE: CONDUCTION COEFFICIENT-TEMPERATURE\n"
#define PAKT_CardV9_2_a_1 "C a) Number of points in table for material set\n"
#define PAKT_CardV9_2_a_2 "C NN,NTAKV(NN)\n"
#define PAKT_CardV9_2_b_1 "C b) Table of values temperature-conduction coefficient\n"
#define PAKT_CardV9_2_b_2 "C (TABK(K,NN,J),K=1..)\n"
#define PAKT_CardH9_3 "C /9-3/ TABLES OF DEPENDENCE: SPECIFIC HEAT-TEMPERATURE\n"
#define PAKT_CardV9_3_a_1 "C a) Number of points in table for material set\n"
#define PAKT_CardV9_3_a_2 "C NN,NTACV(NN)\n"
#define PAKT_CardV9_3_b_1 "C b) Table of values temperature-conduction coefficient\n"
#define PAKT_CardV9_3_b_2 "C (TABC(K,NN,J),K=1..)\n"


//Card /10/
#define PAKT_CardH10 "C /10/ DATA ABOUT TIME FUNCTIONS (2I5)\n"
#define PAKT_CardV10 "C NTABFT,MAXTFT\n"
#define PAKT_CardH10_1 "C /10-1/ GROUP OF CARDS WITH TABLES FOR TIME FUNCTIONS\n"
#define PAKT_CardV10_1_a_1 "C a) data about function in a table form (2I5)\n"
#define PAKT_CardV10_1_a_2 "C IBR,IMAX    (IMAX.LE.MAXTFT)\n"
#define PAKT_CardV10_1_b_1 "C b) values for argument - function (2F10.0)\n"
#define PAKT_CardV10_1_b_2 "C ((FN(I,IBR,J),I=1,2),J=1,IMAX)\n"

//Card/ /11/
#define PAKT_CardH11 "C /11/ DATA FOR PRESCRIBED TEMPERATURE (2I5,F10.2,I5)\n"
#define PAKT_CardV11 "C N,NC,FAK,KORC\n"

//Card/ /12/
#define PAKT_CardH12 "C /12/ DATA ABOUT INITIAL VALUES AND BOUNDARY CONDITIONS (11I5)\n"
#define PAKT_CardV12 "C NPOC,NQP,MAXTQP,NHP,MAXTHP,NTOK,MAXTOK,NQE,MAXTQE,NHR,MAXTHR\n"

#define PAKT_CardH12_1 "C /12-1/ DATA ABOUT INTERNAL HEAT GENERATION (SOURCE)\n"
#define PAKT_CardV12_1_a_1 "C a) Function definition\n"
#define PAKT_CardV12_1_a_2 "C IBR,NTAQE(IBR)\n"
#define PAKT_CardV12_1_b_1 "C b) Values for argument - function\n"
#define PAKT_CardV12_1_b_2 "C ((QEFN(I,IBR,J),I=1,2),J=1,NTAQE(IBR))\n"

#define PAKT_CardH12_2 "C /12-2/ DATA ABOUT SURFACE FLUXES\n"
#define PAKT_CardV12_2_a_1 "C a) Function definition\n"
#define PAKT_CardV12_2_a_2 "C IBR,NTAQP(IBR)\n"
#define PAKT_CardV12_2_b_1 "C b) Values for argument - function\n"
#define PAKT_CardV12_2_b_2 "C ((QPFN(I,IBR,J),I=1,2),J=1,NTAQP(IBR))\n"

#define PAKT_CardH12_3 "C /12-3/ DATA ABOUT ENVIRONMENTAL TEMPERATURE\n"
#define PAKT_CardV12_3_a_1 "C a) Function definition\n"
#define PAKT_CardV12_3_a_2 "C IBR,NTAOK(IBR)\n"
#define PAKT_CardV12_3_b_1 "C b) Values for argument - function\n"
#define PAKT_CardV12_3_b_2 "C ((TOKFN(I,IBR,J),I=1,2),J=1,NTAOK(IBR))\n"

#define PAKT_CardH12_4 "C /12-4/ DATA ABOUT CONVECTION COEFFICIENT\n"
#define PAKT_CardV12_4_a_1 "C a) Function definition\n"
#define PAKT_CardV12_4_a_2 "C IBR,NTAHP(IBR)\n"
#define PAKT_CardV12_4_b_1 "C b) Values for argument - function\n"
#define PAKT_CardV12_4_b_2 "C ((HPFN(I,IBR,J),I=1,2),J=1,NTAHP(IBR))\n"

#define PAKT_CardH12_5 "C /12-5/ DATA ABOUT EMISSIVITY COEFFICIENT\n"
#define PAKT_CardV12_5_a_1 "C a) Function definition\n"
#define PAKT_CardV12_5_a_2 "C IBR,NTAHR(IBR)\n"
#define PAKT_CardV12_5_b_1 "C b) Values for argument - function\n"
#define PAKT_CardV12_5_b_2 "C ((HRFN(I,IBR,J),I=1,2),J=1,NTAHR(IBR))\n"
#define PAKT_CardV12_5_c_1 "C c) Radiation property data (D15.8,I5)\n"
#define PAKT_CardV12_5_c_2 "C SBC,NFO\n"
#define PAKT_CardV12_5_d_1 "C d) Shape factors\n"
#define PAKT_CardV12_5_d_2 "C (FOHR(I),I=1,NFO)\n"

#define PAKT_CardH12_6 "C /12-6/ INITIAL TEMPERATURE\n"
#define PAKT_CardV12_6 "C TPOC\n"

#define PAKT_CardH13_2 "C /13-3/ BOUNDARY CONDITIONS FOR TWO-DIMENSIONAL ELEMENT\n"
#define PAKT_CardV13_2 "C NN,NPV1,NPV2,IFL,IHP,ITO,IHR,FO\n"


#define PAKT_CardH13_3 "C /13-3/ BOUNDARY CONDITIONS FOR THREE-DIMENSIONAL ELEMENT\n"
#define PAKT_CardV13_3 "C NN,NPV1,NPV2,NPV3,NPV4,IFL,IHP,ITO,IHR,FO\n"
#define PAKT_CardV13_3_e "C EMPTY CARD\n\n"

#define PAKT_CardH16 "C /16/ FINAL CARD (A4)\n"
#define PAKT_CardV16 "STOP"


//Default values

//Card /2/
#define PAKT_INDFOR		2
//Card /3/
#define PAKT_NSTAC		1
#define PAKT_NPER		1
#define PAKT_NPRINT		0
#define PAKT_IANIZ		0
#define PAKT_NULAZ		1
#define PAKT_ITOR		0
#define PAKT_IGRAF		1
//Card /4/
#define PAKT_INTEB		1
#define PAKT_INDSC		0
#define PAKT_IFORM		0
#define PAKT_MAXIT		0
#define PAKT_EPSTA		0.
#define PAKT_EPSTR		0.
#define PAKT_NJRAP		0
//Card /5/
#define PAKT_IREST		1
#define PAKT_NCZK		0
#define PAKT_NCZR		0
#define PAKT_VREMO		0.
//Card /6/
#define PAKT_NKDT		1
#define PAKT_DDT			1.
//Card /7/
#define PAKT_KORC		1
//Card /8/
#define PAKT_INDAX		0
#define PAKT_IZIP		0
//Card /8-2/
#define PAKT_NMAT2D		1
#define PAKT_MAT2D		0
#define PAKT_NP2DMX		4
#define PAKT_IPR2DC		0
#define PAKT_IPTG2		0
#define PAKT_NGAU2X		2
#define PAKT_NGAU2Y		2
#define PAKT_NTHIC		0
#define PAKT_NQQ			0
#define PAKT_KORE		0
#define PAKT_NBEG		0
#define PAKT_IPRCO		0
#define PAKT_IPGS		0
//Card /8-3/
#define PAKT_NMAT3D		0
#define PAKT_MAT3D		0
#define PAKT_NP3DMX		8
#define PAKT_IPR3DC		0
#define PAKT_IPRTG3		0
#define PAKT_NGAUSX		2
#define PAKT_NGAUSY		2
#define PAKT_NGAUSZ		2
//Card /9/
#define PAKT_NANLK		0
#define PAKT_NANLC		0
#define PAKT_IBFK		0
#define PAKT_FAKP		0.
#define PAKT_TOPM		0.
#define PAKT_TMNM		0.
//Card /11/
//Card /12/
#define PAKT_NPOC		1
#define PAKT_NTOK		0
#define PAKT_NHR			0
//Card /13-3/
#define PAKT_ITO			0
#define PAKT_IHR			0
#define PAKT_FO			0




//Errors

#define PAKT_NO_NODES		"There are no nodes."
#define PAKT_NO_GROUPS		"There are no groups of elements."
#define PAKT_NO_LOADS		"There are no loads."

//Maximalni broj funkcija
#define PAKT_MAX_TF		100

//Tolerancije
#define PAKT_LOAD_FORCE_TOL		1.e-8
#define PAKT_LOAD_PRESS_TOL		1.e-8
#define PAKT_LOAD_NDISP_TOL		1.e-12
