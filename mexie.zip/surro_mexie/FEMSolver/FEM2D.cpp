/*
 * FEM.cpp
 *
 *  Created on: May 2, 2014
 *      Author: anakaplarevic
 */

//#include "FEM.cpp"
#include "FEM2D.h"
#include "QPointCalculator.h"
using  namespace dealii;
using namespace libconfig;
//#define Linearno
#define Nelinearno
//#define ElasticSupport1D
//#define RelatedDisplacement
#define damped_faktor 0.01
//#define PressureSwallowing
//#define MDX 0.1
//#define Muscle2D  //za konferencijski rad
//#define WriteDisplacement

FEM2D::FEM2D()
:
fe (FE_Q<2>(1), 2),
dof_handler (triangulation),
quadrature_formula(2),
fe_values(fe, quadrature_formula, update_values  | update_jacobians  |   update_quadrature_points | update_q_points  |update_inverse_jacobians | update_gradients | update_JxW_values)
{
    g = Globals::getInstance();
}

FEM2D::~FEM2D() {
    dof_handler.clear ();
}

void FEM2D::run(QPointCalculator* q)
{
    qpoint_calculator = q;
	g->step=0;

    config_t cfg;   config_setting_t *setting;
	double pom;
	long ipom;
	config_init(&cfg);

	if(!config_read_file(&cfg, CFGFAJL))
	{
		  //fprintf(stderr, "%s:%d - %s\n", config_error_file(&cfg),  config_error_line(&cfg), config_error_text(&cfg));
		  config_destroy(&cfg);
	     exit(0);//return(EXIT_FAILURE);
	 }
	if(config_lookup_float(&cfg, "FEM.T", &pom)) T= pom;	 else fprintf(stderr, "Nema 'FEM.T' u konfiguracionom fajlu\n");
	if(config_lookup_float(&cfg, "FEM.dt", &pom)) g->dt=pom;  else fprintf(stderr, "No 'FEM.dt' setting in configuration file.\n");
	if(config_lookup_int(&cfg, "FEM.dimSigmaVector", &ipom)) g->dimOfSigmaVector=ipom;  else fprintf(stderr, "No 'FEM.dimSigmaVector' setting in configuration file.\n");
	config_destroy(&cfg);
	printf("FEM2D - JEZIK pre make_grid() \n");
	make_grid ();
	printf("FEM2D - JEZIK pre stup_system() \n");
	setup_system();
	init();
	simulate();
}

void FEM2D::update_fe_value()
{
	FEValues<2> fe_values(fe, quadrature_formula, update_values  | update_jacobians  |   update_quadrature_points | update_q_points  |update_inverse_jacobians | update_gradients | update_JxW_values);

}

void FEM2D::make_grid ()
{
 //  GridGenerator::subdivided_hyper_cube (triangulation, 2,0, 1);
	unsigned int nx=25,ny=10;
	std::vector< unsigned int >   	repetitions(2);

	long ipom;   config_t cfg;   config_setting_t *setting;
	config_init(&cfg);

	if(!config_read_file(&cfg, CFGFAJL))
	{
		  //fprintf(stderr, "%s:%d - %s\n", config_error_file(&cfg),  config_error_line(&cfg), config_error_text(&cfg));
		  config_destroy(&cfg);
	     exit(0);//return(EXIT_FAILURE);
	 }

	if(config_lookup_int(&cfg, "FEM.nx", &ipom)) nx= ipom;	 else fprintf(stderr, "Nema 'FEM.nx' u konfiguracionom fajlu\n");
	if(config_lookup_int(&cfg, "FEM.ny", &ipom)) ny=ipom;  else fprintf(stderr, "No 'FEM.ny' setting in configuration file.\n");

	config_destroy(&cfg);

	repetitions[0]=nx;
	repetitions[1]=ny;//	repetitions[1]=2;
	//GridGenerator::subdivided_hyper_rectangle (triangulation, repetitions,Point<2>(0,0), Point<2>(10,1));
	num_cells_x = nx;
	num_cells_y=ny;
	


	/*static const Point<2> vertices_1[]
				= { Point<2> (13.30000, 5.10000),//1
					Point<2> (15.14418,   5.36682),// 2
					Point<2> (10.36667,   6.13333),// 8
					Point<2> (12.79270 ,  6.47261),//9
		};

	const unsigned int
	n_vertices = sizeof(vertices_1) / sizeof(vertices_1[0]);

    const std::vector<Point<2> > vertices (&vertices_1[0], &vertices_1[n_vertices]);

	static const int cell_vertices[][GeometryInfo<2>::vertices_per_cell]
			= {{0,1,2,3}
			};
	const unsigned int
		n_cells = sizeof(cell_vertices) / sizeof(cell_vertices[0]);

	std::vector<CellData<2> > cells (n_cells, CellData<2>());
	for (unsigned int i=0; i<n_cells; ++i)
	{
		for (unsigned int j=0; j<GeometryInfo<2>::vertices_per_cell; ++j)
		cells[i].vertices[j] = cell_vertices[i][j];
		cells[i].material_id = 0;
	}

   //GridReordering<2>::reorder_cells(cells);

	//triangulation.create_triangulation_compatibility(vertices, cells, SubCellData());

	 triangulation.create_triangulation (vertices, cells, SubCellData());
*/


	std::vector<Point<2> > vertices;
	std::vector<CellData<2> > cells;


   FILE *f=fopen("Pak.dat","r");
   FILE *g=fopen("FiberDirections.csv","r");
   if (f == NULL)
   				{
   					 printf ("Error opening file");
   			    }

   //Ako zelimo sami svoje boundary
   //m_pImportModel.setModel(f,ModelData,vertices,cells);

   //za boundery iz fajla Pak.dat
  m_pImportModel.setModel(f,g,ModelData,vertices,cells,boundary_point, boundary_vector,m_element_orient,m_element_thickness, mapNodePakModelData,elastic_support1D,IDelastic_support1D);


  /*for(int i=0; i< cells.size(); i++)
                      {
                          printf("i: %d :	%d %d %d %d\n", i, cells[i].vertices[0], cells[i].vertices[1], cells[i].vertices[2], cells[i].vertices[3]);


                          printf("1: %lf  %lf\n",vertices[cells[i].vertices[0]] [0], vertices[cells[i].vertices[0]][1]);
                          printf("2: %lf  %lf\n",vertices[cells[i].vertices[1]] [0], vertices[cells[i].vertices[1]][1]);
                          printf("3: %lf  %lf\n",vertices[cells[i].vertices[2]] [0], vertices[cells[i].vertices[2]][1]);
                          printf("4: %lf  %lf\n",vertices[cells[i].vertices[3]] [0], vertices[cells[i].vertices[3]][1]);
                          //printf("cross product: %lf  %lf\n",p1 [0], p1[1]);
                          //printf("cross product: %lf  %lf\n",p2 [0], p2[1]);
                          //printf("cross product: %lf \n",p1[0]*p2[1] - p2[0]*p1[1]);
                          //if(i==495) {printf("POGRESIO"); break;}

                           getchar();
                      }
   getchar();
  //BEGIN TEST
  printf("%d\n",m_element_orient.size());
 for(int i=0; i<m_element_orient.size(); i++)
  {
      printf("x:%lf y:%lf\n",m_element_orient[i][0],m_element_orient[i][1]);
      //printf("%lf\n",m_element_thickness[i]);

	  printf("\n");
        getchar();
  }

  *///END TEST
   fclose(f);
   fclose(g);
   GridReordering<2>::reorder_cells(cells);
    triangulation.create_triangulation_compatibility(vertices, cells, SubCellData());

	std::ofstream out("grid-1.eps");
	GridOut grid_out;
	grid_out.write_eps (triangulation, out);

	std::cout << "Number of active cells: "
            << triangulation.n_active_cells()
            << std::endl;

   std::cout << "Total number of cells: "
            << triangulation.n_cells()
            << std::endl;

   //getchar();
}

void FEM2D::setup_system ()
{

   dof_handler.distribute_dofs (fe);
  std::cout << "Number of degrees of freedom: "
            << dof_handler.n_dofs()
            << std::endl;
  constraints.clear ();

  /*sparsity_pattern.reinit (dof_handler.n_dofs(),
                             dof_handler.n_dofs(),
                             dof_handler.max_couplings_between_dofs());
  DoFTools::make_sparsity_pattern (dof_handler, sparsity_pattern);

  sparsity_pattern.compress();

  system_matrix.reinit (sparsity_pattern);*/
  solution.reinit (dof_handler.n_dofs());
  system_rhs.reinit (dof_handler.n_dofs());

}

void FEM2D::init()
{
    dofs_per_cell = fe.dofs_per_cell;
    n_q_points    = quadrature_formula.size();
    n_dofs_all 	= dof_handler.n_dofs();
    n_q_points_all = n_q_points*triangulation.n_active_cells();
	int check[n_dofs_all/2];

    FILE* felem=fopen("elementiHuxley.csv","w");
	fUnv=fopen("muscles2D.unv","w");
	DoFHandler<2>::active_quad_iterator    cell = dof_handler.begin_active(),   endc = dof_handler.end();

	cvorovi.reserve(n_dofs_all/2);
	std::vector<unsigned int> dofIndex (dofs_per_cell);
	int ic=0;
	unsigned int k;
	//MappingDeal mapDeal;
	//mapDeal.mappingElem(ModelData,fe,triangulation,fe_values,dof_handler);
		// u stambi za id tada stampamo mapDeal.mapElem[ic]+1, to je pravi id iz Pak.dat, inace mislim da se ta numeracija u pak-u nekako prenumerise
		
		
	fprintf(felem,"idElementa, cvor1X, cvor1Y, cvor2X, cvor2Y, cvor3X, cvor3Y, cvor4X, cvor4Y\n");
    //FEValues<2> fe_values(fe, quadrature_formula, update_values  | update_jacobians  |   update_quadrature_points | update_q_points  |update_inverse_jacobians | update_gradients | update_JxW_values);
	for (; cell!=endc; ++cell)
		 {
			 fe_values.reinit (cell);
			 cell->get_dof_indices (dofIndex);
		//	 printf("doIndex.length = %d ",dofIndex.size());
			 for(unsigned int i=0;i<4;i++)//<GeometryInfo<2>::vertices_per_cell;i++)
			 {			k=(unsigned int)dofIndex[2*i]/2;
			 	 	 	cvorovi[k][0]=cell->vertex(i)[0];
			 	 	 	cvorovi[k][1]=cell->vertex(i)[1];
			 }
			 fprintf(felem,"%d, %e, %e, %e, %e, %e, %e,  %e, %e\n",ic+1, cell->vertex(0)[0], cell->vertex(0)[1], cell->vertex(1)[0], cell->vertex(1)[1], cell->vertex(2)[0], cell->vertex(2)[1], cell->vertex(3)[0], cell->vertex(3)[1]);
			 ic++;
	 }
	fflush(felem);
	fclose(felem);
	fprintf(fUnv,"    -1\n    15\n");
	for(unsigned int i =0;i<n_dofs_all/2;i++) {
		printf("%d: %lf, %lf\n",i,cvorovi[i][0],cvorovi[i][1]);
		fprintf(fUnv,"%10d         0         0         8  %lf  %lf  0\n",i+1,cvorovi[i][0],cvorovi[i][1]);
	}
	fprintf(fUnv,"    -1\n");

	fprintf(fUnv,"    -1\n    71\n");
	cell = dof_handler.begin_active();   endc = dof_handler.end();
	ic=0;
	for (; cell!=endc; ++cell)
			 {
				 fe_values.reinit (cell);
				 cell->get_dof_indices (dofIndex);
				 fprintf(fUnv,"%10d        27        44         1         1         7         4\n",ic+1);
		//		 for(unsigned int i=0;i<4;i++)//<GeometryInfo<2>::vertices_per_cell;i++)
					 fprintf(fUnv,"%10d",1+dofIndex[0]/2);
					 fprintf(fUnv,"%10d",1+dofIndex[2]/2);
					 fprintf(fUnv,"%10d",1+dofIndex[6]/2);
					 fprintf(fUnv,"%10d",1+dofIndex[4]/2);
				 fprintf(fUnv,"\n");
				 ic++;
		 }

	fprintf(fUnv,"    -1\n");
	         fflush(fUnv);

		fOut.open("OUT.csv");
		fOut<< "\t" << "t" <<"\t"<<"U"<<"\t"<< "F"<<"\n";
	    R.reinit(n_dofs_all);
	    F.reinit(n_dofs_all);
	    U.reinit(n_dofs_all);
		U_prev.reinit(n_dofs_all);
	   	U = 0; U_prev = 0;

	   //	boundary_values[0]=0;
	   	//boundary_values[1]=0;
		//boundary_values[4]=0;
	   	/*for(unsigned int i=(num_cells_x+1)*2;i<=((num_cells_y)*(num_cells_x+1));i+=(num_cells_x+1))
	   		{ printf("x(%d)=0\n",i*2);		boundary_values[i*2]=0;}*/
	   	
	   	//BOUNDARY
		//Test1	
	   	/*for(int i =0;i<n_dofs_all/2;i++) {
		//if (fabs(cvorovi[i][0] - 13.30000) < 1.0e-6) {boundary_values[i*2]=0; boundary_values[i*2 +1]=0;}
		//if (fabs(cvorovi[i][0] - 10.36667) < 1.0e-6) {boundary_values[i*2]=0; boundary_values[i*2 +1]=0;}
	   		if ((i==138)||(i==21)) {boundary_values[i*2]=0; boundary_values[i*2 +1]=0;}
	}*/

	   	//boundary iz Pak.dat
	   	for(unsigned int i =0;i<n_dofs_all/2;i++) {
	   	  for(unsigned int j=0; j<boundary_point.size(); j++)
	   	  {
			if (fabs(cvorovi[i][0] - boundary_point[j][0]) < 1.0e-6 && fabs(cvorovi[i][1] - boundary_point[j][1]) < 1.0e-6)
			{
				if(fabs(boundary_vector[j][0] - 1.0)<1.0e-6)  boundary_values[i*2]=0;
				if(fabs(boundary_vector[j][1] - 1.0)<1.0e-6)  boundary_values[i*2 +1]=0;
			}
	   	  }
	   	}
		

		for(unsigned int i=0; i < n_dofs_all/2; i++)
			check[i]=0;
 		for(unsigned int i =0;i<n_dofs_all/2-2;i++) 
		{
			for(unsigned int j=i+1; j<n_dofs_all/2; j++)
			{
				if (check[i]==0 && fabs(cvorovi[i][0] - cvorovi[j][0]) < 1.0e-6 && fabs(cvorovi[i][1] - cvorovi[j][1]) < 1.0e-6)
				{
		            check[j]++;
					constraints.add_line (j*2);
					constraints.add_entry (j*2, i*2, 1.0);
													
					constraints.add_line (j*2+1);
					constraints.add_entry (j*2+1, i*2+1, 1.0);
				}
			}
		}

#ifdef Muscle2D
	   boundary_values[127]=0;
       ///Dodatna vezana pomeranja kao u Hill-u
        MappingDeal mapDeal;
        //mapiranje cvorova
        mapDeal.mappingNodes(ModelData,cvorovi);
        UINT node1[3]={0,1,2}, node2[3]={3,3,3};
        std::map<int,int> ::iterator it3, it4;


        for(int i=0; i<3; i++)

		{
            it3 = mapDeal.mapNod.find(node1[i]);
            it4 = mapDeal.mapNod.find(node2[i]);


                constraints.add_line ((*it3).second*2+1);
                constraints.add_entry ((*it3).second*2+1, (*it4).second*2+1, 1.0);

            //printf("%d  %d  %d  %d \n",node1[i],(*it3).second, node2[i],(*it4).second);
            //getchar();
        }
		//double x[] = {0.0,0.01,0.02,0.06,0.09,0.15,0.2,0.23,0.25,0.27,0.29,0.3,0.31,0.5};
		
		double x[] = {0.0,0.01,0.02,0.06,0.09,0.15,0.2,0.23,0.25,0.27,0.29,0.35,0.40,0.50,0.60,0.70,0.75,5.0};

		//double y[] = {0.0,0.0227388,0.0653326,0.368283,0.645742,1.1025,1.3348,1.40156,1.42458,1.43855,1.44718,1.450160,1.08762,1.08762};  //75%
	    //double y[] = {0.0,0.0227388,0.0653326,0.368283,0.645742,1.1025,1.3348,1.40156,1.42458,1.43855,1.44718,1.450160,0.72508,0.72508}; //50%
	    //double y[] = {0.0,0.0227388,0.0653326,0.368283,0.645742,1.1025,1.3348,1.40156,1.42458,1.43855,1.44718,1.450160,0.36254,0.36254}; //25%
	    //double y[] = {0.0,0.0227388,0.0653326,0.368283,0.645742,1.1025,1.3348,1.40156,1.42458,1.43855,1.44718,1.450160,0.0,0.0}; //0
		//double y[] = {0.0,0.013763,0.050390,0.341314,0.603287,1.030870,1.267810,1.339560,1.361830,1.375010,1.383390,1.396930,1.403470,1.413350,1.421350,1.428220,0.71411,0.71411};//50%
		//double y[] = {0.0,0.013763,0.050390,0.341314,0.603287,1.030870,1.267810,1.339560,1.361830,1.375010,1.383390,1.396930,1.403470,1.413350,1.421350,1.428220,0.285644,0.285644};//20%
		//double y[] = {0.0,0.013763,0.050390,0.341314,0.603287,1.030870,1.267810,1.339560,1.361830,1.375010,1.383390,1.396930,1.403470,1.413350,1.421350,1.428220,1.142576,1.142576};//80%
		double y[] = {0.0,0.013763,0.050390,0.341314,0.603287,1.030870,1.267810,1.339560,1.361830,1.375010,1.383390,1.396930,1.403470,1.413350,1.421350,1.428220,0.142822,0.142822};//10%


		m_ForceFunction.SetValue(x,y,18);
		//printf("%lf\n",m_ForceFunction.GetValue(0.01));
		//getchar();
#endif

#ifdef PressureSwallowing

        double x[] = {0.0,0.1,0.8};
	    double y[] = {0.0,2.0E-02,2.0E-02}; //100%P
		//double y[] = {0.0,2.0E-03,2.0E-03}; //10%P
		//double y[] = {0.0,6.0E-03,6.0E-03}; //30%P
		//double y[] = {0.0,1.2E-02,1.2E-02}; //60%P

		m_PressureFunction.SetValue(x,y,3);
		/*printf("%lf\n",m_PressureFunction.GetValue(0.099));
		printf("%lf\n",m_PressureFunction.GetValue(0.1));
		printf("%lf\n",m_PressureFunction.GetValue(0.101));
		getchar();*/
		
		/*FILE* fnodePressure=fopen("nodePressure.csv","w");
		int nodePressure[14] = {363,362,364,365,347,346,348,349,331,330,332,333,315,314};
		
		double normalF[2];
		for(int i=0; i<13; i++)
		{
							int id1 = nodePressure[i]-1;
							int id2 = nodePressure[i+1]-1;
							normalF[0] = - cvorovi[id2][1] + cvorovi[id1][1];
							normalF[1] = cvorovi[id2][0] - cvorovi[id1][0];
							double intez_normalF = sqrt(normalF[0]*normalF[0]+normalF[1]*normalF[1]);
							normalF[0] /=intez_normalF;
							normalF[1] /=intez_normalF;
							
							double  l = sqrt((cvorovi[id2][0] - cvorovi[id1][0]) * (cvorovi[id2][0] - cvorovi[id1][0]) + (cvorovi[id2][1] - cvorovi[id1][1]) * (cvorovi[id2][1] - cvorovi[id1][1]));

				fprintf(fnodePressure,"%lf\n",l);
		}

		fclose(fnodePressure);
		getchar();*/
#endif
        /*double x[] = {0.0,0.7,1.0,3.0};
	    double y[] = {0.0,0.0,0.5,0.5}; //0

        m_DisplacementFunction.SetValue(x,y,4);*/
        //printf("%lf\n",m_DisplacementFunction.GetValue(0.01));
        //getchar();
        double x[] = {0,0.01,0.02,0.04,0.05,0.07,0.09,0.1,0.12,0.13,0.15,0.17,0.19,0.21,0.22,0.24,0.26,0.3,0.35,0.4,0.5,0.55,0.65,0.7,0.701,5};
        //double y[] = {0.000000,0.002922,0.010756,0.038246,0.056226,0.096448,0.137575,0.157123,0.192574,0.208170,0.234964,0.256331,0.273143,0.285754,0.289923,0.295497,0.298895,0.302604,0.304799,0.305937,0.307036,0.307327,0.307688,0.307804, 0.3693648,0.3693648}; //0%Fmax*/
        // double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.0308,0.0308}; //10%Fmax*/  
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.0616,0.0616}; //20%Fmax*/ 
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.0924,0.0924}; //30%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.1232,0.1232}; //40%Fmax*/  
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.154,0.154}; //50%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.1848,0.1848}; //60%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.2156,0.2156}; //70%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.2464,0.2464}; //80%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.2772,0.2772}; //90%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.3388,0.3388}; //110%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.3696,0.3696}; //120%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.4312,0.4312}; //140%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.4928,0.4928}; //160%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.5544,0.5544}; //180%Fmax*/   
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.616,0.616}; //200%Fmax*/
	    double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.6776,0.6776}; //220%Fmax*/   
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.7392,0.7392}; //240%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.8008,0.8008}; //260%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.8624,0.8624}; //280%Fmax*/
		//double y[] = {0,2.92E-03,1.08E-02,3.83E-02,5.63E-02,9.65E-02,1.38E-01,1.57E-01,1.93E-01,2.08E-01,2.35E-01,2.56E-01,2.73E-01,2.86E-01,2.90E-01,2.96E-01,2.99E-01,3.03E-01,3.05E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.08E-01,0.924,0.924}; //300%Fmax*/

		m_ForceFunction.SetValue(x,y,26);
		//double y[] = {0,5.25E-03,1.51E-02,4.57E-02,6.47E-02,1.06E-01,1.47E-01,1.66E-01,2.00E-01,2.15E-01,2.41E-01,2.61E-01,2.77E-01,2.89E-01,2.92E-01,2.97E-01,3.00E-01,3.04E-01,3.06E-01,3.07E-01,3.08E-01,3.08E-01,3.09E-01,3.09E-01,4.63E-01,4.63E-01}; //150%Fmax

		//Elastican - zadata sila
		/*double x[] = {0,0.1,0.11,0.5};
        double y[] = {0,0.005,0.0,0.0}; 
		m_ForceFunction.SetValue(x,y,4);*/
		/**
		boundary_values[2]=0;
        constraints.add_line (6);
        constraints.add_entry (6, 4, 1.0);
		/**/



        /*printf("%lf\n",m_ForceFunction.GetValue(0.01));
        getchar();*/



#ifdef RelatedDisplacement
        //mapiranje cvorova
        mapDeal.mappingNodes(ModelData,cvorovi);
        FILE *rDisplacement=fopen("RelatedDisplacement.csv","r");
        UINT node1, node2, stepen;
        std::map<int,int> ::iterator it1, it2, it3, it4;


        while(!feof(rDisplacement))
        {
            fscanf(rDisplacement,"%d%d%d",&node1,&node2,&stepen);
            if(feof(rDisplacement)) break;

            it1 = mapNodePakModelData.find(node1);
            it2 = mapNodePakModelData.find(node2);

            it3 = mapDeal.mapNod.find((*it1).second);
            it4 = mapDeal.mapNod.find((*it2).second);



            for(int i=0; i < stepen; i++)
            {
                constraints.add_line ((*it3).second*2+i);
                constraints.add_entry ((*it3).second*2+i, (*it4).second*2+i, 1.0);
            }

            //printf("%d  %d  %d  %d %d\n",node1,(*it3).second, node2,(*it4).second, stepen);
            //getchar();
        }

        fclose(rDisplacement);
        //getchar();
#endif
		constraints.close ();  

	    CompressedSparsityPattern c_sparsity(dof_handler.n_dofs());
        DoFTools::make_sparsity_pattern (dof_handler, c_sparsity);
		constraints.condense (c_sparsity);

	    sparsity_pattern.copy_from(c_sparsity);
        system_matrix.reinit (sparsity_pattern);

        /*std::map<int,int> ::iterator it5;
         for(int i=0;i<elastic_support1D.size();i++)
         {
             it5 =  mapDeal.mapNod.find(IDelastic_support1D[i]);
             boundary_values[(*it5).second*2]=0;
             boundary_values[(*it5).second*2+1]=0;

             //printf("%d %lf %lf %lf\n",(*it5).second,elastic_support1D[IDelastic_support1D[i]][0],elastic_support1D[IDelastic_support1D[i]][1], elastic_support1D[IDelastic_support1D[i]][2]);
             //getchar();

         }*/

        /*std::map<int,int> ::iterator it;

        for(unsigned int i=0;i<elastic_support1D.size();i++)
        {
             it =  mapDeal.mapNod.find(IDelastic_support1D[i]);
             for (unsigned int j=0; j<2; ++j)
             {
                 printf("%d %lf %lf %lf\n",(*it).second,elastic_support1D[IDelastic_support1D[i]][0],elastic_support1D[IDelastic_support1D[i]][j+1], elastic_support1D[IDelastic_support1D[i]][0]*elastic_support1D[IDelastic_support1D[i]][j+1]);
                 getchar();

             }
        }*/



	   	//kraj boundary iz Pak.dat



        //BEGIN: Test mapiranje nodova
        /*MappingDeal mapDeal;
	    //mapiranje cvorova
	   	mapDeal.mappingNodes(ModelData,cvorovi);
        FILE *node=fopen("node.dat","w");
	   	//mapiranje elemenata---nije potrebno
        //mapDeal.mappingElem(ModelData,fe,triangulation,fe_values,dof_handler);
        for(unsigned int i=0; i<n_dofs_all/2; i++)
	    	{
              fprintf(node,"Deal: %d	ModelData:%d\n",i,mapDeal.mapNod[i]);
            }

        for(unsigned int i=0; i<ModelData.m_ElArray.GetSize(); i++)
                {
                  fprintf(node,"ModelData: %d	Deal:%d\n",i,mapDeal.mapElem[i]);
                }
        fclose(node);
        getchar();*/
        //END

       /*std::map< int,int> ::iterator it;
        for( int i=0; i<n_dofs_all/2; i++)
	    {
            it=mapNodePakModelData.find(i);

          printf("dof: %d x: %d \n",i,mapNodePakModelData[i]);
                getchar();
	    }
        getchar();*/


		 MMType tipovi[n_q_points_all];
         double voxelData[n_q_points_all];

         m_pImportModel.setMaterials(ModelData,n_q_points_all,tipovi,voxelData);

         m_qpoint_voxel_orient.resize(n_q_points_all);

        for (unsigned int p=0; p<20; ++p)
             VoxelDataArray[p].bLoaded=0;



         unsigned int cell_Index = 0;
         std::vector<unsigned int> q_point_Index (n_q_points);


         cell = dof_handler.begin_active();   endc = dof_handler.end();
         for (; cell!=endc; ++cell)
                 {
                             fe_values.reinit (cell);
                             cell->get_dof_indices (dofIndex);

                             for (unsigned int i=0;i<n_q_points;i++)
                             q_point_Index[i]=cell_Index*(n_q_points)+i;

                             for(unsigned int q_point=0;q_point<n_q_points;q_point++) {

                                    if(voxelData[q_point_Index[q_point]] < 0.0)
                                    {

                                           int VoxelFileNum = (int)(fabs(voxelData[q_point_Index[q_point]]));
                                           m_qpoint_voxel_orient[q_point_Index[q_point]] = VoxelData_GetVector(VoxelFileNum, fe_values.quadrature_point(q_point)[0],fe_values.quadrature_point(q_point)[1]);

                                           //printf("%d: %lf  %lf\n",VoxelFileNum,m_qpoint_voxel_orient[q_point_Index[q_point]][0],m_qpoint_voxel_orient[q_point_Index[q_point]][1]);
                                           //printf("%lf  %lf\n",fe_values.quadrature_point(q_point)[0],fe_values.quadrature_point(q_point)[1]);
                                           //getchar();
                                    }
                                    else
                                    {
                                           //m_qpoint_voxel_orient[q_point_Index[q_point]][0]= fe_values.jacobian(q_point)[0][0];
                                           //m_qpoint_voxel_orient[q_point_Index[q_point]][1]= fe_values.jacobian(q_point)[1][0];

                                           m_qpoint_voxel_orient[q_point_Index[q_point]][0]= 1.0;
                                           m_qpoint_voxel_orient[q_point_Index[q_point]][1]= 0.0;

                                           //printf("%lf  %lf\n",m_qpoint_voxel_orient[q_point_Index[q_point]][0],m_qpoint_voxel_orient[q_point_Index[q_point]][1]);
                                           //getchar();
                                    }

                                }
                             cell_Index++;
                 }
         /*for(int i=1;i<9;i++)
         {
             for (unsigned int k=0; k<VoxelDataArray[i].nVoxelCountX; ++k)
                 for (unsigned int j=0; j<VoxelDataArray[i].nVoxelCountY; ++j)
                 {
                     printf("%lf %lf\n",VoxelDataArray[i].Vectors[k][j][0],VoxelDataArray[i].Vectors[k][j][1]);
                 }
             getchar();
         }*/

         /*for(int i=0;i<n_q_points_all;i++)
         {
             printf("%lf\n",voxelData[i]);

         }

         getchar();*/

         //za slucaj da se ne zove setModel
         //for(int i=0;i<n_q_points_all;i++) tipovi[i]=Huxley2D;//(i<(num_cells_x*4))?0:1; //tipovi[i]=1;


         //m_pImportModel.setActivation(ModelData, 0.01);
         printf("Postavio aktivaciju\n");
         Globals* g=Globals::getInstance();
#ifdef MDX
		double volume = 0.0;
		int elemID[1500],br = 0;
		double nodeCoord[4][2];
		int elemNode[1500][4];
		ic=0;
		cell = dof_handler.begin_active();   endc = dof_handler.end();

		for (; cell!=endc; ++cell)
		{
			 fe_values.reinit (cell);
			 cell->get_dof_indices (dofIndex);
			 elemNode[ic][0] = dofIndex[0]/2;
			 elemNode[ic][1] = dofIndex[2]/2;
			 elemNode[ic][2] = dofIndex[6]/2;
			 elemNode[ic][3] = dofIndex[4]/2;
			 
			 
             for (unsigned int i=0;i<n_q_points;i++)
				q_point_Index[i]=ic*(n_q_points)+i;
			 if(g->m_fi[q_point_Index[0]] > 0.0)
				{
					elemID[br] = ic;
					br++;
					double p = 0.0;

					/*for (unsigned int i=0;i<2;i++)
						for (unsigned int j=0;j<2;j++)
							nodeCoord[i][j] = cell->vertex(i)[j];							
				    for (unsigned int j=0;j<2;j++)
							nodeCoord[2][j] = cell->vertex(3)[j];
				    for (unsigned int j=0;j<2;j++)
							nodeCoord[3][j] = cell->vertex(2)[j];*/
							
					//for (unsigned int i=0;i<4;i++)
						//printf("%lf, %lf\n", nodeCoord[i][0],nodeCoord[i][1]);
					//getchar();
					/*for(int j = 0; j < 3; j++)
						p = p + (nodeCoord[j][0]*nodeCoord[j+1][1] - nodeCoord[j][1]*nodeCoord[j+1][0]);

					p = p +	(nodeCoord[3][0]*nodeCoord[0][1] - nodeCoord[3][1]*nodeCoord[0][0]);*/
					
					for(int j = 0; j < 3; j++)
						p = p + (cvorovi[elemNode[ic][j]][0]*cvorovi[elemNode[ic][j+1]][1] - cvorovi[elemNode[ic][j]][1]*cvorovi[elemNode[ic][j+1]][0]);
					p = p +	(cvorovi[elemNode[ic][3]][0]*cvorovi[elemNode[ic][0]][1] - cvorovi[elemNode[ic][3]][1]*cvorovi[elemNode[ic][0]][0]);

						p = fabs(p) / 2.0;

			        volume = volume + p * m_element_thickness[ic];
				}			 
			 ic++;
		}

		
		double volumeMDX = 0.0;
		while (volumeMDX < MDX * volume)
		{
			//srand (time(NULL));
			int elemIDposition = rand() % br;

			int ic = elemID[elemIDposition];
			
			for (unsigned int i=0;i<n_q_points;i++)
			{
				g->m_fi[ic*(n_q_points)+i] = 0.0;
			 	//g->m_E[ic*(n_q_points)+i] *= 2.0;
			}


			double p = 0.0;
			for(int j = 0; j < 3; j++)
				p = p + (cvorovi[elemNode[ic][j]][0]*cvorovi[elemNode[ic][j+1]][1] - cvorovi[elemNode[ic][j]][1]*cvorovi[elemNode[ic][j+1]][0]);
					
			p = p +	(cvorovi[elemNode[ic][3]][0]*cvorovi[elemNode[ic][0]][1] - cvorovi[elemNode[ic][3]][1]*cvorovi[elemNode[ic][0]][0]);

			p = fabs(p) / 2.0;

			volumeMDX = volumeMDX + p * m_element_thickness[ic];

			for (int i=elemIDposition; i < br - 1; i++)
				elemID[i] = elemID [i+1];
			br = br - 1;
		}

		//printf("%lf   %lf\n", volume,volumeMDX);
		//getchar();

#endif

		// ic=0;
		// cell = dof_handler.begin_active();   endc = dof_handler.end();

		// for (; cell!=endc; ++cell)
		// {
			 // fe_values.reinit (cell);
			 // cell->get_dof_indices (dofIndex);
			 
             // for (unsigned int i=0;i<n_q_points;i++)
				// q_point_Index[i]=ic*(n_q_points)+i;
				
			 // if(g->m_fi[q_point_Index[0]] > 0.0)
				// {
					// for (unsigned int i=0;i<n_q_points;i++)
					// {
						// g->m_fi[q_point_Index[i]] *= 0.9;
						// g->m_E[q_point_Index[i]] *= 1.19;
					// }

				// }			 
			 // ic++;
		// }


// ----------------- calculator.init()
     // ANAF1TIP qpoint_calculator->init(n_q_points_all,&tipovi[0],g->m_E,g->m_ni,g->m_fi,g->m_f1);
         qpoint_calculator->init(n_q_points_all,&tipovi[0],g->m_E,g->m_ni,g->m_fi,g->m_f1);
// ----------------- calculator.init()  END
	 printf("------- Inicijalizacija QPointCalulator-a ----- END\n");
}


Point<2> FEM2D::VoxelData_GetVector(int VoxelFileNum, double qPointX, double qPointY)
{
    Point<2> pp;
    int i, j;

    if (!(VoxelDataArray[VoxelFileNum].bLoaded)) VoxelData_Load(VoxelFileNum);

    i = (int)((qPointX - VoxelDataArray[VoxelFileNum].Origin[0])/VoxelDataArray[VoxelFileNum].dVoxelSizeX);
    j = (int)((qPointY - VoxelDataArray[VoxelFileNum].Origin[1])/VoxelDataArray[VoxelFileNum].dVoxelSizeY);

    if((i>=VoxelDataArray[VoxelFileNum].nVoxelCountX) || (j>=VoxelDataArray[VoxelFileNum].nVoxelCountY))
    {
        printf("nije nasaooo \n");
        getchar();
    }

    pp = VoxelDataArray[VoxelFileNum].Vectors[i][j];

    return pp;
}

void FEM2D::VoxelData_Load(int VoxelFileNum)
{

    char ch=48+VoxelFileNum;
    char file[10]="Voxel.";
    int len = strlen(file);
    file[len] = ch;
    file[len+1] = '\0';
    double pom;


    FILE *f=fopen(file,"r");

    fscanf(f,"%d%d%d",&VoxelDataArray[VoxelFileNum].nVoxelCountX,&VoxelDataArray[VoxelFileNum].nVoxelCountY,&VoxelDataArray[VoxelFileNum].nVoxelCountZ);
    //printf("%d%d%d\n",VoxelDataArray[VoxelFileNum].nVoxelCountX,VoxelDataArray[VoxelFileNum].nVoxelCountY,VoxelDataArray[VoxelFileNum].nVoxelCountZ);

    fscanf(f,"%lf%lf%lf",&VoxelDataArray[VoxelFileNum].dVoxelSizeX,&VoxelDataArray[VoxelFileNum].dVoxelSizeY,&VoxelDataArray[VoxelFileNum].dVoxelSizeZ);
    //printf("%lf%lf%lf\n",VoxelDataArray[VoxelFileNum].dVoxelSizeX,VoxelDataArray[VoxelFileNum].dVoxelSizeY,VoxelDataArray[VoxelFileNum].dVoxelSizeZ);

    fscanf(f,"%lf%lf%lf",&VoxelDataArray[VoxelFileNum].Origin[0],&VoxelDataArray[VoxelFileNum].Origin[1],&pom);
    //printf("%lf%lf%lf\n",VoxelDataArray[VoxelFileNum].Origin[0],VoxelDataArray[VoxelFileNum].Origin[1],pom);
    //getchar();
    VoxelDataArray[VoxelFileNum].Vectors.resize(VoxelDataArray[VoxelFileNum].nVoxelCountX);
    for ( int i=0; i<VoxelDataArray[VoxelFileNum].nVoxelCountX; ++i)
        VoxelDataArray[VoxelFileNum].Vectors[i].resize(VoxelDataArray[VoxelFileNum].nVoxelCountY);


    for ( int i=0; i<VoxelDataArray[VoxelFileNum].nVoxelCountX; ++i)
        for ( int j=0; j<VoxelDataArray[VoxelFileNum].nVoxelCountY; ++j)
        {
            fscanf(f,"%lf%lf%lf",&VoxelDataArray[VoxelFileNum].Vectors[i][j][0],&VoxelDataArray[VoxelFileNum].Vectors[i][j][1],&pom);
            //printf("%lf %lf% lf\n",VoxelDataArray[VoxelFileNum].Vectors[i][j][0],VoxelDataArray[VoxelFileNum].Vectors[i][j][1],pom);
        }

    VoxelDataArray[VoxelFileNum].bLoaded=true;

    //printf("%s\n",file);
    //getchar();
    fclose(f);

}


void FEM2D::solve ()
{
	  SparseDirectUMFPACK A_direct;
	  A_direct.initialize(system_matrix);
	  A_direct.vmult (solution, system_rhs);
}

FullMatrix<double> FEM2D::e_element(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
		std::vector<unsigned int> dofIndex )
		{
		FullMatrix<double> deformacija;
		deformacija.reinit(3,n_q_points);
		deformacija = 0;
	  	for(unsigned int q_point=0;q_point<n_q_points;q_point++) {
	  	  	  for (unsigned int i=0; i<dofs_per_cell; ++i) {
           		unsigned int  comp = fe.system_to_component_index(i).first;
	  			deformacija[0][q_point] +=((comp==0)*fe_values.shape_grad(i,q_point)[0])*U(i) ;
	  			deformacija[1][q_point] +=((comp==1)*fe_values.shape_grad(i,q_point)[1])*U(i) ;
	  			deformacija[2][q_point] +=((comp==0)*fe_values.shape_grad(i,q_point)[1] +(comp==1)*fe_values.shape_grad(i,q_point)[0])*U(i) ;
	  	  }
	  	}
	  	return deformacija;
		}
FullMatrix<double> FEM2D::e_element_nulti(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape)
        {

        FullMatrix<double> deformacija;
        deformacija.reinit(3,1);
        deformacija = 0;


        for (unsigned int i=0; i<dofs_per_cell; ++i) {
                unsigned int  comp = fe.system_to_component_index(i).first;
                deformacija[0][0] +=((comp==0)*nulti_shape[i])*U(i) ;
                deformacija[1][0] +=((comp==1)*nulti_shape[i])*U(i) ;
                deformacija[2][0] +=(comp==0)?(nulti_shape[i+1]*U(i)):(nulti_shape[i-1]*U(i)) ;
             }
        return deformacija;
 }

 FullMatrix<double>  FEM2D::set_eNL(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape)
{
	    FullMatrix<double> deformacija;
        deformacija.reinit(3,1);
		deformacija = 0;
		double l11=0.0, l22=0.0, l21=0.0, l12=0.0;

		for(unsigned int no=0;no<dofs_per_cell;no++)
		{
				unsigned int  comp_j = fe.system_to_component_index(no).first;
				l11 +=((comp_j==0)?nulti_shape[no]*U(no):0) ;
				l22 +=((comp_j==1)?nulti_shape[no]*U(no):0) ;
				l21 +=((comp_j==1)?nulti_shape[no-1]*U(no):0) ;
				l12 +=((comp_j==0)?nulti_shape[no+1]*U(no):0) ;
		}
		
		deformacija[0][0] = l11 + (l11*l11 + l21*l21)/2.0;
		deformacija[1][0] = l22 + (l12*l12 + l22*l22)/2.0;
		deformacija[2][0]= l12 + l21 + l11*l12 + l21*l22;


		return deformacija;
}
		
FullMatrix<double> FEM2D::t_e_qpoint(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex, Vector<double> &x_local)
		{
		FullMatrix<double> transformacija;
	    double l1, l2, m1, m2;
		transformacija.reinit( 3, 3);
        transformacija = 0;



                                        /*// I varijanta bez vektora orjentacije
                                        l1 = fe_values.jacobian(n_q_points)[0][0];
										l2 = fe_values.jacobian(n_q_points)[0][1];
										
										m1 = fe_values.jacobian(n_q_points)[1][0];
										m2 = fe_values.jacobian(n_q_points)[1][1];

                                       for(int ii=0;ii<2;ii++)
                                                for(int jj=0;jj<2;jj++)
                                                            {
                                                                    printf("%d:  %d:  %lf\n",ii,jj,fe_values.inverse_jacobian(n_q_points)[ii][jj]);
                                                            }

                                       getchar();*/


                                        //Vector<double> x_local (3);
										Vector<double> y_local (3);
										Vector<double> z_ort (3);

                                        /*//I varijanta bez vektora orjentacije
                                        x_local[0] = l1;
										x_local[1] = m1;
                                        x_local[2] = 0;*/



										x_local/=x_local.l2_norm();


                                        /*for(int jj=0;jj<3;jj++)
                                                             {
                                                                     printf("%d:  %lf\n",jj,x_local[jj]);
                                                             }
                                        getchar();*/

										z_ort[0] = 0;
										z_ort[1] = 0;
										z_ort[2] = 1;

										y_local[0] =  z_ort[1]*x_local[2] - x_local[1] * z_ort[2];
										y_local[1] =  z_ort[2]*x_local[0] - x_local[2] * z_ort[0];
										y_local[2] =  z_ort[0]*x_local[1] - x_local[0] * z_ort[1] ;
										
										y_local/=y_local.l2_norm();


											 	 		/*for(int jj=0;jj<3;jj++)
											 	 			 	 	 {
											 	 		 printf("%d:  %lf\n",jj,y_local[jj]);
											 	 				 }
														getchar();*/

									   l1 = x_local[0];
									   l2 = y_local[0];

									   m1 = x_local[1];
									   m2 = y_local[1];
									  /* printf("l1:  %lf\n",l1);
									   printf("l2:  %lf\n",l2);
									   printf("m1:  %lf\n",m1);
									   printf("m2:  %lf\n",m2);
									   getchar();*/


		 	 				 	 		transformacija[0][0] = l1 * l1;
		 	 				 	 		transformacija[0][1] = m1 * m1;
		 	 				 	 		transformacija[0][2] = l1 * m1;
		 	 				 	 		
		 	 				 	 	    transformacija[1][0] = l2 * l2;
		 	 				 	 		transformacija[1][1] = m2 * m2;
		 	 				 	 		transformacija[1][2] = l2 * m2;
		 	 				 	 		
		 	 				 	 		transformacija[2][0] = 2 * l1 * l2;
		 	 				 	 		transformacija[2][1] = 2 * m1 * m2;
		 	 				 	 		transformacija[2][2] = l1 * m2 + m1 * l2;
                                        /*int i,j;
                                        for (i = 0; i < 3; ++i) {
		 	 				 	 			for (j = 0; j < 3; ++j) {
		 	 				 	 			 printf("%d:  %d:  %lf\n",i,j,transformacija[i][j] );
											}

                                        }
                                        getchar();*/
		 	 				 	 		
									
	  	return transformacija;
		}

Vector<double> FEM2D::set_local_orient(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell, double* init_inverse_jacobian, Point<2> init_orient)
{
    Vector<double> local_orient (3);
    double grad_def[2][2];

    /* printf("inverse_jacobian \n");
    for (int i = 0; i < 2; ++i)
       for (int j = 0; j < 2; ++j)
           printf("%d:  %d:  %lf\n",i,j,*(init_inverse_jacobian +i*2 + j)  );

    printf("local_jacobian \n");
   for (int i = 0; i < 2; ++i)
      for (int j = 0; j < 2; ++j)
          printf("%d:  %d:  %lf\n",i,j,fe_values.jacobian(n_q_points)[i][j]);*/

   for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
              grad_def[i][j] = 0.0; 
   /*for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
          for(int k=0; k<2; k++)
          {
              //printf("Mnozim %lf  i   %lf\n",fe_values.jacobian(n_q_points)[k][i] ,(*(init_inverse_jacobian +j*2 + k) ));
              grad_def[i][j] +=fe_values.jacobian(n_q_points)[k][i] * (*(init_inverse_jacobian +j*2 + k) );
		  }*/
   for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
          for(int k=0; k<2; k++)
          {
              //printf("Mnozim %lf  i   %lf\n",fe_values.jacobian(n_q_points)[i][k] ,(*(init_inverse_jacobian +k*2 + j) ));
              grad_def[i][j] +=fe_values.jacobian(n_q_points)[i][k] * (*(init_inverse_jacobian +k*2 + j) );
		  }
	for(int i=0; i<2; i++)
		local_orient[i] = 0.0;

    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
            local_orient[i] += grad_def[i][j] * init_orient[j];
			
	double intez = sqrt(local_orient[0] * local_orient[0] + local_orient[1] * local_orient[1]);
    for(int j=0; j<2; j++)
	local_orient[j] /=intez;
    //for(int j=0; j<2; j++)
      //printf("%d: %lf\n",j,local_orient[j]);
    //getchar();
    local_orient[2] = 0.0;

    /*FILE *pom;
	pom = fopen("stretch_fem.txt","a");
			fprintf(pom,"\t%f\n ",intez);
	fclose(pom);*/

     /*printf("U SET GRAD\n");

     for (int i = 0; i < 2; ++i)
        for (int j = 0; j < 2; ++j)
            printf("%d:  %d:  %lf\n",i,j,grad_def[i][j] );*/
     //getchar();

    return local_orient;



}

Vector<double> FEM2D::set_local_orient(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell, double* init_inverse_jacobian, Point<2> init_orient, Vector<double> &stretch)
{
    Vector<double> local_orient (3);
    double grad_def[2][2];

    /* printf("inverse_jacobian \n");
    for (int i = 0; i < 2; ++i)
       for (int j = 0; j < 2; ++j)
           printf("%d:  %d:  %lf\n",i,j,*(init_inverse_jacobian +i*2 + j)  );

    printf("local_jacobian \n");
   for (int i = 0; i < 2; ++i)
      for (int j = 0; j < 2; ++j)
          printf("%d:  %d:  %lf\n",i,j,fe_values.jacobian(n_q_points)[i][j]);*/

   for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
              grad_def[i][j] = 0.0; 
   /*for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
          for(int k=0; k<2; k++)
          {
              //printf("Mnozim %lf  i   %lf\n",fe_values.jacobian(n_q_points)[k][i] ,(*(init_inverse_jacobian +j*2 + k) ));
              grad_def[i][j] +=fe_values.jacobian(n_q_points)[k][i] * (*(init_inverse_jacobian +j*2 + k) );
		  }*/
   for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
          for(int k=0; k<2; k++)
          {
              //printf("Mnozim %lf  i   %lf\n",fe_values.jacobian(n_q_points)[i][k] ,(*(init_inverse_jacobian +k*2 + j) ));
              grad_def[i][j] +=fe_values.jacobian(n_q_points)[i][k] * (*(init_inverse_jacobian +k*2 + j) );
		  }
	for(int i=0; i<2; i++)
		local_orient[i] = 0.0;

    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
            local_orient[i] += grad_def[i][j] * init_orient[j];
			
	double intez = sqrt(local_orient[0] * local_orient[0] + local_orient[1] * local_orient[1]);
    for(int j=0; j<2; j++)
	local_orient[j] /=intez;
    //for(int j=0; j<2; j++)
      //printf("%d: %lf\n",j,local_orient[j]);
	   //printf("strech: %lf\n",intez);
    //getchar();
    local_orient[2] = 0.0;
    stretch[0] = intez;
	stretch[1] = 0.0;
	stretch[2] = 0.0;
    return local_orient;

}


FullMatrix<double> FEM2D::set_B_matrix_L0(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape)
{
    FullMatrix<double> B_matrix_L0;
    B_matrix_L0.reinit(3,dofs_per_cell);
    B_matrix_L0 = 0;

    /*for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            B_matrix_L0[0][no]=(comp_j==0)?fe_values.shape_grad(no,n_q_points)[0]:0 ;
            B_matrix_L0[1][no]=(comp_j==1)?fe_values.shape_grad(no,n_q_points)[1]:0 ;
            B_matrix_L0[2][no]=(comp_j==0)?fe_values.shape_grad(no,n_q_points)[comp_j+1]:fe_values.shape_grad(no,n_q_points)[comp_j-1] ;
			//printf("%13.5E  \n",fe_values.shape_grad(no,n_q_points)[comp_j]);
    }
	
    return B_matrix_L0;*/

    for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            B_matrix_L0[0][no]=(comp_j==0)?nulti_shape[no]:0 ;
            B_matrix_L0[1][no]=(comp_j==1)?nulti_shape[no]:0 ;
            B_matrix_L0[2][no]=(comp_j==0)?nulti_shape[no+1]:nulti_shape[no-1] ;
			//printf("%13.5E  \n",nulti_shape[no]);
    }
    return B_matrix_L0;

}

FullMatrix<double> FEM2D::set_B_matrix_L1(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape)
{
    FullMatrix<double> B_matrix_L1;
    B_matrix_L1.reinit(3,dofs_per_cell);
    B_matrix_L1 = 0;
    double l11=0.0, l22=0.0, l21=0.0, l12=0.0;

    /*for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            l11 +=((comp_j==0)?fe_values.shape_grad(no,n_q_points)[0]*U(no):0) ;
            l22 +=((comp_j==1)?fe_values.shape_grad(no,n_q_points)[1]*U(no):0) ;
            l21 +=((comp_j==1)?fe_values.shape_grad(no,n_q_points)[0]*U(no):0) ;
            l12 +=((comp_j==0)?fe_values.shape_grad(no,n_q_points)[1]*U(no):0) ;
    }

    for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            B_matrix_L1[0][no]=(comp_j==0)*l11*fe_values.shape_grad(no,n_q_points)[0] + (comp_j==1)*l21*fe_values.shape_grad(no,n_q_points)[0] ;
            B_matrix_L1[1][no]=(comp_j==0)*l12*fe_values.shape_grad(no,n_q_points)[1] + (comp_j==1)*l22*fe_values.shape_grad(no,n_q_points)[1] ;
            B_matrix_L1[2][no]=(comp_j==0)*(l11*fe_values.shape_grad(no,n_q_points)[1]+l12*fe_values.shape_grad(no,n_q_points)[0]) + (comp_j==1)*(l21*fe_values.shape_grad(no,n_q_points)[1]+l22*fe_values.shape_grad(no,n_q_points)[0]) ;
    }
    return B_matrix_L1;*/


    for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            l11 +=((comp_j==0)?nulti_shape[no]*U(no):0) ;
            l22 +=((comp_j==1)?nulti_shape[no]*U(no):0) ;
            l21 +=((comp_j==1)?nulti_shape[no-1]*U(no):0) ;
            l12 +=((comp_j==0)?nulti_shape[no+1]*U(no):0) ;
    }
	/*printf("l11, l22, l21, l12: %lf, %lf, %lf, %lf\n",l11,l22,l21,l12);
	getchar();*/

    for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            B_matrix_L1[0][no]=(comp_j==0)?l11*nulti_shape[no]:l21*nulti_shape[no-1] ;
            B_matrix_L1[1][no]=(comp_j==0)?l12*nulti_shape[no+1]:l22*nulti_shape[no] ;
            B_matrix_L1[2][no]=(comp_j==0)?(l11*nulti_shape[no+1]+l12*nulti_shape[no]):(l21*nulti_shape[no]+l22*nulti_shape[no-1]) ;
    }
    /*for(unsigned int i=0;i<3;i++)
    for(unsigned int no=0;no<dofs_per_cell;no++)
    {
        printf("%lf\n", B_matrix_L1[i][no]);
    }
    getchar();*/
    return B_matrix_L1;


}

FullMatrix<double> FEM2D::set_B_matrix_NL(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
        std::vector<unsigned int> dofIndex ,double* nulti_shape)
{
    FullMatrix<double> B_matrix_NL;
    B_matrix_NL.reinit(4,dofs_per_cell);
    B_matrix_NL = 0;

    /*for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            B_matrix_NL[0][no]=(comp_j==0)?fe_values.shape_grad(no,n_q_points)[0]:0 ;
            B_matrix_NL[1][no]=(comp_j==0)?fe_values.shape_grad(no,n_q_points)[1]:0 ;
            B_matrix_NL[2][no]=(comp_j==1)?fe_values.shape_grad(no,n_q_points)[0]:0 ;
            B_matrix_NL[3][no]=(comp_j==1)?fe_values.shape_grad(no,n_q_points)[1]:0 ;
    }
    return B_matrix_NL;*/


    for(unsigned int no=0;no<dofs_per_cell;no++)
    {
            unsigned int  comp_j = fe.system_to_component_index(no).first;
            B_matrix_NL[0][no]=(comp_j==0)?nulti_shape[no]:0 ;
            B_matrix_NL[1][no]=(comp_j==0)?nulti_shape[no+1]:0 ;
            B_matrix_NL[2][no]=(comp_j==1)?nulti_shape[no-1]:0 ;
            B_matrix_NL[3][no]=(comp_j==1)?nulti_shape[no]:0 ;
    }
    return B_matrix_NL;


}

FullMatrix<double> FEM2D::t_sigma_qpoint(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
		std::vector<unsigned int> dofIndex)
		{
		FullMatrix<double> transformacija;
	    double l1, l2, m1, m2;
		transformacija.reinit( 3, 3);
        transformacija = 0;

										l1 = fe_values.inverse_jacobian(n_q_points)[0][0];
										l2 = fe_values.inverse_jacobian(n_q_points)[0][1];

										m1 = fe_values.inverse_jacobian(n_q_points)[1][0];
										m2 = fe_values.inverse_jacobian(n_q_points)[1][1];

		 	 				 	 		transformacija[0][0] = l1 * l1;
		 	 				 	 		transformacija[0][1] = m1 * m1;
		 	 				 	 		transformacija[0][2] = 2*l1 * m1;

		 	 				 	 	    transformacija[1][0] = l2 * l2;
		 	 				 	 		transformacija[1][1] = m2 * m2;
		 	 				 	 		transformacija[1][2] = 2*l2 * m2;

		 	 				 	 		transformacija[2][0] =  l1 * l2;
		 	 				 	 		transformacija[2][1] =  m1 * m2;
		 	 				 	 		transformacija[2][2] = l1 * m2 + m1 * l2;


	  	return transformacija;
		}
void FEM2D::set_sPK(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell, double* init_inverse_jacobian, double* sigma_global, double* sPK_matrix_vector, FullMatrix<double> & sPK_matrix)
{


    FullMatrix<double>   sigma_matrix_q_point;
    FullMatrix<double>   sPK_matrix_q_point_vector;
    FullMatrix<double>   grad_def;

    sigma_matrix_q_point.reinit(2, 2, false);
    sPK_matrix_q_point_vector.reinit(2, 2, false);
    grad_def.reinit(2, 2,false);

	//CAUCHY STRESSIES TO 2ND PIOLA-KIRCHHOFF STRESSES
    /*//Gradijent deformacije 0-t_X
    for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
      {
              grad_def[i][j] = 0.0;

      }
    //Deal.II Jacobian i inverse Jacobian pamti transponovano u odnosu na literaturu, mi kada mnozimo vodimo racuna
    //kako bi dobili odgovarajuci grad_def za datu q_point, u njemu je sve kao u literaturi.
    for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
          for(int k=0; k<2; k++)
          {
              grad_def[i][j] +=fe_values.jacobian(n_q_points)[k][i] * (*(init_inverse_jacobian +j*2 + k) );
          }


    //od vektora sigma pravim odgovarajucu matricu dimenzije 2x2
    sigma_matrix_q_point[0][0]=sigma_global[0];
    sigma_matrix_q_point[0][1]=sigma_global[2];
    sigma_matrix_q_point[1][0]=sigma_global[2];
    sigma_matrix_q_point[1][1]=sigma_global[1];

    double det = grad_def.determinant();

    //grad_def.invert(grad_def);
    for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
      {
          grad_def[i][j] = 1.0/det * grad_def[j][i];
          //printf("%lf\n",grad_def[i][j]);

      }
    //getchar();


    sPK_matrix_q_point_vector=0;
    sPK_matrix_q_point_vector.triple_product(sigma_matrix_q_point,grad_def,grad_def,false,true,1);
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
        {
            sPK_matrix_q_point_vector[i][j] *=det;
            printf("%lf\n",sPK_matrix_q_point_vector[i][j]);
        }
    getchar();

    //kreiramo vektor istog tipa kao i sigma samo sa 2nd Piola-Kirclloff stress
    sPK_matrix_vector[0]=sPK_matrix_q_point_vector[0][0];
    sPK_matrix_vector[1]=sPK_matrix_q_point_vector[1][1];
    sPK_matrix_vector[2]=sPK_matrix_q_point_vector[0][1];

    //kreiramo matricu dimenzije 4x4 sa istim vrednostima, raspord iz literature
    sPK_matrix=0;
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
        {
            sPK_matrix[i][j]=sPK_matrix_q_point_vector[i][j];
            sPK_matrix[i+2][j+2]=sPK_matrix_q_point_vector[i][j];
        }
    */
	
	//2ND PIOLA-KIRCHHOFF STRESSES	TO CAUCHY STRESSIES
    //Gradijent deformacije 0-t_X
    /*for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
      {
              grad_def[i][j] = 0.0;

      }
    //Deal.II Jacobian i inverse Jacobian pamti transponovano u odnosu na literaturu, mi kada mnozimo vodimo racuna
    //kako bi dobili odgovarajuci grad_def za datu q_point, u njemu je sve kao u literaturi.
    for(int i=0; i<2; i++)
      for(int j=0; j<2; j++)
          for(int k=0; k<2; k++)
          {
              grad_def[i][j] +=fe_values.jacobian(n_q_points)[k][i] * (*(init_inverse_jacobian +j*2 + k) );
          }


    //od vektora sigma pravim odgovarajucu matricu dimenzije 2x2
    sigma_matrix_q_point[0][0]=sigma_global[0];
    sigma_matrix_q_point[0][1]=sigma_global[2];
    sigma_matrix_q_point[1][0]=sigma_global[2];
    sigma_matrix_q_point[1][1]=sigma_global[1];

    double det = grad_def.determinant();

    sPK_matrix_q_point_vector=0;
    sPK_matrix_q_point_vector.triple_product(sigma_matrix_q_point,grad_def,grad_def,false,true,1);
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
        {
            sPK_matrix_q_point_vector[i][j] /=det;
            //printf("%lf\n",sPK_matrix_q_point_vector[i][j]);
        }
    //getchar();

    //kreiramo vektor istog tipa kao i sigma samo sa 2nd Piola-Kirclloff stress
    sPK_matrix_vector[0]=sPK_matrix_q_point_vector[0][0];
    sPK_matrix_vector[1]=sPK_matrix_q_point_vector[1][1];
    sPK_matrix_vector[2]=sPK_matrix_q_point_vector[0][1];

    //kreiramo matricu dimenzije 4x4 sa istim vrednostima, raspord iz literature
    sPK_matrix=0;
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
        {
            sPK_matrix[i][j]=sPK_matrix_q_point_vector[i][j];
            sPK_matrix[i+2][j+2]=sPK_matrix_q_point_vector[i][j];
        }
    */
    //Materijalni model vec vrati PK
    sPK_matrix_q_point_vector=0;
    sPK_matrix_q_point_vector[0][0]=sigma_global[0];
    sPK_matrix_q_point_vector[0][1]=sigma_global[2];
    sPK_matrix_q_point_vector[1][0]=sigma_global[2];
    sPK_matrix_q_point_vector[1][1]=sigma_global[1];

    sPK_matrix_vector[0]=sigma_global[0];
    sPK_matrix_vector[1]=sigma_global[1];
    sPK_matrix_vector[2]=sigma_global[2];

    sPK_matrix=0;
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
        {
            sPK_matrix[i][j]=sPK_matrix_q_point_vector[i][j];
            sPK_matrix[i+2][j+2]=sPK_matrix_q_point_vector[i][j];
        }
	
    /*for(int i=0; i<4; i++)
        for(int j=0; j<4; j++)
        {
            printf("%lf\n",sPK_matrix[i][j]);
        }

    getchar();*/

}

size_t CurlWrite_CallbackFunc_StdString(void *contents, size_t size, size_t nmemb, std::string *s)
{
    size_t newLength = size*nmemb;
    size_t oldLength = s->size();
    try
    {
        s->resize(oldLength + newLength);
    }
    catch(std::bad_alloc &e)
    {
        //handle memory problem
        return 0;
    }

    std::copy((char*)contents, (char*)contents+newLength, s->begin()+oldLength);
    return size*nmemb;
}

void FEM2D::surogat_set_start()
{
    curl_global_init(CURL_GLOBAL_DEFAULT);

    std::string s;
    std::string endpoint = g->network + "/start";	
	int nqp = 0;
	for(int iqp = 0; iqp < n_q_points_all; iqp++)
	{
		if(fabs(g->m_fi[iqp]) > 1.0E-6)
			nqp++;
	}	
    std::ostringstream pom_npq, pom_ts;
	pom_npq	<< nqp;	
	pom_ts << g->use_time_series;
	std::string postthis = "simulation_id="+ g->simulation_id +"&nqp=" + pom_npq.str() 
	                         +"&netname=" + g->netname + "&time_series=" + pom_ts.str();	
	curl = curl_easy_init();
    if (curl) 
    {
        curl_easy_setopt(curl, CURLOPT_URL, endpoint.c_str());	
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postthis.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, &CurlWrite_CallbackFunc_StdString);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &s);
        curl_easy_perform(curl);	
	}
	   
}

void FEM2D::surogat_set_end()
{
	std::string s;
    std::string endpoint = g->network + "/end";		
	std::string postthis = "simulation_id="+ g->simulation_id;
	//curl = curl_easy_init();
    if (curl) 
    {
        curl_easy_setopt(curl, CURLOPT_URL, endpoint.c_str());
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postthis.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, &CurlWrite_CallbackFunc_StdString);	
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &s);		
        curl_easy_perform(curl);
        curl_easy_cleanup(curl);	
	}
	curl_global_cleanup();
}


void FEM2D::calculate_surogat_all_qpoints(double* aktivacija, double* akt_prev, double* stretch, double* stretch_prev, double* sigma_prev, double* delta_sigma_prev, double* sigma_matrix, double* deltasigma_matrix)
{
    std::string s;
    
    // Endpoint R-a na koji se poziva
	std::string endpoint = g->network + "/sigdsig";

	std::string a, a_prev, lamb, lamb_prev, sig_prev, dsig_prev;
	std::string postthis; 
	std::ostringstream ss;

	for(int iqp = 0; iqp < n_q_points_all; iqp++)
	{
		if(fabs(g->m_fi[iqp]) > 1.0E-6)
		{
			ss << aktivacija[iqp]; a   += ss.str();  ss.str("");
			ss << stretch[iqp];   lamb += ss.str(); ss.str("");
			ss << akt_prev[iqp];  a_prev += ss.str(); ss.str("");
			ss << stretch_prev[iqp]; lamb_prev += ss.str(); ss.str("");
			ss << sigma_prev[iqp];   sig_prev  += ss.str(); ss.str("");
			ss << delta_sigma_prev[iqp]; dsig_prev += ss.str(); ss.str("");
			
			a         += ",";			
			lamb      += ",";	
			a_prev    += ",";
			lamb_prev += ",";	
			sig_prev  += ",";
			dsig_prev += ",";			
		}		
	}
	a = a.substr(0, a.size()-1);
	a_prev = a_prev.substr(0, a_prev.size()-1);
	lamb = lamb.substr(0, lamb.size()-1);
	lamb_prev = lamb_prev.substr(0, lamb_prev.size()-1);
	sig_prev = sig_prev.substr(0, sig_prev.size()-1);
	dsig_prev = dsig_prev.substr(0, dsig_prev.size()-1);

	
	if(g->use_time_series)
	{
		postthis = "simulation_id=" + g->simulation_id +"&activation=" + a +  "&stretch=" + lamb
										+ "&sigma_prev="   +sig_prev + "&delta_sigma_prev=" + dsig_prev;			
	}
	else 
	{
		postthis = "simulation_id=" + g->simulation_id + "&activation_prev=" +  a_prev +"&activation=" + a
									  + "&stretch_prev=" + lamb_prev + "&stretch=" + lamb
									  + "&sigma_prev="   +sig_prev + "&delta_sigma_prev=" + dsig_prev;	
	}
    if(g->use_time_series && g->iter) postthis += "&converged=0";
	if(g->use_time_series && !g->iter) postthis += "&converged=1";	
    
    if (curl) 
    {
        curl_easy_setopt(curl, CURLOPT_URL, endpoint.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postthis.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, &CurlWrite_CallbackFunc_StdString);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &s);
        curl_easy_perform(curl);
    }
 
    // Ukloni uglaste zagrade
    boost::erase_all(s, "[");
    boost::erase_all(s, "]");
	boost::erase_all(s, "\"");
    
    std::vector<std::string> qp_delovi; 
	
    // Split i pretvori u double
    boost::split(qp_delovi, s, boost::is_any_of(","));
	int count = 0; 	
	for(int iqp = 0; iqp < n_q_points_all; iqp++)
	{
		if(fabs(g->m_fi[iqp]) > 1.0E-6)
		{
			std::vector<std::string> sigdsig; 
			boost::split(sigdsig,qp_delovi[count++], boost::is_any_of("#")); 
			sigma_matrix[iqp] = atof(sigdsig[0].c_str()); 
			deltasigma_matrix[iqp] = atof(sigdsig[1].c_str()); 
		}
	}			
}

void FEM2D::transform_local_to_global(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
                                      std::vector<unsigned int> dofIndex, const unsigned int q_point_Index, double* sigma_matrix_global,double* sigma_matrix, double* deltasigma_matrix, FullMatrix<double> & C_matrix,FullMatrix<double> &  C_matrix_global, double* tEglobal)
{

    FullMatrix<double> t_e_global;

    t_e_global.reinit(3,3);
    t_e_global = 0;

    /*for (unsigned int  j=0;j<3;j++)
               printf("sigma_matrix[%d][%d]=%lf\t",q_point_Index,j,sigma_matrix[j]);
                                                                                    printf("\n");
                                                                                        getchar();*/

    for (unsigned int z=0; z<3; ++z)
           for (unsigned int j=0; j<3; ++j)
              t_e_global[z][j] = *((tEglobal +z*3*n_q_points_all)+3*q_point_Index +j); //tEglobal[z][3*q_point_Index[q_point]+j];

    /*printf("U funkciji t_e_global\n");
    for(int i=0;i<3;i++)
    {
                for(int j=0;j<3;j++)
                    printf("%lf  ", t_e_global[i][j]);
                printf("\n");
    }
    getchar();*/

    for (unsigned int z=0; z<3; ++z)
           for (unsigned int j=0; j<3; ++j)
              sigma_matrix_global[z] += t_e_global[j][z] * sigma_matrix[j];
			  
	/*sigma_matrix_global[0] = 1.44305E-02;
	sigma_matrix_global[1] = 0.0;
	sigma_matrix_global[2] = 0.0;


    for(int i=0;i<3;i++)
    {
         printf("%lf  ", sigma_matrix_global[i]);
    }
    printf("\n");
    getchar();*/
	
    for(int i=0;i<3;i++)
                for(int j=0;j<3;j++)
                    C_matrix[i][j] +=*((deltasigma_matrix+i*3) + j);

    C_matrix_global=0;
    C_matrix_global.triple_product(C_matrix,t_e_global,t_e_global,true,false,1);
	
	/*for(int i=0;i<3;i++)
		{
					for(int j=0;j<3;j++)
						{
						  printf("*\t%lf", C_matrix[i][j]);
						
						}
					printf("\n");

		}
		getchar();
		
		for(int i=0;i<3;i++)
		{
					for(int j=0;j<3;j++)
						{
						  printf("*\t%lf", C_matrix_global[i][j]);
						
						}
					printf("\n");

		}
		getchar();*/

}

void FEM2D::transform_local_to_global_CE(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
                                      std::vector<unsigned int> dofIndex, const unsigned int q_point_Index, double* sigma_matrix_global,double* sigma_matrix, double* deltasigma_matrix, FullMatrix<double> & C_matrix,FullMatrix<double> &  C_matrix_global, double* tEglobal)
{

    FullMatrix<double> t_e_global;

    t_e_global.reinit(3,3);
    t_e_global = 0;


    for (unsigned int z=0; z<3; ++z)
           for (unsigned int j=0; j<3; ++j)
              t_e_global[z][j] = *((tEglobal +z*3*n_q_points_all)+3*q_point_Index +j); //tEglobal[z][3*q_point_Index[q_point]+j];



    C_matrix_global=0;
    C_matrix_global.triple_product(C_matrix,t_e_global,t_e_global,true,false,1);
	/*for(int i=0;i<3;i++)
    {
                for(int j=0;j<3;j++)
                    {
					  printf("*\t%lf", C_matrix[i][j]);
					
					}
				printf("\n");

    }
    getchar();
	
	for(int i=0;i<3;i++)
    {
                for(int j=0;j<3;j++)
                    {
					  printf("*\t%lf", C_matrix_global[i][j]);
					
					}
				printf("\n");

    }
    getchar();*/
	

}

FullMatrix<double> FEM2D::set_K_matrix(FullMatrix<double>   C_matrix_global,FullMatrix<double>   B_matrix, const unsigned int dofs_per_cell)
{
    FullMatrix<double> tmp_cell_matrix;
    tmp_cell_matrix.reinit(dofs_per_cell,dofs_per_cell);
    tmp_cell_matrix = 0;

    tmp_cell_matrix.triple_product(C_matrix_global,B_matrix,B_matrix,true,false,1);
	
	/*for (unsigned int i=0; i<dofs_per_cell; ++i)
           for (unsigned int j=0; j<dofs_per_cell; ++j)
			printf("%lf\n",tmp_cell_matrix[i][j]);
			
	getchar();*/

    return tmp_cell_matrix;


}
void FEM2D::simulate()
{
	  FullMatrix<double>   cell_matrix (dofs_per_cell, dofs_per_cell);
	  Vector<double>       cell_rhs (dofs_per_cell);

	  std::vector<unsigned int> dofIndex (dofs_per_cell);
	  Vector<double> U_cell (dofs_per_cell);
	  Vector<double> F_cell (dofs_per_cell);
	  Vector<double> deltaU (n_dofs_all);
	  std::vector<unsigned int> q_point_Index (n_q_points);
	  Vector<double> C_cell (n_q_points);

      Vector<double> local_orient (3);
	  Vector<double> stretch (3);


	  	FullMatrix<double> e_cell;
	    FullMatrix<double> t_e;
	    FullMatrix<double> t_e_global;
	    FullMatrix<double> t_sigma_global;
	    FullMatrix<double>   tmp_cell_matrix (dofs_per_cell, dofs_per_cell);
	    FullMatrix<double> C_matrix_nelinearan;
		FullMatrix<double>   B_matrix;
		FullMatrix<double>   B_matrix_L;
        FullMatrix<double>   B_matrix_L1;
        FullMatrix<double>   B_matrix_NL;
		FullMatrix<double>   C_matrix;
		FullMatrix<double>   sPK_matrix;
	    FullMatrix<double>   C_matrix_global;
	    FullMatrix<double>   CE_matrix_global;

	    FullMatrix<double> sigma_cell;
        FILE* fTop=fopen("top_point.csv","w");
        FILE* fNodeForce=fopen("NodalConstrainForcesHuxley.csv","w");
		FILE* fNodeDisplacement=fopen("NodalDiscplacement.csv","w");

        FILE* fPressure=fopen("PressureHuxley.csv","w");

        fprintf(fNodeForce,"feKorak,idCvora, CoordX, CoordY, E, Ox, Oy, Ux, Uy, ForceX, ForceY, ForceX_U, ForceY_U, Force\n");
		fprintf(fNodeDisplacement,"feKorak,idCvora,DisplacementX, DisplacementY\n");
        fprintf(fPressure,"feKorak,l,Pressure\n");

        unsigned int NodeElastic[9];

#ifdef ElasticSupport1D

        int ind=0;
        for(int i=0;i<elastic_support1D.size();i=i+2)
        {
             NodeElastic[ind] = IDelastic_support1D[i];
             ind++;
        }

        for(int i=elastic_support1D.size()-2;i>=0;i=i-2)
        {
             NodeElastic[ind] = IDelastic_support1D[i];
             ind++;
        }

        /*std::map<int,int> ::iterator it;

        for(unsigned int i=0;i<elastic_support1D.size();i++)
        {
             it =  mapDeal.mapNod.find(NodeElastic[i]);
             for (unsigned int j=0; j<2; ++j)
             {
                 printf("%d %lf %lf %lf\n",(*it).second,elastic_support1D[NodeElastic[i]][0],elastic_support1D[NodeElastic[i]][j+1], elastic_support1D[NodeElastic[i]][0]*elastic_support1D[NodeElastic[i]][j+1]);
                 getchar();

             }
        }*/

#endif


#ifdef PressureSwallowing
					
		//int nodePressure[14] = {363,362,364,365,347,346,348,349,331,330,332,333,315,314};
		int nodePressure[14] = {247,246,248,249,231,230,232,233,215,214,216,217,199,198};
		double normalF[2];
		double nodeF;
		double pressureLine;
		FILE* fnodePressure=fopen("nodePressure.csv","w");

#endif




	  DoFHandler<2>::active_cell_iterator
	  cell = dof_handler.begin_active(),
	  endc = dof_handler.end();

	  unsigned int POM=0;
	  deltaU = 1;

	  R = 0;
	  double E_faktor=100.0, ni = 0.3;

	   C_matrix.reinit(3, 3,false);
	   sPK_matrix.reinit(4, 4, false);
	   C_matrix_global.reinit(3, 3, false);
	   CE_matrix_global.reinit(3, 3, false);
	   B_matrix.reinit(3, dofs_per_cell,false);
	   t_e_global.reinit( 3, 3);

/*	  std::map<int,double>::iterator iter ;
	    if (!F_prescribed.empty()) for(iter=F_prescribed.begin(); iter!=F_prescribed.end() ;iter++) R[iter->first]=iter->second;
*/
	  int numOfSteps = g->step+T/g->dt;
	  double sigma[3];
	  Vector<double> e_vector;
	 e_vector.reinit(3,false); // dim = 2

	 double e_matrix[3][n_q_points_all];
	 double e_matrix_global[3][n_q_points_all];
	 double e_matrix_global_prev[3][n_q_points_all];
	 double e_matrix_local[3][n_q_points_all];
	 double e_matrix_local_prev[3][n_q_points_all];

	 double tEglobal[3][3*n_q_points_all];
	 double sigma_matrix[n_q_points_all][3];//,*sigma_inline;
	 double deltasigma_matrix[n_q_points_all][3][3];//,*deltasigma_inline;
     double sigma_matrix_global[n_q_points_all][3];
	 double Sigma_vector[3];
	 double sPK_matrix_vector[n_q_points_all][3];
	 int check_upadate[n_dofs_all/2];
	 unsigned int k;

     for(int i=0; i < n_q_points_all; i++)
         for(int j=0; j<3; j++)
             sigma_matrix[i][j]==0.0;

     for(int i=0; i < n_q_points_all; i++)
         for(int j=0; j<3; j++)
               for(int k=0; k<3; k++)
             deltasigma_matrix[i][j][k]==0.0;

/* DEBUG
	 printf("sizeof(sigma_matrix)=%d \n",sizeof(sigma_matrix)/(sizeof(double)*3));
	 printf("sizeof(deltasigma_matrix)=%d \n",sizeof(deltasigma_matrix)/(sizeof(double)*3*3));
*/
	  int flags[2];
	  flags[0]=0;flags[1]=0;
	  double* U_niz;
	  U_niz=&U[0];
      FILE *Upis, *UpisQP;

      //save initial Jacobian
      double n_q_point_Jacobian[n_q_points_all][2][2];
	  double n_q_point_JxW[n_q_points_all];
	  double nulti_shape[n_q_points_all][dofs_per_cell];
      unsigned int cell_Index = 0;
	  
	  //BEGIN: upis koordinata qpoint-a
      UpisQP=fopen("qPoint_ID.csv","w");
      fprintf(UpisQP,"IDqpoint, ind\n");


      cell = dof_handler.begin_active();   endc = dof_handler.end();
      for (; cell!=endc; ++cell)
              {
                          fe_values.reinit (cell);
                          cell->get_dof_indices (dofIndex);

                          for (unsigned int i=0;i<n_q_points;i++)
                          q_point_Index[i]=cell_Index*(n_q_points)+i;

                          for(unsigned int q_point=0;q_point<n_q_points;q_point++) {
                              for(int i=0;i<2;i++)
                                          for(int j=0;j<2;j++)
                                              n_q_point_Jacobian[q_point_Index[q_point]][i][j] = fe_values.inverse_jacobian(q_point)[i][j];
							  n_q_point_JxW[q_point_Index[q_point]] = fe_values.JxW(q_point);
							  
							  if(g->m_fi[q_point_Index[q_point]] > 0.0)
                                fprintf(UpisQP,"%d, %d\n",q_point_Index[q_point], 1);
								 else
								fprintf(UpisQP,"%d, %d\n",q_point_Index[q_point], 0);
							  
							  for(unsigned int no=0;no<dofs_per_cell;no++)
							  {
                               unsigned int  comp_j = fe.system_to_component_index(no).first;
                               nulti_shape[q_point_Index[q_point]][no]=fe_values.shape_grad(no,q_point)[comp_j];
                               //printf("%13.5E  \n",nulti_shape[q_point_Index[q_point]][no]);
                              }		

                             }
                          cell_Index++;
              }
     fclose(UpisQP);
      /*for(int ii=0;ii<2;ii++)
              for(int jj=0;jj<2;jj++)
                          {
                                  printf("%d:  %d:  %lf\n",ii,jj,n_q_point_Jacobian[0][ii][jj]);
                          }
      getchar();*/

      /*FILE *pomeranja=fopen("Pomeranje.dat","w");
      FILE *deformacije=fopen("Deformacije.dat","w");
      FILE *napon=fopen("Napon.dat","w");
      FILE *promena=fopen("Promena.dat","w");
      FILE *rhs=fopen("rhs.dat","w");*/

// FILE *radFEM; // radFEM
// radFEM=fopen("postHUXLEY.csv","w");
FILE *radFEMFI; // radFEM Bogdan
FILE *fSurro;
radFEMFI = fopen("postHUXLEYFI.csv","w");
fSurro   = fopen("surroHuxley.csv","w");
//fprintf(radFEM,"feKorak,idElementa, indexGausoveTacke, brzina [nm/s],brzinaAvg[nm/s],e_matrix_prev,e_matrix,sigma_global_prev\n");
// fprintf(radFEM,"feKorak,idElementa, indexGausoveTacke,aktivacija,e_matrix_prev,e_matrix,sigma_prev,sigma,delta_sigma_prev,delta_sigma \n");
// Bogdan radFEM
fprintf(radFEMFI,"step,iter,elementID, groupID, GaussPointID,activation_prev, activation,stretch_prev,stretch,sigma_prev,sigma,delta_sigma_prev,delta_sigma \n");
fprintf(fSurro,"step,iter,elementID, GaussPointID, activation_prev, activation,stretch_prev,stretch,sigma_prev,sigma,delta_sigma_prev,delta_sigma \n");
double* Vavg; Vavg=(double*)malloc(n_q_points_all*sizeof(double));
double* Eprev; Eprev=(double*)malloc(n_q_points_all*sizeof(double));
double* Ecarent; Ecarent=(double*)malloc(n_q_points_all*sizeof(double));
double* Aprev; Aprev=(double*)malloc(n_q_points_all*sizeof(double));
double* Acarent; Acarent=(double*)malloc(n_q_points_all*sizeof(double));
double* Sigmaprev; Sigmaprev=(double*)malloc(n_q_points_all*sizeof(double));
double* Sigmacarent; Sigmacarent=(double*)malloc(n_q_points_all*sizeof(double));
double* SigmacarentModel; SigmacarentModel=(double*)malloc(n_q_points_all*sizeof(double));
double* DeltaSigmaprev; DeltaSigmaprev=(double*)malloc(n_q_points_all*sizeof(double));
double* DeltaSigmacarent; DeltaSigmacarent=(double*)malloc(n_q_points_all*sizeof(double));
double* DeltaSigmacarentModel; DeltaSigmacarentModel=(double*)malloc(n_q_points_all*sizeof(double));
for(int i=0;i<n_q_points_all;Eprev[i]=1,Ecarent[i]=1,Sigmaprev[i]=0,Sigmacarent[i]=0,DeltaSigmaprev[i]=0,DeltaSigmacarent[i]=0,Aprev[i]=0,Acarent[i]=0,i++);

for(int i=0;i<n_q_points_all;i++)
	for(int j=0;j<3;j++)
	{
		e_matrix_global_prev[j][i] = 0.0;
		e_matrix_local_prev[j][i] = 0.0;
		}


//BEGIN: upis koordinata qpoint-a
Upis=fopen("qPoint.csv","w");
fprintf(Upis,"t, X, Y,JxW\n");

HuxleyState2D testState;
HuxleyParameters testParameters;
testParameters.InputData();
HuxleyModel2D testModel(&testParameters);
testState.init(&testParameters);
double test_sigma[3];
double test_dsigmade[9];
ublas::vector<_TIP> X;
ublas::vector<_TIP> N;
HuxleyCalculator testCalculator(&testParameters);
_TIP testForce;
	
long DIM = ceil((testParameters.xmax-testParameters.xmin)/testParameters.step);
DIM = DIM + testParameters.m_leftng + testParameters.m_rightng;
ublas::zero_vector<_TIP> _0(DIM+1);

N.resize(DIM+1,false);
X.resize(DIM+1,false);
N = _0;
_TIP poc = testParameters.xmin - testParameters.m_leftng*testParameters.step;
for(unsigned int i = 0; i <= DIM; i++) {
		X(i) = poc + testParameters.step * i;
}
FILE *IO_test = fopen("IO.csv","w");
fprintf(IO_test,"feKorak, idElementa, indexGausoveTacke, brzina [nm/s],force, lambda, sigma ,deltasigma\n");
char imeFajla[40];

int loadCaseUnv = 0;
      surogat_set_start();
      for(;g->step < numOfSteps;g->step++)
      {
	//	 printf("+++++++++++++++++++++++++++++++++  %d  +++++++++++++++++++++++++++++++++\n",g->step);
// jedan simulacioni korak
         //update_fe_value();
         FEValues<2> fe_values(fe, quadrature_formula, update_values  | update_jacobians  |   update_quadrature_points | update_q_points  |update_inverse_jacobians | update_gradients | update_JxW_values);
		 deltaU=1;
		 POM = 0;
         //postavljanje aktivacija za novi time step
         //m_pImportModel.setActivation(ModelData, (g->step+1)*g->dt);


         cell = dof_handler.begin_active(),
         endc = dof_handler.end();
 	 	 for (; cell!=endc; ++cell)
 	 	 {
             fe_values.reinit (cell);
 	 		 cell->get_dof_indices (dofIndex);
            for (unsigned int i=0;i<n_q_points;i++)
		 	 	q_point_Index[i]=cell_Index*(n_q_points)+i;

 	 		for (unsigned int i=0; i<n_q_points; ++i) //<GeometryInfo<2>::vertices_per_cell;i++)
		 				 {
                            fprintf(Upis,"%d, %lf,%lf,%lf\n",g->step,fe_values.quadrature_point(i)[0],fe_values.quadrature_point(i)[1],fe_values.JxW(i));
		 				 }
 	 	 }
		 fflush(Upis);
         //END

for(int i=0;i<n_q_points_all;Vavg[i]=0,i++); // radFEM

		 while (deltaU.l2_norm() > 1.0E-6) {
				FEValues<2> fe_values(fe, quadrature_formula, update_values  | update_jacobians  |   update_quadrature_points | update_q_points  |update_inverse_jacobians | update_gradients | update_JxW_values);
				 //update_fe_value();
		  	  	 system_matrix=0;
		 	 	 F=0;
		 	 	 cell = dof_handler.begin_active(),
				 endc = dof_handler.end();
// ----------------- calculator.saveAndcontinue()
		 	 	 if (flags[0]!=0)
		 	 		 	 	 qpoint_calculator->saveAndcontinue(flags);
// ----------------- calculator.saveAndcontinue()   END
		 		// printf("Da pocnem?\n");
		  	 	 unsigned int cell_Index = 0;
		  	 	 

		  	 	 for (int i = 0; i < 3; ++i)
					for (int j = 0; j < n_q_points_all; ++j)
						e_matrix[i][j]=0.0;

		 	 	 for (; cell!=endc; ++cell)
		 	 	 {
                     fe_values.reinit (cell);
	 	 		 	 cell->get_dof_indices (dofIndex);
		 	 		 for (unsigned int i=0;i<n_q_points;i++)
		 	 			 	 	 	 	 q_point_Index[i]=cell_Index*(n_q_points)+i;
		 	 		 for (unsigned int i=0; i<dofs_per_cell; ++i){
		 	 			 	 	 	 	 U_cell(i)=U(dofIndex[i]);
		 	 	 	 	 	 	// 	 	 printf("cell(%d): %d - %d \t U(%d) = %lf\n",cell_Index,i,dofIndex[i],i,U_cell(i));
		 	 	 	 }
		 	 		 //e_cell=e_element(fe_values,U_cell,n_q_points,dofs_per_cell,dofIndex);
		 	 		for (unsigned int i=0; i<n_q_points; ++i) {
                                        /*//bez transformacija
                                        e_matrix[0][q_point_Index[i]]=e_cell[0][i];
		 	 				 	 		e_matrix[1][q_point_Index[i]]=e_cell[1][i];
                                        e_matrix[2][q_point_Index[i]]=e_cell[2][i];*/
		 	 				 	 		
		 	 				 	 		
		 	 				 	 		//transformacija sa globalnog na lokalni
                                        //pocetak
                                        //kada je bio jedan file fibre direction
                                        //local_orient = set_local_orient(fe_values,U_cell,i,dofs_per_cell,(double *)n_q_point_Jacobian[q_point_Index[i]],m_element_orient[cell_Index]);
#ifdef Linearno
										e_cell=e_element_nulti(fe_values,U_cell,i,dofs_per_cell,dofIndex,(double *) nulti_shape[q_point_Index[i]]);
#endif		

#ifdef Nelinearno
										e_cell = set_eNL(fe_values,U_cell,i,dofs_per_cell,dofIndex,(double *) nulti_shape[q_point_Index[i]]);
#endif								
                                        //local_orient = set_local_orient(fe_values,U_cell,i,dofs_per_cell,(double *)n_q_point_Jacobian[q_point_Index[i]],m_qpoint_voxel_orient[q_point_Index[i]]);
										local_orient = set_local_orient(fe_values,U_cell,i,dofs_per_cell,(double *)n_q_point_Jacobian[q_point_Index[i]],m_qpoint_voxel_orient[q_point_Index[i]],stretch);
										
										local_orient[0] = m_qpoint_voxel_orient[q_point_Index[i]][0];
										local_orient[1] = m_qpoint_voxel_orient[q_point_Index[i]][1];
										local_orient[2] = 0.0; 

										//printf("%13.5E  %13.5E\n",stretch[0],stretch[1]);
										//getchar();

                                        t_e=t_e_qpoint(fe_values,U_cell,i,dofs_per_cell,dofIndex,local_orient);
                                        for (unsigned int z=0; z<3; ++z)
										{
											e_matrix_global[z][q_point_Index[i]] = e_cell[z][0];
											for (unsigned int j=0; j<3; ++j) 
											{
											   //e_matrix[z][q_point_Index[i]] += t_e[z][j] * e_cell[j][i];
											   e_matrix[z][q_point_Index[i]] += t_e[z][j] * e_cell[j][0];
											   tEglobal[z][3*q_point_Index[i] + j] = t_e[z][j];
                                            }
											e_matrix_local[z][q_point_Index[i]] = e_matrix[z][q_point_Index[i]];
										}
										

										//umesto e prosledjujem stretch, a deformaciju ne saljem
										for (unsigned int z=0; z<3; ++z)
										{
											e_matrix[z][q_point_Index[i]] = stretch[z];	
											//e_matrix_local[z][q_point_Index[i]] = stretch[z];											
											//printf("%lf \n",sigma_matrix[q_point_Index[i]][z]);
										}
										//getchar();

		 	 				// 	 	//printf("cell(%d): %d - %d \t U(%d) = %lf\n",cell_Index,i,q_point_Index[i]);
		 	 		}

		 	 		cell_Index++;
		 	 	 }

				 m_pImportModel.setActivation(ModelData, (g->step+1)*g->dt, (double *)e_matrix);
		 	 	 cell_Index=0;
				 
		 	 	 /*for (int ii=0;ii<n_q_points_all*3;ii++)
		 	 			 		 {
		 	 			 			 for (int jj=0;jj<3;jj++)
		 	 			 				 	 printf("tEglobal[%d][%d]=%lf\t",ii,jj,tEglobal[ii][jj]);
		 	 			 			 printf("\n");
		 	 			 		 }*/

                 /*fprintf(deformacije,"Iteracija: %d\n",POM);
                 for (int ii=0;ii<n_q_points_all;ii++)
                                 {
                                     for (int jj=0;jj<3;jj++)
                                             fprintf(deformacije,"e_matrix[%d][%d]=%lf\t",jj,ii,e_matrix[jj][ii]);
                                     fprintf(deformacije,"\n");
                                 }

                fflush(deformacije);*/


// ----------------- calculator.calculate()
for(int i=0;i<n_q_points_all;i++) // radFEM
{
	Vavg[i]=Vavg[i]+((e_matrix[0][i]-Eprev[i])*1074.0/g->dt);
    if((g->m_fi[i] > 0.0) && ((e_matrix[0][i]-Eprev[i])*1074.0/g->dt) > 3000.0)	
		fprintf(IO_test,"%d,%d,%d,%d,%e,%e\n",g->step,i/4+1,i,POM, ((e_matrix[0][i]-Eprev[i])*1074.0/g->dt),e_matrix[0][i]); 
				 
}
				// Bogdan - zakomentarisi
                 g->iter = POM;
				 if(!g->use_surro)
				 {
		 	        qpoint_calculator->calculate((double *)e_matrix,(double *)sigma_matrix,(double *)deltasigma_matrix);
					for(int i=0;i<n_q_points_all;i++) { // stampa za ucenje
						if(!(fabs(g->m_fi[i]) < 1.0E-6))
						{
							Ecarent[i]=e_matrix[0][i];
							Sigmacarent[i]=sigma_matrix[i][0];
							DeltaSigmacarent[i]=deltasigma_matrix[i][0][0];	
							Acarent[i]=g->m_f1[i]/Globals::f1;							
						}
					}
				 }
  
	// for(int i=0;i<n_q_points_all;i++) { // radFEM
		 // if(!(fabs(g->m_fi[i] - 0.0) < 1.0E-6))
		 // {
			// //if(g->step < 200)
			// {
				// Ecarent[i]=e_matrix[0][i];
				// Sigmacarent[i]=sigma_matrix[i][0];
				// DeltaSigmacarent[i]=deltasigma_matrix[i][0][0];
			// }
			// /*else
			// {
							
				// Ecarent[i]=e_matrix[0][i];
				// Sigmacarent[i]=0.00000369002723302698 * (g->m_f1[i]/Globals::f1) +0.11595567318153352 * Eprev[i] -0.1106864464117232  * Ecarent[i] + 1.0136142536629962 * Sigmaprev[i] -0.005207622009900895;
				// sigma_matrix[i][0]=Sigmacarent[i];
				
				// DeltaSigmacarent[i]  = 0.09420716424208424 * (g->m_f1[i]/Globals::f1) +9.52126884075408 * Eprev[i] -6.417369452381744 * Ecarent[i] + 9.484010746226764  * Sigmaprev[i] + 0.9859486118933191 * DeltaSigmaprev[i] -3.0698805827814493;
				// deltasigma_matrix[i][0][0]=DeltaSigmacarent[i]; 
					
			// }*/

		 // }
	// }

	// Bogdan 
   if(g->use_surro)
   {
		for(int i=0;i<n_q_points_all;i++) 
		{ 
			 if(fabs(g->m_fi[i]) > 1.0E-6)
			 {
				Ecarent[i]=e_matrix[0][i];
				Acarent[i]=g->m_f1[i]/Globals::f1;
			 }
		}
		calculate_surogat_all_qpoints(Acarent, Aprev, Ecarent, Eprev, Sigmaprev, DeltaSigmaprev, 
									Sigmacarent,  DeltaSigmacarent);
							
		for(int iqp=0;iqp<n_q_points_all;iqp++) 
		{ 
		 if(fabs(g->m_fi[iqp]) > 1.0E-6)
		 {  		
			for(int i=0;i<3;i++)
				for(int j=0;j<3;j++)
						deltasigma_matrix[iqp][i][j]=0.0;
			for (int j=0; j<3; j++)
					sigma_matrix[iqp][j]=0.0;  
		
			sigma_matrix[iqp][0]         = Sigmacarent[iqp];
			deltasigma_matrix[iqp][0][0] = DeltaSigmacarent[iqp];
		 }
		}							
   }							
	
/*  DEBUG
		 	 	 printf("FEM2D pokupio rezultate\n");
		 		 for (int ii=0;ii<4;ii++)
		 		 {
		 			 for (int jj=0;jj<3;jj++)
		 				 	 printf("sigma_matrix[%d][%d]=%lf\t",ii,jj,sigma_matrix[ii][jj]);
		 			 printf("\n");
		 		 }
		 		 for(int kk=0;kk<4;kk++)
		 		 for (int ii=0;ii<3;ii++)
		 		 {
		 			 for (int jj=0;jj<3;jj++)
		 				 	 printf("delstasigma_matrix[%d][%d][%d]=%lf\t",kk,ii,jj,deltasigma_matrix[kk][ii][jj]);
		 			 printf("\n");
		 		 }
*/
                 /*fprintf(napon,"Iteracija: %d\n",POM);
                 for (int ii=0;ii<n_q_points_all;ii++)
                                 {
                                     for (int jj=0;jj<3;jj++)
                                             fprintf(napon,"sigma_matrix[%d][%d]=%e\t",ii,jj,sigma_matrix[ii][jj]);
                                     fprintf(napon,"\n");
                                 }

                fflush(napon);*/

                /*fprintf(promena,"Iteracija: %d\n",POM);
                for(int kk=0;kk<n_q_points_all;kk++)
                for (int ii=0;ii<3;ii++)
                {
                    for (int jj=0;jj<3;jj++)
                            fprintf(promena,"delstasigma_matrix[%d][%d][%d]=%lf\t",kk,ii,jj,deltasigma_matrix[kk][ii][jj]);
                    fprintf(promena,"\n");
                }
               fflush(promena);*/



// ----------------- calculator.calculate()   END


			 	 for (int i = 0; i < n_q_points_all; ++i)
					for (int j = 0; j < 3; ++j)
						sigma_matrix_global[i][j]=0.0;
			 	 
			 	 cell = dof_handler.begin_active(),
				 endc = dof_handler.end();

		 	 	 int celija=0;
		 	 	 for (; cell!=endc; ++cell)
		 	 	 {
		 	 		 celija++;
		 	 		cell_matrix = 0; 	C_cell = 0;  F_cell=0;  cell_rhs(0)= 0;
		 	 		 fe_values.reinit (cell);
		 	 		 cell->get_dof_indices (dofIndex);

// DEBUG		 	 		 printf("------------------------------ postavljam  sistem --------------- 0\n");
	 	 		 	 for (unsigned int i=0;i<n_q_points;i++)
		 	 			 	 	 	 	 q_point_Index[i]=cell_Index*(n_q_points)+i;
		 	 		 for (unsigned int i=0; i<dofs_per_cell; ++i){
		 	 			 	 	 	 	 U_cell(i)=U(dofIndex[i]);
		 	 	 	 }
		 	 		 for(unsigned int q_point=0;q_point<n_q_points;q_point++) {
	
#ifdef Linearno	
											 B_matrix=set_B_matrix_L0(fe_values,U_cell,q_point,dofs_per_cell,dofIndex,(double *) nulti_shape[q_point_Index[q_point]]);											
		 	 			 	                 transform_local_to_global(fe_values,U_cell,q_point,dofs_per_cell,dofIndex, q_point_Index[q_point],
                                                               (double *) sigma_matrix_global[q_point_Index[q_point]], (double *) sigma_matrix[q_point_Index[q_point]],
                                                               (double *) deltasigma_matrix[q_point_Index[q_point]], C_matrix, C_matrix_global, (double *) tEglobal);
                                     
											 //Formiranje KL
											 tmp_cell_matrix=set_K_matrix(C_matrix_global,B_matrix,dofs_per_cell);


                                             for(unsigned int ii=0;ii<dofs_per_cell;ii++)
		 	 			 	 		 		 	for(unsigned int jj=0;jj<dofs_per_cell;jj++)
                                                        cell_matrix(ii,jj)+=tmp_cell_matrix(ii,jj)*n_q_point_JxW[q_point_Index[q_point]]*m_element_thickness[cell_Index];
		 	 			 	 		 	       			
		 	 			 	 			     for(unsigned int i=0;i<dofs_per_cell;i++)	 			 	 				  
                                                for(unsigned int j=0;j<3;j++)
                                                        F_cell[i] += B_matrix[j][i]*sigma_matrix_global[ q_point_Index[q_point]][j]*n_q_point_JxW[q_point_Index[q_point]]*m_element_thickness[cell_Index];
#endif
#ifdef Nelinearno
                                     B_matrix_L=set_B_matrix_L0(fe_values,U_cell,q_point,dofs_per_cell,dofIndex,(double *) nulti_shape[q_point_Index[q_point]]);
                                     /*printf("Matrica BL0, qpoint %d\n",q_point_Index[q_point]);
                                     for (unsigned int j=0; j<3; ++j)
                                     for (unsigned int i=0; i<dofs_per_cell; ++i)
                                                         printf("%e\n",B_matrix_L[j][i]);
                                     getchar();*/

                                     B_matrix_L.add(1,set_B_matrix_L1(fe_values,U_cell,q_point,dofs_per_cell,dofIndex,(double *) nulti_shape[q_point_Index[q_point]]));
                                     /*printf("Matrica BL, qpoint %d\n",q_point_Index[q_point]);
                                     for (unsigned int j=0; j<3; ++j)
                                     for (unsigned int i=0; i<dofs_per_cell; ++i)
                                                         printf("%lf\n",B_matrix_L[j][i]);
                                     getchar();*/


                                     //Formiranje matrice BNL
                                     B_matrix_NL=set_B_matrix_NL(fe_values,U_cell,q_point,dofs_per_cell,dofIndex,(double *) nulti_shape[q_point_Index[q_point]]);
                                     /*printf("Matrica BNL, qpoint %d\n",q_point_Index[q_point]);
                                     for (unsigned int j=0; j<4; ++j)
                                     for (unsigned int i=0; i<dofs_per_cell; ++i)
                                                         printf("%lf\n",B_matrix_NL[j][i]);
                                     getchar();*/
                                     //Transformacija sa lokalnog na globalni, pravimo C_matrix_global i sigma_matrix_global
									/* FILE *pom22;
									pom22 = fopen("c-matrica.txt","a+");
									fprintf(pom22,"%d %d\t",g->step,POM);
									fclose(pom22);*/
									//sigma_matrix[q_point_Index[q_point]][0] += (0.000440204 / g->dt);

									sigma_matrix[q_point_Index[q_point]][0] *= g->m_fi[q_point_Index[q_point]];
									if(g->m_fi[q_point_Index[q_point]] > 0.0)		
										sigma_matrix[q_point_Index[q_point]][0] += ((e_matrix_local[0][q_point_Index[q_point]] - e_matrix_local_prev[0][q_point_Index[q_point]])*(damped_faktor / g->dt));

									for (int i = 0; i < 3; ++i)
										for (int j = 0; j < 3; ++j)
										C_matrix[i][j] = 0.0;										
									if(g->m_fi[q_point_Index[q_point]] > 0.0)
										C_matrix[0][0] += (damped_faktor / g->dt);
									
									deltasigma_matrix[q_point_Index[q_point]][0][0] *= g->m_fi[q_point_Index[q_point]];
 
                                    transform_local_to_global(fe_values,U_cell,q_point,dofs_per_cell,dofIndex, q_point_Index[q_point],
                                                               (double *) sigma_matrix_global[q_point_Index[q_point]], (double *) sigma_matrix[q_point_Index[q_point]],
                                                               (double *) deltasigma_matrix[q_point_Index[q_point]], C_matrix, C_matrix_global, (double *) tEglobal);

									//ELASTIC matrix
									
									C_matrix[0][0]=1.0; 	C_matrix[0][1]=g->m_ni[q_point_Index[q_point]]; C_matrix[0][2]=0.0;
									C_matrix[1][0]=g->m_ni[q_point_Index[q_point]];		C_matrix[1][1]=1.0 / (1-g->m_fi[q_point_Index[q_point]]);	C_matrix[1][2]=0.0;
									C_matrix[2][0]=0.0; 	C_matrix[2][1]=0.0;		C_matrix[2][2]=(1-(1-g->m_fi[q_point_Index[q_point]]) * g->m_ni[q_point_Index[q_point]]*g->m_ni[q_point_Index[q_point]])  / (2.0 * (1 - g->m_fi[q_point_Index[q_point]]) * (1 + g->m_ni[q_point_Index[q_point]]));

									for (int i = 0; i < 3; ++i)
										for (int j = 0; j < 3; ++j)
										C_matrix[i][j]*= ((1-g->m_fi[q_point_Index[q_point]]) * g->m_E[q_point_Index[q_point]]/(1-(1-g->m_fi[q_point_Index[q_point]]) * g->m_ni[q_point_Index[q_point]]*g->m_ni[q_point_Index[q_point]]));
										

                                    transform_local_to_global_CE(fe_values,U_cell,q_point,dofs_per_cell,dofIndex, q_point_Index[q_point],
                                                               (double *) sigma_matrix_global[q_point_Index[q_point]], (double *) sigma_matrix[q_point_Index[q_point]],
                                                               (double *) deltasigma_matrix[q_point_Index[q_point]], C_matrix, CE_matrix_global, (double *) tEglobal);
										

									//Add fiber tangential matrix to elastic tangential matrix 
																				
									for (int i = 0; i < 3; ++i)
										for (int j = 0; j < 3; ++j)
										{
											//C_matrix_global[i][j] = g->m_fi[q_point_Index[q_point]] * C_matrix_global[i][j] + C_matrix[i][j];
											C_matrix_global[i][j] += CE_matrix_global[i][j];

										}
									 
								    //Stress of elastic part of muscle
								    for (int i = 0; i < 3; ++i) Sigma_vector[i]=0; 
									 
									for(int i=0;i<3;i++)
										for(int j=0;j<3;j++)
											//Sigma_vector[i]+=C_matrix[i][j]*e_matrix_global[j][q_point_Index[q_point]];
											Sigma_vector[i]+=CE_matrix_global[i][j]*e_matrix_global[j][q_point_Index[q_point]];
											
									

									//if(g->m_fi[q_point_Index[q_point]] > 0.0)		
										//Sigma_vector[0] += ((e_matrix_global[0][q_point_Index[q_point]] - e_matrix_global_prev[0][q_point_Index[q_point]])*(damped_faktor / g->dt));
									//Adding contraction stress
									for (int i = 0; i < 3; ++i)
									   sigma_matrix_global[q_point_Index[q_point]][i]  +=  Sigma_vector[i];
								    
                                     //Formaranje 2nd Piola-Kirchhoff stress
                                     set_sPK(fe_values,U_cell, q_point,dofs_per_cell, (double *)n_q_point_Jacobian[q_point_Index[q_point]], (double *) sigma_matrix_global[q_point_Index[q_point]],  (double *) sPK_matrix_vector[q_point_Index[q_point]] , sPK_matrix);
                                    //for(int j=0;j<3;j++)
									//printf("%13.5E\n", sigma_matrix_global[q_point_Index[q_point]][j]);
									//getchar();

                                     //Formiranje KL
                                     tmp_cell_matrix=set_K_matrix(C_matrix_global,B_matrix_L,dofs_per_cell);
									 /*for (unsigned int i=0; i<dofs_per_cell; ++i)
										for (unsigned int j=0; j<dofs_per_cell; ++j)
											printf("%lf\n",tmp_cell_matrix[i][j]);
			
									 getchar();
									 printf("SIGMA matrica\n");
									 for (unsigned int i=0; i<4; ++i)
										for (unsigned int j=0; j<4; ++j)
											printf("%lf\n",sPK_matrix[i][j]);
			
									 getchar();*/
                                     //Na to dodam KNL
                                     tmp_cell_matrix.add(1,set_K_matrix(sPK_matrix,B_matrix_NL,dofs_per_cell));

                                      for(unsigned int ii=0;ii<dofs_per_cell;ii++)
                                            for(unsigned int jj=0;jj<dofs_per_cell;jj++)
													cell_matrix(ii,jj)+=tmp_cell_matrix(ii,jj)*n_q_point_JxW[q_point_Index[q_point]]*m_element_thickness[cell_Index];
									

									 /*for (unsigned int i=0; i<dofs_per_cell; ++i)
												   for (unsigned int j=0; j<dofs_per_cell; ++j)
													printf("%lf\n",cell_matrix[i][j]);
													
											getchar();*/
									

                                      for(unsigned int i=0;i<dofs_per_cell;i++)
                                          for(unsigned int j=0;j<3;j++)													
													  F_cell[i] += B_matrix_L[j][i]*sPK_matrix_vector[ q_point_Index[q_point]][j]*n_q_point_JxW[q_point_Index[q_point]]*m_element_thickness[cell_Index];
											 
									 /*printf("sigmaPK\n");
									 for(unsigned int j=0;j<3;j++)
									 printf("%lf\n",sPK_matrix_vector[ q_point_Index[q_point]][j]);
                                     printf("F, qpoint %d, fe_values.JxW(q_point)=%lf\n",q_point_Index[q_point],fe_values.JxW(q_point));
                                     for(unsigned int i=0;i<dofs_per_cell;i++)
                                         printf("%lf\n",F_cell[i]);
                                     getchar();*/

                      /*for(unsigned int ii=0;ii<dofs_per_cell;ii++)
                            for(unsigned int jj=0;jj<dofs_per_cell;jj++)
                                    cell_matrix(ii,jj)+=tmp_cell_matrix(ii,jj)*fe_values.JxW(q_point)*m_element_thickness[cell_Index];

                      for(unsigned int i=0;i<dofs_per_cell;i++)
                          for(unsigned int j=0;j<3;j++)

                                    F_cell[i] += B_matrix[j][i]*sigma_matrix_global[ q_point_Index[q_point]][j]*fe_values.JxW(q_point)*m_element_thickness[cell_Index];*/

#endif

		 	 			 	 			  }
// end




				 	 		 for (unsigned int i=0; i<dofs_per_cell; ++i)
				 	 			 	 for (unsigned int j=0; j<dofs_per_cell; ++j)
				 	 			 		 system_matrix.add((unsigned int)dofIndex[i],
				 	 			 				 	 	 	 	 	 	 	 	 	 (unsigned int)dofIndex[j],
                                                                                     cell_matrix(i,j));


			 	 		        for (unsigned int i=0; i<dofs_per_cell; ++i)
					 	 			 	 	 F((unsigned int)dofIndex[i]) += F_cell(i);
			 	 		        cell_Index++;
		 	 	 }

#ifdef ElasticSupport1D
                             std::map<int,int> ::iterator it;

                             for(unsigned int i=0;i<elastic_support1D.size();i++)
                             {
                                  it =  mapDeal.mapNod.find(IDelastic_support1D[i]);
								  double skalar_u_n = 0.0;
								  double E = elastic_support1D[IDelastic_support1D[i]][0];

								  for (unsigned int j=0; j<2; ++j)
                                  {
						              double nj = elastic_support1D[IDelastic_support1D[i]][j+1];
									  double Uj = U(2*(*it).second + j);
									  
									  skalar_u_n += nj * Uj;
								  }
                                  for (unsigned int j=0; j<2; ++j)
                                  {
						              double nj = elastic_support1D[IDelastic_support1D[i]][j+1];
                                      F((*it).second * 2 +j) += E * skalar_u_n * nj;
                                  }
								  
								  for (unsigned int j=0; j<2; ++j)
                                  {
						              double nj = elastic_support1D[IDelastic_support1D[i]][j+1];
									  for (unsigned int k=0; k<2; ++k)
									  {
						              double nk = elastic_support1D[IDelastic_support1D[i]][k+1];
									  
                                      system_matrix.add((unsigned int)((*it).second * 2 +j),
                                                                                  (unsigned int)((*it).second * 2 +k),
																					E * nj * nk);
							          }

                                  }

                             }
				             // std::map<int,int> ::iterator it;

                             // for(unsigned int i=0;i<elastic_support1D.size();i++)
                             // {
                                  // it =  mapDeal.mapNod.find(IDelastic_support1D[i]);
								 
								 // system_matrix.set((unsigned int)2*(*it).second,(unsigned int)2*(*it).second,10000000);
								 // system_rhs((unsigned int)2*(*it).second)=10000000*0.0;
								 
								 // system_matrix.set((unsigned int)2*(*it).second + 1,(unsigned int)2*(*it).second + 1,10000000);
								 // system_rhs((unsigned int)2*(*it).second + 1)=10000000*0.0;


                             // }
#endif

		 	 	// system_rhs.print(std::cout,9,false);
#ifdef Muscle2D
				 //R[127] = -m_ForceFunction.GetValue((g->step+1)*g->dt);
#endif
               //  R[2] = m_ForceFunction.GetValue((g->step+1)*g->dt)/2.0;
               //  R[6] = m_ForceFunction.GetValue((g->step+1)*g->dt)/2.0;
#ifdef PressureSwallowing
					
					double	prev_normalF[2], rezF[2];
					prev_normalF[0] = 0.0;
					prev_normalF[1] = 0.0;
					
							
					for(int i=0; i<13; i++)
					{
							int id1 = nodePressure[i]-1;
							int id2 = nodePressure[i+1]-1;
							
							double x1 = cvorovi[id1][0] + U[2*id1];
							double y1 = cvorovi[id1][1] + U[2*id1+1];
							
							double x2 = cvorovi[id2][0] + U[2*id2];
							double y2 = cvorovi[id2][1] + U[2*id2+1];


							normalF[0] = -y2 + y1;
							normalF[1] = x2 - x1;
							double intez_normalF = sqrt(normalF[0]*normalF[0]+normalF[1]*normalF[1]);
							normalF[0] /=intez_normalF;
							normalF[1] /=intez_normalF;
							
							double  l = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
							pressureLine = 20.0 * m_PressureFunction.GetValue((g->step+1)*g->dt);
							nodeF = (pressureLine * l) / 2.0;

						    normalF[0] *=nodeF;
							normalF[1] *=nodeF;
							
							rezF[0] = prev_normalF[0] + normalF[0];
							rezF[1] = prev_normalF[1] + normalF[1];
							R[2*id1] = -rezF[0];
							R[2*id1 + 1] = -rezF[1];
							
							if (i==12)
							{
								R[2*id2] = -normalF[0];
								R[2*id2 + 1] = -normalF[1];
							}
							prev_normalF[0] = normalF[0];
                            prev_normalF[1] = normalF[1];
							
							fprintf(fnodePressure,"%lf,%lf,%lf,%lf,%lf,%lf\n",x1,y1,x2,y2,rezF[0],rezF[1]);
					}
					fflush(fnodePressure);

#endif

		 	 	 system_rhs=R;
		 	 	 system_rhs.add(-1,F);
				 /*
                         printf("F^%d\t\t\t\t rhs^%d \n",POM,POM);
                         //fprintf(rhs,"F^%d\t\t\t\t rhs^%d \n",POM,POM);

                         for(unsigned int i=0;i<n_dofs_all/2;i++)
                         {
                                 printf("(%d) : (%lf,%lf)\t (%d) : (%lf,%lf) \n",i,F(i*2),F(i*2+1),i,system_rhs(i*2),system_rhs(i*2+1));
                                 //fprintf(rhs,"(%d) : (%lf,%lf)\t (%d) : (%lf,%lf) \n",i,F(i*2),F(i*2+1),i,system_rhs(i*2),system_rhs(i*2+1));

                         }
				*/
				constraints.condense (system_matrix);
		        constraints.condense (system_rhs);
				
				
				/*system_matrix.set((unsigned int)1,(unsigned int)1,10000000);
                system_rhs((unsigned int)1)=10000000*0.0;
                system_matrix.set((unsigned int)3,(unsigned int)3,10000000);
                system_rhs((unsigned int)3)=10000000*0.0;
				system_matrix.set((unsigned int)9,(unsigned int)9,10000000);
                system_rhs((unsigned int)9)=10000000*0.0;
				system_matrix.set((unsigned int)13,(unsigned int)13,10000000);
                system_rhs((unsigned int)13)=10000000*0.0;*/

				/*if ((g->step+1)*g->dt < 0.5)
				{
				system_matrix.set((unsigned int)2,(unsigned int)2,10000000);
                system_rhs((unsigned int)2)=10000000*0.0;
                system_matrix.set((unsigned int)6,(unsigned int)6,10000000);
                system_rhs((unsigned int)6)=10000000*0.0;
                }
				else
				{
				system_matrix.set((unsigned int)2,(unsigned int)2,10000000);
                system_rhs((unsigned int)2)=10000000*0.001;
                system_matrix.set((unsigned int)6,(unsigned int)6,10000000);
                system_rhs((unsigned int)6)=10000000*0.001;

				}*/


						
                /*system_matrix.set((unsigned int)2,(unsigned int)2,10000000);
                system_rhs((unsigned int)2)=10000000*(POM?0:m_DisplacementFunction.GetValue((g->step+1)*g->dt)-U(2));
                system_matrix.set((unsigned int)6,(unsigned int)6,10000000);
                system_rhs((unsigned int)6)=10000000*(POM?0:m_DisplacementFunction.GetValue((g->step+1)*g->dt)-U(6));*/



                 MatrixTools::apply_boundary_values (boundary_values,
		                                     system_matrix,
		                                      solution,
		                                     system_rhs);



 	 	 	 	 solve();
				 constraints.distribute (solution);

 	 	 	 	 deltaU = solution;

 	 	 	 	 	 	 	// stampa(deltaU,"deltaU",POM+1);
 	 	 	 	 	 	 	// std::cout<<"------------------------------------------------------------"<<std::endl;
 	 	 	 	 U.add(solution);

                     /*fprintf(pomeranja,"Korak: %d\t Iteracija = %d   deltaU.l2_norm()=%lf\n",g->step+1,POM,deltaU.l2_norm());
                     printf("Korak: %d\t Iteracija = %d\n",g->step+1,POM);
 	 	 	 	 	 for(unsigned int i=0;i<n_dofs_all/2;i++)
                     {
                             printf("X(%d) : pomeranje (%lf,%lf)\n",i,U(i*2),U(i*2+1));
                             fprintf(pomeranja,"X(%d) : pomeranje (%lf,%lf)\n",i,U(i*2),U(i*2+1));

                     }
                     fflush(pomeranja);*/
 	 	 	 	// std::cout<<"\n";
 	 	 	 	 POM++;

 	 	 	 	 flags[0]=1; flags[1]=0;
                 if  (POM>30)  {
 	 	 	 		 	 	 printf("PRECERA\n");  
							 if(g->use_surro) surogat_set_end();
							 exit(0);
 	 	 	 	 }
 	 	 	 	// 	 printf("------------- kraj jedne iteracije");
					 
				//priprema za novi korak
				
				
         //pomeranje cvorova
				for(unsigned int i=0;i<n_dofs_all/2;i++)
					check_upadate[i] = 0;
					
                 cell = dof_handler.begin_active(),
	 			 endc = dof_handler.end();
	 	 	 	 for (; cell!=endc; ++cell)
	 	 	 	 {
	 	 	 		 fe_values.reinit (cell);
	 	 	 		 cell->get_dof_indices (dofIndex);
	 	 	 		 for(unsigned int i=0;i<4;i++)//<GeometryInfo<2>::vertices_per_cell;i++)
	 	 	 					 {
								         k=(unsigned int)dofIndex[2*i]/2;
										 if (check_upadate[k]==0)
										 {
											cell->vertex(i)[0] +=deltaU[dofIndex[2*i]];
											cell->vertex(i)[1] +=deltaU[dofIndex[2*i+1]];
											check_upadate[k]=1;
										 }
	 	 	 					 }

	 	 	 	 }	
				 
				/*FILE *pom;
				pom = fopen("huxley.txt","a");
				fprintf(pom," __________%d\n",POM);
				fclose(pom);*/ 
				
	for(int i=0;i<n_q_points_all;i++)  // radFEM Bogdan 
		 if(!(fabs(g->m_fi[i] - 0.0) < 1.0E-6))
		 {
			int groupID = ModelData.m_PropArray.GetById(ModelData.m_ElArray[i/4+1].m_uPropID).m_nID;
			fprintf(radFEMFI,"%d,%d,%d,%d,%d,%.10lf,%.10lf,%.10lf,%.10lf,%.10lf,%.10lf,%.10lf,%.10lf\n",g->step,POM,i/4+1, groupID, i%4, Aprev[i], Acarent[i],Eprev[i],Ecarent[i],
			Sigmaprev[i],Sigmacarent[i],DeltaSigmaprev[i],DeltaSigmacarent[i]);	
		 }			
		 }
// kraj while petlje i jedne iteracije0
		 flags[0]=1; flags[1]=1;

		/*FILE *f = fopen("sigma.csv","a");
		fprintf(f,"\nSIGMA =%2.6lf ",(g->step+1)*g->dt);	
		//fprintf(f,"%13.5E %13.5E %13.5E %13.5E",sigma_matrix[0][0], sigma_matrix_global[0][0], e_matrix[0][0], Sigma_vector[0]);
		fprintf(f,"%13.5E %13.5E ",(sigma_matrix[0][0]-((e_matrix_local[0][0] - e_matrix_local_prev[0][0])*(damped_faktor / g->dt)))/g->m_fi[0], sigma_matrix_global[0][0]);
		fclose(f);*/
		/*FILE *pom;
		pom = fopen("huxley.txt","a");
		fprintf(pom," %lf\n",(g->step+1)*g->dt);
		fclose(pom);*/
		 		
if (((g->step+1) % 10 ==0))
{
        //loadCaseUnv = g->step+1
		loadCaseUnv++;

		fprintf(fUnv,"    -1\n    55\n\n");
		fprintf(fUnv,"NODAL TRANSLATIONS AND ROTATIONS\nDATE AND TIME\nEMPTY\nLOAD CASE         :%10d\n",loadCaseUnv);
		fprintf(fUnv,"         1         4         3         8         2         6\n");
        fprintf(fUnv,"         2         1%10d%10d\n",loadCaseUnv,loadCaseUnv);
        fprintf(fUnv,"  %lf\n",(g->step+1)*g->dt);
		double Fukupno = 0.0;
        for(unsigned int i=0;i<n_dofs_all/2;i++){
		        U_prev(i*2) = U(i*2);
				U_prev(i*2+1) = U(i*2+1);
        		fprintf(fUnv,"%10d\n",i+1);
                fprintf(fUnv,"%13.5E%13.5E%13.5E%13.5E%13.5E%13.5E\n",U(i*2),U(i*2+1),0.0,0.0,0.0,0.0);
                //if (i+1==43) fprintf(fTop,"%lf%13.5E%13.5E\n",(g->step+1)*g->dt,U(i*2),U(i*2+1));
				//if ((i+1==64)||(i+1==43)||(i+1==3) ||(i+1==1) ) Fukupno +=F(i*2+1);
				//if (i+1==64) fprintf(fTop,"%10.2lf%13.5E%13.5E\n",(g->step+1)*g->dt,U(i*2),U(i*2+1)); //2DMuscle
				//if ((i+1==1)||(i+1==2)||(i+1==5)||(i+1==7)) Fukupno +=F(i*2+1);
				//if ((i+1==1)||(i+1==2)) Fukupno +=F(i*2+1);
				if ((i+1==2)||(i+1==4)) Fukupno +=F(i*2);
#ifdef WriteDisplacement
				//if((i+1==314)||(i+1==331)||(i+1==348) ||(i+1==365)||(i+1==363))
				if((i+1==198)||(i+1==215)||(i+1==232) ||(i+1==249)||(i+1==247))
				fprintf(fNodeDisplacement,"%lf,%d,%13.5E,%13.5E\n",(g->step+1)*g->dt,i+1,U(i*2),U(i*2+1));
#endif
        	}
		 //fprintf(fTop,"%10.2lf%13.5E\n",(g->step+1)*g->dt,Fukupno);
		 fprintf(fTop,"%10.5lf,%13.5E,%13.5E\n",(g->step+1)*g->dt,U(2),U(3));
		 //fprintf(fNodeDisplacement,"%10.2lf%13.5E%13.5E%13.5E%13.5E\n",(g->step+1)*g->dt,U(126),U(127),sigma_matrix_global[0][0], sigma_matrix_global[0][1]);
	 	 fprintf(fUnv,"    -1\n");
         fflush(fUnv);
         fflush(fTop);
         fflush(fNodeDisplacement);

// write stress in .unv file
         fprintf(fUnv,"    -1\n    57\n\n");
         fprintf(fUnv,"STRESS OF 2/D ELEMENTS\nDATE AND TIME\nEMPTY\nLOAD CASE         :%10d\n",loadCaseUnv);
         fprintf(fUnv,"         1         4         4         2         2         6\n");
         fprintf(fUnv,"         2         1%10d%10d\n",loadCaseUnv,loadCaseUnv);
         fprintf(fUnv,"  %lf\n",(g->step+1)*g->dt);

         cell_Index=0;
       cell = dof_handler.begin_active(),
         endc = dof_handler.end();

         for (; cell!=endc; ++cell)
         {
             fe_values.reinit (cell);
             cell->get_dof_indices (dofIndex);
             for (unsigned int i=0;i<n_q_points;i++)
                                 q_point_Index[i]=cell_Index*(n_q_points)+i;

             fprintf(fUnv,"%10d         1         4         6\n",cell_Index+1);
             for (unsigned int i=0; i<n_q_points; ++i) {
                      fprintf(fUnv,"%13.5E%13.5E%13.5E%13.5E%13.5E%13.5E\n",sigma_matrix_global[q_point_Index[i]][0],sigma_matrix_global[q_point_Index[i]][2],sigma_matrix_global[q_point_Index[i]][1],0.0,0.0,0.0);

            }

            cell_Index++;
         }




         fprintf(fUnv,"    -1\n");
         fflush(fUnv);

// write strain in .unv file
         fprintf(fUnv,"    -1\n    57\n\n");
         fprintf(fUnv,"STRAIN OF 2/D ELEMENTS\nDATE AND TIME\nEMPTY\nLOAD CASE         :%10d\n",loadCaseUnv);
         fprintf(fUnv,"         1         4         4         3         2         6\n");
         fprintf(fUnv,"         2         1%10d%10d\n",loadCaseUnv,loadCaseUnv);
         fprintf(fUnv,"  %lf\n",(g->step+1)*g->dt);

         cell_Index=0;
         cell = dof_handler.begin_active(),
         endc = dof_handler.end();

         for (; cell!=endc; ++cell)
         {
               fe_values.reinit (cell);
               cell->get_dof_indices (dofIndex);
               for (unsigned int i=0;i<n_q_points;i++)
                                          q_point_Index[i]=cell_Index*(n_q_points)+i;

               fprintf(fUnv,"%10d         1         4         6\n",cell_Index+1);
               for (unsigned int i=0; i<n_q_points; ++i) {

					  fprintf(fUnv,"%13.5E%13.5E%13.5E%13.5E%13.5E%13.5E\n",e_matrix_global[0][q_point_Index[i]],e_matrix_global[2][q_point_Index[i]],e_matrix_global[1][q_point_Index[i]],0.0,0.0,0.0);


               }

               cell_Index++;
          }



          fprintf(fUnv,"    -1\n");
          fflush(fUnv);
}
Globals* g=Globals::getInstance();
// if(g->step!=0)
	// {
	// for(int i=0;i<n_q_points_all;i++) { // radFEM
		 // if(!(fabs(g->m_fi[i] - 0.0) < 1.0E-6))
		 // {
			// //Vavg[i]=Vavg[i]+((e_matrix[0][i]-Eprev[i])*1074.0/g->dt);
			// Vavg[i]=Vavg[i]/POM;
			// fprintf(radFEM,"%d,%d,%d,%e,%e,%e,%e, %e\n",g->step,i/4+1,i%4,((e_matrix[0][i]-Eprev[i])*1074.0/g->dt),Vavg[i],Eprev[i],e_matrix[0][i],sigma_matrix_global[i][0]); // fekorak idElem idx_qpoint V Vavg
			// Eprev[i]=e_matrix[0][i];
			// Sigmaprev[i]=sigma_matrix_global[i][0];
		 // }
		 // if((i==622)&&(g->step > 180)&&(g->step<300))
		 // {
			// testParameters.m_f1 = g->m_f1[i];
			// double test_e[3];
			// test_e[0] = e_matrix[0][i];
			// test_e[1] = e_matrix[1][i];
			// test_e[2] = e_matrix[2][i];
			// testModel.Calculate(&testState, test_e, test_sigma, test_dsigmade);
			// testCalculator.Calculate(X,N,((e_matrix[0][i]-Eprev[i])*1074.0/g->dt),g->dt,&testForce);

			// FILE *fV;		
			// sprintf(imeFajla,"N_X_%d.csv",g->step);
			// fV = fopen(imeFajla,"w");
			// for(unsigned i=0;i<X.size();i++) fprintf(fV,"%lf,%lf\n",X(i), N(i));
			// fclose(fV);
			
			// fprintf(IO_test,"%d,%d,%d,%e,%e,%e,%e,%e\n",g->step,i/4+1,i,((e_matrix[0][i]-Eprev[i])*1074.0/g->dt), testForce, e_matrix[0][i],test_sigma[0],test_dsigmade[0]); // fekorak idElem idx_qpoint V Vavg

		 // }
	// }
// }
// else
// {
	// for(int i=0;i<n_q_points_all;i++) {
		// Eprev[i]=e_matrix[0][i];
		// Sigmaprev[i]=sigma_matrix_global[i][0];

		 // }
// }
	for(int i=0;i<n_q_points_all;i++) { // radFEM
		 if(!(fabs(g->m_fi[i]) < 1.0E-6))
		 {
			//Vavg[i]=Vavg[i]+((e_matrix[0][i]-Eprev[i])*1074.0/g->dt);
			Vavg[i]=Vavg[i]/POM;
			//fprintf(radFEM,"%d,%d,%d,%e,%e,%e,%e, %e\n",g->step,i/4+1,i%4,((e_matrix[0][i]-Eprev[i])*1074.0/g->dt),Vavg[i],Eprev[i],e_matrix[0][i],sigma_matrix_global[i][0]); // fekorak idElem idx_qpoint V Vavg
		//  Bogdan otkomentarisi radFem 
		//	fprintf(radFEM,"%d,%d,%d,%e,%e,%e,%e,%e,%e,%e\n",g->step,i/4+1,i%4,g->m_f1[i]/Globals::f1,Eprev[i],Ecarent[i],Sigmaprev[i],Sigmacarent[i],DeltaSigmaprev[i],DeltaSigmacarent[i]); // fekorak idElem idx_qpoint V Vavg
		    
		//	fprintf(radFEMFI,"%d,%d,%d,%d,%e,%e,%e,%e,%e,%e,%e\n",g->step,POM,i/4+1,i%4,g->m_f1[i]/Globals::f1,Eprev[i],Ecarent[i],Sigmaprev[i],Sigmacarent[i],DeltaSigmaprev[i],DeltaSigmacarent[i]);
		 // if((i==3653)&&(g->step > 180)&&(g->step<300))
		 // {
			// testParameters.m_f1 = g->m_f1[i];
			// double test_e[3];
			// testState.e_t[0] = Eprev[i];
			// testState.e_t[1] = 0.0;
		    // testState.e_t[2] = 0.0;

			// test_e[0] = e_matrix[0][i];
			// test_e[1] = e_matrix[1][i];
			// test_e[2] = e_matrix[2][i];
			// testModel.Calculate(&testState, test_e, test_sigma, test_dsigmade);
			// testCalculator.Calculate(X,N,((e_matrix[0][i]-Eprev[i])*1074.0/g->dt),g->dt,&testForce);
			
			// FILE *fV;		
			// sprintf(imeFajla,"N_X_%d.csv",g->step);
			// fV = fopen(imeFajla,"w");
			// for(unsigned i=0;i<X.size();i++) fprintf(fV,"%e,%e\n",X(i), N(i));
			// fclose(fV);
			
			// fprintf(IO_test,"%d,%d,%d,%e,%e,%e,%e,%e\n",g->step,i/4+1,i,((e_matrix[0][i]-Eprev[i])*1074.0/g->dt),testForce, e_matrix[0][i],test_sigma[0],test_dsigmade[0]); 

		 // }
		 
		    // Bogdan kraj koraka 
			int groupID = ModelData.m_PropArray.GetById(ModelData.m_ElArray[i/4+1].m_uPropID).m_nID;
			fprintf(fSurro,"%d,%d,%d,%d, %d, %.10lf, %.10lf,%.10lf,%.10lf,%.10lf,%.10lf,%.10lf,%.10lf\n",g->step,POM,i/4+1, groupID, i%4,Aprev[i], Acarent[i], Eprev[i],Ecarent[i],
			Sigmaprev[i],Sigmacarent[i],DeltaSigmaprev[i],DeltaSigmacarent[i]);			 

		 	Eprev[i]=Ecarent[i];
			Sigmaprev[i]=Sigmacarent[i];
			DeltaSigmaprev[i]=DeltaSigmacarent[i];
			Aprev[i]=Acarent[i];		
		 }
	}

fflush(IO_test);

//cuvanje trenutne deformacije
for(int i=0;i<n_q_points_all;i++)
	for(int j=0;j<3;j++)
	{
		e_matrix_global_prev[j][i] = e_matrix_global[j][i];
		e_matrix_local_prev[j][i] = e_matrix_local[j][i];
		}

//fflush(radFEM);
fflush(radFEMFI);
fflush(fSurro);

#ifdef ElasticSupport1D

        std::map<int,int> ::iterator it,itnext;

        for(unsigned int i=0;i<elastic_support1D.size();i++)
        {
             it =  mapDeal.mapNod.find(NodeElastic[i]);
			 double prevU[2];
			 prevU[0]=U(2*(*it).second)-deltaU[2*(*it).second];
			 prevU[1]=U(2*(*it).second+1)-deltaU[2*(*it).second+1];
			 
			 
			 double skalar_u_n = 0.0;
			 double E = elastic_support1D[NodeElastic[i]][0];

			 for (unsigned int j=0; j<2; ++j)
             {
				double nj = elastic_support1D[NodeElastic[i]][j+1];								  
				skalar_u_n += nj * prevU[j];
			 }

			 double nx = elastic_support1D[NodeElastic[i]][1];
			 double ny = elastic_support1D[NodeElastic[i]][2];
			 
             double Fx = E * skalar_u_n * nx;
             double Fy = E * skalar_u_n * ny;

             fprintf(fNodeForce,"%10d,%10d,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E,%13.5E\n",g->step,(*it).second,cvorovi[(*it).second][0],cvorovi[(*it).second][1], E, nx , ny , prevU[0], prevU[1], Fx, Fy, F(2*(*it).second),F(2*(*it).second+1), sqrt(Fx*Fx+Fy*Fy));

             if(i<elastic_support1D.size()-1)
             {
                 itnext =  mapDeal.mapNod.find(NodeElastic[i+1]);
                 double l = sqrt((cvorovi[(*it).second][0] - cvorovi[(*itnext).second][0])*(cvorovi[(*it).second][0] - cvorovi[(*itnext).second][0])+(cvorovi[(*it).second][1] - cvorovi[(*itnext).second][1])*(cvorovi[(*it).second][1] - cvorovi[(*itnext).second][1]));
				 double prevNextU[2];
			     prevNextU[0]=U(2*(*itnext).second)-deltaU[2*(*itnext).second];
			     prevNextU[1]=U(2*(*itnext).second+1)-deltaU[2*(*itnext).second+1];
				 
				 double skalar_next_u_n = 0.0;
			     double E = elastic_support1D[NodeElastic[i+1]][0];

			     for (unsigned int j=0; j<2; ++j)
                 {
				  double nj = elastic_support1D[NodeElastic[i+1]][j+1];								  
				  skalar_next_u_n += nj * prevNextU[j];
			     }

			     double nx_next = elastic_support1D[NodeElastic[i+1]][1];
			     double ny_next = elastic_support1D[NodeElastic[i+1]][2];


                 double FxNext = E * skalar_next_u_n * nx_next;
                 double FyNext = E * skalar_next_u_n * ny_next;

                 fprintf(fPressure,"%10d,%10d,%13.5E\n",g->step,i, (sqrt(Fx*Fx+Fy*Fy)+sqrt(FxNext*FxNext+FyNext*FyNext))/(2.0*l*20.0));


             }

        }
        fflush(fNodeForce);
        fflush(fPressure);



#endif



/*//priprema za novi korak
         //pomeranje cvorova
				for(unsigned int i=0;i<n_dofs_all/2;i++)
					check_upadate[i] = 0;
					
                 cell = dof_handler.begin_active(),
	 			 endc = dof_handler.end();
	 	 	 	 for (; cell!=endc; ++cell)
	 	 	 	 {
	 	 	 		 fe_values.reinit (cell);
	 	 	 		 cell->get_dof_indices (dofIndex);
	 	 	 		 for(unsigned int i=0;i<4;i++)//<GeometryInfo<2>::vertices_per_cell;i++)
	 	 	 					 {
								         k=(unsigned int)dofIndex[2*i]/2;
										 if (check_upadate[k]==0)
										 {
											cell->vertex(i)[0] +=(U(dofIndex[2*i]) - U_prev(dofIndex[2*i]));
											cell->vertex(i)[1] +=(U(dofIndex[2*i+1]) - U_prev(dofIndex[2*i+1]));
											check_upadate[k]=1;
										 }
	 	 	 					 }

	 	 	 	 }*/

	 }
// kraj simulacionog koraka

      fclose(fUnv);
      fclose(fTop);
      //fclose(radFEM); // radFEM
	  fclose(radFEMFI); 
	  fclose(fSurro);
      fclose(fNodeForce);
      fclose(fPressure);
	  fclose(fNodeDisplacement);
	  fclose(Upis);
	  fclose(IO_test);

	  free(Vavg);
	  free(Eprev);
	  free(Sigmaprev);
	  free(Aprev);
	  free(Acarent);
	  free(Ecarent);
	  free(Sigmacarent);
	  free(DeltaSigmacarent);
	  free(DeltaSigmaprev);
	  if(g->use_surro) surogat_set_end();

#ifdef PressureSwallowing
	  fclose(fnodePressure);
#endif



      /*fclose(pomeranja);
      fclose(deformacije);
      fclose(napon);
      fclose(promena);
      fclose(rhs);*/

	  F_prescribed.clear();
	  U_prescribed.clear();

// ----------------- calculator.saveAndcontinue()
	 flags[0]=0; flags[1]=0;
	 printf("FEM2D poziva saveAndContinue\n");
	 qpoint_calculator->saveAndcontinue(flags);
	 printf("Obradjen zahtev saveAndContinue\n");
// ----------------- calculator.saveAndcontinue()    END
}

void FEM2D::stampa(const Vector<double> vektor, const char* naziv, const int POM)
{
	std::cout << "\t" << naziv << "^" << POM << " : ";
	vektor.print(std::cout,9,false);
}
