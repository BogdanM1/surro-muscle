/*!
 * \file EffectiveTranslation.h
 * Interface for the CEffectiveTranslation class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// EffectiveTranslation.h: interface for the CEffectiveTranslation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EFFECTIVETRANSLATION_H__5F690E4E_A805_49D5_9F79_B3585A172228__INCLUDED_)
#define AFX_EFFECTIVETRANSLATION_H__5F690E4E_A805_49D5_9F79_B3585A172228__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Stdafx.h"

#include "EffectiveValueCalculator.h"

class CEffectiveTranslation2D : public CEffectiveValueCalculator  
{
public:
	CEffectiveTranslation2D() {};
	virtual ~CEffectiveTranslation2D() {};

	/*!
	 * Calculates translation effective value.
	 * 
	 * \param[in] dCompValues
	 * 3-element array of component values.
	 * 
	 * \returns
	 * Translation effective value.
	 */
	inline double Calculate(double dCompValues[]) const
	{
		return	( sqrt(
						dCompValues[0]*dCompValues[0]+
						dCompValues[1]*dCompValues[1] )
				);
	}

};

class CEffectiveTranslation3D : public CEffectiveValueCalculator  
{
public:
	CEffectiveTranslation3D() {};
	virtual ~CEffectiveTranslation3D() {};

	/*!
	 * Calculates translation effective value.
	 * 
	 * \param[in] dCompValues
	 * 3-element array of component values.
	 * 
	 * \returns
	 * Translation effective value.
	 */
	inline double Calculate(double dCompValues[]) const
	{
		return	( sqrt(
						dCompValues[0]*dCompValues[0]+
						dCompValues[1]*dCompValues[1]+
						dCompValues[2]*dCompValues[2]
					)
				);
	}

};

#endif // !defined(AFX_EFFECTIVETRANSLATION_H__5F690E4E_A805_49D5_9F79_B3585A172228__INCLUDED_)
