/*!
 * \file TimeSteps.cpp
 * Implementation of the CTimeSteps class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// TimeStep.cpp: implementation of the CTimeStep class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "TimeSteps.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

/*!
 * Default constructor.
 */
CTimeSteps::CTimeSteps()
{

}

/*!
 * Destructor.
  */
CTimeSteps::~CTimeSteps()
{

}

/*!
 * Equalizes two objects of the CTimeSteps class.
 * 
 * \param[in] other
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
CTimeSteps& CTimeSteps::operator=(const CTimeSteps& other)
{
	m_TimePeriods.RemoveAll();

	m_TimePeriods.Copy(other.m_TimePeriods);

	return(*this);
}

///*!
// * Serializes object of the COutSet class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void CTimeSteps::Serialize(CArchive& ar)
//{
//	CObject::Serialize(ar);
//
//	if (ar.IsStoring())
//	{
//		// TODO: add storing code here
//	}
//	else
//	{
//		// TODO: add loading code here
//	}
//
//	m_TimePeriods.Serialize(ar);
//}
//
