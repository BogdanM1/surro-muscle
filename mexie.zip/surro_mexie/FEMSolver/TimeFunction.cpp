#include "TimeFunction.h"


TimeFunction::TimeFunction(void)
{
}


TimeFunction::~TimeFunction(void)
{
}

void TimeFunction::LoadValues(string fileName)
{
			ifstream inputMultilinear (fileName.c_str ());
						
			double time, value;
			string s;

			while (getline (inputMultilinear, s))
			{
				std::istringstream multistr (s);
				multistr >> time >> value;
				pair<double,double> p(time,value);
				m_function.push_back(p);
			}
}
void TimeFunction::SetValue(double* x, double *y, int n)
{
    for(int i=0; i<n; i++)
    {
        pair<double,double> p(x[i],y[i]);
        m_function.push_back(p);
    }
}

double TimeFunction::GetValue(double t)
{
	double y;
	int left, right;

	if(t < m_function[0].first)
	{
		left = 0;
		right = 1;
	}
	else if(t > m_function[m_function.size()-1].first)
	{
		left = m_function.size() - 2;
		right = m_function.size() - 1;
	}
	else
	{
		int half = m_function.size() * 0.5;

		if(t > m_function[half].first)
		{
			left = half;
			right = m_function.size()-1;
		}
		else
		{
			left = 0;
			right = half;
		}

		while(right-left != 1)
		{
			half = (right + left)*0.5;
			if(t > m_function[half].first)
				left = half;
			else
				right = half;
		}
	}

	y = m_function[left].second + (m_function[right].second - m_function[left].second)*(t - m_function[left].first)/(m_function[right].first - m_function[left].first);

	return y;
}
