/*
 * MaterialModel.h
 *
 *  Created on: Aug 7, 2013
 *      Author: anakaplarevic
 */

#ifndef MATERIALMODEL_H_
#define MATERIALMODEL_H_

#include "MaterialModelState.h"
#include "MaterialModelParameters.h"
//#include "Globals.h"

class MaterialModel {
public:

    MaterialModel();
	MaterialModel(MaterialModelParameters* p);
	virtual ~MaterialModel();

	virtual void Calculate(MaterialModelState *state, // stanje modela
							    double* e, // deformacija na kraju vremenskog koraka - e^(t+dt)
							    double* sigma, // naponi
							    double* dsigmade  // izvod napona po defomaciji
	)=0;

	virtual void CalculateStress(_TIP *force, // sila u materijalnoj tacki
								_TIP* forceP, // pertubovana sila
		    					double* e, // deformacija na kraju vremenskog koraka - e^(t+dt)
								double* sigma, // naponi
							    double* dsigmade  // izvod napona po defomaciji
	)=0;

	virtual MaterialModelParameters* getParameters()=0;
    	virtual void getCountOfIterations(int& countV,int& countVPert);
	virtual _TIP getCurrForce(MaterialModelState *s);
	virtual void getV(_TIP* V, _TIP* VP);
};

#endif /* MATERIALMODEL_H_ */
