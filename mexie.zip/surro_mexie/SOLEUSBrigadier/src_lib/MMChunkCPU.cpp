/*
 * MMChunkCPU.cpp
 *
 *  Created on: May 13, 2014
 *      Author: anakaplarevic
 */

#include "MMChunkCPU.h"
#include <math.h>

MMChunkCPU::MMChunkCPU() {
}

MMChunkCPU::~MMChunkCPU() {
}

void MMChunkCPU::init(int num_points,MMType *types,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1){
#ifdef LOGON
    fprintf(velikiLogChunk,"MPIChunkCPU::init ... start\n");
    fflush(velikiLogChunk);
#endif
    sizeOfChunk = num_points;
	this->types = types;
	korak=1;
	iter=0;
    	fillArrays(num_points,types,m_E,m_ni,m_fi,m_f1);
        countV = (int*)calloc(num_points,sizeof(int));
        countVP = (int*)calloc(num_points,sizeof(int));
	Vend = (double*)malloc(num_points*sizeof(double));
	Eend = (double*)malloc(num_points*sizeof(double));
	for(int i=0;i<30;i++) countVniz[i]=(int*)calloc(num_points,sizeof(int));
	if(fLog) printf("MMChnukCalculator ima fajl\n");
		else printf("MMChnukCalculator NO FAJL\n"); 
#ifdef LOGON
    fprintf(velikiLogChunk,"MPIChunkCPU::init ... end\n");
    fflush(velikiLogChunk);
#endif
}

void MMChunkCPU::calculateChunk(double *e,double* sigma,double* dsigmade){
#ifdef LOGON
    fprintf(velikiLogChunk,"MPIChunkCPU::calculateChunk ... start\n");
    fflush(velikiLogChunk);
#endif
//	int dim = Globals::getInstance()->dimOfSigmaVector;
    int dim = Globals::dimOfSigmaVector;
    int tmpCount=0,tmpV=0,tmpVP=0;
//	HuxleyParameters* hp;
//	double fi,f1;
//    _TIP forceStart=111111;
      _TIP V,VP;
    iter++;
#ifdef LOGON
    fprintf(velikiLogChunk,"... racun \n");
    fprintf(velikiLogChunk,"tacka\tf\te\tsigma\tdeltasigma\n");
    fflush(velikiLogChunk);
#endif
    for(int i=0;i<sizeOfChunk;i++)
    {
//	    if (fLog) forceStart=model[i]->getCurrForce(state_curr[i]);
            model[i]->Calculate(state_curr[i],&e[i*dim],&sigma[i*dim],&dsigmade[i*dim*dim]);
            model[i]->getCountOfIterations(tmpV,tmpVP);
#ifdef LOGON
    if (i<10) {
    fprintf(velikiLogChunk,"%d\t%f\t%f\t%f\t%f\n",moj_start+i,model[i]->getCurrForce(state_curr[i]),*(e+i*dim),*(sigma+i*dim),*(dsigmade+i*dim*dim));
    fflush(velikiLogChunk);
    }
#endif
	    model[i]->getV(&V,&VP);
	    countVniz[iter-1][i]=tmpV;
	    if (fLog) 
		{
//			hp=(HuxleyParameters*)model[i]->getParameters();
			Vend[i]=V;
			Eend[i]=e[i*dim];
//			fi=hp->_fi;
//			f1=hp->m_f1;
		//	fprintf(fLog,"%f\t%f\t%lf\t%lf\t%d\n",V,forceStart,fi,f1,tmpV); // forceOld Vbrzina
            	//	fprintf(fLog,"%f\t%f\t%lf\t%lf\t%d\n",VP,forceStart,fi,f1,tmpVP); // forceOld Vbrzina
		}
	    countV[i]+=tmpV;
	    countVP[i]+=tmpVP;
            tmpCount+=tmpV;
            tmpCount+=tmpVP;
// 	    fprintf(fLog," --- %ld\t%ld\n",countV[i],countVP[i]); 
    }
    printf("\nMMChunkCPU::calculateChunk - countV:%d \t countVP:%d \t total:%d\n\n",tmpV,tmpVP,tmpCount);
    allIterationCount+=tmpCount;
//    fprintf(fLog,"%ld\t%ld\n",countV[i],countVP[i]); // forceOld Vbrzina



#ifdef LOGON
    fprintf(velikiLogChunk,"MPIChunkCPU::calculateChunk ... end\n");
    fflush(velikiLogChunk);
#endif
}

void MMChunkCPU::setToNew(int flag){
#ifdef LOGON
    fprintf(velikiLogChunk,"MPIChunkCPU::setToNew ... start\n");
    fflush(velikiLogChunk);
#endif

    // TEST 7.7.2016
  /*  double V = (((HuxleyState2D*)state_curr[0])->e_t[0]-((HuxleyState2D*)state_t[0])->e_t[0])*(1074.0)/0.001;
	if(flag==1)
	{
		FILE *f = fopen("Brzina.csv","a");
		fprintf(f,"%d,%lf\n",Globals::getInstance()->step, V);
		fclose(f);	
    }*/

//         double sumErr=0;
 	 if (flag ==1) {
          for(int i=0;i<sizeOfChunk;i++) state_t[i]->init(state_curr[i]);
	  if (fLog) { 
	      for(int j=0;j<iter;j++) 
		for(int i=0;i<sizeOfChunk;i++) 
		   // mpiID korak iteracija q_point_ID, brojHuxleyIteracija
    //	   fprintf(fLog,"%d %d %d %d %d\n",moj_MPI,korak,j,moj_start+i,countVniz[j][i]);
	      for(int i=0;i<sizeOfChunk;i++) countV[i]=0;
	      korak++;
	      for(int i=0;i<iter;i++)
	      for(int j=0;j<sizeOfChunk;j++) countVniz[i][j]=0;
	      iter=0;
	   }
	 }	
 	 else 
          for(int i=0;i<sizeOfChunk;i++) state_curr[i]->init(state_t[i]);
		  
    // TEST 6.7.2016
	/*if ((flag ==1)&&((Globals::getInstance()->step == 4)||(Globals::getInstance()->step == 19)||(Globals::getInstance()->step == 79)||(Globals::getInstance()->step == 699))) {
		 FILE *fV;	
		 char imeFajla[40];		 
		 sprintf(imeFajla,"N_X_%d.csv",Globals::getInstance()->step);
		 fV = fopen(imeFajla,"w");
	     HuxleyState2D* s = (HuxleyState2D*) state_curr[0];
	     unsigned int no = (unsigned int)s->N.size();
	     for(unsigned int i=0;i<no;i++) 
		     fprintf(fV,"%lf,%lf\n", s->X(i), s->N(i));
		 fclose(fV);	
		 
	}*/
#ifdef LOGON
    fprintf(velikiLogChunk,"MPIChunkCPU::setToNew ... end\n");
    fflush(velikiLogChunk);
#endif
}
