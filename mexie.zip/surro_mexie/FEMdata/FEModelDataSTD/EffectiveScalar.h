/*!
 * \file EffectiveScalar.h
 * Interface for the CEffectiveScalar class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// EffectiveScalar.h: interface for the CEffectiveScalar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EFFECTIVEScalar_H__5F690E4E_A805_49D5_9F79_B3585A172228__INCLUDED_)
#define AFX_EFFECTIVEScalar_H__5F690E4E_A805_49D5_9F79_B3585A172228__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Stdafx.h"

#include "EffectiveValueCalculator.h"

class CEffectiveScalar : public CEffectiveValueCalculator  
{
public:
	CEffectiveScalar() {};
	virtual ~CEffectiveScalar() {};

	/*!
	 * Set effective value to be equal to first component.
	 * 
	 * \param[in] dCompValues
	 * 3-element array of component values.
	 * 
	 * \returns
	 * Scalar effective value.
	 */
	inline double Calculate(double dCompValues[]) const
	{
		return	( dCompValues[0] );
	}

};


#endif // !defined(AFX_EFFECTIVEScalar_H__5F690E4E_A805_49D5_9F79_B3585A172228__INCLUDED_)
