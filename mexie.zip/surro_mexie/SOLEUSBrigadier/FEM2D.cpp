/*
 * FEM.cpp
 *
 *  Created on: May 2, 2014
 *      Author: anakaplarevic
 */

//#include "FEM.cpp"
#include "FEM2D.h"
#include "QPointCalculator.h"


using  namespace dealii;
using namespace libconfig;

FEM2D::FEM2D()
:
fe (FE_Q<2>(1), 2),
dof_handler (triangulation),
quadrature_formula(2),
fe_values(fe, quadrature_formula, update_values | update_gradients | update_JxW_values)
{
    g = Globals::getInstance();
}

FEM2D::~FEM2D() {
    dof_handler.clear ();
}

void FEM2D::run(QPointCalculator* q)
{
	qpoint_calculator = q;
	g->step=0;

    config_t cfg; //  config_setting_t *setting;
	double pom;
//	int ipom;
printf("FEM2D: pre config_init()\n");
	config_init(&cfg);

	if(!config_read_file(&cfg, CFGFAJL))
	{
	//	  fprintf(stderr, "%s:%d - %s\n", config_error_file(&cfg),  config_error_line(&cfg), config_error_text(&cfg));
           printf("FEM2D :: Neuspesno otvaranje FEM_MM.cfg fajla\n");
            config_destroy(&cfg);
	     exit(0);//return(EXIT_FAILURE);
	 }
	if(config_lookup_float(&cfg, "FEM.T", &pom)) T= pom;	 else fprintf(stderr, "Nema 'FEM.T' u konfiguracionom fajlu\n");
//	if(config_lookup_float(&cfg, "FEM.dt", &pom)) g->dt=pom;  else fprintf(stderr, "No 'FEM.dt' setting in configuration file.\n");
//	if(config_lookup_int(&cfg, "FEM.dimSigmaVector", &ipom)) g->dimOfSigmaVector=ipom;  else fprintf(stderr, "No 'FEM.dimSigmaVector' setting in configuration file.\n");
	config_destroy(&cfg);
printf("FEM2D: kraj\n");
	make_grid ();
	setup_system();
	init();
	simulate();
}

void FEM2D::make_grid ()
{
 //  GridGenerator::subdivided_hyper_cube (triangulation, 2,0, 1);
	unsigned int nx=1,ny=1;
	std::vector< unsigned int >   	repetitions(2);

    	long ipom;   config_t cfg;//  config_setting_t *setting;
	config_init(&cfg);

	if(!config_read_file(&cfg, CFGFAJL))
	{
	//	  fprintf(stderr, "%s:%d - %s\n", config_error_file(&cfg),  config_error_line(&cfg), config_error_text(&cfg));
          printf("FEM2D :: Neuspesno otvaranje FEM_MM.cfg fajla\n");
		  config_destroy(&cfg);
	     exit(0);//return(EXIT_FAILURE);
	 }
	if(config_lookup_int(&cfg, "FEM.nx", &ipom)) nx= (int)ipom;	 else fprintf(stderr, "Nema 'FEM.nx' u konfiguracionom fajlu\n");
	if(config_lookup_int(&cfg, "FEM.ny", &ipom)) ny=(int)ipom;  else fprintf(stderr, "No 'FEM.ny' setting in configuration file.\n");

	config_destroy(&cfg);


	repetitions[0]=nx;
	repetitions[1]=ny;//	repetitions[1]=2;
	GridGenerator::subdivided_hyper_rectangle (triangulation, repetitions,Point<2>(0,0), Point<2>(10,1));
	num_cells_x = nx;
	num_cells_y=ny;

	std::ofstream out("grid-1.eps");
	GridOut grid_out;
	grid_out.write_eps (triangulation, out);

	std::cout << "Number of active cells: "
            << triangulation.n_active_cells()
            << std::endl;

   std::cout << "Total number of cells: "
            << triangulation.n_cells()
            << std::endl;
}

void FEM2D::setup_system ()
{

  dof_handler.distribute_dofs (fe);
  std::cout << "Number of degrees of freedom: "
            << dof_handler.n_dofs()
            << std::endl;
  dof_handler.distribute_dofs (fe);

  sparsity_pattern.reinit (dof_handler.n_dofs(),
                             dof_handler.n_dofs(),
                             dof_handler.max_couplings_between_dofs());
  DoFTools::make_sparsity_pattern (dof_handler, sparsity_pattern);

  sparsity_pattern.compress();

  system_matrix.reinit (sparsity_pattern);
  solution.reinit (dof_handler.n_dofs());
  system_rhs.reinit (dof_handler.n_dofs());
}

void FEM2D::init()
{
    dofs_per_cell = fe.dofs_per_cell;
    n_q_points    = quadrature_formula.size();
    n_dofs_all 	= dof_handler.n_dofs();
    n_q_points_all = n_q_points*triangulation.n_active_cells();

	fUnv=fopen("muscles2D.unv","w");
	DoFHandler<2>::active_quad_iterator    cell = dof_handler.begin_active(),   endc = dof_handler.end();

	cvorovi.reserve(n_dofs_all/2);
	std::vector<unsigned int> dofIndex (dofs_per_cell);
	int ic=0;
	unsigned int k;
	for (; cell!=endc; ++cell)
		 {
			 fe_values.reinit (cell);
			 cell->get_dof_indices (dofIndex);
		//	 printf("doIndex.length = %d ",dofIndex.size());
			 for(unsigned int i=0;i<4;i++)//<GeometryInfo<2>::vertices_per_cell;i++)
			 {			k=(unsigned int)dofIndex[2*i]/2;
			 	 	 	cvorovi[k][0]=cell->vertex(i)[0];
			 	 	 	cvorovi[k][1]=cell->vertex(i)[1];
			 }
			 ic++;
	 }
	fprintf(fUnv,"    -1\n    15\n");
    for(unsigned int i =0;i<n_dofs_all/2;i++) {
        printf("%d: %f, %f\n",i,cvorovi[i][0],cvorovi[i][1]);
        fprintf(fUnv,"%10d         0         0         8  %f  %f  0\n",i+1,cvorovi[i][0],cvorovi[i][1]);
	}
	fprintf(fUnv,"    -1\n");

	fprintf(fUnv,"    -1\n    71\n");
	cell = dof_handler.begin_active();   endc = dof_handler.end();
	ic=0;
	for (; cell!=endc; ++cell)
			 {
				 fe_values.reinit (cell);
				 cell->get_dof_indices (dofIndex);
				 fprintf(fUnv,"%10d        27        44         1         1         7         4\n",ic+1);
		//		 for(unsigned int i=0;i<4;i++)//<GeometryInfo<2>::vertices_per_cell;i++)
					 fprintf(fUnv,"%10d",1+dofIndex[0]/2);
					 fprintf(fUnv,"%10d",1+dofIndex[2]/2);
					 fprintf(fUnv,"%10d",1+dofIndex[6]/2);
					 fprintf(fUnv,"%10d",1+dofIndex[4]/2);
				 fprintf(fUnv,"\n");
				 ic++;
		 }

	fprintf(fUnv,"    -1\n");

		fOut.open("OUT.csv");
		fOut<< "\t" << "t" <<"\t"<<"U"<<"\t"<< "F"<<"\n";
	    R.reinit(n_dofs_all);
	    F.reinit(n_dofs_all);
	    U.reinit(n_dofs_all);
	   	U = 0;

	   	boundary_values[0]=0;
	   	boundary_values[1]=0;
		boundary_values[4]=0;
	   	for(unsigned int i=(num_cells_x+1)*2;i<=((num_cells_y)*(num_cells_x+1));i+=(num_cells_x+1))
	   		{ printf("x(%d)=0\n",i*2);		boundary_values[i*2]=0;}

         MMType* tipovi;
         tipovi=(MMType*)malloc(n_q_points_all);
         for(unsigned int i=0;i<n_q_points_all;i++) tipovi[i]=Huxley2D;//(i<(num_cells_x*4))?0:1; //tipovi[i]=1;

         Globals* g=Globals::getInstance();


// ----------------- calculator.init()
// ANAF1TIP
     qpoint_calculator->init(n_q_points_all,&tipovi[0],g->m_E,g->m_ni,g->m_fi,g->m_f1);
// ----------------- calculator.init()  END
	 printf("------- Inicijalizacija QPointCalulator-a ----- END\n");
}


void FEM2D::solve ()
{
	  SparseDirectUMFPACK A_direct;
	  A_direct.initialize(system_matrix);
	  A_direct.vmult (solution, system_rhs);
}

FullMatrix<double> FEM2D::e_element(const FEValues<2> & fe_values,const Vector<double> U, const unsigned int n_q_points,const unsigned int dofs_per_cell,
		std::vector<unsigned int> dofIndex )
		{
		FullMatrix<double> deformacija;
		deformacija.reinit(3,n_q_points);
		deformacija = 0;
	  	for(unsigned int q_point=0;q_point<n_q_points;q_point++) {
	  	  	  for (unsigned int i=0; i<dofs_per_cell; ++i) {
           		unsigned int  comp = fe.system_to_component_index(i).first;
	  			deformacija[0][q_point] +=((comp==0)*fe_values.shape_grad(i,q_point)[0])*U(i) ;
	  			deformacija[1][q_point] +=((comp==1)*fe_values.shape_grad(i,q_point)[1])*U(i) ;
	  			deformacija[2][q_point] +=((comp==0)*fe_values.shape_grad(i,q_point)[1] +(comp==1)*fe_values.shape_grad(i,q_point)[0])*U(i) ;
	  	  }
	  	}
	  	return deformacija;
		}

void FEM2D::simulate()
{
	  FullMatrix<double>   cell_matrix (dofs_per_cell, dofs_per_cell);
	  Vector<double>       cell_rhs (dofs_per_cell);

	  std::vector<unsigned int> dofIndex (dofs_per_cell);
	  Vector<double> U_cell (dofs_per_cell);
	  Vector<double> F_cell (dofs_per_cell);
	  Vector<double> deltaU (n_dofs_all);
	  std::vector<unsigned int> q_point_Index (n_q_points);
	  Vector<double> C_cell (n_q_points);

	  	FullMatrix<double> e_cell;
	    FullMatrix<double>   tmp_cell_matrix (dofs_per_cell, dofs_per_cell);
	    FullMatrix<double> C_matrix_nelinearan;
		FullMatrix<double>   B_matrix;
		FullMatrix<double>   C_matrix;
	    FullMatrix<double> sigma_cell;

	  DoFHandler<2>::active_cell_iterator
	  cell = dof_handler.begin_active(),
	  endc = dof_handler.end();

	  unsigned int POM=0;
	  deltaU = 1;

	  R = 0;
    //  double E_faktor=100.0, ni = 0.3;

	   C_matrix.reinit(3, 3,false);
	   B_matrix.reinit(3, dofs_per_cell,false);

/*	  std::map<int,double>::iterator iter ;
	    if (!F_prescribed.empty()) for(iter=F_prescribed.begin(); iter!=F_prescribed.end() ;iter++) R[iter->first]=iter->second;
*/
	  int numOfSteps = g->step+T/g->dt;
    //  double sigma[3];
	  Vector<double> e_vector;
	 e_vector.reinit(3,false); // dim = 2

	 double e_matrix[3][n_q_points_all];
	 double sigma_matrix[n_q_points_all][3];//,*sigma_inline;
	 double deltasigma_matrix[n_q_points_all][3][3];//,*deltasigma_inline;

/* DEBUG
	 printf("sizeof(sigma_matrix)=%d \n",sizeof(sigma_matrix)/(sizeof(double)*3));
	 printf("sizeof(deltasigma_matrix)=%d \n",sizeof(deltasigma_matrix)/(sizeof(double)*3*3));
*/
	  int flags[2];
	  flags[0]=0;flags[1]=0;
    //  double* U_niz;
    //  U_niz=&U[0];

	  for(;g->step < numOfSteps;g->step++)
	 {
		 printf("+++++++++++++++++++++++++++++++++  %d  +++++++++++++++++++++++++++++++++\n",g->step);
// jedan simulacioni korak
		 deltaU=1;
		 POM = 0;

		 while (deltaU.l2_norm() > 1.0E-3) {
		  	  	 system_matrix=0;
		 	 	 F=0;
		 	 	 cell = dof_handler.begin_active(),
				 endc = dof_handler.end();
// ----------------- calculator.saveAndcontinue()
		 	 	 if (flags[0]!=0)
		 	 		 	 	 qpoint_calculator->saveAndcontinue(flags);
// ----------------- calculator.saveAndcontinue()   END
		 		 printf("Da pocnem?\n");
		  	 	 unsigned int cell_Index = 0;
		 	 	 for (; cell!=endc; ++cell)
		 	 	 {
	 	 		 	 cell->get_dof_indices (dofIndex);
		 	 		 for (unsigned int i=0;i<n_q_points;i++)
		 	 			 	 	 	 	 q_point_Index[i]=cell_Index*(n_q_points)+i;
		 	 		 for (unsigned int i=0; i<dofs_per_cell; ++i){
		 	 			 	 	 	 	 U_cell(i)=U(dofIndex[i]);
                                // 	 	 printf("cell(%d): %d - %d \t U(%d) = %f\n",cell_Index,i,dofIndex[i],i,U_cell(i));
		 	 	 	 }
		 	 		 e_cell=e_element(fe_values,U_cell,n_q_points,dofs_per_cell,dofIndex);
		 	 		for (unsigned int i=0; i<n_q_points; ++i) {
		 	 				 	 		e_matrix[0][q_point_Index[i]]=e_cell[0][i];
		 	 				 	 		e_matrix[1][q_point_Index[i]]=e_cell[1][i];
		 	 				 	 		e_matrix[2][q_point_Index[i]]=e_cell[2][i];
                            // 	 	printf("cell(%d): %d - %d \t U(%d) = %f\n",cell_Index,i,q_point_Index[i]);
		 	 		}
		 	 		cell_Index++;
		 	 	 }
		 	 	 cell_Index=0;

// ----------------- calculator.calculate()
		 	 	 qpoint_calculator->calculate((double *)e_matrix,(double *)sigma_matrix,(double *)deltasigma_matrix);
/*  DEBUG
		 	 	 printf("FEM2D pokupio rezultate\n");
		 		 for (int ii=0;ii<4;ii++)
		 		 {
		 			 for (int jj=0;jj<3;jj++)
		 				 	 printf("sigma_matrix[%d][%d]=%lf\t",ii,jj,sigma_matrix[ii][jj]);
		 			 printf("\n");
		 		 }
		 		 for(int kk=0;kk<4;kk++)
		 		 for (int ii=0;ii<3;ii++)
		 		 {
		 			 for (int jj=0;jj<3;jj++)
		 				 	 printf("delstasigma_matrix[%d][%d][%d]=%lf\t",kk,ii,jj,deltasigma_matrix[kk][ii][jj]);
		 			 printf("\n");
		 		 }
*/
// ----------------- calculator.calculate()   END

			 	 cell = dof_handler.begin_active(),
				 endc = dof_handler.end();

		 	 	 int celija=0;
		 	 	 for (; cell!=endc; ++cell)
		 	 	 {
		 	 		 celija++;
		 	 		cell_matrix = 0; 	C_cell = 0;  F_cell=0;  cell_rhs(0)= 0;
		 	 		 fe_values.reinit (cell);
		 	 		 cell->get_dof_indices (dofIndex);
// DEBUG		 	 		 printf("------------------------------ postavljam  sistem --------------- 0\n");
	 	 		 	 for (unsigned int i=0;i<n_q_points;i++)
		 	 			 	 	 	 	 q_point_Index[i]=cell_Index*(n_q_points)+i;
		 	 		 for (unsigned int i=0; i<dofs_per_cell; ++i){
		 	 			 	 	 	 	 U_cell(i)=U(dofIndex[i]);
		 	 	 	 }
		 	 		 for(unsigned int q_point=0;q_point<n_q_points;q_point++) {
		 	 			 	 		 	 	 for(unsigned int no=0;no<dofs_per_cell;no++) 	{
		 	 			 	 		 		 	 		                            		unsigned int  comp_j = fe.system_to_component_index(no).first;
		 	 			 	 		 	 		 	 	 	 	 	 	 	 	 	   		B_matrix[0][no]=(comp_j==0)?fe_values.shape_grad(no,q_point)[0]:0 ;
		 	 			 	 		 		 	 		                            		B_matrix[1][no]=(comp_j==1)?fe_values.shape_grad(no,q_point)[1]:0 ;
		 	 			 	 		 		 	 		                            		B_matrix[2][no]=(comp_j==0)*fe_values.shape_grad(no,q_point)[1] +
		 	 			 	 		 		 	 		                            				(comp_j==1)*fe_values.shape_grad(no,q_point)[0] ;
		 	 			 	 		 		 	 		                            	}
		 	 			 	 		 	 	 for(int i=0;i<3;i++)
		 	 			 	 		 	 		 	 for(int j=0;j<3;j++)
		 	 			 	 		 	 		 		 C_matrix[i][j]=deltasigma_matrix[q_point_Index[q_point]][i][j];
		 	 			 	 		 	 	 tmp_cell_matrix=0;
	 	 		                             tmp_cell_matrix.triple_product(C_matrix,B_matrix,B_matrix,true,false,1);
		 	 			 	 		        for(unsigned int ii=0;ii<dofs_per_cell;ii++)
		 	 			 	 		 		 	for(unsigned int jj=0;jj<dofs_per_cell;jj++)
		 	 			 	 		 	       			cell_matrix(ii,jj)+=tmp_cell_matrix(ii,jj)*fe_values.JxW(q_point);
		 	 			 	 			   for(unsigned int i=0;i<dofs_per_cell;i++) {
		 	 			 	 					  unsigned int  comp = fe.system_to_component_index(i).first;
		 	 			 	 					  F_cell[i] += ((comp==0)*fe_values.shape_grad(i,q_point)[comp]*sigma_matrix[ q_point_Index[q_point]][0]+ //sigma[q][0]+
		 	 			 	 							  (comp==1)*fe_values.shape_grad(i,q_point)[comp]*sigma_matrix[ q_point_Index[q_point]][1]+//sigma[q][1]+
		 	 			 	 							  ((comp==0)*fe_values.shape_grad(i,q_point)[comp]+
		 	 			 	 									  (comp==1)*fe_values.shape_grad(i,q_point)[comp])*sigma_matrix[ q_point_Index[q_point]][2])*fe_values.JxW(q_point); //sigma[q][2]
		 	 			 	 			  }
	      	  	      	  		 }
				 	 		 for (unsigned int i=0; i<dofs_per_cell; ++i)
				 	 			 	 for (unsigned int j=0; j<dofs_per_cell; ++j)
				 	 			 		 system_matrix.add((unsigned int)dofIndex[i],
				 	 			 				 	 	 	 	 	 	 	 	 	 (unsigned int)dofIndex[j],
				 	 			 				 	 	 	 	 	 	 	 	 	 cell_matrix(i,j));
			 	 		        for (unsigned int i=0; i<dofs_per_cell; ++i)
					 	 			 	 	 F((unsigned int)dofIndex[i]) += F_cell(i);
			 	 		        cell_Index++;
		 	 	 }
		 	 	 system_rhs.print(std::cout,9,false);
		 	 	 system_rhs=R;
		 	 	 system_rhs.add(-1,F);
		 	 	 	 	 printf("F^%d\t\t\t\t rhs^%d \n",POM,POM);
		 	 	 	 	 for(unsigned int i=0;i<n_dofs_all/2;i++)
                                 printf("(%d) : (%f,%f)\t (%d) : (%f,%f) \n",i,F(i*2),F(i*2+1),i,system_rhs(i*2),system_rhs(i*2+1));
		 	 	 MatrixTools::apply_boundary_values (boundary_values,
		                                     system_matrix,
		                                      solution,
		                                     system_rhs);
 	 	 	 	 solve();
 	 	 	 	 deltaU = solution;

 	 	 	 	 	 	 	 stampa(deltaU,"deltaU",POM+1);
 	 	 	 	 	 	 	 std::cout<<"------------------------------------------------------------"<<std::endl;
 	 	 	 	 U.add(solution);

 	 	 	 	 	 printf("Korak: %d\t Iteracija = %d\n",g->step+1,POM);
 	 	 	 	 	 for(unsigned int i=0;i<n_dofs_all/2;i++)
                             printf("X(%d) : pomeranje (%f,%f)\n",i,U(i*2),U(i*2+1));
 	 	 	 	 std::cout<<"\n";
 	 	 	 	 POM++;

 	 	 	 	 flags[0]=1; flags[1]=0;
 	 	 	 	 if  (POM>30)  {
 	 	 	 		 	 	 printf("PRECERA\n");  exit(0);
 	 	 	 	 }
 	 	 	 	 	 printf("------------- kraj jedne iteracije");
		 }
// kraj while petlje i jedne iteracije0
		 flags[0]=1; flags[1]=1;

		fprintf(fUnv,"    -1\n    55\n\n");
		fprintf(fUnv,"NODAL TRANSLATIONS AND ROTATIONS\nDATE AND TIME\nEMPTY\nLOAD CASE         :%10d\n",g->step+1);
		fprintf(fUnv,"         1         4         3         8         2         6\n");
        fprintf(fUnv,"         2         1%10d%10d\n",g->step+1,g->step+1);
        fprintf(fUnv,"  %f\n",(g->step+1)*g->dt);
        for(unsigned int i=0;i<(unsigned int)n_dofs_all/2;i++){
        		fprintf(fUnv,"%10d\n",i+1);
                fprintf(fUnv,"  %f  %f  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00\n",U(i*2),U(i*2+1));
        	}
	 	 fprintf(fUnv,"    -1\n");
	 }
// kraj simulacionog koraka

	  fclose(fUnv);
	  F_prescribed.clear();
	  U_prescribed.clear();

// ----------------- calculator.saveAndcontinue()
	 flags[0]=0; flags[1]=0;
	 printf("FEM2D poziva saveAndContinue\n");
	 qpoint_calculator->saveAndcontinue(flags);
	 printf("Obradjen zahtev saveAndContinue\n");
// ----------------- calculator.saveAndcontinue()    END
}

void FEM2D::stampa(const Vector<double> vektor, const char* naziv, const int POM)
{
	std::cout << "\t" << naziv << "^" << POM << " : ";
	vektor.print(std::cout,9,false);
}
