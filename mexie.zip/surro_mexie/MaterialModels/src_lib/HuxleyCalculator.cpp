/*
 * HuxleyCalculator.cpp
 *
 *  Created on: Aug 8, 2013
 *      Author: anakaplarevic
 */

#include "HuxleyCalculator.h"
#include "huxley_functions.h"
#include <cstring>

HuxleyCalculator::HuxleyCalculator(HuxleyParameters* param) {
	// TODO Auto-generated constructor stub
	_param = param;
}

HuxleyCalculator::~HuxleyCalculator() {
	// TODO Auto-generated destructor stub
}

void HuxleyCalculator::Calculate(ublas::vector<_TIP>& X,ublas::vector<_TIP>& N,_TIP velocity,_TIP time,_TIP* force, _TIP O){
	//INIT
// Ulazi u calculate 1
    brojac=0;

	long DIVISION = X.size();
	N_remash.resize(DIVISION,false);
	X_remash.resize(DIVISION,false);
	_TIP x0,x0_new;
	_TIP poc = _param->xmin - _param->m_leftng*_param->step;
	for(unsigned int i = 0; i < DIVISION; i++) {
		X_remash(i) = poc + _param->step * i;
	}
	this->X.resize(DIVISION,false);
	this->N.resize(DIVISION,false);
	this->X = X;
	this->N = N;

	V.resize(DIVISION,false);
	F.resize(DIVISION,false);

//	printf("duzina %ld\n",V.size());

	//F = fun_F(N,X,_param);
	fun_F(N,X,*_param,F,O);
	ublas::vector<_TIP> V_initial(DIVISION,(_TIP) velocity);

	V = V_initial;

	X_curr.resize(DIVISION,false);
	N_curr.resize(DIVISION,false);
	V_curr.resize(DIVISION,false);
	F_curr.resize(DIVISION,false);

	X_next.resize(DIVISION,false);
	N_next.resize(DIVISION,false);
	V_next.resize(DIVISION,false);
	F_next.resize(DIVISION,false);

	// Simulate;

	Simulate(time, O);
	X=this->X;
	N=this->N;
	*force = getForce();
	//printf("HuxleyCalculator::Calculate -----   *force=%lf\n",*force);
}

void HuxleyCalculator::Calculate(ublas::vector<_TIP>& X,ublas::vector<_TIP>& N,_TIP& v_t,_TIP velocity_avg,_TIP time,_TIP* force, _TIP O){
	//INIT
    brojac=0;

	long DIVISION = X.size();
	N_remash.resize(DIVISION,false);
	X_remash.resize(DIVISION,false);
	_TIP x0,x0_new;
	_TIP poc = _param->xmin - _param->m_leftng*_param->step;
	for(unsigned int i = 0; i < DIVISION; i++) {
		X_remash(i) = poc + _param->step * i;
	}
	this->X.resize(DIVISION,false);
	this->N.resize(DIVISION,false);
	this->X = X;
	this->N = N;

	V.resize(DIVISION,false);
	F.resize(DIVISION,false);

//	printf("duzina %ld\n",V.size());

	//F = fun_F(N,X,_param);
	fun_F(N,X,*_param,F,O);
//	ublas::vector<_TIP> V_initial(DIVISION,(_TIP) velocity_avg);
	ublas::vector<_TIP> V_initial(DIVISION,(_TIP) v_t);
//	ublas::vector<_TIP> V_initial(DIVISION,(_TIP) 0.0);
	V = V_initial;

	X_curr.resize(DIVISION,false);
	N_curr.resize(DIVISION,false);
	V_curr.resize(DIVISION,false);
	F_curr.resize(DIVISION,false);

	X_next.resize(DIVISION,false);
	N_next.resize(DIVISION,false);
	V_next.resize(DIVISION,false);
	F_next.resize(DIVISION,false);

	// Simulate;

	_TIP V_start = v_t;
	_TIP V_end = 2*velocity_avg - v_t;
	printf("________________________ V_t V_avg V_t+dt _____________ %f %f %f\n",V_start,velocity_avg,V_end);
//	Simulate(time, V_start, V_end);
	Simulate(time, O);
	v_t = V_end;
	X=this->X;
	N=this->N;
	*force = getForce();
//	printf("HuxleyCalculator::Calculate -----   *force=%lf\n",*force);
}

void HuxleyCalculator::Simulate(_TIP time,_TIP V_start,_TIP V_end, _TIP O){
	long DIVISION = X.size();
	int m_nt=(round)(time /_param->m_dt);
	_TIP v_inc = _param->m_dt * (V_end - V_start)/time;
	_TIP v_i = V_start;
	_TIP x0,x0_new;
	_TIP poc = _param->xmin - _param->m_leftng*_param->step;
//		FILE* f;
//		f=fopen("AVG_iterations","a+");
//	printf("Broj simulacionih koraka je %d\n",m_nt);

	for(int i = 0; i < m_nt; i++)
	{
		int ind;
		v_i += v_inc;
		printf("________________________ BRZINE _____________ %f\n",v_i);
		for(int ii=0;ii<V.size();ii++) V(i) = v_i;
		ind = Iteration(O);
		if (ind == 0)
		{
			printf("Error: No convergence, step %d\n", i);
			exit(1);
		}
        brojac += ind;
//		printf("%d \n",ind);
//		fprintf(f,"%d \n",ind);
		x0 = X_remash(0);
		x0_new=X(0);
		if (x0_new-x0!=0)	remash(x0_new-x0);
		//FILE *fV;
// DEBUG 
		//		fV = fopen("__test.csv","a");
//				for(unsigned i=0;i<DIVISION;i++) fprintf(fV,"%lf\t%lf\n",X(i),N(i));
		//		fclose(fV);
// end DEBUG
	}
// 	printf("hux  %lf \t",getForce());
//	fclose(f);
	FILE *fV;
//			fV = fopen("Calc.csv","w");
//			for(unsigned i=0;i<DIVISION;i++) fprintf(fV,"%lf\t%lf\n",X(i),N(i));
//			fclose(fV);
}

void HuxleyCalculator::Simulate(_TIP time, _TIP O){
// Ulazi u simulate 2
	long DIVISION = X.size();
	int m_nt=(round)(time /_param->m_dt);
	_TIP x0,x0_new;
	_TIP poc = _param->xmin - _param->m_leftng*_param->step;
//		FILE* f;
//		f=fopen("AVG_iterations","a+");
//	printf("Broj simulacionih koraka je %d\n",m_nt);


	for(int i = 0; i < m_nt; i++)
	{
		int ind;
		ind = Iteration(O);
		if (ind == 0)
		{
			printf("Error: No convergence, step %d\n", i);
			exit(1);
		}
        brojac += ind;
//		printf("%d \n",ind);
//		fprintf(f,"%d \n",ind);
		x0 = X_remash(0);
		x0_new=X(0);
		_TIP diff = fabs(x0_new-x0);
		diff = (x0_new<x0)?-diff:diff;
		if (diff!=0)	remash(diff);
		//FILE *fV;
// DEBUG 
		//		fV = fopen("__test.csv","a");
//				for(unsigned i=0;i<DIVISION;i++) fprintf(fV,"%lf\t%lf\n",X(i),N(i));
		//		fclose(fV);
// end DEBUG
	}
	// stampaj ovde X, N
// 	printf("hux  %lf \t",getForce());
//	fclose(f);
	FILE *fV;
//			fV = fopen("Calc.csv","w");
//			for(unsigned i=0;i<DIVISION;i++) fprintf(fV,"%lf\t%lf\n",X(i),N(i));
//			fclose(fV);
}

void HuxleyCalculator::remash(_TIP diff){
	unsigned int i=0,ir=0;
	_TIP k;
	long DIVISION = X.size();

	ublas::zero_vector<_TIP> _0(DIVISION);

	N_remash = _0;
	if (diff>0) {
        for (ir=(diff/_param->step-1); (ir<DIVISION) && (X_remash(ir)<X(i)); ir++);
        if (ir<DIVISION) {
		k = (X_remash(ir)-X(i))/_param->step;
		i++;
		}
		for (;ir<DIVISION;ir++,i++)
				N_remash(ir)=k*N(i)+(1-k)*N(i-1);
	}
	else {
        for (i=(-diff/_param->step-1); (i<DIVISION) && (X(i)<X_remash(ir)); i++);
		if (i<DIVISION) {
		k = (X_remash(ir)-X(i-1))/_param->step;
		}
		for (;i<DIVISION;ir++,i++)
				N_remash(ir)=k*N(i)+(1-k)*N(i-1);
	}
	X = X_remash;
	N = N_remash;
}

int HuxleyCalculator::Iteration(_TIP O){
	int iter = 0;
	_TIP dt = _param->m_dt;

	_TIP deltaXerr, deltaNerr;

	X_curr = X + V * dt;
	//for(unsigned long i=0;i<N.size();i++) N(i)=(N(i)<0)?0:N(i);
	N_curr = N + F * dt;
	V_curr = V;
	F_curr = F;
    //getchar();
	while(iter++ < _param->maxIter)
	{
		X_next = X + 0.5 * (V_curr + V) * dt;
		V_next = (X_next - X) / dt;
	//	F_next = fun_F(N_curr, X_next, _param);
		fun_F(N_curr, X_next, *_param, F_next, O);
		N_next = N + 0.5 * (F_next + F) * dt;
		/*for(unsigned long i=0;i<N_next.size();i++) {
			F_next(i)=(N_next(i)<0)?-2*N(i)/dt+F(i):F_next(i);		
			N_next(i)=(N_next(i)<0)?0:N_next(i);
		}*/
		deltaXerr = 0.5 * ublas::norm_2(V_next - V_curr) * dt;
		deltaNerr = 0.5 * ublas::norm_2(F_next - F_curr) * dt;

//		std::cout<< V_next(1) <<std::endl;

		X_curr = X_next;
		V_curr = V_next;
		F_curr = F_next;
		N_curr = N_next;
	/*	std::string imef;
		imef = "__X_N_" + iter;
		//std::string s
		char *a=new char[imef.size()+1];
		a[imef.size()]=0;
		memcpy(a,imef.c_str(),imef.size());*/

/*		FILE *fV;
				fV = fopen(a,"w");
				for(unsigned i=0;i<X.size();i++) fprintf(fV,"%lf\t%lf\n",X(i),N(i));
				printf("iter = %d \t deltaNerr = %f \n",iter,deltaNerr);
				fclose(fV);
				*/
		if((deltaXerr< _param->EpsXerr) && (deltaNerr < _param->EpsNerr))
		{
			X = X_curr;
			V = V_curr;
			F = F_curr;
			N = N_curr;
//				printf("Broj iteracija %d deltaNerr=%f \n",iter,deltaNerr);
				FILE *fV;
// DEBUG
//						fV = fopen("__test.csv","a");
//						fprintf(fV,"Broj iteracija %d deltaNerr=%f \n",iter,deltaNerr);
//						fclose(fV);
// end DEBUG	
						return iter;
		}
	}
	 printf("%lf\n",V(0));
     FILE *fV;
				fV = fopen("HuxleyConvergence.csv","w");
				fprintf(fV,"%lf\n",V(0));
				for(unsigned i=0;i<X.size();i++) fprintf(fV,"%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf\n",X(i),F(i), N(i),X_curr(i),N_curr(i),X_next(i), F_next(i),N_next(i));
				fclose(fV);
			

	return 0; // no convergence
}

int HuxleyCalculator::getBrojac()
{
    return brojac;
}

_TIP HuxleyCalculator::getStiffness()
{
	return fun_Stiffness(X,N,_param->m_Kxb); // k = \itegral_min^max N(x)dx
}
_TIP HuxleyCalculator::getSigmaTangent()
{
	return fun_Stiffness(X,N,_param->m_Kxb)*_param->L0/_param->A; // k = tsigma * A/l; -> tsigma = k*l/A
}
_TIP HuxleyCalculator::getSigmaTangent(_TIP e)
{
	return fun_Stiffness(X,N,_param->m_Kxb)*e*_param->L0/_param->A; // k = tsigma * A/l; -> tsigma = k*l/A
}

_TIP HuxleyCalculator::getSigma()
{
	return fun_Force(X,N,_param->m_Kxb)/_param->A; // sigma = F/A;
}
_TIP HuxleyCalculator::getForce()
{
	return fun_Force(X,N,_param->m_Kxb);
}
_TIP HuxleyCalculator::getVelocity()
{
	return V(0);
}

