/*!
 * \file PAKP_Material.cpp
 * Implementation of the CPAKP_Material class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// PAKP_Material.cpp: implementation of the CPAKP_Material class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
#include "PAKP_Material.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//IMPLEMENT_SERIAL(CPAKP_Material, CObject, VERSIONABLE_SCHEMA)

/*!
 * Default constructor.
 */
CPAKP_Material::CPAKP_Material()
{

}

/*!
 * Destructor.
 */
CPAKP_Material::~CPAKP_Material()
{

}
