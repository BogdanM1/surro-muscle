/*!
 * \file HMaterial.h
 * Interface for the HMaterial class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HMaterial.h: interface for the HMaterial class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HMATERIAL_H__E4BF19A0_6284_11D2_B069_444553540000__INCLUDED_)
#define AFX_HMATERIAL_H__E4BF19A0_6284_11D2_B069_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include "HDataBlock.h"
#include "MyString.h"

#define	ST_PAK_ELASTIC_ISO_NAME			"PAK Elastic Isotropic"
#define	ST_PAK_ELASTIC_ORTHO_NAME		"PAK Elastic Orthotropic"
#define	ST_PAK_THERMO_ELASTIC_ISO_NAME	"PAK Thermoelastic"
#define	ST_PAK_MISES_PLASTIC_NAME		"PAK Mises Plastic"
#define	ST_PAK_HYSTERELASTIC_NAME		"PAK Elastic with hysteresis"
#define	ST_PAK_BIO32_NAME				"PAK Biomaterial 32"
#define	ST_PAK_BIAXIAL_NAME				"PAK Biaxial (36)"
#define	ST_PAK_MODEL_37_NAME			"PAK Model 37 (Surfactant)"
#define	ST_PAK_MODEL_38_NAME			"PAK Model 38 (Stress-Stretch)"
#define	ST_PAK_MODEL_39_NAME			"PAK Model 39"
#define	ST_PAK_MODEL_41_NAME			"PAK Model 41"
#define	ST_PAK_HILLS2002_NAME			"PAK Hill's muscle model (2002)"
#define	ST_PAK_HILLS_NAME				"PAK Hill's muscle model"
#define	ST_PAK_HILLS_2FIBER_NAME		"PAK Hill's 2 fiber muscle model"
#define	ST_PAK_MODEL_62_NAME			"PAK Carter&Hayes Bone model (62)"
#define	ST_PAK_DELFINO_SEF_2D_NAME		"PAK Delfino SEF 2D (81)"
#define	ST_PAK_FUNG_SEF_NAME			"PAK Fung SEF (83)"
#define	ST_PAK_POROUS_DEFORMABLE_NAME	"PAK Porous deformable model"
#define	ST_PAK_FLUID_NAME				"PAK Fluid"
#define ST_HUXLEY_NAME                  "Huxley"

/** Class representing material. */
class HMaterial : public HDataBlock  
{
public:

	typedef enum
	{
		MT_FEMAP_ISO			= 0,
		MT_FEMAP_2D_ORTHO		= 1,
		MT_FEMAP_3D_ORTHO		= 2,
		MT_FEMAP_2D_ANISO		= 3,
		MT_FEMAP_3D_ANISO		= 4,
		MT_FEMAP_HYPERELASTIC	= 5,
		MT_FEMAP_OTHER			= 6
	} Type;

	typedef enum
	{
		ST_PAK_ELASTIC_ISO			= 1,
		ST_PAK_ELASTIC_ORTHO		= 2,
		ST_PAK_THERMO_ELASTIC_ISO	= 3,
		ST_PAK_MISES_PLASTIC		= 5,
		ST_PAK_HYSTERELASTIC		= 100,	
		ST_PAK_BIO32				= 32,
		ST_PAK_BIAXIAL				= 36,
		ST_PAK_MODEL_37				= 37,
		ST_PAK_MODEL_38				= 38,
		ST_PAK_MODEL_39				= 39,
		ST_PAK_MODEL_41				= 41,
		ST_PAK_HILLS2002			= 31,
		ST_PAK_HILLS				= 310,
		ST_PAK_HILLS_2FIBER			= 312,
		ST_PAK_MODEL_62				= 62,
		ST_PAK_DELFINO_SEF_2D		= 81,
		ST_PAK_FUNG_SEF				= 83,
		ST_PAK_POROUS_DEFORMABLE	= 200,
		ST_PAK_FLUID				= 1001,
		ST_HUXLEY					= 92
	} SubType;


	HMaterial();
	HMaterial (const HMaterial& rc);
	virtual ~HMaterial();

	HMaterial& operator = (const HMaterial& rp);
	//DECLARE_SERIAL(HMaterial)
	//void Serialize( CArchive& ar );

	/// ID of the material
	UINT m_nID;
	/// Color of the material
	UINT m_uColor;
	/// Type of the material
	Type m_uType;
	/// Subtype of the material
	SubType m_uSubType;
	/// Layer of the material
	UINT m_uLayer;
	bool m_bHas_functions;
	/// Title of the material
	MyString m_strTitle;
	/// Young's modulus
	double m_dE[3]; 
	/// Shear modulus
	double m_dG[3]; 
	/// Poisson's ratio
	double m_dNu[3]; 
	/// Upper triangle of 6x6 3D anisotropic elastic matrix
	double m_dGMatrix_3D[22];
	/// Upper triangle of 6x6 3D anisotropic elastic matrix
	double m_dGMatrix_2D[6];
	/// Thermal expansion coefficients
	double m_dAlpha[6];
	/// Thermal conductivity coefficients
	double m_dK[6];
	/// Thermal capacity
	double m_dThermal_cap;
	/// Density
	double m_dDensity;
	double m_dDamping;
	double m_dTemperature;
	double m_dTensionLimit[2];
	double m_dCompLimit[2];
	double m_dShearLimit;
// Naredne promenljive se odnose na funkcije
	UINT m_uFE[3];
	UINT m_uFG[3];
	UINT m_uNu[3];
	UINT m_uFGMatrix3D[22];
	UINT m_uFGMatrix2D[6];
	UINT m_uFAlpha[6];
	UINT m_uFK[6];
	UINT m_uFThermal_cap;
	UINT m_uFDensity;
	UINT m_uFDamping;
	UINT m_uFTemperature;
	UINT m_uFTensionLimit[2];
	UINT m_uCompLimit[2];
	UINT m_uShearLimit;

	double m_dPlastHardSlope;
	double m_dPlastYieldLim[2];
	double m_dHypPolyord[2];
	UINT   m_uNonlin_type;
	UINT   m_uNonlin_func;
	int	   m_iHard_type;
	int	   m_iYield_type;
};

#endif // !defined(AFX_HMATERIAL_H__E4BF19A0_6284_11D2_B069_444553540000__INCLUDED_)
