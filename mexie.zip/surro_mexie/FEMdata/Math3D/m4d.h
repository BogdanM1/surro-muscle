// -*- c++ -*-
#ifndef INCLUDED_MATH3D_M4D_H
#define INCLUDED_MATH3D_M4D_H
/*
 * Math3d - The 3D Computer Graphics Math Library
 * Copyright (C) 1996-2000 by J.E. Hoffmann <je-h@gmx.net>
 * All rights reserved.
 *
 * This program is  free  software;  you can redistribute it and/or modify it
 * under the terms of the  GNU Lesser General Public License  as published by 
 * the  Free Software Foundation;  either version 2.1 of the License,  or (at 
 * your option) any later version.
 *
 * This  program  is  distributed in  the  hope that it will  be useful,  but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or  FITNESS FOR A  PARTICULAR PURPOSE.  See the  GNU Lesser General Public  
 * License for more details.
 *
 * You should  have received  a copy of the GNU Lesser General Public License
 * along with  this program;  if not, write to the  Free Software Foundation,
 * Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * $Id: m4d.h,v 1.1.1.1 2004/11/13 14:05:40 krle Exp $
 */

#ifndef INCLUDED_MATH3D_MATH3DDEF_H
#include "math3ddef.h"
#endif

namespace Math3d {
  
  class M3d;
  class M4x4;

/*!
 * 4-dimensional vector.
 */
  class _CCMATH3D M4d {
    public:
	  double x,y,z,w;

      M4d() {};
      M4d(double tx, double ty, double tz, double tw) 
        {x=tx; y=ty; z=tz; w=tw;}
      M4d(const M3d& A);
      M4d(const M4d& A);
      const M4d& operator=(const M4d& A);
      
      void zero();
      void set(double tx, double ty, double tz, double tw) 
        {x=tx; y=ty; z=tz; w=tw;}
      void copy(const M4d& A);

      inline double& operator[](int i);
      operator double*() {return(&x);}
//      double& x() {return(x);}
//      double& y() {return(y);}
//      double& z() {return(z);}
//      double& w() {return(w);}
      double& get(int i);

      M4d operator+(const M4d& A);
      M4d operator+();
      const M4d& operator+=(const M4d& A);
      M4d operator-(const M4d& A);
      M4d operator-();
      const M4d& operator-=(const M4d& A);
      M4d operator*(double k);
      const M4d& operator*=(double k);
      void neg();
      void abs();
      void add(const M4d& A, const M4d& B);
      void sub(const M4d& A, const M4d& B);
      void scalar(double k);
      void normalize();
      void cartesianize();
      M3d cartesianized();
      void rationalize();
      void homogenize();
      void lerp(const M4d& A, const M4d& B, double t);
      void Min(const M4d& m);
      void Max(const M4d& m);
      void cubic(const M4d& A, const M4d& TA, const M4d& TB, 
        const M4d& B, double t);
      
      inline double operator[](int i) const;
      operator const double*() const {return(&x);}
//      double x() const {return(x);}
//      double y() const {return(y);}
//      double z() const {return(z);}
//      double w() const {return(w);}
      double get(int i) const;

      double operator*(const M4d& A) const;
      bool operator==(const M4d& A) const;
      bool operator!=(const M4d& A) const;
      double dot(const M4d& A) const;
      bool cmp(const M4d& A, double epsilon=EPSILON) const;
      double squared() const;
      double length() const;

      friend class M3d;
      friend class M4x4;
  };
  
  inline double&
  M4d::operator[](int i)
  {
    ASSERT(i>=0 && i<4);
    return((&x)[i]);
  }
  inline double
  M4d::operator[](int i) const
  {
    ASSERT(i>=0 && i<4);
    return((&x)[i]);
  }

//  extern _CCMATH3D std::ostream& operator << (std::ostream& co, const M4d& v);

}
#endif // INCLUDED_MATH3D_M4D_H







