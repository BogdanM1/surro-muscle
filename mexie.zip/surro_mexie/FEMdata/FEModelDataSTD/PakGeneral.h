// PakGeneral.h: interface for the CPakGeneral class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PAKGENERAL_H__D1352841_B120_11D6_8623_5254AB509DC9__INCLUDED_)
#define AFX_PAKGENERAL_H__D1352841_B120_11D6_8623_5254AB509DC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TimeSteps.h"
#include "PakIterMethod.h"

class CPakGeneral  
{
public:
	CPakGeneral();
	virtual ~CPakGeneral();
	CPakGeneral& operator=(const CPakGeneral &other);

//	CGeneralOptionsDlg *dlgGeneralOptions;
	
	MyString GetTitle();
	bool	GetDynamicAnIsSet();
	bool    GetEigenvalueIsSet();
	int		GetNSOPV();
	int		GetProgramStart();
	int		GetAnalysisType();

	MyString m_strTitle;
	bool m_bDynamic;	
	bool m_bEigenValue;
	bool m_bFreeNumeration;
	bool m_bReadInitFile;//TRUE = Read data from Initial file
	bool m_bIale;//Use ALE formulation
	bool m_bIBound;//Use IBOUND
	int m_iNSOPV;
	int m_iProgramStart;
	int m_iAnalysisType;
	int m_iFieldType; // 0 - Fluid with heat transport
					  // 1 - Fluid only
					  // 2 - Heat transport

	bool m_bNewtonianFluid;

//Time periods
	int		GetNumOfPeriods();
	int		GetNumSteps(int i);
	double	GetStep(int i);

	CTimeSteps m_TimeSteps;
	CPakIterMethod m_IterMethod;

//Ither method
	int		GetIterMethod();
	int 	GetMaterialModel(int ElementType);
	UINT	GetNodeNumber();
	int		GetDirection();
	double	GetValue();
	double	GetAG();
	double	GetDS();

};

#endif // !defined(AFX_PAKGENERAL_H__D1352841_B120_11D6_8623_5254AB509DC9__INCLUDED_)
