/*!
 * \file HLoads.cpp
 * Implementation of the HLoads class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HLoads.cpp: implementation of the HLoads class.
//
//////////////////////////////////////////////////////////////////////

#include "Stdafx.h"
//#include "Femcon.h"
#include "HLoads.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
/*
template <> void AFXAPI SerializeElements <HLoads> ( CArchive& ar, HLoads* pHLoads, int nCount )
{
    for ( int i = 0; i < nCount; i++, pHLoads++ )
    {
        pHLoads->Serialize( ar );
    }
}
*/

/*!
 * Default constructor.
 */
HLoads::HLoads()
{
	m_StructLoads.SetSize(0,10);
	m_NodalTemps.SetSize(0,1);
	m_ElTemps.SetSize(0,1);

	m_bGrav_on = FALSE;
}

/*!
 * Copy constructor.
 */
HLoads::HLoads(const HLoads & rc)
{
	(*this)=rc;
}


/*!
 * Destructor.
 */
HLoads::~HLoads()
{
	m_StructLoads.RemoveAll();

	m_NodalTemps.RemoveAll();

	m_ElTemps.RemoveAll();
}

/*!
 * Equalizes two objects of the HLoads class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
HLoads& HLoads::operator =(const HLoads & rp)
{

	m_uDataBlockID=rp.m_uDataBlockID;
	m_nID=rp.m_nID;
	m_strTitle=rp.m_strTitle;
	m_uCSys=rp.m_uCSys;
	m_dDef_temp=rp.m_dDef_temp;
	m_bTemp_on=rp.m_bTemp_on;
	m_bGrav_on=rp.m_bGrav_on;
	m_bOmega_on=rp.m_bOmega_on;
	int i;
	for (i=0;i<6;i++)
		m_dGrav[i]=rp.m_dGrav[i];
	for (i=0;i<3;i++)
		m_dOrigin[i]=rp.m_dOrigin[i];
	for (i=0;i<3;i++)
		m_dOmega[i]=rp.m_dOmega[i];
	m_dStef_boltz=rp.m_dStef_boltz;
	m_dAbs_temp=rp.m_dAbs_temp;
	m_dFree_cnv_exp=rp.m_dFree_cnv_exp;
	m_dFc_flu_cond=rp.m_dFc_flu_cond;
	m_dFc_flu_cp=rp.m_dFc_flu_cp;
	m_dFc_flu_vis=rp.m_dFc_flu_vis;
	m_dFc_flu_dens=rp.m_dFc_flu_dens;
	m_dFc_cons_coef=rp.m_dFc_cons_coef;
	m_dFc_reynolds=rp.m_dFc_reynolds;
	m_dFc_pran_in=rp.m_dFc_pran_in;
	m_dFc_pran_out=rp.m_dFc_pran_out;
	m_uTfc_flu_cond=rp.m_uTfc_flu_cond;
	m_uTfc_flu_cp=rp.m_uTfc_flu_cp;
	m_uTfc_flu_vis=rp.m_uTfc_flu_vis;
	m_bAlt_free_conv=rp.m_bAlt_free_conv;
	m_bFc_flu_flag=rp.m_bFc_flu_flag;
	m_bFc_conv_flow=rp.m_bFc_conv_flow;

	m_dDyn_trans_dt = rp.m_dDyn_trans_dt;
	m_uDyn_trans_ts = rp.m_uDyn_trans_ts;
	m_uDyn_type = rp.m_uDyn_type;

	m_StructLoads.RemoveAll();
	m_StructLoads.Copy(rp.m_StructLoads);

	m_NodalTemps.RemoveAll();
	m_NodalTemps.Copy(rp.m_NodalTemps);

	m_ElTemps.RemoveAll();
	m_ElTemps.Copy(rp.m_ElTemps);

	return *this;
}

///*!
// * serializes object of the HFunctions class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void HLoads::Serialize(CArchive& ar)
//{
//	UINT i;
//	if (ar.IsStoring())
//	{
//		ar << m_uDataBlockID;
//		ar << m_nID;
//		ar << m_strTitle;
//		ar << m_uCSys;
//		ar << m_dDef_temp;
//		ar << m_bTemp_on;
//		ar << m_bGrav_on;
//		ar << m_bOmega_on;
//		for (i=0;i<6;i++)
//			ar << m_dGrav[i];
//		for (i=0;i<3;i++)
//			ar << m_dOrigin[i];
//		for (i=0;i<3;i++)
//			ar << m_dOmega[i];
//		ar << m_dStef_boltz;
//		ar << m_dAbs_temp;
//		ar << m_dFree_cnv_exp;
//		ar << m_dFc_flu_cond;
//		ar << m_dFc_flu_cp;
//		ar << m_dFc_flu_vis;
//		ar << m_dFc_flu_dens;
//		ar << m_dFc_cons_coef;
//		ar << m_dFc_reynolds;
//		ar << m_dFc_pran_in;
//		ar << m_dFc_pran_out;
//		ar << m_uTfc_flu_cond;
//		ar << m_uTfc_flu_cp;
//		ar << m_uTfc_flu_vis;
//		ar << m_bAlt_free_conv;
//		ar << m_bFc_flu_flag;
//		ar << m_bFc_conv_flow;
//	}
//	else
//	{
//		ar >> m_uDataBlockID;
//		ar >> m_nID;
//		ar >> m_strTitle;
//		ar >> m_uCSys;
//		ar >> m_dDef_temp;
//		ar >> m_bTemp_on;
//		ar >> m_bGrav_on;
//		ar >> m_bOmega_on;
//		for (i=0;i<6;i++)
//			ar >> m_dGrav[i];
//		for (i=0;i<3;i++)
//			ar >> m_dOrigin[i];
//		for (i=0;i<3;i++)
//			ar >> m_dOmega[i];
//		ar >> m_dStef_boltz;
//		ar >> m_dAbs_temp;
//		ar >> m_dFree_cnv_exp;
//		ar >> m_dFc_flu_cond;
//		ar >> m_dFc_flu_cp;
//		ar >> m_dFc_flu_vis;
//		ar >> m_dFc_flu_dens;
//		ar >> m_dFc_cons_coef;
//		ar >> m_dFc_reynolds;
//		ar >> m_dFc_pran_in;
//		ar >> m_dFc_pran_out;
//		ar >> m_uTfc_flu_cond;
//		ar >> m_uTfc_flu_cp;
//		ar >> m_uTfc_flu_vis;
//		ar >> m_bAlt_free_conv;
//		ar >> m_bFc_flu_flag;
//		ar >> m_bFc_conv_flow;	
//	}
//
//	m_StructLoads.Serialize(ar);
//	m_NodalTemps.Serialize(ar);
//	m_ElTemps.Serialize(ar);
//}

/*!
 * Default constructor.
 */
StructLoad::StructLoad()
{
	int j;
	for (j=0;j<6;j++)
		m_uDof_face[j]=FALSE;

	for (j=0;j<6;j++)
		m_dValue[j]=0.0;
}

/*!
 * Destructor.
 */
StructLoad::~StructLoad()
{
}

/*!
 * Copy constructor.
 */
StructLoad::StructLoad(const StructLoad & rc)
{
	(*this)=rc;

}

/*!
 * Equalizes two objects of the StructLoad class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
StructLoad& StructLoad::operator =(const StructLoad & rp)
{
	m_uLoadID=rp.m_uLoadID;
	m_sTitle = rp.m_sTitle;
	m_uLoadtype=rp.m_uLoadtype;
	m_uColor=rp.m_uColor;
	m_uLayer=rp.m_uLayer;
	m_uDefine_sys=rp.m_uDefine_sys;
	m_uSl_funcID=rp.m_uSl_funcID;
	m_dPhase=rp.m_dPhase;
	m_dCoefficient=rp.m_dCoefficient;
	int j;
	for (j=0;j<6;j++)
		m_uDof_face[j]=rp.m_uDof_face[j];
	for (j=0;j<6;j++)
		m_dValue[j]=rp.m_dValue[j];
	m_dAddI_coeff=rp.m_dAddI_coeff;
	for (j=0;j<3;j++)
	m_uAddI_fnc[j]=rp.m_uAddI_fnc[j];
	m_bCan_shade=rp.m_bCan_shade;
	m_bCan_be_shade=rp.m_bCan_be_shade;
	m_uSubtype=rp.m_uSubtype;
	for (j=0;j<3;j++)
		m_uDir_func[j]=rp.m_uDir_func[j];
	for (j=0;j<3;j++)
		m_dDirection[j]=rp.m_dDirection[j];

	return *this;
}

///*!
// * Serializes object of the StructLoad class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void StructLoad::Serialize(CArchive& ar)
//{
//	if (ar.IsStoring())
//	{
//		ar << m_uLoadID;
//		ar << m_sTitle;
//		ar << m_uLoadtype;
//		ar << m_uColor;
//		ar << m_uLayer;
//		ar << m_uDefine_sys;
//		ar << m_uSl_funcID;
//		ar << m_dPhase;
//		ar << m_dCoefficient;
//		int j;
//		for (j=0;j<6;j++)
//			ar << m_uDof_face[j];
//		for (j=0;j<6;j++)
//			ar << m_dValue[j];
//		ar << m_dAddI_coeff;
//		for (j=0;j<3;j++)
//			ar << m_uAddI_fnc[j];
//		ar << m_bCan_shade;
//		ar << m_bCan_be_shade;
//		ar << m_uSubtype;
//		for (j=0;j<3;j++)
//			ar << m_uDir_func[j];
//		for (j=0;j<3;j++)
//			ar << m_dDirection[j];
//	}
//	else
//	{
//		ar >> m_uLoadID;
//		ar >> m_sTitle;
//
//		int nLoadType;
//		ar >> nLoadType;
//		m_uLoadtype = (TLoadType)nLoadType;
//
//		ar >> m_uColor;
//		ar >> m_uLayer;
//		ar >> m_uDefine_sys;
//		ar >> m_uSl_funcID;
//		ar >> m_dPhase;
//		ar >> m_dCoefficient;
//		int j;
//		for (j=0;j<6;j++)
//			ar >> m_uDof_face[j];
//		for (j=0;j<6;j++)
//			ar >> m_dValue[j];
//		ar >> m_dAddI_coeff;
//		for (j=0;j<3;j++)
//			ar >> m_uAddI_fnc[j];
//		ar >> m_bCan_shade;
//		ar >> m_bCan_be_shade;
//		ar >> m_uSubtype;
//		for (j=0;j<3;j++)
//			ar >> m_uDir_func[j];
//		for (j=0;j<3;j++)
//			ar >> m_dDirection[j];
//	}
//}

/*!
 * Copy constructor.
 */
NodalTemp::NodalTemp(const NodalTemp & rc)
{
	(*this)=rc;
}

/*!
 * Equalizes two objects of the NodalTemp class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
NodalTemp& NodalTemp::operator =(const NodalTemp & rp)
{
	m_uNdtempID=rp.m_uNdtempID;
	m_uColor=rp.m_uColor;
	m_uLayer=rp.m_uLayer;
	m_dNdtemp=rp.m_dNdtemp;
	m_uNdt_funcID=rp.m_uNdt_funcID;
	return *this;
}

/*!
 * Default constructor.
 */
NodalTemp::NodalTemp()
{

}

///*!
// * Serializes object of the NodalTemp class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void NodalTemp::Serialize(CArchive& ar)
//{
//	if (ar.IsStoring())
//	{
//		ar << m_uNdtempID;
//		ar << m_uColor;
//		ar << m_uLayer;
//		ar << m_dNdtemp;
//		ar << m_uNdt_funcID;
//	}
//	else
//	{
//		ar >> m_uNdtempID;
//		ar >> m_uColor;
//		ar >> m_uLayer;
//		ar >> m_dNdtemp;
//		ar >> m_uNdt_funcID;
//	}
//}

/*!
 * Equalizes two objects of the ElTemp class.
 * 
 * \param[in] rp
 * Reference to the right-hand side operand.
 * 
 * \returns
 * Reference to this object.
 */
ElTemp& ElTemp::operator =(const ElTemp & rp)
{
	m_uEltempID=rp.m_uEltempID;
	m_uColor=rp.m_uColor;
	m_uLayer=rp.m_uLayer;
	m_dEltemp=rp.m_dEltemp;
	m_uElf_funcID=rp.m_uElf_funcID;
	return *this;
}

/*!
 * Copy constructor.
 */
ElTemp::ElTemp(const ElTemp & rc)
{
	(*this)=rc;
}

/*!
 * Default constructor.
 */
ElTemp::ElTemp()
{

}

///*!
// * Serializes object of the ElTemp class.
// * 
// * \param[in,out] ar
// * Reference to the archive object.
// */
//void ElTemp::Serialize(CArchive& ar)
//{
//	if (ar.IsStoring())
//	{
//		ar << m_uEltempID;
//		ar << m_uColor;
//		ar << m_uLayer;
//		ar << m_dEltemp;
//		ar << m_uElf_funcID;
//	}
//	else
//	{
//		ar >> m_uEltempID;
//		ar >> m_uColor;
//		ar >> m_uLayer;
//		ar >> m_dEltemp;
//		ar >> m_uElf_funcID;
//	}
//}