/*
 * MappingDeal.h
 *
 *  Created on: Jul 8, 2014
 *      Author: marina
 */

#ifndef MAPPINGDEAL_H_
#define MAPPINGDEAL_H_


#include <deal.II/grid/tria.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_q.h>
#include <deal.II/dofs/dof_tools.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/function.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/lac/vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/constraint_matrix.h>
#include <deal.II/lac/compressed_sparsity_pattern.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/grid/grid_out.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <cstdlib>
#include <vector>
#include <map>


#include<FEModelData.h>
using namespace dealii;

class MappingDeal{
public:
	MappingDeal();
	virtual ~MappingDeal();
    void mappingNodes(CModelData &ModelData,   std::vector<Point<2> > &cvorovi);
	void mappingElem(CModelData &ModelData,   FESystem<2>   & fe, Triangulation<2>    &triangulation,  FEValues<2> & fe_values,DoFHandler<2>       & dof_handler);
	  std::map< int, int> mapNod;
	  std::map< int, int> mapElem;



private:


};





#endif /* MAPPINGDEAL_H_ */
