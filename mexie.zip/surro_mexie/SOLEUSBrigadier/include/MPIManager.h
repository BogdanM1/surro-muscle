/*
 * MPIManager.h
 *
 *  Created on: May 14, 2014
 *      Author: anakaplarevic
 */

#ifndef MPIMANAGER_H_
#define MPIMANAGER_H_

#include "MPIProcess.h"
#include "QPointCalculator.h"
#include "vector"

class MPIManager: public MPIProcess,public QPointCalculator{
public:
    FILE *f;
    double totalCalculateTime; // bez scatter i gather
    double totalCalculateTimeWithComm; // sa scatter i gather
	MPIManager(FEM2D* makroModel,MMChunkCalculator* mikroModelChunk);
	virtual ~MPIManager();
	void run();

    void init(int number_of_q_points, MMType* mmtypes,std::vector<double> &m_E,std::vector<double> &m_ni,std::vector<double> &m_fi,std::vector<_TIPF1> &m_f1);
    void calculate(double* e,double* sigma,double* dsigmade);
    void saveAndcontinue(int* flags);

    void defineChunks();
    void defineChunks(int cudaNum, int *cudaMPI_ID, int *cudaMaxPoints);
    void defineChunks(int cudaNum, int *cudaMPI_ID, int *cudaMaxPoints, double *cudaV, double mpiV);

    void scatterAndUpdateParameters();
    void createFileForChunk();

private:
    map<int,int> toBrigadier;
    map<int,int> toFEM;
    void createMaps(int* in,int* out,int size);
    void imageByMap(double* in,double* out,int size,map<int,int>& mapa);
};

#endif /* MPIMANAGER_H_ */
