/*
 * HuxleyState2D.cpp
 *
 *  Created on: Nov 14, 2013
 *      Author: anakaplarevic
 */

#include "HuxleyState2D.h"
#include "Globals.h"

HuxleyState2D::HuxleyState2D() {

}

HuxleyState2D::~HuxleyState2D() {
}

void HuxleyState2D::init(MaterialModelParameters* param)
{
	if(Globals::getInstance()->use_surro) return;
	/**/
    HuxleyParameters* p=static_cast<HuxleyParameters*>(param);
 //   HuxleyParameters* p=(HuxleyParameters*)param;

    long DIM = ceil((p->xmax-p->xmin)/p->step);
    DIM = DIM + p->m_leftng + p->m_rightng;

	ublas::zero_vector<_TIP> _0(DIM+1);
	ublas::vector<_TIP> _1(DIM+1, 1.0);

	N.resize(DIM+1,false);
	X.resize(DIM+1,false);
	N = _0;
	_TIP poc = p->xmin - p->m_leftng*p->step;
	for(unsigned int i = 0; i <= DIM; i++) {
		X(i) = poc + p->step * i;
	}

	e_t.resize(3,false);
	//e_t(0)=0;
	e_t(0)=1;
	e_t(1)=0;
	e_t(2)=0;
	v_t=0;

	for(int i=0;i<2;i++) direction[0]=(p->direction==i?1:0);
/*	histogram.resize(Globals::nbins);
	for(int i=0; i<10; i++) histogram[i] = 0;
	histogram[5] = 5;
	histogram[6] = 10;
	histogram[7] = 16;
	histogram[8] = 17;
	histogram[9] = 26;*/
}

void HuxleyState2D::init(MaterialModelState* state)
{
	if(Globals::getInstance()->use_surro) return;	
	/**/
	HuxleyState2D* s = (HuxleyState2D*) state;
	N.resize(s->N.size(),false);
	X.resize(s->N.size(),false);
	e_t.resize(3,false);
	X = s->X;
	N = s->N;
	e_t=s->e_t;
	v_t=s->v_t;
	
	histogram.resize(Globals::nbins);
	histogram = s->histogram;
	/**/
}

bool HuxleyState2D::equal(MaterialModelState* state)
{
	HuxleyState2D* s = (HuxleyState2D*) state;
//	unsigned int no = (unsigned int)s->N.size();
//	for(unsigned int i=0;i<no;i++) if (N(i) != s->N(i)) return false;
//	for(unsigned int i=0;i<no;i++) if (X(i) != s->X(i)) return false;
    int nhist = histogram.size();
	for(int i=0; i< nhist; i++) if(histogram(i) != s->histogram(i)) return false; 
	return true;
}

