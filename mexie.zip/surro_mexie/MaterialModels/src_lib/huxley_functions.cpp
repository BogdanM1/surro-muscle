#include "huxley_functions.h"
#include "histogram.h"

// F(X) = (1-n(X))*f(X) - n(x)*g(X))

void fun_F(ublas::vector<_TIP> &N, ublas::vector<_TIP> &X, const HuxleyParameters &param,ublas::vector<_TIP> &FX, _TIP O)
{
	int size = X.size();
	_TIP f1 = param.m_f1;
	_TIP g1 = param.m_g1;
	_TIP g2 = param.m_g2;
	_TIP h = param.m_h;
	_TIP Zahalak = param.m_Zahalak;
	_TIP fx, gx;
	_TIP FPOM;
	Globals* g = Globals::getInstance();
	for(int i = 0; i < size; i++)
	{
/*			if(X(i) >= 0)
			{
				if(X(i) <= h)  fx = f1 * X(i) / h;
						else fx = 0.0;
				gx = g1 * X(i) / h;
			}
			else 
			{
				fx = 0.0;
				gx = g2;
			}
		//	FX(i) = fx * (1.0 - N(i)) - gx * N(i);
*/
		
		fx=0.0 + (0<=X(i)) * (X(i)<=h) * f1 * X(i) /  h;
		gx = (0<=X(i))* (X(i)<=h)*g1*X(i)/ h + (0>X(i))*g2 + (X(i)>h)*Zahalak*g1*X(i)/ h;
		//gx = (0<=X(i))* (X(i)<=h)*g1*X(i)/ h + (0>X(i))*g2 + (X(i)>h) *(X(i)<20)*Zahalak*g1*X(i)/ h + (X(i)>=20) *2*Zahalak*g1*X(i)/ h;
		//FX(i) = fx * (1.0 - N(i)) - gx * N(i);
		FX(i) = (O >= N(i) ? fx:0) * (O - N(i)) - gx * N(i);
				//printf("%d -- %lf %lf %lf %lf %lf \n", i, X(i), N(i), fx, gx, FX(i));	
	}
}

// Calculating stiffness
_TIP fun_Stiffness(ublas::vector<_TIP> &X, ublas::vector<_TIP> &N, _TIP Kxb)
{
	long vectorSize = X.size();
	_TIP delta_x = X(1) - X(0);
	_TIP stiffness = 0.0;
	for(int i = 1; i < vectorSize; i++)
	{
		stiffness += (0.5*(N(i-1) + N(i))*delta_x);
	}
	return Kxb * stiffness;
}

/*// ANA: Calculating force
_TIP fun_Force(ublas::vector<_TIP> &X, ublas::vector<_TIP> &N, _TIP Kxb)
{
	long vectorSize = X.size();
	_TIP delta_x = X(1) - X(0);
	_TIP force = 0.0;
	for(int i = 1; i < vectorSize; i++)
	{
		force += (0.25*(N(i-1) + N(i))*(X(i-1) + X(i))*delta_x);
	}
	return Kxb * force;
}*/

//Djordje: Calculating force
_TIP fun_Force(ublas::vector<_TIP> &X, ublas::vector<_TIP> &N, _TIP Kxb)
{
int vectorSize = X.size();
_TIP delta_x = X(1) - X(0);
_TIP force = 0.0;
for(int i = 1; i < vectorSize; i++)
{
 force += (0.5*(N(i-1)*X(i-1) + N(i)*X(i))*delta_x);
}

return Kxb * force;
}
