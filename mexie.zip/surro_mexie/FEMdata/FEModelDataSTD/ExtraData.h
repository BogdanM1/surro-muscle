/*!
 * \file ExtraData.h
 * Interface for the CExtraData class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// ExtraData.h: interface for the CExtraData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ExtraDATA_H__B2AB5333_A6CE_4F66_8092_534BAAF0A835__INCLUDED_)
#define AFX_ExtraDATA_H__B2AB5333_A6CE_4F66_8092_534BAAF0A835__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CExtraData //: public CObject  
{
public:
	CExtraData();
	virtual ~CExtraData();

	virtual CExtraData& operator=(CExtraData &other) = 0;

};

#endif // !defined(AFX_ExtraDATA_H__B2AB5333_A6CE_4F66_8092_534BAAF0A835__INCLUDED_)
