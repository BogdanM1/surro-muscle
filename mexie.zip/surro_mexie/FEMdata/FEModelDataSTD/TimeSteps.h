/*!
 * \file TimeSteps.h
 * Interface for the CTimeSteps class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// TimeStep.h: interface for the CTimeStep class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMESTEPS_H__C67DDE3D_C21B_4413_8F1A_ECB6EDD7CA48__INCLUDED_)
#define AFX_TIMESTEPS_H__C67DDE3D_C21B_4413_8F1A_ECB6EDD7CA48__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyArray.h"
#include "Stdafx.h"

/** Class containing data about time steps. */
class CTimeSteps ////: public CObject  
{
public:
	struct TimePeriod
	{
		UINT nSteps;
		double dStepDuration;
	};

	CTimeSteps();
	virtual ~CTimeSteps();
	CTimeSteps(const CTimeSteps &other)
	{
		*this = other;
	}

	CTimeSteps& operator=(const CTimeSteps& other);
	//void Serialize(CArchive& ar);

	inline void AddTimePeriod(UINT nSteps, double dStepDuration)
	{
		TimePeriod Period;
		Period.nSteps = nSteps;
		Period.dStepDuration = dStepDuration;

		m_TimePeriods.Add(Period);
	}
	inline TimePeriod& GetTimePeriod(UINT nIndex)
	{
		return( m_TimePeriods.ElementAt( nIndex ) );
	}
	inline void RemoveTimePeriod(UINT nIndex)
	{
		m_TimePeriods.RemoveAt( nIndex );
	}
	inline void InsertTimePeriod(UINT nSteps, double dStepDuration, UINT nIndex)
	{
		TimePeriod Period;
		Period.nSteps = nSteps;
		Period.dStepDuration = dStepDuration;
		
		m_TimePeriods.InsertAt(nIndex, Period);
	}
	inline UINT GetTimePeriodsCount()
	{
		return(m_TimePeriods.GetSize());
	}

	UINT GetTotalStepCount()
	{
		UINT nStepCount = 0;
		for(UINT i = 0; i < GetTimePeriodsCount(); i++)
			nStepCount += GetTimePeriod(i).nSteps;

		return(nStepCount);
	}

	inline double GetTimeForTimeStep(UINT nStep)
	{
		UINT nStepCount = 0;
		UINT nStepCountPrevious;
		double dTime = 0.0;
		for(UINT i = 0; i < GetTimePeriodsCount(); i++)
		{
			CTimeSteps::TimePeriod &TimePeriod = GetTimePeriod(i);
			nStepCountPrevious = nStepCount;
			nStepCount += TimePeriod.nSteps;
			
			if(nStep < nStepCount)
			{
				dTime += (nStep - nStepCountPrevious) * TimePeriod.dStepDuration;
				break;
			}
			dTime += TimePeriod.nSteps * TimePeriod.dStepDuration;
		}
		
		return(dTime);
	}

	UINT Init()
	{
		return 0;
	}

	void DeleteContents()
	{
		m_TimePeriods.RemoveAll();
	}



private:

	/// Collection of time periods
	MyArray<TimePeriod, TimePeriod&> m_TimePeriods;
};

#endif // !defined(AFX_TIMESTEPS_H__C67DDE3D_C21B_4413_8F1A_ECB6EDD7CA48__INCLUDED_)
