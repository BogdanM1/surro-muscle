#include "MaterialModelState.h"

MaterialModelState::MaterialModelState(){

}
MaterialModelState::~MaterialModelState(){

}

