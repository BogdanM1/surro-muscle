import sys

if __name__ == "__main__":
    lines = [line.lstrip(' ') for line in open('freenodes.txt')]
    
    np = 16
    index = 0
    curr_cn = None
    final = 'nodes='

    while index < len(lines):
        if lines[index].startswith('cn', 0, 2):
            if (curr_cn != None) and (curr_ppn != 0):
                final += curr_cn + ':ppn=' + str(curr_ppn) + '+'
                
            curr_cn = lines[index].strip()
            curr_ppn = np
        else:
            if lines[index].startswith('jobs = '):
                job_line = lines[index].lstrip('jobs = ')
                curr_ppn = np - len(job_line.split(','))

        index += 1
    final = final.rstrip('+')
    sys.stdout.write(final)      
                 
               
