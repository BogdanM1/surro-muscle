/* 
 *  Scheduler.cpp
 *  13.07.2015. Ana
 * 
 *
 */

#include <Scheduler.h>

using namespace std;

struct sort_predS sorterSpec;

Scheduler::Scheduler(int n, int k){
    num_jobs = n;
    num_proc = k;
    pomInt=(int*)malloc(num_jobs*sizeof(int));
    pomDouble=(double*)malloc(num_jobs*sizeof(double));
}

Scheduler::~Scheduler(){
}

void Scheduler::createTestSchedule() {
    for(int i=0;i<num_jobs;i++) {
        std::pair<int,int> *p;
        p = new std::pair<int,int>(i,i%num_proc);
        mapToProcess.push_back(*p);
	}
    sort(mapToProcess.begin(), mapToProcess.end(), sorterSpec);
}

/**
 * Za zadate brzine i kapacitete odredjuje raspored poslova po procesima
 * broj poslova i broj ucestvujucih poslova se smatraju vec postavljenim
 * u num_jobs i num_proc radi isto sto i
 * void MPIManager::defineChunks(int cudaNum, int *cudaMPI_ID, int *cudaMaxPoints, double *cudaV, double mpiV)
 * @brief Definise raspored poslova, pri cemu se smatra da su svi poslovi jednake slozenosti.
 * @param V
 * @param max
 */
void Scheduler::createBasicSchedule(double* V, int* max) {
    int B = num_jobs,p = num_proc,pom,i;
    double Vsum,Ti;

//  ODREDI Tidealno - vreme obrade svih zadataka kao broj_poslova/suma_brzina
    int* podela;
    podela=(int*)calloc(num_proc,sizeof(int));
    bool nasao=false;
        while (!nasao){
            for(Vsum=0,i=0;i<p;Vsum+=V[i],i++);
            Ti=B/Vsum;
            for(i=0;i<p;i++) podela[i]=trunc(V[i]*Ti);
            nasao=true;
            for(i=0;i<p;i++) {
                nasao=nasao?(podela[i]<=max[i]):nasao;
                if (podela[i]>max[i]) {
                    V[i]=max[i]*1.0/Ti;
                    podela[i]=max[i];
                }
            }
        }
    for(i=0;i<p;i++) printf("sch - podela[%d] = %d   V = %f\n",i,podela[i],V[i]);

//  RASPOREDI nerasporedjene B-Sum(Ni)
    while(B>0)
    {
    B=num_jobs;
    for(Vsum=0,i=0;i<p;Vsum+=V[i],i++);
    Ti=B/Vsum;
    for(i=0;i<p;i++) B=B-podela[i];
    for(i=0;(i<p)&&(B>0);i++)
    {
         if (podela[i]>=max[i]) continue;
          // pom = round((Ti-podela[i]/V[i])*V[i]);
            pom = ceil(Ti*V[i])-podela[i];//V[i])*V[i]);
            pom = (pom==0)?1:pom;
            pom = ((max[i]-podela[i])>=pom)?pom:(max[i]-podela[i]);
            printf("i = %d\t pom = %d\n",i,pom);
            podela[i]=podela[i]+(((B-pom)>=0)?pom:(B-pom));
            B=B-(((B-pom)>=0)?pom:(B-pom));
            printf("i = %d\t B = %d\n",i,B);
        }
        if (B!=0) printf("sch - Ima nerasporedenjenih. Ukupno %d, Nerasporedjeno %d \n",num_jobs,B);
        for(i=0;i<p;i++) printf("sch - podela[%d] = %d   V = %f\n",i,podela[i],V[i]);
    }
//  UPISI u mapToProcess
    mapToProcess.clear();
    int tek=0;
    for(int i=0;i<num_proc;i++){
        for(int j=0;j<podela[i];j++) {
            std::pair<int,int> *p;
            p = new std::pair<int,int>(tek,i);
            mapToProcess.push_back(*p);
            tek++;
        }
    }
    printf("sch -- provera 1 tek=%d\n",tek);
// nepotrebno sortirati, jer vec jeste sortirano
   sort(mapToProcess.begin(), mapToProcess.end(), sorterSpec);
   printf("sch -- provera 2\n");
}
/**
 * @brief Popunjava niz u argumentu brojem dodeljenih poslova procesima.
 * Niz[i] - broj poslova dodeljenijh i-tom procesu.
 * @param niz
 */
void Scheduler::getSizeOfPartitions(int* niz) {
    printf("sch -- provera 3\n");
    for(int i=0;i<num_proc;i++) niz[i]=0;
    printf("sch -- provera 4\n");
    for(int i=0;i<num_jobs;i++) {
     //    printf("mapToProcess.at(%d).second=%d\n",i,mapToProcess.at(i).second);
        niz[mapToProcess.at(i).second]++;
    }
    printf("sch -- provera 5\n");
}

void Scheduler::createBasicSchedule(double* w,double* v, int* m) {
}

void Scheduler::orderForExecution(int* niz){
    for(int i=0;i<10;i++) pomInt[i]=niz[mapToProcess.at(i).first];
    for(int i=0;i<10;i++) niz[i]=pomInt[i];
}

void Scheduler::orderForExecution(double* niz){
    for(int i=0;i<10;i++) pomDouble[i]=niz[mapToProcess.at(i).first];
    for(int i=0;i<10;i++) niz[i]=pomDouble[i];
}

void Scheduler::orderAsOriginal(int* niz){
    for(int i=0;i<10;i++) pomInt[mapToProcess.at(i).first]=niz[i];
    for(int i=0;i<10;i++) niz[i]=pomInt[i];
}

void Scheduler::orderAsOriginal(double* niz) {
    for(int i=0;i<10;i++) pomDouble[mapToProcess.at(i).first]=niz[i];
    for(int i=0;i<10;i++) niz[i]=pomDouble[i];
}
