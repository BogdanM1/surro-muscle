/*!
 * \file EffectiveValueCalculator.h
 * Interface for the CEffectiveValueCalculator class.
 * 
 * \author Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// EffectiveValueCalculator.h: interface for the CEffectiveValueCalculator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EFFECTIVEVALUECALCULATOR_H__40A0A318_52EB_4CF7_8837_6462FD0F2798__INCLUDED_)
#define AFX_EFFECTIVEVALUECALCULATOR_H__40A0A318_52EB_4CF7_8837_6462FD0F2798__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Stdafx.h"

#include <math.h>

class CEffectiveValueCalculator  
{
public:
	CEffectiveValueCalculator() {};
	virtual ~CEffectiveValueCalculator() {};

	/*!
	 * Calculates effective value.
	 * 
	 * \param[in] dCompValues
	 * 3-element array of component values.
	 * 
	 * \returns
	 * Effective value.
	 */
	virtual double Calculate(double dCompValues[]) const = 0;


};

#endif // !defined(AFX_EFFECTIVEVALUECALCULATOR_H__40A0A318_52EB_4CF7_8837_6462FD0F2798__INCLUDED_)
