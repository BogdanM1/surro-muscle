/*!
 * \file HDataBlock.h
 * Interface for the HDataBlock class.
 * 
 * \author Nemanja Trifunovic, Nikola Milivojevic, Boban Stojanovic.
 * Copyright (c) 2006 by Center SASA and University of Kragujevac
 */

// HDataBlock.h: interface for the HDataBlock class.
//
//////////////////////////////////////////////////////////////////////
#include "Stdafx.h"

#if !defined(AFX_HDATABLOCK_H__C9812550_60EF_11D2_9943_8BCA2B38BBFE__INCLUDED_)
#define AFX_HDATABLOCK_H__C9812550_60EF_11D2_9943_8BCA2B38BBFE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CExtraData;

/** Abstract class representing FEMAP data block. */
class HDataBlock ////: public CObject  
{
public:
	void AttachExtraData(CExtraData &ExtraData);
	void DetachExtraData();
	HDataBlock& operator = (const HDataBlock& rp);

	////DECLARE_SERIAL(HDataBlock)
	//virtual void Serialize( CArchive& ar );

	/// ID of the data block
	UINT m_uDataBlockID;

	/// Pointer to extra data
	CExtraData* m_pExtraData;

protected:
	HDataBlock();
	virtual ~HDataBlock();

};

#endif // !defined(AFX_HDATABLOCK_H__C9812550_60EF_11D2_9943_8BCA2B38BBFE__INCLUDED_)
