/*
 * HuxleyParameters.h
 *
 *  Created on: Jul 24, 2013
 *      Author: anakaplarevic
 */

#ifndef LIBCONFIG_H
#define LIBCONFIG_H

#include <libconfig.h>

#endif /* LIBCONFIG_H */

#ifndef HUXLEYPARAMETERS_H_
#define HUXLEYPARAMETERS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "MaterialModelParameters.h"
#include "TimeFunction.h"

using namespace std;

//#include <string>


class HuxleyParameters:public MaterialModelParameters {
private:
	string strFileIn;
	string strFileOut;

public:
	HuxleyParameters();
	HuxleyParameters(string inS);
	virtual ~HuxleyParameters();

	void InputData();
	void CheckInputData();

// NUMERICKI parametri OPSTI
	_TIP pertubacija;
	double _E;
	double _ni;
	double _fi;
	int direction;
// Stress-Stretch function
    double x[6];
    double y[6];
    TimeFunction stressStretchFunction;

// FIZICKI parametri

	_TIP m_h;			// Distribution length
	_TIP m_f1;		// Rate of attachments
	_TIP m_g1;		// Slow rate of detachments
	_TIP m_g2;		// Fast rate of detachments

	_TIP m_Kxb;		// Cross-bridge stiffness
	_TIP m_Zahalak;		// Zahalak faktor


	_TIP L0;			// half sarcomere length
	_TIP A;			// povrsina poprecnog preseka sarkomere

// NUMERICKI parametri specificni za Huxley-a

	_TIP m_dt;		// Time step
	int m_ng;			// gustina mreze od 0 do h
	int m_leftng;		// broj tacaka levo od 0
	int m_rightng;		// broj tacaka desno od h
	int maxIter;		// maksimalan broj iteracija
	_TIP EpsXerr;		// uslov konvergencija za X
	_TIP EpsNerr;		// uslov konvergencija za N

//  deprecated
	_TIP xmin;		// -step*m_leftng
	_TIP xmax;		//	h + step*m_rightng
	_TIP step;		// 	step = m_h / m_ng

};

#endif /* HUXLEYPARAMETERS_H_ */
