#!/bin/bash

cd MaterialModels/build
#rm -r CMakeFiles CMakeCache.txt
#cmake ..
make -j 4

cd ../../FEMdata/build
#rm -r CMakeFiles CMakeCache.txt
#cmake ..
make -j 4

cd ../../SOLEUSBrigadier/build
#rm -r CMakeFiles CMakeCache.txt
#cmake .. -DhaveCUDA:STRING=NO
make -j 4

cd ../../FEMSolver/build
#rm -r CMakeFiles CMakeCache.txt
#cmake .. -DhaveCUDA:STRING=NO
make -j 4
